package tv.own.owntv.core.timeshift

import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.async
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.File
import java.nio.file.Files
import java.util.concurrent.atomic.AtomicBoolean

class LocalTimeshiftServerTest {
    @Test fun byteRangesAreBounded() {
        assertEquals(0L to 99L, LocalTimeshiftServer.byteRange(null, 100))
        assertEquals(20L to 99L, LocalTimeshiftServer.byteRange("bytes=20-", 100))
        assertEquals(95L to 99L, LocalTimeshiftServer.byteRange("bytes=-5", 100))
        assertEquals(0L to 99L, LocalTimeshiftServer.byteRange("bytes=0-1000", 100))
        listOf("bytes=100-", "bytes=2-1", "bytes=0-1,3-4", "bytes=-0", "wrong").forEach {
            assertNull(LocalTimeshiftServer.byteRange(it, 100))
        }
    }
    @Test fun invalidSegmentNeverMakesTheSessionReady() = runBlocking {
        val source = LocalSegmentStore(Files.createTempDirectory("timeshift-invalid").toFile())
        repeat(3) { index ->
            val part = File(source.directory, "incoming.part")
            val bytes = ByteArray(188)
            if (index < 2) bytes[0] = 0x47
            part.writeBytes(bytes); source.commit(part, 5_000, false)
        }
        val upstream = LocalTimeshiftServer(source)
        val destination = Files.createTempDirectory("timeshift-invalid-target").toFile()
        val session = LocalTimeshiftSession(destination, OkHttpClient(), upstream.url, emptyMap(), reserveBytes = 0)
        try {
            try { session.awaitReady(); fail() } catch (_: IllegalStateException) { }
            assertEquals(LocalTimeshiftSession.Status.FAILED, session.status.value)
            assertEquals(10_000L, session.retainedDurationMs())
        } finally { session.close(); upstream.closeAndAwait(); source.close() }
        assertFalse(destination.exists())
    }

    @Test fun cancellationClosesBlockedUpstreamReadBeforeReturning() = runBlocking {
        val server = java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
        val responseStarted = kotlinx.coroutines.CompletableDeferred<Unit>()
        val peer = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).async {
            server.accept().use { socket ->
                socket.soTimeout = 5000
                val input = socket.getInputStream().bufferedReader()
                while (!input.readLine().isNullOrEmpty()) { }
                socket.getOutputStream().apply {
                    write("HTTP/1.1 200 OK\r\nContent-Length: 10000\r\n\r\n#EXTM3U\n".toByteArray()); flush()
                }
                responseStarted.complete(Unit)
                assertEquals(-1, socket.getInputStream().read())
            }
        }
        val destination = Files.createTempDirectory("timeshift-cancel").toFile()
        val session = LocalTimeshiftSession(destination, OkHttpClient(), "http://127.0.0.1:${server.localPort}/index.m3u8", emptyMap(), reserveBytes = 0)
        try {
            kotlinx.coroutines.withTimeout(5000) { responseStarted.await() }
            kotlinx.coroutines.withTimeout(5000) { session.close(); peer.await() }
            assertEquals(LocalTimeshiftSession.Status.CLOSED, session.status.value)
            assertFalse(destination.exists())
        } finally { session.close(); server.close(); peer.cancel() }
    }

    @Test fun producerServesCompleteLocalSegmentsAndCloses() = runBlocking {
        val source = LocalSegmentStore(Files.createTempDirectory("timeshift-source").toFile())
        repeat(3) {
            val part = File(source.directory, "incoming.part")
            val bytes = ByteArray(564)
            bytes[0] = 0x47; bytes[188] = 0x47; bytes[376] = 0x47
            part.writeBytes(bytes)
            source.commit(part, 5_000, false)
        }
        val upstream = LocalTimeshiftServer(source)
        val client = OkHttpClient()
        val destination = Files.createTempDirectory("timeshift-target").toFile()
        val session = LocalTimeshiftSession(destination, client, upstream.url, emptyMap(), reserveBytes = 0)
        try {
            session.awaitReady()
            assertEquals(15_000L, session.retainedDurationMs())
            assertEquals(1692L, session.bytesOnDisk())
            fun fetch(url: String) = client.newCall(Request.Builder().url(url).build()).execute()
            fetch(session.url).use { response ->
                assertEquals(200, response.code)
                val manifest = response.body.string()
                assertTrue(manifest.contains("2.ts"))
                assertFalse(manifest.contains(upstream.url))
            }
            val segmentUrl = session.url.replace("index.m3u8", "0.ts")
            client.newCall(Request.Builder().url(segmentUrl).header("Range", "bytes=188-375").build()).execute().use {
                assertEquals(206, it.code)
                assertEquals(188, it.body.bytes().size)
            }
            fetch(session.url.replace("index.m3u8", "../incoming.part")).use { assertEquals(404, it.code) }
            fetch(session.url.replace("index.m3u8", "999.ts")).use { assertEquals(404, it.code) }
        } finally {
            session.close()
            upstream.closeAndAwait(); source.close()
            client.dispatcher.executorService.shutdown(); client.connectionPool.evictAll()
        }
        assertFalse(destination.exists())
        assertEquals(LocalTimeshiftSession.Status.CLOSED, session.status.value)
    }

    @Test fun nonSeekableStreamServesFullGetRangeAndHeadCorrectly() = runBlocking {
        val payload = ByteArray(1000) { it.toByte() }
        val closed = AtomicBoolean(false)
        val server = LocalTimeshiftServer(
            playlist = { "#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6.0,\n0.ts\n#EXT-X-ENDLIST\n" },
            open = { id ->
                if (id != 0L) null else {
                    val stream = ByteArrayInputStream(payload)
                    LocalSegmentStore.Reader(stream, payload.size.toLong(), "video/mp2t") {
                        closed.set(true)
                    }
                }
            }
        )
        val client = OkHttpClient()
        try {
            val segmentUrl = server.url.replace("index.m3u8", "0.ts")
            // 1. GET full segment without Range
            client.newCall(Request.Builder().url(segmentUrl).build()).execute().use { response ->
                assertEquals(200, response.code)
                assertArrayEquals(payload, response.body.bytes())
            }

            // 2. GET partial segment with Range (skip first 100 bytes, read 200 bytes)
            client.newCall(Request.Builder().url(segmentUrl).header("Range", "bytes=100-299").build()).execute().use { response ->
                assertEquals(206, response.code)
                val body = response.body.bytes()
                assertEquals(200, body.size)
                assertArrayEquals(payload.copyOfRange(100, 300), body)
            }

            // 3. HEAD request
            client.newCall(Request.Builder().url(segmentUrl).head().build()).execute().use { response ->
                assertEquals(200, response.code)
                assertEquals("1000", response.header("Content-Length"))
                assertEquals(0, response.body.bytes().size)
            }

            // 4. Out of bounds range returns 416
            client.newCall(Request.Builder().url(segmentUrl).header("Range", "bytes=2000-3000").build()).execute().use { response ->
                assertEquals(416, response.code)
            }
        } finally {
            server.closeAndAwait()
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        }
        assertTrue(closed.get())
    }

    @Test fun initMp4AndZeroByteStreamAreServedCorrectly() = runBlocking {
        val initPayload = byteArrayOf(1, 2, 3, 4)
        val server = LocalTimeshiftServer(
            playlist = { "#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-MAP:URI=\"-1.mp4\"\n#EXT-X-ENDLIST\n" },
            open = { id ->
                when (id) {
                    -1L -> LocalSegmentStore.Reader(ByteArrayInputStream(initPayload), initPayload.size.toLong(), "video/mp4") { }
                    0L -> LocalSegmentStore.Reader(ByteArrayInputStream(ByteArray(0)), 0L, "video/mp4") { }
                    else -> null
                }
            }
        )
        val client = OkHttpClient()
        try {
            // 1. init.mp4 served via id = -1
            val initUrl = server.url.replace("index.m3u8", "init.mp4")
            client.newCall(Request.Builder().url(initUrl).build()).execute().use { response ->
                assertEquals(200, response.code)
                assertArrayEquals(initPayload, response.body.bytes())
            }

            // 2. -1.mp4 also maps to id = -1
            val dashInitUrl = server.url.replace("index.m3u8", "-1.mp4")
            client.newCall(Request.Builder().url(dashInitUrl).build()).execute().use { response ->
                assertEquals(200, response.code)
                assertArrayEquals(initPayload, response.body.bytes())
            }

            // 3. Zero-byte full GET returns 200 OK with empty body
            val zeroUrl = server.url.replace("index.m3u8", "0.mp4")
            client.newCall(Request.Builder().url(zeroUrl).build()).execute().use { response ->
                assertEquals(200, response.code)
                assertEquals(0, response.body.bytes().size)
            }
        } finally {
            server.closeAndAwait()
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        }
    }

    @Test fun skipFullyHandlesThrowingSkipGracefully() {
        val payload = ByteArray(200) { it.toByte() }
        val stream = object : java.io.InputStream() {
            private var pos = 0
            override fun read(): Int = if (pos < payload.size) payload[pos++].toInt() and 0xFF else -1
            override fun read(b: ByteArray, off: Int, len: Int): Int {
                if (pos >= payload.size) return -1
                val count = minOf(len, payload.size - pos)
                System.arraycopy(payload, pos, b, off, count)
                pos += count
                return count
            }
            override fun skip(n: Long): Long {
                throw java.io.IOException("ESPIPE: Illegal seek")
            }
        }
        assertTrue(LocalTimeshiftServer.skipFully(stream, 50))
        val remaining = stream.readBytes()
        assertEquals(150, remaining.size)
        assertArrayEquals(payload.copyOfRange(50, 200), remaining)
    }
    @Test fun preparingManifestReturnsTypedHttpForGetAndHeadThenReadyOrTerminal() = runBlocking {
        val store = LocalSegmentStore(Files.createTempDirectory("local-preparing").toFile())
        val server = LocalTimeshiftServer(store)
        val client = OkHttpClient()
        try {
            for (method in listOf("GET", "HEAD")) {
                client.newCall(Request.Builder().url(server.url).method(method, null).build()).execute().use {
                    assertEquals(503, it.code)
                    assertEquals("preparing", it.header("X-OwnTV-Local-State"))
                    assertEquals("1", it.header("Retry-After"))
                    assertEquals("0", it.header("Content-Length"))
                    assertEquals("", it.body?.string())
                }
            }
            val part = File(store.directory, "incoming.part")
            part.writeBytes(ByteArray(564).also { it[0] = 0x47; it[188] = 0x47; it[376] = 0x47 })
            store.commit(part, 5000, false)
            client.newCall(Request.Builder().url(server.url).build()).execute().use {
                assertEquals(200, it.code); assertTrue(it.body!!.string().startsWith("#EXTM3U"))
            }
        } finally { server.closeAndAwait(); store.close(); client.connectionPool.evictAll() }
        val empty = LocalSegmentStore(Files.createTempDirectory("local-ended").toFile()).also { it.finish() }
        val terminal = LocalTimeshiftServer(empty)
        try {
            client.newCall(Request.Builder().url(terminal.url).build()).execute().use {
                assertEquals(410, it.code); assertNull(it.header("Retry-After"))
            }
        } finally { terminal.closeAndAwait(); empty.close() }
    }

}
