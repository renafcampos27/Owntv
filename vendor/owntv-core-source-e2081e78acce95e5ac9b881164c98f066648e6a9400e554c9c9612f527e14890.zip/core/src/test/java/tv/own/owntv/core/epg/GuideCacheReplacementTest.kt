package tv.own.owntv.core.epg

import java.io.IOException
import java.nio.file.Files
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.database.entity.computeContentHash

class GuideCacheReplacementTest {
    private fun row(source: Long, channel: String = "c", start: Long = 1) =
        EpgProgrammeEntity(sourceId = source, epgChannelId = channel, startMs = start, stopMs = start + 1, title = "News")

    private fun scenario(parse: suspend (suspend (EpgProgrammeEntity) -> Unit) -> Unit, failInsert: Boolean = false): List<EpgProgrammeEntity> = runBlocking {
        val directory = Files.createTempDirectory("guide-test").toFile()
        val original = listOf(row(1), row(2), row(1, "unrequested"))
        val stored = original.toMutableList()
        try {
            try {
                replaceGuideCache(1, directory, parse,
                    transaction = { block ->
                        val before = stored.toList()
                        try { block() } catch (failed: Throwable) { stored.clear(); stored.addAll(before); throw failed }
                    },
                    clear = { key, source -> stored.removeAll { it.sourceId == source && it.epgChannelId == key } },
                    insert = { if (failInsert) throw IOException("insert failed"); stored.addAll(it) })
            } catch (_: IOException) { assertEquals(original, stored) }
            catch (_: CancellationException) { assertEquals(original, stored) }
            assertTrue(directory.listFiles().orEmpty().isEmpty())
            stored.toList()
        } finally { directory.delete() }
    }

    @Test fun incompleteParseDoesNotClearExistingData() {
        val result = scenario({ emit -> emit(row(1, start = 10)); throw IOException("truncated") })
        assertEquals(1L, result.first().startMs)
    }
    @Test fun cancellationDoesNotPublishPartialData() {
        scenario({ emit -> emit(row(1, start = 10)); throw CancellationException() })
    }
    @Test fun failedInsertRollsBackReplacement() {
        scenario({ emit -> emit(row(1, start = 10)) }, failInsert = true)
    }
    @Test fun replacementPreservesOtherSourcesAndUnrequestedChannels() {
        val result = scenario({ emit -> emit(row(1, start = 10)) })
        assertTrue(result.contains(row(2)))
        assertTrue(result.contains(row(1, "unrequested")))
        val replacement = row(1, start = 10)
        assertTrue(result.contains(replacement.copy(contentHash = replacement.computeContentHash())))
        assertFalse(result.contains(row(1)))
    }
    @Test fun emptyResponseDoesNotDeleteExistingGuide() {
        assertEquals(3, scenario({ _ -> }).size)
    }
    @Test fun restoredCacheHashMatchesNormalIngestionAndIgnoresStaleStoredHash() = runBlocking {
        val directory = Files.createTempDirectory("guide-hash-test").toFile()
        val original = row(1).copy(description = "Programme details", contentHash = -1)
        try {
            var restored: EpgProgrammeEntity? = null
            replaceGuideCache(1, directory, { emit -> emit(original) }, transaction = { it() },
                clear = { _, _ -> }, insert = { restored = it.single() })
            val result = requireNotNull(restored)
            assertEquals(original.computeContentHash(), result.contentHash)
            assertEquals(original.title, result.title)
            assertEquals(original.description, result.description)
        } finally { directory.delete() }
    }
    @Test fun largeReplacementUsesBoundedInsertBatches() = runBlocking {
        val directory = Files.createTempDirectory("guide-test").toFile()
        val batches = mutableListOf<Int>()
        try {
            replaceGuideCache(1, directory, { emit -> repeat(1101) { emit(row(1, start = it + 1L)) } },
                transaction = { it() }, clear = { _, _ -> }, insert = { batches += it.size })
            assertEquals(listOf(500, 500, 101), batches)
            assertTrue(directory.listFiles().orEmpty().isEmpty())
        } finally { directory.delete() }
    }
}
