package tv.own.owntv.core.timeshift

import org.junit.Assert.*
import org.junit.Test

class LocalTimeshiftBookmarkTest {
    private val bookmark = LocalTimeshiftBookmark(1, 2, 3, 15_000, 100)
    @Test fun retainedPositionIsRelativeToRemainingCopy() {
        assertEquals(5_000L, bookmark.positionInCopy(1, 2, 3, 10_000, 20_000, 200))
    }
    @Test fun evictedPositionCannotResumeAtADifferentProgramme() {
        assertNull(bookmark.positionInCopy(1, 2, 3, 16_000, 20_000, 200))
    }
    @Test fun profileSourceAndChannelMustMatch() {
        assertNull(bookmark.positionInCopy(4, 2, 3, 0, 20_000, 200))
        assertNull(bookmark.positionInCopy(1, 4, 3, 0, 20_000, 200))
        assertNull(bookmark.positionInCopy(1, 2, 4, 0, 20_000, 200))
    }
    @Test fun expiredAndFutureBookmarksAreRejected() {
        assertNull(bookmark.positionInCopy(1, 2, 3, 0, 20_000, 100 + LocalTimeshiftBookmark.EXPIRATION_MS))
        assertNull(bookmark.positionInCopy(1, 2, 3, 0, 20_000, 99))
    }
    @Test fun endOfCopyDoesNotOfferAnImmediateDeadEnd() {
        assertNull(bookmark.positionInCopy(1, 2, 3, 0, 18_000, 200))
        assertNull(bookmark.positionInCopy(1, 2, 3, 0, 3_000, 200))
    }
}
