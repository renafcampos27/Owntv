package tv.own.owntv.core.sync.work

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.live.WatchSession

class EpgRefreshDeferralTest {
    @Test fun `busy playback is deferred but cannot starve refresh forever`() {
        assertTrue(EpgRefreshDeferral.retry(0)); assertTrue(EpgRefreshDeferral.retry(2))
        assertFalse(EpgRefreshDeferral.retry(3)); assertFalse(EpgRefreshDeferral.retry(40))
    }
    @Test fun `wait distinguishes playback timeout from a genuine idle session`() = runBlocking {
        val watch = WatchSession()
        assertTrue(watch.awaitIdleWithin(100))
        watch.open(1)
        assertFalse(watch.awaitIdleWithin(10))
        val waiter = async(start = CoroutineStart.UNDISPATCHED) { watch.awaitIdleWithin(1000) }
        watch.close(1)
        assertTrue(waiter.await())
    }
}
