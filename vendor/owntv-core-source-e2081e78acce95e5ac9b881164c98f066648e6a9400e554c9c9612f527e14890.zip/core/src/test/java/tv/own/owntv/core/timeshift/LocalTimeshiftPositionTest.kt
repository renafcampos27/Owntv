package tv.own.owntv.core.timeshift

import java.io.File
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Test

class LocalTimeshiftPositionTest {
    @Test fun actualPlaylistSequenceDeterminesBookmarkAndEvictedManifestIsRejected() {
        val directory = Files.createTempDirectory("timeshift-position").toFile()
        val store = LocalSegmentStore(directory, maxBytes = 1024, maxDurationMs = 20_000, reserveBytes = 0)
        try {
            fun add() = store.commit(File(directory, "incoming.part").also { it.writeBytes(ByteArray(10)) }, 10_000, false)
            add(); add()
            assertEquals(5_000L, store.absolutePosition(0, 5_000))
            assertEquals(15_000L, store.absolutePosition(1, 5_000))
            add()
            assertEquals(10_000L, store.startOffsetMs())
            assertNull(store.absolutePosition(0, 5_000))
            assertEquals(15_000L, store.absolutePosition(1, 5_000))
            assertEquals(25_000L, store.absolutePosition(2, 5_000))
        } finally { store.close() }
        assertFalse(directory.exists())
    }
}
