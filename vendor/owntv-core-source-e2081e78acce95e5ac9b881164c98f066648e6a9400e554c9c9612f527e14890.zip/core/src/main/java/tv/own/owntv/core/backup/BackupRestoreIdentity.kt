package tv.own.owntv.core.backup

import org.json.JSONObject
import tv.own.owntv.core.settings.StartupChannelRef
import tv.own.owntv.core.settings.StartupMode

/** Device-local counters are not identity. Only mappings resolved by this restore may attach data. */
internal class BackupRestoreIdentity(
    private val profiles: Map<Long, Long>,
    private val sources: Map<Long, Long>,
) {
    var skipped = 0
        private set

    fun profile(old: Long): Long? = profiles[old].also { if (it == null) skipped++ }
    fun source(old: Long): Long? = if (old < 0) old else sources[old].also { if (it == null) skipped++ }

    fun profileMap(input: JSONObject): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile)
            if (mapped != null) put(mapped.toString(), input.get(key))
        }
    }

    /** A specific-channel mode and its target are one choice; never borrow a stale local target. */
    fun startupModes(input: JSONObject, targets: JSONObject?): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile) ?: return@forEach
            if (input.optString(key) == StartupMode.SPECIFIC_CHANNEL.name) {
                val ref = StartupChannelRef.fromJson(targets?.optJSONObject(key)?.toString())
                if (ref == null) { skipped++; return@forEach }
                if (source(ref.sourceId) == null) return@forEach
            }
            put(mapped.toString(), input.get(key))
        }
    }

    fun startupChannels(input: JSONObject): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile) ?: return@forEach
            val value = input.optJSONObject(key)
            val ref = StartupChannelRef.fromJson(value?.toString())
            if (ref == null) { skipped++; return@forEach }
            if (source(ref.sourceId) != null) put(mapped.toString(), value)
        }
    }

    /** Legacy URL/file keys carry no source namespace and retain their exact identity. */
    fun engineKey(key: String): String? {
        val old = key.substringBefore(':').toLongOrNull() ?: return key
        return source(old)?.let { "$it:${key.substringAfter(':')}" }
    }

    fun typedKey(key: String): String? {
        val parts = key.split(':', limit = 3)
        if (parts.size < 3) return key
        val old = parts[1].toLongOrNull() ?: return key
        return source(old)?.let { "${parts[0]}:$it:${parts[2]}" }
    }
}
