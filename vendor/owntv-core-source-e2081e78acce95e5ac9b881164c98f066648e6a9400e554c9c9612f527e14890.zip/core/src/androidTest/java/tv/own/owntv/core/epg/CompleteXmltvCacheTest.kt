package tv.own.owntv.core.epg

import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.ByteArrayInputStream
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import tv.own.owntv.core.parser.XmltvParser

@RunWith(AndroidJUnit4::class)
class CompleteXmltvCacheTest {
    private suspend fun parse(xml: String) = XmltvParser.parse(ByteArrayInputStream(xml.toByteArray()),
        onChannel = { _, _, _ -> }, onProgramme = { _, _, _, _, _ -> }, requireCompleteDocument = true)
    @Test fun completeDocumentIsAccepted() = runBlocking { parse("<tv></tv>") }
    @Test fun truncatedDocumentIsRejected() = runBlocking {
        try { parse("<tv><channel id=\"c\"><display-name>News</display-name></channel>"); fail("Incomplete cache accepted") }
        catch (_: java.io.IOException) { }
        catch (_: org.xmlpull.v1.XmlPullParserException) { }
    }
}
