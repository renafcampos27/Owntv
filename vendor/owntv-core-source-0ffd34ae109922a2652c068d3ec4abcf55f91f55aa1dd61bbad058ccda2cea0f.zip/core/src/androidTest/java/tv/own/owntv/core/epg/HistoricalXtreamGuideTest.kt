package tv.own.owntv.core.epg

import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.parser.XtreamClient

@RunWith(AndroidJUnit4::class)
class HistoricalXtreamGuideTest {
    @Test fun historyUsesOneStreamAndFiltersRowsOutsideTheRequestedWindow() = runBlocking {
        val source = SourceEntity(name = "List", type = SourceType.XTREAM, url = "https://example.test", username = "u", password = "p")
        val client = OkHttpClient.Builder().addInterceptor { chain ->
            assertEquals("get_simple_data_table", chain.request().url.queryParameter("action"))
            assertEquals("42", chain.request().url.queryParameter("stream_id"))
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(200).message("OK")
                .body("""{"epg_listings":[{"title":"TmV3cw==","start_timestamp":100,"end_timestamp":200},{"title":"T2xk","start_timestamp":1,"stop_timestamp":2}]}""".toResponseBody()).build()
        }.build()
        try {
            val rows = XtreamClient(HttpClient(client)).getHistoricalEpg(source, "42", 100_000, 200_000)
            assertEquals(1, rows.size)
            assertEquals("News", rows.single().title)
            assertEquals(200_000L, rows.single().stopMs)
        } finally { client.dispatcher.executorService.shutdown(); client.connectionPool.evictAll() }
    }
}
