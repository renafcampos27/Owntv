package tv.own.owntv.core.epg

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.io.File
import java.io.IOException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import tv.own.owntv.core.database.ownTVTestDatabase
import tv.own.owntv.core.database.transaction
import tv.own.owntv.core.database.entity.EpgProgrammeEntity

@RunWith(AndroidJUnit4::class)
class GuideCacheTransactionTest {
    @Test fun realRoomTransactionRestoresDeletedRowsWhenInsertFails() = runBlocking {
        val db = ownTVTestDatabase()
        val directory = File.createTempFile("guide-test", ".dir", InstrumentationRegistry.getInstrumentation().targetContext.cacheDir)
        directory.delete(); directory.mkdir()
        try {
            val original = EpgProgrammeEntity(sourceId = 1, epgChannelId = "c", startMs = 1, stopMs = 2, title = "Original")
            db.epgDao().upsertProgrammes(listOf(original))
            try {
                replaceGuideCache(1, directory, parse = { emit -> emit(original.copy(startMs = 3, stopMs = 4)) },
                    transaction = { block -> db.transaction { block() } },
                    clear = { key, source -> db.epgDao().clearChannelForSources(key, listOf(source)) },
                    insert = { throw IOException("insertion failed") })
                fail("Expected insertion failure")
            } catch (_: IOException) { }
            assertEquals("Original", db.epgDao().programmesForChannel("c", 0, 10).single().title)
            assertEquals(1L, db.epgDao().programmesForChannel("c", 0, 10).single().startMs)
            assertTrue(directory.listFiles().orEmpty().isEmpty())
        } finally { db.close(); directory.delete() }
    }
}
