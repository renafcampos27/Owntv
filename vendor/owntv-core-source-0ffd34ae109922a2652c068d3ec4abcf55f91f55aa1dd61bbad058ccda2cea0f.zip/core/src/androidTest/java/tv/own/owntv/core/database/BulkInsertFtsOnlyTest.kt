package tv.own.owntv.core.database

import androidx.room.useWriterConnection
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Real Room + bundled SQLite regression for index retirement, including concurrent bulk owners. */
@RunWith(AndroidJUnit4::class)
class BulkInsertFtsOnlyTest {
    private suspend fun names(db: OwnTVDatabase, type: String): Set<String> = db.useWriterConnection { connection ->
        connection.usePrepared("SELECT name FROM sqlite_master WHERE type=? AND tbl_name='channels'") { statement ->
            statement.bindText(1, type)
            buildSet { while (statement.step()) add(statement.getText(0)) }
        }
    }

    @Test fun ftsOnlyKeepsBTreeIndexesDuringWorkAndAfterCancellation() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            val before = names(db, "index")
            assertTrue(before.isNotEmpty())
            val helper = BulkInsertHelper(db)
            try {
                helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true, ftsOnly = true) {
                    assertEquals(before, names(db, "index"))
                    throw CancellationException("synthetic cancelled import")
                }
                fail("Expected cancellation")
            } catch (_: CancellationException) { }
            assertEquals(before, names(db, "index"))
            assertTrue(names(db, "trigger").contains("room_fts_content_sync_channels_fts_AFTER_INSERT"))
        } finally { db.close() }
    }

    @Test fun concurrentOwnerCannotRestoreTriggerUntilLastWriterLeaves() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            withTimeout(10_000) {
                val before = names(db, "index")
                val helper = BulkInsertHelper(db)
                val firstEntered = CompletableDeferred<Unit>()
                val secondEntered = CompletableDeferred<Unit>()
                val leaveFirst = CompletableDeferred<Unit>()
                val leaveSecond = CompletableDeferred<Unit>()
                val first = launch {
                    helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true, ftsOnly = true) {
                        firstEntered.complete(Unit); leaveFirst.await()
                    }
                }
                firstEntered.await()
                val second = launch {
                    helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true, ftsOnly = false) {
                        secondEntered.complete(Unit); leaveSecond.await()
                    }
                }
                secondEntered.await()
                assertEquals(before, names(db, "index"))
                leaveFirst.complete(Unit); first.join()
                assertFalse(names(db, "trigger").contains("room_fts_content_sync_channels_fts_AFTER_INSERT"))
                leaveSecond.complete(Unit); second.join()
                assertEquals(before, names(db, "index"))
                assertTrue(names(db, "trigger").contains("room_fts_content_sync_channels_fts_AFTER_INSERT"))
            }
        } finally { db.close() }
    }

    @Test fun fullBulkModeStillRestoresCanonicalBTreeIndexes() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            val before = names(db, "index")
            BulkInsertHelper(db).withOptimizedBulkInsert("channels", "channels_fts", eligible = true) {
                assertTrue(names(db, "index").size < before.size)
            }
            assertEquals(before, names(db, "index"))
        } finally { db.close() }
    }
}
