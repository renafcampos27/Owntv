package tv.own.owntv.core.epg

import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.ByteArrayInputStream
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import tv.own.owntv.core.parser.XmltvParser

@RunWith(AndroidJUnit4::class)
class CompleteXmltvCacheTest {
    private suspend fun parse(xml: String) = XmltvParser.parse(ByteArrayInputStream(xml.toByteArray()),
        onChannel = { _, _, _ -> }, onProgramme = { _, _, _, _, _ -> }, requireCompleteDocument = true)
    @Test fun completeDocumentIsAccepted() = runBlocking { parse("<tv></tv>") }
    @Test fun truncatedDocumentIsRejected() = runBlocking {
        try { parse("<tv><channel id=\"c\"><display-name>News</display-name></channel>"); fail("Incomplete cache accepted") }
        catch (_: java.io.IOException) { }
        catch (_: org.xmlpull.v1.XmlPullParserException) { }
    }
    @Test fun unrelatedXmlIsRejected() = runBlocking {
        try { parse("<html><body>error</body></html>"); fail("Non-guide accepted") }
        catch (_: java.io.IOException) { }
    }
    @Test fun largeDescriptionIsBoundedWithoutLosingNextProgramme() = runBlocking {
        val descriptions = mutableListOf<String?>()
        val xml = "<tv><programme channel=\"c\" start=\"20261020000000 +0000\" stop=\"20261020010000 +0000\"><title>One</title><desc>" +
            "a".repeat(1_000_000) + "</desc></programme><programme channel=\"c\" start=\"20261020010000 +0000\" stop=\"20261020020000 +0000\"><title>Two</title></programme></tv>"
        XmltvParser.parse(xml.byteInputStream(), { _, _, _ -> }, { _, _, _, _, description -> descriptions += description }, requireCompleteDocument = true)
        assertEquals(2, descriptions.size)
        assertEquals(256 * 1024, descriptions.first()!!.length)
    }
}
