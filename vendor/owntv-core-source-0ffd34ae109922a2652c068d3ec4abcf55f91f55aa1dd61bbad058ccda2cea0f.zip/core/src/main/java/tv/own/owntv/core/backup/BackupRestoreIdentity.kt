package tv.own.owntv.core.backup

import org.json.JSONObject
import org.json.JSONArray
import tv.own.owntv.core.settings.StartupChannelRef
import tv.own.owntv.core.settings.StartupMode

/** Device-local counters are not identity. Only mappings resolved by this restore may attach data. */
internal class BackupRestoreIdentity(
    private val profiles: Map<Long, Long>,
    private val sources: Map<Long, Long>,
) {
    var skipped = 0
        private set

    fun profile(old: Long): Long? = profiles[old].also { if (it == null) skipped++ }
    fun source(old: Long): Long? = if (old < 0) old else sources[old].also { if (it == null) skipped++ }

    fun sourceMap(input: JSONObject, mapping: Map<Long, Long> = sources): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val old = key.toLongOrNull()
            val mapped = old?.let { mapping[it] }
            if (mapped == null) skipped++ else put(mapped.toString(), input.get(key))
        }
    }

    fun contentKey(key: String): String? {
        val old = key.substringBefore(':').toLongOrNull() ?: return key
        return source(old)?.let { "$it:${key.substringAfter(':')}" }
    }

    fun typedMap(input: JSONObject): JSONObject = JSONObject().apply {
        input.keys().forEach { key -> typedKey(key)?.let { put(it, input.get(key)) } }
    }

    fun userDataRow(input: JSONObject): JSONObject? {
        val profile = profile(input.optLong("p", -1)) ?: return null
        val source = source(input.optLong("src", -1)) ?: return null
        val context = if (input.has("ctx")) contentKey(input.getString("ctx")) ?: return null else null
        return JSONObject(input.toString()).put("p", profile).put("src", source).apply {
            if (context != null) put("ctx", context)
        }
    }

    /** Unknown source namespaces are omitted; custom and built-in keys remain byte-for-byte. */
    fun customization(raw: String): String {
        val input = JSONObject(raw)
        return JSONObject().apply {
            input.keys().forEach { field ->
                when (val value = input.get(field)) {
                    is JSONArray -> put(field, JSONArray().apply {
                        for (i in 0 until value.length()) {
                            val item = value.get(i)
                            if (item is String) contentKey(item)?.let { put(it) } else put(item)
                        }
                    })
                    is JSONObject -> put(field, JSONObject().apply {
                        value.keys().forEach entry@{ key ->
                            val mapped = contentKey(key) ?: return@entry
                            val entry = value.get(key)
                            if (field == "movedFrom" || field == "channelVersionGroups") {
                                contentKey(entry as String)?.let { put(mapped, it) }
                            } else put(mapped, entry)
                        }
                    })
                    else -> put(field, value)
                }
            }
        }.toString()
    }

    fun profileMap(input: JSONObject): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile)
            if (mapped != null) put(mapped.toString(), input.get(key))
        }
    }

    /** A specific-channel mode and its target are one choice; never borrow a stale local target. */
    fun startupModes(input: JSONObject, targets: JSONObject?): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile) ?: return@forEach
            if (input.optString(key) == StartupMode.SPECIFIC_CHANNEL.name) {
                val ref = StartupChannelRef.fromJson(targets?.optJSONObject(key)?.toString())
                if (ref == null) { skipped++; return@forEach }
                if (source(ref.sourceId) == null) return@forEach
            }
            put(mapped.toString(), input.get(key))
        }
    }

    fun startupChannels(input: JSONObject): JSONObject = JSONObject().apply {
        input.keys().forEach { key ->
            val mapped = key.toLongOrNull()?.let(::profile) ?: return@forEach
            val value = input.optJSONObject(key)
            val ref = StartupChannelRef.fromJson(value?.toString())
            if (ref == null) { skipped++; return@forEach }
            if (source(ref.sourceId) != null) put(mapped.toString(), value)
        }
    }

    /** Legacy URL/file keys carry no source namespace and retain their exact identity. */
    fun engineKey(key: String): String? {
        val old = key.substringBefore(':').toLongOrNull() ?: return key
        return source(old)?.let { "$it:${key.substringAfter(':')}" }
    }

    fun typedKey(key: String): String? {
        val parts = key.split(':', limit = 3)
        if (parts.size < 3) return key
        val old = parts[1].toLongOrNull() ?: return key
        return source(old)?.let { "${parts[0]}:$it:${parts[2]}" }
    }
}
