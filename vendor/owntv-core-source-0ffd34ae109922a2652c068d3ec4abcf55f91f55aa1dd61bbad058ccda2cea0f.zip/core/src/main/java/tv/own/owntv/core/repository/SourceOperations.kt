package tv.own.owntv.core.repository

import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** An edit cancels and joins the old import before saving new credentials. */
internal class SourceOperations {
    private val locks = ConcurrentHashMap<Long, Mutex>()
    private val active = ConcurrentHashMap<Long, Job>()
    suspend fun <T> sync(id: Long, block: suspend () -> T): T = locks.getOrPut(id) { Mutex() }.withLock {
        coroutineScope {
            val job = currentCoroutineContext().job
            active[id] = job
            try { block() } finally { active.remove(id, job) }
        }
    }
    suspend fun <T> edit(id: Long, block: suspend () -> T): T {
        active[id]?.cancelAndJoin()
        return locks.getOrPut(id) { Mutex() }.withLock { block() }
    }
}
