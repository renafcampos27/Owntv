package tv.own.owntv.core.backup

import tv.own.owntv.core.model.MediaType

internal data class SnapshotRow(val kind: String, val profileId: Long, val type: MediaType, val itemId: Long)
internal data class SnapshotPurgeBatch(val kind: String, val profileId: Long, val type: MediaType, val itemIds: List<Long>)

/** Profile/type and captured ids bound the deletion. Leave room below SQLite's legacy 999 variables. */
internal fun snapshotPurgeBatches(rows: List<SnapshotRow>, chunk: Int = 900): List<SnapshotPurgeBatch> {
    require(chunk in 1..900)
    return rows.asSequence().filter { it.kind == "order" || it.kind == "member" }
        .groupBy { Triple(it.kind, it.profileId, it.type) }
        .flatMap { (key, group) ->
            group.map { it.itemId }.distinct().chunked(chunk).map {
                SnapshotPurgeBatch(key.first, key.second, key.third, it)
            }
        }
}
