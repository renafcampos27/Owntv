package tv.own.owntv.core.recording

/**
 * Outcome of attempting to delete a recording.
 *
 * Guarantees that neither the database row nor physical storage are partially removed
 * or orphaned when deletion cannot complete cleanly.
 */
enum class RecordingDeleteResult {
    /** The recording files and database entry were successfully removed. */
    SUCCESS,

    /** The recording is currently open for playback or in use by another task. */
    IN_USE,

    /** The storage volume is unmounted, disconnected or unwritable. */
    STORAGE_UNAVAILABLE,

    /** System permission to delete the file or document was denied. */
    PERMISSION_DENIED,

    /** Physical files could not be deleted from storage; database row is preserved. */
    DELETE_FAILED,

    /** The recording row no longer exists or the identity does not match the current selection. */
    STALE_SELECTION,
}
