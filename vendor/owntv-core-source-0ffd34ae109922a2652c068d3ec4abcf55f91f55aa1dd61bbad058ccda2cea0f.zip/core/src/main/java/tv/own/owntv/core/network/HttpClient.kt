package tv.own.owntv.core.network

import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream

/**
 * Thin OkHttp wrapper for fetching M3U playlists and Xtream JSON. [get] streams the response body to
 * a block (so huge payloads are never fully buffered) and always closes the response. A per-source
 * custom User-Agent can be supplied (Phase 12 power feature).
 */
class HttpClient(private val client: OkHttpClient) {
    private val cooldowns = CatalogCooldowns()

    /** Non-2xx response. Thrown before the body block runs, so retrying it never re-emits parsed items. */
    class HttpStatusException(val code: Int, message: String, val retryAfterMillis: Long? = null) : IOException(message)

    suspend fun <T> get(
        url: String,
        userAgent: String? = null,
        onProgress: ((Long, Long?) -> Unit)? = null,
        maxAttempts: Int = 1,
        headers: Map<String, String> = emptyMap(),
        block: suspend (InputStream) -> T,
    ): T = withContext(Dispatchers.IO) {
        val ua = userAgent?.takeIf { it.isNotBlank() } ?: DEFAULT_USER_AGENT
        val request = Request.Builder()
            .url(url.toHttpUrlOrNull() ?: throw IOException("Invalid provider address"))
            .header("User-Agent", ua)
            // Caller-supplied identity headers (today: the metadata Worker's x-owntv-key / x-owntv-client).
            // Blank values are dropped so an unconfigured build never sends an empty header.
            .apply { headers.forEach { (name, value) -> if (value.isNotBlank()) header(name, value) } }
            .build()

        val coroutineContext = currentCoroutineContext()
        val startedAt = SystemClock.elapsedRealtime()
        val safeUrl = diagnosticOrigin(url)
        val attempts = maxAttempts.coerceAtLeast(1)
        var attempt = 1
        val cooldownKey = cooldowns.key(request)
        while (attempt <= attempts) {
            coroutineContext.ensureActive()
            val pending = cooldowns.pending(cooldownKey)
            if (pending != null) {
                if (pending.remainingMillis > MAX_RETRY_DELAY_MS)
                    throw HttpStatusException(pending.status, "Provider retry deferred", pending.remainingMillis)
                delay(pending.remainingMillis)
                continue // Another response may have extended this account's deadline while we waited.
            }
            val call = client.newCall(request)
            var responseReceived = false
            Log.d(TAG, "GET start url=$safeUrl customUa=${userAgent?.isNotBlank() == true} attempt=$attempt/$attempts")
            try {
                return@withContext cancelBlockingCallWithCoroutine(call::cancel) {
                    call.execute().use { response ->
                        responseReceived = true
                        val headersAt = SystemClock.elapsedRealtime()
                        if (!response.isSuccessful) {
                            val retryAfter = if (response.code == 429 || response.code == 503)
                                catalogRetryAfterMillis(response.header("Retry-After")) else null
                            if (retryAfter != null) cooldowns.defer(cooldownKey, retryAfter, response.code)
                            throw HttpStatusException(response.code, "HTTP ${response.code} for $safeUrl", retryAfter)
                        }
                        val body = response.body
                        val totalBytes = body.contentLength().takeIf { it >= 0 }
                        // Info, not debug, and deliberately so: release builds strip Log.d, and this one
                        // line is what answers "are we actually getting gzip?" — the question behind a
                        // 73 MB catalogue body that the provider drops four minutes in (plan N2a). It
                        // was debug-level for exactly as long as that question went unanswered.
                        Log.i(
                            TAG,
                            "GET headers url=$safeUrl code=${response.code} contentLength=${totalBytes ?: -1} " +
                                "contentEncoding=${response.header("Content-Encoding").orEmpty()} " +
                                // The one that actually answers the question. OkHttp adds
                                // `Accept-Encoding: gzip` on its own when the caller sets none, and then
                                // *strips* Content-Encoding from the user-facing response after
                                // decompressing — so the field above reads empty whether gzip happened
                                // or not. The network response still carries the wire value.
                                "wireEncoding=${response.networkResponse?.header("Content-Encoding").orEmpty()} " +
                                "transferEncoding=${response.header("Transfer-Encoding").orEmpty()} " +
                                "headersMs=${headersAt - startedAt}",
                        )
                        onProgress?.invoke(0, totalBytes)
                        body.byteStream().withProgress(totalBytes, onProgress, safeUrl).use { input ->
                            block(input).also {
                                Log.d(TAG, "GET body done url=$safeUrl totalMs=${SystemClock.elapsedRealtime() - startedAt}")
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                coroutineContext.ensureActive()
                // Retry only when the body block never ran: no response at all, or a 5xx/429 status
                // (thrown before the block). Mid-body failures are NOT retried — the block may already
                // have consumed items, and the truncation fallback handles those.
                val retryableStatus = e is HttpStatusException && (e.code in 500..599 || e.code == 429)
                val retrying = (!responseReceived || retryableStatus) && attempt < attempts
                Log.w(
                    TAG,
                    "GET failed url=$safeUrl attempt=$attempt/$attempts totalMs=${SystemClock.elapsedRealtime() - startedAt} " +
                        diagnosticFailure(e, retrying),
                )
                if (!retrying || (e is HttpStatusException && (e.retryAfterMillis ?: 0) > MAX_RETRY_DELAY_MS)) throw e
            }
            delay((RETRY_DELAY_MS * attempt).coerceAtMost(MAX_RETRY_DELAY_MS))
            attempt++
        }
        throw IOException("GET failed for $safeUrl")
    }

    /** Convenience for small responses (e.g. Xtream category lists). */
    suspend fun getText(
        url: String,
        userAgent: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): String = get(url, userAgent, headers = headers) { it.readBytes().decodeToString() }

    companion object {
        private const val TAG = "HttpClient"

        /** Default IPTV identity. Explicit per-source and per-channel overrides take precedence. */
        const val DEFAULT_USER_AGENT = "IPTVSmartersPro"

        /**
         * The identity to fall back on when a provider refuses [DEFAULT_USER_AGENT] outright.
         *
         * Some hosts sit behind a WAF that blocklists player User-Agents by name: measured on a
         * Cloudflare-fronted panel that answers `VLC/3.0.20 LibVLC/3.0.20` — and `vlc`, and `okhttp/…`,
         * and a blank UA — with a 403 "Just a moment…" challenge page, while serving the identical URL
         * 200 to anything else. A bare `Mozilla/5.0` was enough to clear that particular panel, but the
         * full desktop-browser string is what such rules are actually written around, so it is the safer
         * bet against the next WAF that scores UA *completeness* rather than matching a blocklist.
         *
         * This is only reached after a provider refuses the configured default identity.
         */
        const val FALLBACK_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"
        private const val RETRY_DELAY_MS = 750L
        private const val MAX_RETRY_DELAY_MS = 3_000L

        /** Catalog logs need the origin, never account paths or arbitrary signed query parameters. */
        internal fun diagnosticOrigin(url: String): String = runCatching {
            val parsed = java.net.URI(url)
            val scheme = parsed.scheme?.lowercase(java.util.Locale.ROOT)
            val host = parsed.host?.takeIf { it.isNotBlank() }
            if (scheme !in setOf("http", "https") || host == null) "invalid-url"
            else "$scheme://$host${if (parsed.port >= 0) ":${parsed.port}" else ""}"
        }.getOrDefault("invalid-url")

        /** Throwable messages/causes can repeat raw URLs; retain only controlled diagnostic fields. */
        internal fun diagnosticFailure(error: IOException, retrying: Boolean): String =
            "type=${error.javaClass.simpleName} status=${(error as? HttpStatusException)?.code ?: 0} retrying=$retrying"

        /** Mask credentials for display (info overlay / logs): query params AND Xtream `/type/user/pass/`
         *  path segments, which is where live URLs embed them. */
        fun redactUrl(url: String): String = url
        .replace(Regex("(?i)(username|password|user|pass|token|data|auth|signature|sig|key)=[^&]*"), "$1=***")
            // `timeshift` is the catch-up/archive form (/timeshift/user/pass/duration/start/id.ts) — it
            // embeds the same credentials as a live URL, so it must be masked here too.
            .replace(Regex("(?i)(://[^/]+/(?:live|movie|series|vod|timeshift)/)([^/]+)/([^/]+)/"), "$1•••/•••/")
            // Strip userinfo credentials from a `scheme://user:pass@host` URL (e.g. a proxy URL handed
            // to mpv, or any source URL with embedded creds) so they never reach a log line.
            .replace(Regex("(?i)(://)([^/@:]+)(:[^/@]*)?@"), "$1***@")
    }
}

internal fun InputStream.withProgress(
    totalBytes: Long?,
    onProgress: ((Long, Long?) -> Unit)?,
    diagnosticLabel: String? = null,
): InputStream = if (onProgress == null && diagnosticLabel == null) {
    this
} else {
    ProgressInputStream(this, totalBytes, onProgress, diagnosticLabel)
}

private class ProgressInputStream(
    input: InputStream,
    private val totalBytes: Long?,
    private val onProgress: ((Long, Long?) -> Unit)?,
    private val diagnosticLabel: String?,
) : FilterInputStream(input) {
    private val startedAt = SystemClock.elapsedRealtime()
    private var bytesRead = 0L
    private var lastNotifiedBytes = 0L
    private var lastNotifiedAt = 0L
    private var lastDiagnosticBytes = 0L
    private var lastDiagnosticAt = startedAt
    private var readCalls = 0L
    private var readBlockedMs = 0L
    private var maxReadMs = 0L

    // No per-call timing here: a caller reading byte-by-byte would pay two clock syscalls per byte.
    override fun read(): Int {
        val value = super.read()
        if (value >= 0) advance(1)
        return value
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val started = SystemClock.elapsedRealtime()
        val read = super.read(b, off, len)
        recordRead(SystemClock.elapsedRealtime() - started)
        if (read > 0) advance(read.toLong())
        return read
    }

    override fun close() {
        try {
            super.close()
        } finally {
            notifyProgress(force = true)
        }
    }

    private fun recordRead(durationMs: Long) {
        readCalls++
        readBlockedMs += durationMs
        if (durationMs > maxReadMs) maxReadMs = durationMs
    }

    private fun advance(delta: Long) {
        bytesRead += delta
        notifyProgress()
    }

    private fun notifyProgress(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime() // monotonic — wall clock can jump on NTP sync
        val bytesDelta = bytesRead - lastNotifiedBytes
        val timeDelta = now - lastNotifiedAt
        val complete = totalBytes?.let { bytesRead >= it } == true
        if (!force && bytesDelta < PROGRESS_BYTES_STEP && timeDelta < PROGRESS_MIN_INTERVAL_MS && !complete) return
        lastNotifiedBytes = bytesRead
        lastNotifiedAt = now
        onProgress?.invoke(bytesRead, totalBytes)
        notifyDiagnostics(force)
    }

    private fun notifyDiagnostics(force: Boolean = false) {
        val label = diagnosticLabel ?: return
        val now = SystemClock.elapsedRealtime()
        val bytesDelta = bytesRead - lastDiagnosticBytes
        val timeDelta = now - lastDiagnosticAt
        if (!force && bytesDelta < DIAGNOSTIC_BYTES_STEP && timeDelta < DIAGNOSTIC_MIN_INTERVAL_MS) return
        val kbps = if (timeDelta > 0) bytesDelta * 1000 / timeDelta / 1024 else 0
        Log.d(
            "HttpClient",
            "GET body progress url=$label bytes=$bytesRead total=${totalBytes ?: -1} " +
                "deltaBytes=$bytesDelta deltaMs=$timeDelta kbps=$kbps " +
                "readCalls=$readCalls readBlockedMs=$readBlockedMs maxReadMs=$maxReadMs " +
                "elapsedMs=${now - startedAt}",
        )
        lastDiagnosticBytes = bytesRead
        lastDiagnosticAt = now
    }

    private companion object {
        const val PROGRESS_BYTES_STEP = 256L * 1024L
        const val PROGRESS_MIN_INTERVAL_MS = 150L
        const val DIAGNOSTIC_BYTES_STEP = 2L * 1024L * 1024L
        const val DIAGNOSTIC_MIN_INTERVAL_MS = 5_000L
    }
}
