package tv.own.owntv.core.recording

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import tv.own.owntv.core.network.HttpRetryAfter

/** Result of an HLS segment download attempt, carrying HTTP status and server backoff cues. */
internal sealed class HlsSegmentDownloadResult {
    object Success : HlsSegmentDownloadResult()
    data class Failure(
        val httpCode: Int? = null,
        val retryAfterHeader: String? = null,
        val isTerminal: Boolean = false,
    ) : HlsSegmentDownloadResult()
}

/** HTTP classification policy for HLS segment downloads. */
internal object HlsHttpPolicy {
    fun isTerminal(code: Int): Boolean = when (code) {
        400, 401, 403, 404, 405, 410, 414, 416 -> true
        else -> false
    }
}

/** Bounded sequential retry of the same sequence; each retry respects server delays and obtains fresh signed URIs. */
internal object HlsSegmentRetry {
    const val ATTEMPTS = 3
    const val DEFAULT_WAIT_MS = 500L
    const val MAX_WAIT_MS = 10_000L

    suspend inline fun <S> capture(
        sequence: Long,
        initial: S,
        segmentOf: (S, Long) -> HlsMediaPlaylist.Segment?,
        refresh: () -> S,
        capture: (S, HlsMediaPlaylist.Segment) -> Any,
        clock: () -> Long = { System.currentTimeMillis() },
        noinline wait: suspend (Long) -> Unit = { delay(it) },
    ): Boolean {
        var snapshot = initial
        repeat(ATTEMPTS) { attempt ->
            currentCoroutineContext().ensureActive()
            val segment = segmentOf(snapshot, sequence) ?: return false
            if (segment.gap) return false

            val outcome = capture(snapshot, segment)
            val failure = when (outcome) {
                true, is HlsSegmentDownloadResult.Success -> return true
                false -> HlsSegmentDownloadResult.Failure()
                is HlsSegmentDownloadResult.Failure -> outcome
                else -> return false
            }

            // Terminal HTTP errors (401, 403, 404, 410, etc.) cannot succeed on retry
            if (failure.isTerminal) return false
            if (attempt + 1 >= ATTEMPTS) return false

            val now = clock()
            val serverDelay = HttpRetryAfter.delayMs(failure.retryAfterHeader, now)
            val delayMs = when {
                serverDelay != null -> {
                    // If the server asks to wait beyond segment expiration window, do not stall indefinitely
                    if (serverDelay > MAX_WAIT_MS) return false
                    serverDelay.coerceAtLeast(0L)
                }
                else -> (DEFAULT_WAIT_MS * (attempt + 1)).coerceAtMost(MAX_WAIT_MS)
            }

            if (delayMs > 0L) {
                wait(delayMs)
            }
            currentCoroutineContext().ensureActive()

            val nextSnapshot = try {
                refresh()
            } catch (c: kotlinx.coroutines.CancellationException) {
                throw c
            } catch (_: Exception) {
                currentCoroutineContext().ensureActive()
                null
            }
            if (nextSnapshot == null) return false
            snapshot = nextSnapshot
            currentCoroutineContext().ensureActive()

            // Ensure the segment is still present in the updated playlist and not expired or gap
            val freshSegment = segmentOf(snapshot, sequence) ?: return false
            if (freshSegment.gap) return false
        }
        return false
    }
}
