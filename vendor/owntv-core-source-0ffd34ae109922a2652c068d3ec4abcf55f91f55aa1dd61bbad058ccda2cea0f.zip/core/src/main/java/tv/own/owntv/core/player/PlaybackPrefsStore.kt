package tv.own.owntv.core.player

import kotlinx.coroutines.flow.first
import tv.own.owntv.core.database.dao.PlaybackPrefsDao
import tv.own.owntv.core.database.entity.PlaybackPrefsEntity
import tv.own.owntv.core.settings.SettingsRepository

/**
 * Stores per-item zoom/aspect and A/V-sync preferences. Legacy volume APIs/columns remain for
 * compatibility with other consumers and backups; the TV player keeps application gain at 100%.
 *
 * Keyed exactly like the engine pins ([VodEngineStore], [ForceMpvStore]) — [enginePinKey] when the
 * row carries a provider id, the stream URL when it doesn't — which is why a re-sync doesn't lose
 * these: the same item computes the same key again. Scoped to the active profile, so the kids
 * profile's choices never reach the main one.
 *
 * Nothing is stored until the user actually changes something in the player. A missing row, or a
 * null column in an existing one, means "follow the global default in Settings".
 */
class PlaybackPrefsStore(
    private val dao: PlaybackPrefsDao,
    private val settings: SettingsRepository,
) {
    /** The remembered values for [contentKey], or null when this item has none. */
    suspend fun prefsFor(contentKey: String): PlaybackPrefsEntity? =
        runCatching { dao.get(settings.activeProfileId.first(), contentKey) }.getOrNull()

    /** Remember a deliberate zoom choice ([tv.own.owntv.player.ZoomMode] name). */
    suspend fun rememberZoom(contentKey: String, zoomMode: String) {
        runCatching { dao.setZoom(settings.activeProfileId.first(), contentKey, zoomMode) }
    }

    /** Remember a deliberate volume change (percent, 0–150). */
    suspend fun rememberVolume(contentKey: String, volume: Int) {
        runCatching { dao.setVolume(settings.activeProfileId.first(), contentKey, volume) }
    }

    /** Remember a deliberate A/V-sync offset in ms; null forgets it and returns to the global value. */
    suspend fun rememberAudioDelay(contentKey: String, audioDelayMs: Int?) {
        runCatching { dao.setAudioDelay(settings.activeProfileId.first(), contentKey, audioDelayMs) }
    }

    /** Settings escape hatch: forget every item's zoom, on every profile. Volumes are kept. */
    suspend fun clearZoom() {
        runCatching { dao.clearZoom() }
    }

    /** Settings escape hatch: forget every item's volume, on every profile. Zoom modes are kept. */
    suspend fun clearVolume() {
        runCatching { dao.clearVolume() }
    }

    /** How many items currently remember a zoom / a volume — the two Settings rows' chips. */
    fun observeZoomCount(): kotlinx.coroutines.flow.Flow<Int> = dao.observeZoomCount()

    fun observeVolumeCount(): kotlinx.coroutines.flow.Flow<Int> = dao.observeVolumeCount()

    /** Settings escape hatch: forget every item's audio delay, on every profile. */
    suspend fun clearAudioDelay() {
        runCatching { dao.clearAudioDelay() }
    }

    fun observeAudioDelayCount(): kotlinx.coroutines.flow.Flow<Int> = dao.observeAudioDelayCount()
}
