package tv.own.owntv.core.parser

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import tv.own.owntv.core.database.entity.SourceEntity

/** Inputs are logical values. A literal percent is escaped, never decoded a second time. */
internal object XtreamUrls {
    private fun endpoint(source: SourceEntity, path: String): HttpUrl.Builder = (source.url.trimEnd('/').toHttpUrlOrNull()
        ?: throw java.io.IOException("Invalid provider address"))
        .newBuilder().query(null).fragment(null).addPathSegment(path)

    fun account(source: SourceEntity, file: String = "player_api.php"): HttpUrl.Builder =
        endpoint(source, file).addQueryParameter("username", source.username.orEmpty())
            .addQueryParameter("password", source.password.orEmpty())

    fun media(source: SourceEntity, kind: String, segments: List<String>): String {
        require(source.username !in setOf(".", "..") && source.password !in setOf(".", "..")) { "Invalid Xtream path identity" }
        return endpoint(source, kind).addPathSegment(source.username.orEmpty())
            .addPathSegment(source.password.orEmpty()).apply { segments.forEach(::addPathSegment) }.build().toString()
    }
}
