package tv.own.owntv.core.timeshift

/** A local capture exists but has not yet committed a readable segment. */
class LocalPlaylistNotReady : IllegalStateException("Local playlist is preparing")

/** The local capture is closed or completed without usable content; do not retry it. */
class LocalPlaylistUnavailable : IllegalStateException("Local playlist is unavailable")
