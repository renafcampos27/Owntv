package tv.own.owntv.core.settings

/** Quiet time after leaving a live channel, measured with a monotonic clock. */
object ChannelReopenInterval {
    const val DEFAULT_SECONDS = 20
    const val MIN_SECONDS = 10
    const val MAX_SECONDS = 50
    val CHOICES = MIN_SECONDS..MAX_SECONDS
    fun normalize(seconds: Int): Int = seconds.coerceIn(MIN_SECONDS, MAX_SECONDS)
}
