package tv.own.owntv.core.parser

/** PHP false placeholders are absent text; flags retain their boolean semantics. */
internal object XtreamScalarPolicy {
    fun text(value: Any?): String? = when (value) {
        is String -> value
        is Number -> value.toString()
        else -> null
    }
    fun flag(value: String, fallback: Boolean): Boolean = when (value.trim().lowercase(java.util.Locale.ROOT)) {
        "true", "1" -> true
        "false", "0" -> false
        else -> value.trim().toIntOrNull()?.let { it > 0 } ?: fallback
    }
}
