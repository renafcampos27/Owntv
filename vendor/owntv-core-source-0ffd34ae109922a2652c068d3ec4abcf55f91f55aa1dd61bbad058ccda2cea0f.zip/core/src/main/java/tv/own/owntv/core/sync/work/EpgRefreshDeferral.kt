package tv.own.owntv.core.sync.work

/** WorkManager backoff separates attempts; no worker waits indefinitely for a continuously playing TV. */
internal object EpgRefreshDeferral {
    const val MAX_DEFERRALS = 3
    fun retry(attempt: Int): Boolean = attempt < MAX_DEFERRALS
}
