package tv.own.owntv.core.epg

/** Ordered addresses for one archive interval. Never log or render these credential-bearing URLs. */
data class ResolvedArchiveSource(
    val url: String,
    val alternatives: List<String>,
    val manifestTypes: Map<String, String>,
    /** Clock shown to the user, independent from provider request correction. */
    val displayStartMs: Long? = null,
    val requestStartMs: Long? = null,
    val clockZoneId: String? = null,
    val requestCorrectionMinutes: Int = 0,
    val reconnect: tv.own.owntv.core.stalker.ReconnectUrlProvider? = null,
)
