package tv.own.owntv.core.network

import okhttp3.Dns
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.*

/** Limits the caller's wait; Android's underlying resolver can continue after a timeout. */
class BoundedDns(
    private val delegate: Dns = Dns.SYSTEM,
    private val timeoutMs: Long = 5_000,
    private val cachedWaitMs: Long = 1_000,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
) : Dns {
    private data class Answer(val addresses: List<InetAddress>, val timeMs: Long)
    private val answers = object : LinkedHashMap<String, Answer>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Answer>?) = size > 64
    }
    private val inFlight = ConcurrentHashMap<String, FutureTask<List<InetAddress>>>()
    override fun lookup(hostname: String): List<InetAddress> {
        val previous = synchronized(answers) { answers[hostname]?.takeIf { nowMs() - it.timeMs <= 300_000 } }
        val task = object : FutureTask<List<InetAddress>>(Callable { delegate.lookup(hostname) }) {
            override fun done() { inFlight.remove(hostname, this) }
        }
        val pending = inFlight.compute(hostname) { _, current -> if (current == null || current.isDone) task else current }!!
        if (pending === task) try { EXECUTOR.execute(task) } catch (_: RejectedExecutionException) {
            inFlight.remove(hostname, task)
            return previous?.addresses ?: throw UnknownHostException("DNS resolver busy")
        }
        try {
            val result = pending.get(if (previous == null) timeoutMs else cachedWaitMs, TimeUnit.MILLISECONDS)
            if (result.isEmpty()) throw UnknownHostException("Empty DNS answer")
            synchronized(answers) { answers[hostname] = Answer(result.toList(), nowMs()) }
            return result
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw UnknownHostException("DNS lookup interrupted").apply { initCause(e) }
        } catch (e: ExecutionException) {
            return previous?.addresses ?: throw UnknownHostException("DNS lookup failed").apply { initCause(e.cause) }
        } catch (e: TimeoutException) {
            return previous?.addresses ?: throw UnknownHostException("DNS lookup timed out").apply { initCause(e) }
        }
    }
    private companion object {
        val EXECUTOR = ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS, ArrayBlockingQueue<Runnable>(64),
            ThreadFactory { Thread(it, "owntv-live-dns").apply { isDaemon = true } })
    }
}
