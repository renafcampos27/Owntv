package tv.own.owntv.core.profile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.media.ExifInterface
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import tv.own.owntv.core.backup.BackupManager
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/**
 * Where a profile's own picture lives once the user has chosen one.
 *
 * Both apps let a picture in from more than one direction — a file on the television's storage, a
 * photo sent from a phone over the local network, the phone's own photo picker — and every one of
 * them ends here, so the rules are written once: the image is **copied** into app-private storage
 * (a picture on a USB stick must not vanish when the stick does), cropped square about its centre,
 * scaled down to [SIZE_PX], and written as JPEG.
 *
 * Scaling is the point, not a nicety. A profile picture is drawn at about 40 dp in a settings row
 * and 96 dp on the profile gate; keeping a 12-megapixel phone photo to decode on every one of those
 * would cost far more memory than the whole rest of the screen.
 */
class ProfileAvatarStore(private val context: Context) {

    private val dir: File get() = File(context.filesDir, DIR)

    /** Where [profileId]'s picture would live. Present on disk only if one has been saved. */
    fun fileFor(profileId: Long): File = File(dir, "profile_$profileId.jpg")

    /**
     * Copy [source] in as [profileId]'s picture and return its absolute path, or null if the bytes
     * were not a readable image. Any previous picture for that profile is replaced only after
     * successful decoding, scaling, and atomic persistence.
     */
    suspend fun save(profileId: Long, source: File): String? = withContext(Dispatchers.IO) {
        currentCoroutineContext().ensureActive()
        if (!source.isFile || source.length() <= 0L || source.length() > MAX_INPUT_BYTES) {
            return@withContext logUnreadable(profileId)
        }
        processImageFile(profileId, source)
    }

    /** As [save], for bytes that never were a file — a photo handed over by the phone, say. */
    suspend fun save(profileId: Long, source: InputStream): String? = withContext(Dispatchers.IO) {
        currentCoroutineContext().ensureActive()
        context.cacheDir.mkdirs()
        val spoolFile = runCatching {
            File.createTempFile(DIR, BackupManager.TMP_SUFFIX, context.cacheDir)
        }.getOrElse { File(context.cacheDir, fileFor(profileId).name + BackupManager.TMP_SUFFIX) }
        try {
            val spooled = spoolInput(source, spoolFile)
            if (!spooled) {
                return@withContext logUnreadable(profileId)
            }
            currentCoroutineContext().ensureActive()
            processImageFile(profileId, spoolFile)
        } finally {
            spoolFile.delete()
        }
    }

    private fun logUnreadable(profileId: Long): String? {
        Log.w(TAG, "profile $profileId: the chosen file is not a readable image")
        return null
    }

    private fun logUnwritable(profileId: Long): String? {
        Log.w(TAG, "profile $profileId: unable to write the picture")
        return null
    }

    private fun spoolInput(input: InputStream, dest: File): Boolean = runCatching {
        dest.outputStream().use { out ->
            val buf = ByteArray(8192)
            var total = 0L
            while (true) {
                if (Thread.currentThread().isInterrupted) return false
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_INPUT_BYTES) return false
                out.write(buf, 0, n)
            }
            if (total == 0L) return false
        }
        dest.length() > 0
    }.getOrDefault(false)

    private fun processImageFile(profileId: Long, file: File): String? {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsRead = runCatching {
            file.inputStream().use { BitmapFactory.decodeStream(it, null, boundsOpts) }
        }.isSuccess
        if (!boundsRead) return logUnreadable(profileId)
        val rawWidth = boundsOpts.outWidth
        val rawHeight = boundsOpts.outHeight
        if (rawWidth <= 0 || rawHeight <= 0) {
            return logUnreadable(profileId)
        }

        val orientation = runCatching {
            val exif = ExifInterface(file.absolutePath)
            exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val inSampleSize = calculateInSampleSize(rawWidth, rawHeight, SIZE_PX)
        val decodeOpts = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
        }

        val rawDecoded = runCatching {
            file.inputStream().use {
                BitmapFactory.decodeStream(it, null, decodeOpts)
            }
        }.getOrNull() ?: return logUnreadable(profileId)

        val oriented = applyExifOrientation(rawDecoded, orientation)

        val square = runCatching { squareThumbnail(oriented) }.getOrElse {
            Log.w(TAG, "profile $profileId: unable to scale the chosen image", it)
            if (oriented !== rawDecoded) oriented.recycle()
            rawDecoded.recycle()
            return null
        }

        val dest = fileFor(profileId)
        dir.mkdirs()
        val tmpDest = runCatching {
            File.createTempFile(DIR, BackupManager.TMP_SUFFIX, dir)
        }.getOrElse { File(dir, dest.name + BackupManager.TMP_SUFFIX) }

        val written = runCatching {
            val ok = FileOutputStream(tmpDest).use { fos ->
                val compressed = square.compress(Bitmap.CompressFormat.JPEG, QUALITY, fos)
                fos.fd.sync()
                compressed
            }
            ok && tmpDest.length() > 0
        }.getOrDefault(false)

        if (square !== oriented && square !== rawDecoded) square.recycle()
        if (oriented !== rawDecoded) oriented.recycle()
        rawDecoded.recycle()

        if (!written) {
            tmpDest.delete()
            return logUnwritable(profileId)
        }

        val replaced = replaceAtomically(tmpDest, dest)
        if (!replaced) {
            tmpDest.delete()
            return logUnwritable(profileId)
        }

        return dest.absolutePath
    }


    /** Forget [profileId]'s picture. Safe to call when there is none — the drawn tile returns. */
    suspend fun clear(profileId: Long) = withContext(Dispatchers.IO) {
        runCatching { fileFor(profileId).delete() }
        Unit
    }

    /**
     * The centre square of [source], at most [SIZE_PX] a side.
     *
     * Centre-cropped rather than squashed: a portrait photo stretched into a circle makes a face
     * look wrong in a way nobody can name but everybody sees. Returns [source] itself when it is
     * already a small square, so the caller must check identity before recycling.
     */
    private fun squareThumbnail(source: Bitmap): Bitmap {
        val side = minOf(source.width, source.height)
        if (side <= 0) throw IllegalArgumentException("empty image")
        val left = (source.width - side) / 2
        val top = (source.height - side) / 2
        val target = minOf(side, SIZE_PX)
        if (left == 0 && top == 0 && side == source.width && side == source.height && target == side) return source
        val out = Bitmap.createBitmap(target, target, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            source,
            Rect(left, top, left + side, top + side),
            Rect(0, 0, target, target),
            Paint(Paint.FILTER_BITMAP_FLAG),
        )
        return out
    }

    companion object {
        private const val TAG = "ProfileAvatar"
        private const val DIR = "avatars"

        /** Maximum accepted input picture file size (20 MB). */
        const val MAX_INPUT_BYTES = 20L * 1024 * 1024

        /** Comfortably above the largest size either app draws a profile picture at. */
        const val SIZE_PX = 512
        private const val QUALITY = 90

        internal fun replaceAtomically(source: File, target: File): Boolean {
            // 1. Try atomic rename with Files.move (atomic on POSIX / Android 26+)
            val moved = runCatching {
                java.nio.file.Files.move(
                    source.toPath(),
                    target.toPath(),
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                )
                true
            }.getOrDefault(false)
            if (moved) return true

            // 2. Try standard replace move if ATOMIC_MOVE is not supported across OS/filesystem
            val standardMove = runCatching {
                java.nio.file.Files.move(
                    source.toPath(),
                    target.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                )
                true
            }.getOrDefault(false)
            if (standardMove) return true

            // 3. Safe rotation fallback: rotate target to .bak first, rename source to target,
            // and if rename fails, restore target from .bak so target is NEVER lost.
            if (target.exists()) {
                val bak = File(target.parentFile, target.name + BackupManager.BAK_SUFFIX)
                bak.delete()
                if (!target.renameTo(bak)) {
                    return false
                }
                if (source.renameTo(target)) {
                    bak.delete()
                    return true
                } else {
                    bak.renameTo(target)
                    return false
                }
            }
            return source.renameTo(target)
        }

        /**
         * Calculates the largest power of 2 sample size that keeps the smaller dimension >= [targetSize].
         * This preserves full detail up to [targetSize] while reducing heap allocation by up to 90+%.
         */
        internal fun calculateInSampleSize(width: Int, height: Int, targetSize: Int): Int {
            val minDim = minOf(width, height)
            if (minDim <= 0 || targetSize <= 0) return 1
            var inSampleSize = 1
            while (inSampleSize <= (Int.MAX_VALUE / 2) && (minDim / (inSampleSize * 2)) >= targetSize) {
                inSampleSize *= 2
            }
            return inSampleSize
        }

        internal fun applyExifOrientation(source: Bitmap, orientation: Int): Bitmap {
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> {
                    matrix.postRotate(90f)
                    matrix.postScale(-1f, 1f)
                }
                ExifInterface.ORIENTATION_TRANSVERSE -> {
                    matrix.postRotate(270f)
                    matrix.postScale(-1f, 1f)
                }
                else -> return source
            }
            return runCatching {
                val transformed = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
                transformed
            }.getOrDefault(source)
        }
    }
}
