package tv.own.owntv.core.timeshift

/** A bookmark is valid only inside the retained copy; elapsed time never invents recorded media. */
data class LocalTimeshiftBookmark(
    val profileId: Long,
    val sourceId: Long,
    val channelId: Long,
    val absolutePositionMs: Long,
    val savedAtMs: Long,
) {
    fun positionInCopy(profile: Long, source: Long, channel: Long, startMs: Long, durationMs: Long, nowMs: Long): Long? {
        if (profile != profileId || source != sourceId || channel != channelId ||
            nowMs - savedAtMs !in 0 until EXPIRATION_MS || durationMs <= MIN_REMAINING_MS) return null
        val position = absolutePositionMs - startMs
        return position.takeIf { it >= 0 && it < durationMs - MIN_REMAINING_MS }
    }

    companion object {
        const val EXPIRATION_MS = 30 * 60_000L
        const val MIN_REMAINING_MS = 3_000L
    }
}
