package tv.own.owntv.core.repository

import tv.own.owntv.core.database.entity.SourceEntity

fun SourceEntity.connectionConfigurationKey(): String = copy(epgUrl = null, syncLive = true,
    syncMovies = true, syncSeries = true, preferHls = false).catalogConfigurationKey()

/** No secrets in state identifiers or logs; operational counters do not change this revision. */
fun SourceEntity.catalogConfigurationKey(): String {
    val fields = listOf(type.name, url, username, password, mac, userAgent, epgUrl, httpReferer,
        stalkerSerialNumber, stalkerDeviceId, stalkerDeviceId2, stalkerSignature,
        syncLive.toString(), syncMovies.toString(), syncSeries.toString(), preferHls.toString())
    val bytes = fields.joinToString("") { value -> value?.let { "${it.length}:$it" } ?: "-:" }.toByteArray()
    return java.security.MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
