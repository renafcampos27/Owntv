package tv.own.owntv.core.epg

import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.database.entity.computeContentHash

/** Stage a complete source on disk before replacing it; memory is bounded to one insert batch. */
internal suspend fun replaceGuideCache(
    sourceId: Long,
    directory: File,
    parse: suspend (suspend (EpgProgrammeEntity) -> Unit) -> Unit,
    transaction: suspend (suspend () -> Unit) -> Unit,
    clear: suspend (String, Long) -> Unit,
    insert: suspend (List<EpgProgrammeEntity>) -> Unit,
    clearBatch: (suspend (List<String>, Long) -> Unit)? = null,
): Set<String> {
    val staged = File.createTempFile("guide-restore-", ".tmp", directory)
    try {
        val keys = linkedSetOf<String>()
        var count = 0
        DataOutputStream(staged.outputStream().buffered()).use { out ->
            parse { row ->
                currentCoroutineContext().ensureActive()
                out.writeText(row.epgChannelId)
                out.writeLong(row.startMs)
                out.writeLong(row.stopMs)
                out.writeText(row.title)
                out.writeBoolean(row.description != null)
                row.description?.let { out.writeText(it) }
                keys += row.epgChannelId
                count++
            }
        }
        if (keys.isEmpty()) return emptySet()
        currentCoroutineContext().ensureActive()
        transaction {
            if (clearBatch == null) keys.forEach { clear(it, sourceId) }
            else keys.toList().chunked(900).forEach { clearBatch(it, sourceId) }
            DataInputStream(staged.inputStream().buffered()).use { input ->
                val batch = ArrayList<EpgProgrammeEntity>(500)
                repeat(count) {
                    currentCoroutineContext().ensureActive()
                    val row = EpgProgrammeEntity(sourceId = sourceId, epgChannelId = input.readText(),
                        startMs = input.readLong(), stopMs = input.readLong(), title = input.readText(),
                        description = if (input.readBoolean()) input.readText() else null)
                    batch += row.copy(contentHash = row.computeContentHash())
                    if (batch.size == 500) { insert(batch.toList()); batch.clear() }
                }
                if (batch.isNotEmpty()) insert(batch)
            }
        }
        return keys
    } finally {
        staged.delete()
    }
}

private fun DataOutputStream.writeText(value: String) {
    val bytes = value.toByteArray(Charsets.UTF_8)
    writeInt(bytes.size)
    write(bytes)
}

private fun DataInputStream.readText(): String {
    val length = readInt()
    require(length in 0..64 * 1024 * 1024)
    return ByteArray(length).also { readFully(it) }.toString(Charsets.UTF_8)
}
