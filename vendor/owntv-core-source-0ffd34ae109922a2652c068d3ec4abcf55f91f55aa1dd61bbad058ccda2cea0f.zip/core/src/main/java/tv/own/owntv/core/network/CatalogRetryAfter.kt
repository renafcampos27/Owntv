package tv.own.owntv.core.network

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.ConcurrentHashMap
import okhttp3.Request

internal fun catalogRetryAfterMillis(value: String?, nowMillis: Long = System.currentTimeMillis()): Long? {
    val text = value?.trim()?.takeIf { it.length in 1..128 } ?: return null
    text.toLongOrNull()?.let { seconds ->
        return seconds.takeIf { it >= 0 }?.coerceAtMost(86_400)?.times(1000)
    }
    return runCatching { (ZonedDateTime.parse(text, DateTimeFormatter.RFC_1123_DATE_TIME)
        .toInstant().toEpochMilli() - nowMillis).coerceIn(0, 86_400_000) }.getOrNull()
}

/** Only hashed account identities are retained; independent accounts never share a cooldown. */
internal class CatalogCooldowns(private val clock: () -> Long = { System.nanoTime() / 1_000_000 }) {
    private data class Entry(val deadline: Long, val status: Int)
    data class Pending(val remainingMillis: Long, val status: Int)
    private val entries = ConcurrentHashMap<String, Entry>()
    fun key(request: Request): String {
        val url = request.url
        val account = listOfNotNull(url.queryParameter("username"), url.queryParameter("password"))
        val identity = if (account.size == 2) listOf(url.scheme, url.host, url.port.toString(),
            url.encodedPath.substringBeforeLast('/')) + account else listOf(url.toString())
        val material = (identity + listOf("User-Agent", "Authorization", "Cookie").map { request.headers.values(it).joinToString("\n") })
            .joinToString("") { "${it.length}:$it" }
        return java.security.MessageDigest.getInstance("SHA-256").digest(material.toByteArray()).joinToString("") { "%02x".format(it) }
    }
    fun pending(key: String): Pending? {
        val entry = entries[key] ?: return null
        val remaining = entry.deadline - clock()
        if (remaining <= 0) { entries.remove(key, entry); return null }
        return Pending(remaining, entry.status)
    }
    fun remaining(key: String): Long = pending(key)?.remainingMillis ?: 0
    fun defer(key: String, delayMillis: Long, status: Int = 429) {
        val now = clock()
        entries.forEach { (id, entry) -> if (entry.deadline <= now) entries.remove(id, entry) }
        val next = Entry(now + delayMillis.coerceIn(0, 86_400_000), status)
        entries.merge(key, next) { old, incoming -> if (old.deadline >= incoming.deadline) old else incoming }
    }
}
