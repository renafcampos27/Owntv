package tv.own.owntv.core.epg

import java.util.SimpleTimeZone
import java.util.TimeZone
import tv.own.owntv.core.database.entity.SourceEntity

/** Source offset is a UTC timezone offset, never an extra programme/request shift. */
object CatchupClock {
    /** Only the provider request is rounded; its correction never moves the visible guide clock. */
    fun effectiveDisplayStart(displayMs: Long, correctedRequestMs: Long, minuteBased: Boolean): Long =
        displayMs - if (minuteBased) Math.floorMod(correctedRequestMs, 60_000L) else 0L

    fun resolve(source: SourceEntity, fallback: TimeZone, automatic: Boolean = false): TimeZone = when (
        source.catchupTimezone ?: if (automatic) tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.AUTO.name else null) {
        tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.DEVICE.name -> TimeZone.getDefault()
        tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.MANUAL.name -> source.catchupOffsetMin?.takeIf { it in -720..840 }
            ?.let { SimpleTimeZone(it * 60_000, "catchup-source") } ?: fallback
        tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.AUTO.name ->
            source.serverTimeZone?.let(::validatedZone) ?: fallback
        else -> fallback
    }
    private val zoneIds by lazy { TimeZone.getAvailableIDs().toSet() }
    fun validatedZone(id: String): TimeZone? = id.takeIf {
        it in zoneIds || Regex("GMT[+-](?:0[0-9]|1[0-4]):[0-5][0-9]").matches(it)
    }?.let(TimeZone::getTimeZone)
}

