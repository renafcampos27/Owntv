package tv.own.owntv.core.settings

internal data class Phase23PlaybackPatchResult(
    val rows: List<ChannelPlaybackConfig>,
    val legacy: List<ManualTsChannel>,
)

/** Called inside DataStore.edit so both representations belong to one consistent read. */
internal fun phase23PatchPlaybackBatch(
    rows: List<ChannelPlaybackConfig>,
    legacy: List<ManualTsChannel>,
    targets: List<ManualTsChannel>,
    patch: (ChannelPlaybackOptions) -> ChannelPlaybackOptions,
): Phase23PlaybackPatchResult {
    fun key(ref: ManualTsChannel) = ref.sourceId to (ref.remoteId ?: ref.name)
    val effective = ChannelPlaybackConfig.includeLegacy(rows, legacy).associateBy { key(it.channel) }
    val result = rows.associateBy { key(it.channel) }.toMutableMap()
    val targetKeys = targets.map(::key).toSet()
    targets.distinctBy(::key).forEach { target ->
        val updated = patch(effective[key(target)]?.options ?: ChannelPlaybackOptions()).normalized()
        if (updated.isDefault) result.remove(key(target))
        else result[key(target)] = ChannelPlaybackConfig(target, updated)
    }
    return Phase23PlaybackPatchResult(result.values.toList(), legacy.filterNot { key(it) in targetKeys })
}
