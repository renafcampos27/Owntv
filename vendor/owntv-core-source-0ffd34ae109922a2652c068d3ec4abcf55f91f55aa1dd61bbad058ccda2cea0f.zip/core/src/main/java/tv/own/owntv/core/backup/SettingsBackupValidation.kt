package tv.own.owntv.core.backup

import org.json.JSONObject

/** Unknown optional keys remain forward compatible; known keys must match their storage types. */
internal object SettingsBackupValidation {
    fun validate(input: JSONObject, strings: Set<String>, integers: Set<String>, flags: Set<String>,
        floats: Set<String>, stringSets: Set<String>, ranges: Map<String, LongRange>) {
        input.keys().forEach { key ->
            val value = input.get(key)
            val path = "settings.$key"
            when (key) {
                in strings -> {
                    val text = BackupValueValidator.text(value, path)
                    val choices = when (key) {
                        "live_latency_mode", "live_reserve_mode" -> tv.own.owntv.core.settings.LiveLatency.entries.map { it.name }
                        "mini_player_position" -> tv.own.owntv.core.player.MiniPlayerPosition.entries.map { it.name }
                        else -> null
                    }
                    if (choices != null && text !in choices) BackupValueValidator.invalid(path)
                }
                in integers -> {
                    val bounds = ranges[key] ?: (Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong())
                    val number = BackupValueValidator.whole(value, path, bounds.first, bounds.last)
                    val choices = when (key) {
                        "seek_step_sec" -> tv.own.owntv.core.settings.SeekSteps.SEEK_CHOICES
                        "live_rewind_step_sec" -> tv.own.owntv.core.settings.SeekSteps.LIVE_REWIND_CHOICES
                        else -> null
                    }
                    if (choices != null && number.toInt() !in choices) BackupValueValidator.invalid(path)
                    if (key == "audio_delay_ms" && number !in -5_000L..5_000L) BackupValueValidator.invalid(path)
                }
                in flags -> BackupValueValidator.flag(value, path)
                in floats -> {
                    BackupValueValidator.finite(value, path)
                    // Wide compatibility range: reject invisible/pathological scales, preserve old UI values.
                    if (key in setOf("sub_scale", "sub_scale_mpv", "sub_scale_exo") &&
                        (value as Number).toDouble() !in 0.25..4.0) BackupValueValidator.invalid(path)
                }
                in stringSets -> {
                    val values = BackupValueValidator.array(value, path)
                    for (i in 0 until values.length()) BackupValueValidator.text(values.get(i), "$path[$i]")
                }
            }
        }
    }
}
