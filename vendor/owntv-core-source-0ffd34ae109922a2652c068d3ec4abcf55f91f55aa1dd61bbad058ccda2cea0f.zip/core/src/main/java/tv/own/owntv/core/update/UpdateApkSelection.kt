package tv.own.owntv.core.update

internal data class UpdateApkAsset(val name: String, val url: String)

/** Choose a compatible architecture explicitly; never fall back to an arbitrary release asset. */
internal fun selectUpdateApk(assets: List<UpdateApkAsset>, supportedAbis: List<String>): UpdateApkAsset? {
    fun architecture(name: String): String? {
        val lower = name.lowercase(java.util.Locale.ROOT)
        return when {
            "x86_64" in lower || "x86-64" in lower -> "x86_64"
            "armeabi-v7a" in lower || "armv7" in lower -> "armeabi-v7a"
            "arm64" in lower || "armv8" in lower -> "arm64-v8a"
            Regex("(?:^|[-_.])x86(?:[-_.]|$)").containsMatchIn(lower) -> "x86"
            "universal" in lower -> "universal"
            else -> null // Existing OwnTV.apk is the generic ARM release.
        }
    }
    val candidates = assets.filter { it.name.endsWith(".apk", ignoreCase = true) && it.url.isNotBlank() }
    for (abi in supportedAbis) candidates.firstOrNull { architecture(it.name) == abi }?.let { return it }
    candidates.firstOrNull { architecture(it.name) == "universal" }?.let { return it }
    return if (supportedAbis.any { it == "arm64-v8a" || it == "armeabi-v7a" })
        candidates.firstOrNull { architecture(it.name) == null } else null
}
