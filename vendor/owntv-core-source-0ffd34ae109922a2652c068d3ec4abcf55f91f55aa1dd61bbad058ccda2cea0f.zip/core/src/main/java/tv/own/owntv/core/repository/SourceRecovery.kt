package tv.own.owntv.core.repository

import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

/** Retry edits the setup form's fields; settings outside that form belong to the existing source. */
internal fun SourceEntity.recoverOnto(previous: SourceEntity): SourceEntity = previous.copy(
    name = name,
    type = type,
    url = url,
    username = username,
    password = password,
    mac = mac,
    stalkerSerialNumber = stalkerSerialNumber,
    stalkerDeviceId = stalkerDeviceId,
    stalkerDeviceId2 = stalkerDeviceId2,
    stalkerSignature = stalkerSignature,
    userAgent = userAgent,
    epgUrl = epgUrl,
    httpReferer = httpReferer,
    syncLive = if (type == SourceType.M3U) previous.syncLive else syncLive,
    syncMovies = if (type == SourceType.M3U) previous.syncMovies else syncMovies,
    syncSeries = if (type == SourceType.M3U) previous.syncSeries else syncSeries,
    preferHls = if (type == SourceType.XTREAM) preferHls else previous.preferHls,
)
