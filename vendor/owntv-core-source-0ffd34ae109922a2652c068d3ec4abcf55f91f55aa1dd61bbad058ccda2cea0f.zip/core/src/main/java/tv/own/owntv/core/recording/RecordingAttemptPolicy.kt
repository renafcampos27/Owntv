package tv.own.owntv.core.recording

import kotlinx.coroutines.delay
import java.io.IOException
import tv.own.owntv.core.epg.CatchupUrl

/** A finite raw archive has no verified byte-resume contract. Never append a second full body. */
internal object RecordingAttemptPolicy {
    fun mayRetry(archive: Boolean, writtenBytes: Long, segmented: Boolean): Boolean =
        !archive || writtenBytes <= 0L || segmented

    fun archiveWindow(startMs: Long, stopMs: Long, shiftMinutes: Int): LongRange =
        CatchupUrl.requestStartMs(startMs, shiftMinutes)..CatchupUrl.requestStartMs(stopMs, shiftMinutes)

    /** Delay is measured monotonically; the recording window and cancellation always win. */
    suspend fun awaitRetry(waitMs: Long, stopMs: Long, wallClock: () -> Long,
        monotonicMs: () -> Long = { System.nanoTime() / 1_000_000L },
        pause: suspend (Long) -> Unit = { delay(it) }): Boolean {
        val started = monotonicMs()
        while (wallClock() < stopMs) {
            val elapsed = (monotonicMs() - started).coerceAtLeast(0)
            val remaining = waitMs.coerceAtLeast(0) - elapsed
            if (remaining <= 0) return true
            pause(minOf(remaining, 1_000L, (stopMs - wallClock()).coerceAtLeast(1)))
        }
        return false
    }
}

/** HTTP metadata is retained through the capture loop, not reduced to an untyped IOException. */
internal class RecordingHttpFailure(val status: Int, val retryAfterMs: Long?) :
    IOException("Recording HTTP $status")

/** Container completion is part of success, rather than best-effort cleanup. */
internal object RecordingMuxCompletion {
    fun complete(copy: () -> Unit, stop: () -> Unit, valid: () -> Boolean): Boolean {
        copy()
        stop()
        return valid()
    }
}
