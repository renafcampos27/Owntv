package tv.own.owntv.core.epg

import org.json.JSONArray
import org.json.JSONObject
import tv.own.owntv.core.database.entity.ChannelEntity

/** Provider-declared archive addresses. A channel override takes precedence over its playlist. */
data class ArchivePlaybackConfig(
    val sourceId: Long,
    val remoteId: String? = null,
    val channelName: String? = null,
    val templates: List<String>,
    val manifestType: String? = null,
) {
    val isPlaylist: Boolean get() = remoteId == null && channelName == null
    fun sameTarget(other: ArchivePlaybackConfig): Boolean = sourceId == other.sourceId &&
        remoteId == other.remoteId && (remoteId != null || channelName == other.channelName)
    fun matches(channel: ChannelEntity): Boolean = sourceId == channel.sourceId &&
        (isPlaylist || if (remoteId != null) remoteId == channel.remoteId else channelName == channel.name)

    companion object {
        const val MAX_ENTRIES = 20_000
        const val MAX_TEMPLATES = 3
        const val MAX_TEMPLATE_LENGTH = 4096
        private val token = Regex("\\$?\\{([A-Za-z_][A-Za-z0-9_-]*)\\}")
        private val supported = setOf("start", "utc", "timestamp", "start-timestamp", "utcstart", "end", "utcend", "end-timestamp", "stop", "duration", "offset", "lutc", "now", "timenow", "currenttime", "Y", "m", "d", "H", "M", "S", "streamId", "username", "password")
        fun isValidTemplate(value: String): Boolean {
            if (value.length !in 1..MAX_TEMPLATE_LENGTH || value.any { it.isWhitespace() }) return false
            if (!value.startsWith("https://", true) && !value.startsWith("http://", true)) return false
            val tokens = token.findAll(value).map { it.groupValues[1] }.toSet()
            if (tokens.any { it !in supported }) return false
            if (tokens.none { it in setOf("start", "utc", "timestamp", "start-timestamp", "utcstart") } &&
                !tokens.containsAll(setOf("Y", "m", "d", "H", "M"))) return false
            if (tokens.none { it in setOf("end", "utcend", "end-timestamp", "stop", "duration") }) return false
            val replaced = value.replace(token, "1")
            return runCatching { java.net.URI(replaced).let { it.host != null && it.userInfo == null && it.fragment == null } }.getOrDefault(false)
        }
        fun resolve(rows: List<ArchivePlaybackConfig>, channel: ChannelEntity): ArchivePlaybackConfig? =
            rows.firstOrNull { !it.isPlaylist && it.matches(channel) }
                ?: rows.firstOrNull { it.isPlaylist && it.matches(channel) }
        fun decode(raw: String?): List<ArchivePlaybackConfig> = runCatching {
            val array = JSONArray(raw ?: return emptyList())
            (0 until minOf(array.length(), MAX_ENTRIES)).mapNotNull { i ->
                val row = array.optJSONObject(i) ?: return@mapNotNull null
                val source = row.optLong("sourceId", -1).takeIf { it > 0 } ?: return@mapNotNull null
                val templates = row.optJSONArray("templates") ?: return@mapNotNull null
                val urls = (0 until minOf(templates.length(), MAX_TEMPLATES)).mapNotNull {
                    (templates.opt(it) as? String)?.trim()?.takeIf(::isValidTemplate)
                }.distinct()
                if (urls.isEmpty()) return@mapNotNull null
                ArchivePlaybackConfig(source,
                    row.optString("remoteId").takeIf { it.isNotBlank() },
                    row.optString("channelName").takeIf { it.isNotBlank() }, urls,
                    row.optString("manifestType").takeIf { it == "hls" || it == "mpd" })
            }.distinctBy { Triple(it.sourceId, it.remoteId, if (it.remoteId == null) it.channelName else null) }
        }.getOrDefault(emptyList())
        fun encode(rows: List<ArchivePlaybackConfig>): String = JSONArray().apply {
            rows.take(MAX_ENTRIES).filter { it.sourceId > 0 && it.templates.isNotEmpty() }.forEach { row ->
                val urls = row.templates.map(String::trim).filter(::isValidTemplate).distinct().take(MAX_TEMPLATES)
                if (urls.isNotEmpty()) put(JSONObject().put("sourceId", row.sourceId)
                    .putOpt("remoteId", row.remoteId).putOpt("channelName", row.channelName)
                    .put("templates", JSONArray(urls)).putOpt("manifestType", row.manifestType))
            }
        }.toString()
        fun remap(rows: List<ArchivePlaybackConfig>, sources: Map<Long, Long>): List<ArchivePlaybackConfig> =
            rows.mapNotNull { row -> sources[row.sourceId]?.let { row.copy(sourceId = it) } }
    }
}
