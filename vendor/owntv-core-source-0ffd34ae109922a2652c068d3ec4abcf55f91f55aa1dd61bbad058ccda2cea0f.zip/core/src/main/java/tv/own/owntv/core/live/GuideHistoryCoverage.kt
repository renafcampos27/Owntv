package tv.own.owntv.core.live

/** Only fetch a missing historical prefix; current/future gaps need no archive request. */
internal object GuideHistoryCoverage {
    fun missingPrefix(from: Long, to: Long, firstStoredStart: Long?, now: Long): Pair<Long, Long>? {
        if (to <= from || firstStoredStart == null || from >= now - 6 * 3_600_000L) return null
        val end = minOf(to, firstStoredStart)
        return if (end > from) from to end else null
    }
}
