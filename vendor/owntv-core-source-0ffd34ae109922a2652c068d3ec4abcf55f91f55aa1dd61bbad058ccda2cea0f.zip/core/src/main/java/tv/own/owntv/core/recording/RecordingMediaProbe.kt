package tv.own.owntv.core.recording

/** Refuse error pages and playlist text before writing them as a supposedly playable capture. */
object RecordingMediaProbe {
    fun isErrorDocument(prefix: ByteArray): Boolean {
        val text = prefix.toString(Charsets.UTF_8).trimStart('\uFEFF', ' ', '\t', '\r', '\n').lowercase()
        return text.startsWith("<!doctype") || text.startsWith("<html") || text.startsWith("<?xml") ||
            text.startsWith("{\"") || text.startsWith("#extm3u")
    }
}
