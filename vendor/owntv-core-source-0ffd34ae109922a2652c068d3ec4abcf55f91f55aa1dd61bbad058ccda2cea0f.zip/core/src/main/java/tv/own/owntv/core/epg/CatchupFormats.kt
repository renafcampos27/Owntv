package tv.own.owntv.core.epg

enum class CatchupFormat { AUTO, TS, HLS }

/** Bounded Xtream archive candidates; timestamps, stream and duration are never changed. */
object CatchupFormats {
    fun initial(url: String, mode: CatchupFormat): String = when (mode) {
        CatchupFormat.AUTO -> url
        CatchupFormat.TS -> CatchupUrl.timeshiftFormat(url, "ts") ?: url
        CatchupFormat.HLS -> CatchupUrl.timeshiftFormat(url, "m3u8") ?: url
    }

    fun candidates(original: String, mode: CatchupFormat): List<String> {
        val ts = CatchupUrl.timeshiftFormat(original, "ts") ?: return listOf(original)
        val hls = CatchupUrl.timeshiftFormat(original, "m3u8") ?: return listOf(original)
        val php = CatchupUrl.timeshiftPhpAlternate(ts)
        return when (mode) {
            CatchupFormat.TS -> listOfNotNull(ts, php)
            CatchupFormat.HLS -> listOf(hls)
            CatchupFormat.AUTO -> if (original == hls) listOfNotNull(hls, ts, php)
                else listOfNotNull(ts, php, hls)
        }.distinct()
    }

    fun next(original: String?, current: String?, mode: CatchupFormat, beforePlayback: Boolean,
        httpStatus: Int?, malformed: Boolean): String? {
        if (!beforePlayback || original == null || current == null) return null
        // Never mask auth, session-limit, expiry, network or server errors with a new format.
        if (httpStatus != null && httpStatus !in setOf(404, 405, 415)) return null
        if (httpStatus == null && !malformed) return null
        val options = candidates(original, mode)
        val index = options.indexOf(current)
        return if (index < 0) null else options.getOrNull(index + 1)
    }
}
