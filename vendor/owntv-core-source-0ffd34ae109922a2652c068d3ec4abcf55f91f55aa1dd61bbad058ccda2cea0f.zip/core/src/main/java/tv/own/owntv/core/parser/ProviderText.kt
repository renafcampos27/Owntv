package tv.own.owntv.core.parser

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Base64

internal fun decodeProviderText(original: String): String {
    val compact = original.filterNot(Char::isWhitespace)
    if (compact.length < 4 || compact.length % 4 == 1 || !compact.matches(Regex("[A-Za-z0-9+/]*={0,2}"))) return original
    return runCatching {
        val bytes = Base64.getDecoder().decode(compact)
        val decoded = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString().trim()
        val canonical = Base64.getEncoder().encodeToString(bytes).trimEnd('=')
        if (canonical != compact.trimEnd('=') || decoded.isBlank() ||
            decoded.any { (it.isISOControl() && it !in "\n\r\t") || it == '\uFFFD' } ||
            decoded.none(Char::isLetterOrDigit)) original else decoded
    }.getOrDefault(original)
}

/** BOM is authoritative; otherwise UTF-8 is strict, so a wrong charset cannot silently corrupt IDs. */
internal fun playlistReader(input: java.io.InputStream): java.io.BufferedReader {
    val stream = java.io.PushbackInputStream(input, 3)
    val prefix = ByteArray(3)
    var count = 0
    while (count < prefix.size) {
        val n = stream.read(prefix, count, prefix.size - count)
        if (n < 0) break
        if (n == 0) { val b = stream.read(); if (b < 0) break; prefix[count++] = b.toByte() } else count += n
    }
    val utf8 = count >= 3 && prefix[0] == 0xEF.toByte() && prefix[1] == 0xBB.toByte() && prefix[2] == 0xBF.toByte()
    val le = count >= 2 && prefix[0] == 0xFF.toByte() && prefix[1] == 0xFE.toByte()
    val be = count >= 2 && prefix[0] == 0xFE.toByte() && prefix[1] == 0xFF.toByte()
    val skip = if (utf8) 3 else if (le || be) 2 else 0
    if (count > skip) stream.unread(prefix, skip, count - skip)
    val charset = if (le) Charsets.UTF_16LE else if (be) Charsets.UTF_16BE else Charsets.UTF_8
    return java.io.InputStreamReader(stream, charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)).buffered()
}
