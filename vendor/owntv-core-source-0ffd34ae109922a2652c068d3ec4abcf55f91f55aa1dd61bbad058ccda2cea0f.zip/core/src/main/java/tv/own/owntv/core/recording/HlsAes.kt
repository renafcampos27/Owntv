package tv.own.owntv.core.recording

import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/** AES-128 HLS segments, not SAMPLE-AES/DRM. Decryption is streamed to bounded disk storage. */
object HlsAes {
    fun ivFor(key: HlsMediaPlaylist.Key, sequence: Long): ByteArray {
        val text = key.iv?.removePrefix("0x")?.removePrefix("0X")
        if (text != null) {
            require(text.length == 32 && text.all { it.digitToIntOrNull(16) != null })
            return ByteArray(16) { text.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        }
        require(sequence >= 0)
        return ByteBuffer.allocate(16).putLong(0).putLong(sequence).array()
    }
    fun decryptFile(file: File, key: ByteArray, iv: ByteArray, checkActive: () -> Unit = {}) {
        require(key.size == 16 && iv.size == 16)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        val clear = File(file.parentFile, file.name + ".clear")
        try {
            file.inputStream().use { input -> FileOutputStream(clear).use { out ->
                val buffer = ByteArray(32 * 1024)
                while (true) {
                    checkActive()
                    val read = input.read(buffer)
                    if (read < 0) break
                    cipher.update(buffer, 0, read)?.let { out.write(it) }
                }
                out.write(cipher.doFinal())
                out.fd.sync()
            } }
            checkActive()
            Files.move(clear.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } finally { clear.delete() }
    }
}
