package tv.own.owntv.core.nav

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import tv.own.owntv.core.database.dao.ChannelDao
import tv.own.owntv.core.database.dao.MovieDao
import tv.own.owntv.core.database.dao.SeriesDao
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.repository.SourceRepository
import tv.own.owntv.core.settings.SettingsRepository

/**
 * Which nav destinations to show, for whichever app is asking.
 *
 * - **STATIC** (the default): every browse item minus the set the user hid.
 * - **DYNAMIC**: derived from the active playlist's content — see [MainSection.dynamicVisible].
 *   When the source picker is on "All playlists" (`defaultSourceId <= 0`) the counts are unioned
 *   across the profile's sources, so a VOD-only playlist still hides Live in the merged view.
 *   Per-section Off flags drop a section even when cached rows for it remain.
 *
 * The counts come from the reactive `countAll` DAO flows, which Room re-emits on every write, so the
 * nav updates itself right after a sync with no probe call.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class NavVisibility(
    private val settings: SettingsRepository,
    private val sourceRepository: SourceRepository,
    private val channelDao: ChannelDao,
    @Suppress("UNUSED_PARAMETER") movieDao: MovieDao,
    @Suppress("UNUSED_PARAMETER") seriesDao: SeriesDao,
) {

    /** What the nav shows right now, honouring the user's mode, hidden set, and liveTvOnlyMode. */
    fun visibleSections(): Flow<Set<MainSection>> = combine(
        settings.navMenuMode,
        settings.liveTvOnlyMode,
    ) { mode, liveOnly -> mode to liveOnly }
        .flatMapLatest { (mode, liveOnly) ->
            navigationSections(mode, liveOnly, settings.navMenuHidden, ::dynamicCaps)
        }
        .distinctUntilChanged()

    /** The set DYNAMIC mode *would* show. Also what the settings screen's read-only rows report, so
     *  the two can never disagree about what DYNAMIC means. */
    fun dynamicCaps(): Flow<Set<MainSection>> = settings.activeProfileId
        .flatMapLatest { pid ->
            if (pid < 0) flowOf(MainSection.allBrowse)
            else sourceRepository.observeSources(pid).flatMapLatest { sources ->
                settings.defaultSourceId.flatMapLatest { defaultId -> capsFlow(sources, defaultId) }
            }
        }

    private fun capsFlow(sources: List<SourceEntity>, defaultId: Long): Flow<Set<MainSection>> {
        val scoped = if (defaultId > 0) sources.filter { it.id == defaultId } else sources
        if (scoped.isEmpty()) return flowOf(setOf(MainSection.HOME, MainSection.DOWNLOADS))
        val liveIds = scoped.filter { it.syncLive }.map { it.id }
        // Empty id lists would make countAll misbehave — use a sentinel that matches nothing.
        val empty = listOf(-1L)
        return channelDao.countAll(liveIds.ifEmpty { empty }).map { channels ->
            MainSection.dynamicVisible(
                hasLive = liveIds.isNotEmpty() && channels > 0,
                hasMovies = false,
                hasSeries = false,
            )
        }
    }
}

/** STATIC must never subscribe to playlist/content queries; keep the dynamic factory lazy. */
internal fun navigationSections(
    mode: SettingsRepository.NavMenuMode,
    liveOnly: Boolean,
    hidden: Flow<Set<String>>,
    dynamic: () -> Flow<Set<MainSection>>,
): Flow<Set<MainSection>> {
    val base = when (mode) {
        SettingsRepository.NavMenuMode.STATIC -> hidden.map { names ->
            MainSection.allBrowse - names.mapNotNull { name ->
                runCatching { MainSection.valueOf(name) }.getOrNull()
            }.toSet()
        }
        SettingsRepository.NavMenuMode.DYNAMIC -> dynamic()
    }
    return base.map { sections ->
        if (liveOnly) sections - setOf(MainSection.MOVIES, MainSection.SERIES) else sections
    }
}
