package tv.own.owntv.core.customize

/** Replace the visible rail's order at its first saved position, retaining other playlists and hides. */
internal fun mergeCategoryOrder(stored: List<String>, onScreen: List<String>): List<String> {
    val ordered = onScreen.distinct()
    val shown = ordered.toSet()
    val saved = stored.distinct()
    val firstShown = saved.indexOfFirst { it in shown }
    val rest = saved.filterNot { it in shown }
    val at = if (firstShown < 0) rest.size else saved.take(firstShown).count { it !in shown }
    return rest.take(at) + ordered + rest.drop(at)
}
