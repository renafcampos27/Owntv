package tv.own.owntv.core.backup

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray

/** Coordinates the entire read/resolve/replace cycle, not just the final DataStore edit. */
internal class PendingUserDataQueue(
    private val read: suspend () -> String?,
    private val write: suspend (String?) -> Unit,
    private val mutex: Mutex = Mutex(),
) {
    suspend fun append(extra: JSONArray) = mutex.withLock {
        val entries = read()?.let { JSONArray(it) } ?: JSONArray()
        val seen = (0 until entries.length()).mapTo(HashSet()) { entries.getJSONObject(it).toString() }
        for (i in 0 until extra.length()) {
            val entry = extra.getJSONObject(i)
            if (seen.add(entry.toString())) entries.put(entry)
        }
        write(entries.toString())
    }

    /** The resolver may access Room; no DataStore edit is held while it does so. */
    suspend fun resolve(resolver: suspend (JSONArray) -> Pair<JSONArray, Int>): Int = mutex.withLock {
        val raw = read() ?: return@withLock 0
        val entries = JSONArray(raw)
        if (entries.length() == 0) return@withLock 0
        val (remaining, refused) = resolver(entries)
        write(remaining.takeIf { it.length() > 0 }?.toString())
        refused
    }
}
