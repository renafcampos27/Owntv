package tv.own.owntv.core.backup

import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Field-level secret encryption for backups (NOT whole-file encryption — only individual secret values).
 *
 * Only individual secret values (source/proxy passwords) are encrypted; everything else in the backup
 * JSON stays human-readable — whole-file protection is [BackupContainer]'s job, which seals the
 * container with the same passphrase. A user-supplied passphrase is stretched with PBKDF2 over a
 * per-backup random salt (so the file is portable across devices — no Android Keystore), then each
 * field is sealed with AES-256-GCM using a fresh random IV. The GCM tag authenticates both the value
 * and lets us detect a wrong passphrase (decrypt throws) without ever comparing the passphrase itself.
 *
 * Detection on import: a secret stored as a JSON string is legacy plaintext (v5); a secret stored as a
 * JSON object `{ "iv":..., "ct":... }` is encrypted. The root `crypto` block carries the KDF params.
 *
 * Logging rule: this class never logs the passphrase, derived key, plaintext, or ciphertext.
 */
object BackupCrypto {
    const val SCHEME = "field-aes-gcm"
    const val KDF = "PBKDF2WithHmacSHA256"
    const val ITERATIONS = 210_000
    internal const val MAX_ITERATIONS = 2_000_000
    private const val SALT_BYTES = 16
    private const val MIN_SALT_BYTES = 8
    private const val MAX_SALT_BYTES = 64
    private const val IV_BYTES = 12
    private const val KEY_BITS = 256
    private const val GCM_TAG_BITS = 128
    private const val MAX_FIELD_CIPHERTEXT_BYTES = 16 * 1024 * 1024

    private val rng = SecureRandom()

    private fun b64(bytes: ByteArray): String = java.util.Base64.getEncoder().encodeToString(bytes)
    /** Bound before decoding; permit historical line wrapping, but not arbitrary MIME junk. */
    private fun unb64(value: String, maximumBytes: Int): ByteArray {
        val maximumEncoded = 4L * ((maximumBytes.toLong() + 2L) / 3L) + 1024L
        require(value.length.toLong() <= maximumEncoded) { "Invalid encrypted backup field" }
        val compact = value.filterNot { it == ' ' || it == '\r' || it == '\n' || it == '\t' }
        require(compact.length.toLong() <= 4L * ((maximumBytes.toLong() + 2L) / 3L)) {
            "Invalid encrypted backup field"
        }
        val bytes = java.util.Base64.getDecoder().decode(compact)
        require(bytes.size <= maximumBytes) { "Invalid encrypted backup field" }
        return bytes
    }

    /** A fresh random salt for a new backup. */
    fun newSalt(): ByteArray = ByteArray(SALT_BYTES).also { rng.nextBytes(it) }

    /** Builds the root `crypto` metadata block for the given salt. */
    fun cryptoBlock(salt: ByteArray): JSONObject = JSONObject().apply {
        put("scheme", SCHEME)
        put("kdf", KDF)
        put("iterations", ITERATIONS)
        put("salt", b64(salt))
    }

    /** Derives the AES key from a passphrase + the backup's salt/iterations. */
    fun deriveKey(passphrase: CharArray, salt: ByteArray, iterations: Int): SecretKey {
        require(iterations in 1..MAX_ITERATIONS && salt.size in MIN_SALT_BYTES..MAX_SALT_BYTES) {
            "Invalid backup encryption metadata"
        }
        val spec = PBEKeySpec(passphrase, salt, iterations, KEY_BITS)
        return try {
            val factory = SecretKeyFactory.getInstance(KDF)
            SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    /**
     * Returns null for malformed metadata, before expensive key derivation. The whole-container
     * reader supplies its own scheme; field encryption is the default for legacy JSON callers.
     * Every supported writer emits these four fields, so missing or coerced values are not defaults.
     */
    fun deriveKey(passphrase: String, crypto: JSONObject?, expectedScheme: String = SCHEME): SecretKey? {
        crypto ?: return null
        if (crypto.opt("scheme") != expectedScheme || crypto.opt("kdf") != KDF) return null
        // optInt accepts strings/fractions and can narrow overflowing longs. Metadata must instead
        // contain an actual bounded JSON integer, including when constructed programmatically.
        val value = crypto.opt("iterations")
        val iterations: Long
        if (value is Int) iterations = value.toLong()
        else if (value is Long) iterations = value
        else return null
        if (iterations !in 1L..MAX_ITERATIONS.toLong()) return null
        val encodedSalt = crypto.opt("salt") as? String ?: return null
        val salt = runCatching { unb64(encodedSalt, MAX_SALT_BYTES) }.getOrNull() ?: return null
        if (salt.size !in MIN_SALT_BYTES..MAX_SALT_BYTES) return null
        return deriveKey(passphrase.toCharArray(), salt, iterations.toInt())
    }

    /** Seals a plaintext secret into a `{ "iv":..., "ct":... }` object. */
    fun encrypt(key: SecretKey, plaintext: String): JSONObject {
        val iv = ByteArray(IV_BYTES).also { rng.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        val ct = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return JSONObject().put("iv", b64(iv)).put("ct", b64(ct))
    }

    /**
     * Seals arbitrary bytes, returning `iv || ciphertext` as one blob — used by [BackupContainer] to
     * encrypt the WHOLE `.own` container, not just individual fields. The IV rides in front because a
     * container has nowhere to put a JSON wrapper: everything after the plaintext header is opaque.
     */
    fun encryptBytes(key: SecretKey, plaintext: ByteArray): ByteArray {
        val iv = ByteArray(IV_BYTES).also { rng.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return iv + cipher.doFinal(plaintext)
    }

    /**
     * Opens an [encryptBytes] blob (or slice `[offset, offset + length)`). Throws on a wrong
     * passphrase (GCM tag mismatch) or truncation.
     */
    fun decryptBytes(
        key: SecretKey,
        blob: ByteArray,
        offset: Int = 0,
        length: Int = blob.size - offset,
    ): ByteArray {
        require(offset >= 0 && length >= IV_BYTES + GCM_TAG_BITS / 8 && offset <= blob.size - length) { "Truncated encrypted backup" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, blob, offset, IV_BYTES))
        return cipher.doFinal(blob, offset + IV_BYTES, length - IV_BYTES)
    }

    /** True if [value] is an encrypted secret object (vs a legacy plaintext string). */
    fun isEncrypted(value: Any?): Boolean = value is JSONObject && value.has("iv") && value.has("ct")

    /**
     * Opens a sealed secret object. Throws on a wrong passphrase (GCM tag mismatch) or malformed input —
     * callers use this both to validate the passphrase and to decrypt.
     */
    fun decrypt(key: SecretKey, sealed: JSONObject): String {
        val encodedIv = sealed.opt("iv") as? String ?: error("Invalid encrypted backup field")
        val encodedCt = sealed.opt("ct") as? String ?: error("Invalid encrypted backup field")
        val iv = unb64(encodedIv, IV_BYTES)
        require(iv.size == IV_BYTES) { "Invalid encrypted backup nonce" }
        val ct = unb64(encodedCt, MAX_FIELD_CIPHERTEXT_BYTES)
        require(ct.size >= GCM_TAG_BITS / 8) { "Truncated encrypted backup field" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return String(cipher.doFinal(ct), Charsets.UTF_8)
    }
}
