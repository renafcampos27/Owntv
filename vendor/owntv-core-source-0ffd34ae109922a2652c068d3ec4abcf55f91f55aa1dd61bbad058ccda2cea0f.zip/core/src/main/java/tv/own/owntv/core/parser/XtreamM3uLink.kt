package tv.own.owntv.core.parser

import java.net.URI
import java.net.URLDecoder

/** Import-time interpretation only; never rewrites an existing source or playback URL. */
data class XtreamM3uLink(
    val server: String,
    val username: String,
    val password: String,
    val preferHls: Boolean,
) {
    companion object {
        fun clean(url: String): String = url.trim().replace("&amp;", "&", ignoreCase = true)

        fun parse(url: String): XtreamM3uLink? {
            val uri = runCatching { URI(clean(url)) }.getOrNull() ?: return null
            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") return null
            val authority = uri.rawAuthority?.takeIf { it.isNotBlank() } ?: return null
            if (uri.rawUserInfo != null || uri.host.isNullOrBlank()) return null
            val path = uri.rawPath.orEmpty()
            if (!path.endsWith("/get.php", ignoreCase = true)) return null
            val params = uri.rawQuery.orEmpty().split('&').mapNotNull { pair ->
                val key = pair.substringBefore('=').takeIf { it.isNotBlank() } ?: return@mapNotNull null
                key.lowercase() to URLDecoder.decode(pair.substringAfter('=', ""), "UTF-8")
            }.toMap()
            val username = params["username"]?.takeIf { it.isNotBlank() } ?: return null
            val password = params["password"]?.takeIf { it.isNotBlank() } ?: return null
            return XtreamM3uLink(
                server = "$scheme://$authority${path.dropLast("/get.php".length)}",
                username = username,
                password = password,
                preferHls = params["output"]?.lowercase() in setOf("m3u8", "hls"),
            )
        }
    }
}
