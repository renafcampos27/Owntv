package tv.own.owntv.core.database.dao

import tv.own.owntv.core.database.entity.ContentOrderEntity
import tv.own.owntv.core.model.MediaType

/** Keep hidden/inactive items in their existing relative order after the edited items. */
internal fun mergeContentOrder(
    profileId: Long, type: MediaType, contextKey: String,
    itemIds: List<Long>, existing: List<ContentOrderEntity>,
): List<ContentOrderEntity> {
    val edited = itemIds.distinct()
    val editedIds = edited.toHashSet()
    val retained = existing.filter {
        it.profileId == profileId && it.mediaType == type && it.contextKey == contextKey && it.itemId !in editedIds
    }.sortedBy { it.position }
    return edited.mapIndexed { index, id ->
        ContentOrderEntity(profileId = profileId, mediaType = type, contextKey = contextKey, itemId = id, position = index)
    } + retained.mapIndexed { index, row -> row.copy(position = edited.size + index) }
}
