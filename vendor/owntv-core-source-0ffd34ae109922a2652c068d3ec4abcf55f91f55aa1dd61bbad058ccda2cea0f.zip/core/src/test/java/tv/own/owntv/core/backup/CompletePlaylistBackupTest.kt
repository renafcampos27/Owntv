package tv.own.owntv.core.backup

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class CompletePlaylistBackupTest {
    // Synthetic secrets only; the production encryption is tested separately.
    private val seal: (String) -> JSONObject = { JSONObject().put("ct", it.reversed()) }

    @Test fun `protected export includes every persisted playlist field and recoverable credentials`() {
        val source = SourceEntity(id = 7, name = "My playlist", type = SourceType.XTREAM,
            url = "https://provider.example", username = "test-user", password = "synthetic-password",
            userAgent = "TestAgent", epgUrl = "https://provider.example/guide.xml",
            preferHls = true, livePrerollSecs = 5, liveEnginePreference = "EXO",
            liveLatencyMode = "CUSTOM", liveLatencyCustomSecs = 10,
            liveReserveMode = "CUSTOM", liveReserveCustomSecs = 12, liveReserveExtraSecs = 3,
            catchupTimezone = "Europe/Lisbon", catchupOffsetMin = 60,
            liveTuneTimeoutSecs = 15, httpReferer = "https://provider.example/?token=synthetic",
            createdAt = 123, lastSyncAt = 456)
        val restoredTransport = JSONObject(BackupManager.encodeSource(source, seal).toString())
        val fields = SourceEntity::class.java.declaredFields
            .filterNot { it.isSynthetic || it.name == "\$stable" }
        for (field in fields) {
            assertTrue("Missing playlist field: ${field.name}", restoredTransport.has(field.name))
            field.isAccessible = true
            val expected = field.get(source)
            val value = restoredTransport.opt(field.name)
            when {
                expected == null -> assertTrue(restoredTransport.isNull(field.name))
                field.name in setOf("password", "httpReferer") ->
                    assertEquals(expected, (value as JSONObject).getString("ct").reversed())
                expected is Enum<*> && field.name == "hlsSupported" -> Unit // stable numeric wire code
                expected is Enum<*> -> assertEquals(expected.name, value)
                else -> assertEquals(expected.toString(), value?.toString())
            }
        }
        assertFalse(restoredTransport.toString().contains("synthetic-password"))
        assertFalse(restoredTransport.toString().contains("token=synthetic"))
    }

    @Test fun `playlist refresh interval keeps its value when restored source ids differ`() {
        val source = JSONObject().put("7", "HOURS_6").put("99", "OFF")
        val scoped = filterBySourceId(source, setOf(7L))
        val restored = remapKeys(JSONObject(scoped.toString()), mapOf(7L to 42L))
        assertEquals("HOURS_6", restored.getString("42"))
        assertFalse(restored.has("7"))
        assertFalse(restored.has("99"))
    }
}