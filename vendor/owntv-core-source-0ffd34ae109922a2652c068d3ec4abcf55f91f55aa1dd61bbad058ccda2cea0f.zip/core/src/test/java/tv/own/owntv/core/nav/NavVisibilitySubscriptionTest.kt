package tv.own.owntv.core.nav

import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test
import tv.own.owntv.core.settings.SettingsRepository

class NavVisibilitySubscriptionTest {
    @Test fun staticModeDoesNotCreateContentQueriesAndStillTracksHiddenSections() = runBlocking {
        val emissions = navigationSections(
            SettingsRepository.NavMenuMode.STATIC,
            liveOnly = true,
            hidden = flowOf(emptySet(), setOf(MainSection.EPG.name, "obsolete")),
            dynamic = { error("STATIC must not query playlist content") },
        ).toList()
        assertEquals(listOf(MainSection.allBrowse, MainSection.allBrowse - MainSection.EPG), emissions)
    }

    @Test fun dynamicModeTracksContentWithoutSubscribingToHiddenPreferences() = runBlocking {
        val noChannels = MainSection.dynamicVisible(false, false, false)
        val withChannels = MainSection.dynamicVisible(true, false, false)
        val emissions = navigationSections(
            SettingsRepository.NavMenuMode.DYNAMIC,
            liveOnly = true,
            hidden = kotlinx.coroutines.flow.flow { error("Hidden preferences do not affect DYNAMIC") },
            dynamic = { flowOf(noChannels, withChannels) },
        ).toList()
        assertEquals(listOf(noChannels, withChannels), emissions)
    }
}
