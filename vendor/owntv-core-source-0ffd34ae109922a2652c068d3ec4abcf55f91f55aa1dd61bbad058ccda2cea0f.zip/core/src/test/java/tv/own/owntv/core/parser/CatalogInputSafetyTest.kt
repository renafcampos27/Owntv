package tv.own.owntv.core.parser

import java.io.ByteArrayInputStream
import java.io.IOException
import java.util.zip.GZIPOutputStream
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import okhttp3.HttpUrl.Companion.toHttpUrl

class CatalogInputSafetyTest {
    private val source = SourceEntity(name = "Test", type = SourceType.XTREAM, url = "https://host.invalid:8080/panel/",
        username = "a b/+?#%", password = "p+/%&")

    @Test fun credentialsAndProviderIdsAreSinglePathSegments() {
        val url = XtreamClient(HttpClient(OkHttpClient())).liveUrl(source, "id/a?x=1").toHttpUrl()
        assertEquals(listOf("panel", "live", source.username, source.password, "id/a?x=1.ts"), url.pathSegments)
        assertNull(url.query)
        assertNull(url.fragment)
        assertTrue(url.encodedPath.contains("%2F"))
    }
    @Test fun queryCredentialsAreEncodedOnceWithoutLosingSubdirectory() {
        val url = XtreamClient(HttpClient(OkHttpClient())).xmltvUrl(source).toHttpUrl()
        assertEquals("/panel/xmltv.php", url.encodedPath)
        assertEquals(source.username, url.queryParameter("username"))
        assertEquals(source.password, url.queryParameter("password"))
        assertEquals(8080, url.port)
    }
    @Test fun literalPercentEncodingInCredentialsRemainsLiteral() {
        val url = XtreamClient(HttpClient(OkHttpClient())).liveUrl(source.copy(username = "u%2Fv"), "1").toHttpUrl()
        assertEquals("u%2Fv", url.pathSegments[2])
        assertTrue(url.encodedPath.contains("u%252Fv"))
    }
    @Test fun archiveTimestampAndCorrectionsAreNotChangedByEncoding() {
        val url = XtreamClient(HttpClient(OkHttpClient())).timeshiftUrl(source, "7", 0, 60).toHttpUrl()
        assertEquals(listOf("60", "1970-01-01:00-00", "7.ts"), url.pathSegments.takeLast(3))
    }
    @Test fun ordinaryTitlesRemainIntactAndEncodedAccentedTitlesDecode() {
        listOf("News", "Test", "Live", "SIC HD", "RTP 1").forEach { assertEquals(it, decodeProviderText(it)) }
        assertEquals("Notícias", decodeProviderText(java.util.Base64.getEncoder().encodeToString("Notícias".toByteArray())))
        assertEquals("//8=", decodeProviderText("//8="))
        assertEquals("AAE=", decodeProviderText("AAE="))
    }
    @Test fun gzipSignatureWorksWhenUnderlyingReadsReturnOneByte() {
        val bytes = java.io.ByteArrayOutputStream().also { out -> GZIPOutputStream(out).use { it.write("<tv/>".toByteArray()) } }.toByteArray()
        val input = object : ByteArrayInputStream(bytes) {
            override fun read(b: ByteArray, off: Int, len: Int) = super.read(b, off, minOf(len, 1))
        }
        assertEquals("<tv/>", XmltvParser.maybeGunzip(input).reader().readText())
        assertEquals("x", XmltvParser.maybeGunzip("x".byteInputStream()).reader().readText())
    }
    @Test fun utf8AndUtf16BomAreAuthoritative() = runBlocking {
        val text = "#EXTM3U\n#EXTINF:-1,Notícias\nhttps://host.invalid/1.m3u8\n"
        for (bytes in listOf(text.toByteArray(), byteArrayOf(0xEF.toByte(),0xBB.toByte(),0xBF.toByte()) + text.toByteArray(),
            byteArrayOf(0xFF.toByte(),0xFE.toByte()) + text.toByteArray(Charsets.UTF_16LE))) {
            val names = mutableListOf<String>()
            val header = M3uParser().parse(bytes.inputStream()) { names += it.name }
            assertEquals(listOf("Notícias"), names)
            assertEquals(1, header.acceptedEntries)
            assertEquals(0, header.rejectedEntries)
        }
    }
    @Test fun wrongCharsetAndIncompleteEntriesCannotSilentlyLookComplete() = runBlocking {
        val invalid = byteArrayOf(0xFF.toByte(), 0x20)
        assertTrue(runCatching { M3uParser().parse(invalid.inputStream()) { } }.isFailure)
        val header = M3uParser().parse("#EXTM3U\n#EXTINF:-1,Missing\n".byteInputStream()) { fail("No URL exists") }
        assertEquals(0, header.acceptedEntries)
        assertEquals(1, header.rejectedEntries)
    }
    @Test fun htmlAndEmptyListsDoNotInventChannels() = runBlocking {
        for (body in listOf("<html>error</html>", "#EXTM3U\n")) {
            assertEquals(0, M3uParser().parse(body.byteInputStream()) { fail("Invalid content") }.acceptedEntries)
        }
    }
    @Test fun provider503IsIndeterminateAndImportDoesNotFallBackToM3u() = runBlocking {
        val client = XtreamClient(HttpClient(OkHttpClient.Builder().addInterceptor { chain ->
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(503).message("Unavailable")
                .body("failure".toResponseBody()).build()
        }.build()))
        assertEquals(XtreamClient.AccountProbe.INDETERMINATE, client.probeXtreamAccount(source))
        assertTrue(runCatching { client.resolveM3uImport(source.copy(type = SourceType.M3U,
            url = "https://host.invalid/get.php?username=u&password=p"), true, true) }.exceptionOrNull() is IOException)
    }
}
