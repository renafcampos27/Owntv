package tv.own.owntv.core.settings

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.player.EnginePreference

class ChannelPlaybackConfigTest {
    private val ref = ManualTsChannel(7, "100", "Odisseia HD")
    @Test fun `round trip preserves explicit zero false and every override`() {
        val options = ChannelPlaybackOptions(EnginePreference.EXO_ONLY, ChannelStreamFormat.HLS, 12, 3, 0, 10, false, 0)
        val row = ChannelPlaybackConfig(ref, options)
        assertEquals(listOf(row), ChannelPlaybackConfig.decode(ChannelPlaybackConfig.encode(listOf(row))))
        assertFalse(options.isDefault)
        assertEquals(emptyList<ChannelPlaybackConfig>(), ChannelPlaybackConfig.decode(ChannelPlaybackConfig.encode(listOf(row.copy(options = ChannelPlaybackOptions())))))
    }
    @Test fun `invalid backup values cannot create an invalid buffer configuration`() {
        val bounded = ChannelPlaybackOptions(reserveSecs = -100, extraSecs = 999, prerollSecs = 999, latencySecs = -3, audioDelayMs = 999999).normalized()
        assertEquals(ChannelPlaybackOptions(reserveSecs = 1, extraSecs = LiveBuffer.MAX_EXTRA_SECS, prerollSecs = 10, latencySecs = 1, audioDelayMs = 5000), bounded)
        val load = LiveBuffer.loadControlFor(bounded.reserveSecs, bounded.prerollSecs!!, bounded.extraSecs!!)
        assertTrue(load.minBufferMs >= load.bufferForPlaybackMs)
        assertTrue(load.maxBufferMs >= load.minBufferMs)
        assertTrue(ChannelPlaybackConfig.decode("broken").isEmpty())
    }
    @Test fun `legacy TS choices migrate without overriding newer channel options`() {
        val migrated = ChannelPlaybackConfig.includeLegacy(emptyList(), listOf(ref)).single()
        assertEquals(ChannelStreamFormat.TS, migrated.options.format)
        val newer = ChannelPlaybackConfig(ref, ChannelPlaybackOptions(format = ChannelStreamFormat.HLS))
        assertEquals(listOf(newer), ChannelPlaybackConfig.includeLegacy(listOf(newer), listOf(ref)))
    }
    @Test fun `restoration remaps source identity and ignores unknown sources`() {
        val row = ChannelPlaybackConfig(ref, ChannelPlaybackOptions(reserveSecs = 15))
        val restored = ChannelPlaybackConfig.remap(listOf(row), mapOf(7L to 42L)).single()
        assertEquals(42L, restored.channel.sourceId)
        assertEquals(row.options, restored.options)
        assertTrue(ChannelPlaybackConfig.remap(listOf(row), emptyMap()).isEmpty())
    }
    @Test fun `only an explicit channel mpv choice bypasses the inherited strict HLS engine`() {
        val defaults = ChannelPlaybackOptions(engine = EnginePreference.MPV_ONLY)
        assertTrue(defaults.hlsOnly(true))
        assertEquals(EnginePreference.MPV_ONLY, defaults.effectiveEngine(EnginePreference.MPV_FIRST, defaults.hlsOnly(true), false))
        assertEquals(EnginePreference.EXO_ONLY, ChannelPlaybackOptions().effectiveEngine(EnginePreference.MPV_ONLY, true, false))
        assertEquals(EnginePreference.EXO_ONLY, defaults.copy(engine = EnginePreference.MPV_FIRST).effectiveEngine(EnginePreference.MPV_ONLY, true, false))
        val automatic = defaults.copy(format = ChannelStreamFormat.AUTO)
        assertFalse(automatic.hlsOnly(true))
        assertEquals(EnginePreference.MPV_ONLY, automatic.effectiveEngine(EnginePreference.EXO_ONLY, automatic.hlsOnly(true), false))
        val ts = defaults.copy(format = ChannelStreamFormat.TS)
        assertFalse(ts.hlsOnly(true))
        assertEquals(EnginePreference.MPV_ONLY, ts.effectiveEngine(EnginePreference.EXO_FIRST, false, true))
    }
    @Test fun `HLS compatibility options preserve explicit false and default older backups to null`() {
        val options = ChannelPlaybackOptions(hlsDetectAccessUnits = true, hlsAllowNonIdrKeyframes = false, hlsPrepareFromSegments = true)
        val row = ChannelPlaybackConfig(ref, options)
        assertEquals(listOf(row), ChannelPlaybackConfig.decode(ChannelPlaybackConfig.encode(listOf(row))))
        val old = ChannelPlaybackConfig.decode("""[{"channel":{"sourceId":7,"remoteId":"100","name":"Odisseia HD"},"options":{"reserveSecs":12}}]""").single()
        assertNull(old.options.hlsDetectAccessUnits)
        assertNull(old.options.hlsAllowNonIdrKeyframes)
        assertNull(old.options.hlsPrepareFromSegments)
    }

    @Test fun `round trip with more than 1000 items preserves all items without data loss`() {
        val count = 1200
        val items = (1..count).map { i ->
            ChannelPlaybackConfig(
                ManualTsChannel(1L, "remote-$i", "Channel $i"),
                ChannelPlaybackOptions(reserveSecs = (i % 30) + 1)
            )
        }
        val encoded = ChannelPlaybackConfig.encode(items)
        val decoded = ChannelPlaybackConfig.decode(encoded)
        assertEquals(count, decoded.size)
        assertEquals(items, decoded)

        val manualChannels = (1..count).map { i -> ManualTsChannel(1L, "remote-$i", "Channel $i") }
        val manualEncoded = ManualTsChannel.encode(manualChannels)
        val manualDecoded = ManualTsChannel.decode(manualEncoded)
        assertEquals(count, manualDecoded.size)
        assertEquals(manualChannels, manualDecoded)
    }

    @Test fun `duplicate entries are deduplicated on encode and decode`() {
        val ch = ManualTsChannel(1L, "same", "Same Name")
        val item1 = ChannelPlaybackConfig(ch, ChannelPlaybackOptions(reserveSecs = 5))
        val item2 = ChannelPlaybackConfig(ch, ChannelPlaybackOptions(reserveSecs = 10))
        val encoded = ChannelPlaybackConfig.encode(listOf(item1, item2))
        val decoded = ChannelPlaybackConfig.decode(encoded)
        assertEquals(1, decoded.size)
    }

    @Test fun `batch patch preserves unaffected fields and global inheritance`() {
        val ch1 = ManualTsChannel(1L, "1", "Channel 1")
        val ch2 = ManualTsChannel(1L, "2", "Channel 2")

        // ch1 had mpv engine and 50ms audio delay
        val initial1 = ChannelPlaybackOptions(engine = EnginePreference.MPV_ONLY, audioDelayMs = 50)
        // ch2 had only preroll 3s, other fields inherited (null)
        val initial2 = ChannelPlaybackOptions(prerollSecs = 3)

        // Batch update: only change engine to EXO_ONLY
        val patchEngine: (ChannelPlaybackOptions) -> ChannelPlaybackOptions = { existing ->
            existing.copy(engine = EnginePreference.EXO_ONLY)
        }

        val updated1 = patchEngine(initial1)
        val updated2 = patchEngine(initial2)

        // ch1 engine changed, but audioDelayMs was preserved!
        assertEquals(EnginePreference.EXO_ONLY, updated1.engine)
        assertEquals(50, updated1.audioDelayMs)

        // ch2 engine changed, prerollSecs was preserved, and other fields remain null (inherited)!
        assertEquals(EnginePreference.EXO_ONLY, updated2.engine)
        assertEquals(3, updated2.prerollSecs)
        assertNull(updated2.audioDelayMs)
        assertNull(updated2.reserveSecs)

        // Setting a field back to null inherits global default
        val resetToInherit: (ChannelPlaybackOptions) -> ChannelPlaybackOptions = { existing ->
            existing.copy(engine = null)
        }
        val inherited2 = resetToInherit(updated2)
        assertNull(inherited2.engine)
        assertEquals(3, inherited2.prerollSecs) // preroll still kept
    }

    @Test fun `batch patch reset to default removes customized row`() {
        val ch = ManualTsChannel(1L, "1", "Channel 1")
        val initial = ChannelPlaybackConfig(ch, ChannelPlaybackOptions(reserveSecs = 10))
        val list = listOf(initial)

        val patchReset: (ChannelPlaybackOptions) -> ChannelPlaybackOptions = { _ ->
            ChannelPlaybackOptions() // reset all fields to inherited/default
        }

        val updatedOptions = patchReset(initial.options).normalized()
        assertTrue(updatedOptions.isDefault)

        val updatedList = list.mapNotNull {
            val res = patchReset(it.options).normalized()
            if (res.isDefault) null else ChannelPlaybackConfig(it.channel, res)
        }
        assertTrue(updatedList.isEmpty())
    }

    @Test fun `channel backup roundtrip preserves extended upper loading range`() {
        val row = ChannelPlaybackConfig(ref, ChannelPlaybackOptions(reserveSecs = 8, extraSecs = 52))
        val restored = ChannelPlaybackConfig.decode(ChannelPlaybackConfig.encode(listOf(row))).single()
        assertEquals(row, restored)
        val resolved = LiveBuffer.loadControlFor(restored.options.reserveSecs, 0, restored.options.extraSecs!!)
        assertEquals(8_000, resolved.minBufferMs)
        assertEquals(60_000, resolved.maxBufferMs)
    }
}
