package tv.own.owntv.core.recording

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.epg.EpgDedupe

class RecordingGuideDedupeTest {
    private fun programme(source: Long, start: Long, stop: Long) = EpgProgrammeEntity(
        sourceId = source, epgChannelId = "test", title = "News", startMs = start, stopMs = stop,
    )

    @Test fun sameShowingFromTwoFeedsSchedulesOnlyThePreferredFeed() {
        val own = programme(1, 600_000, 3_600_000)
        val other = programme(2, 900_000, 3_900_000)
        val guide = EpgDedupe.collapse(listOf(other, own), 1)
        val showings = RecordingRuleMatcher.showingsToSchedule(RecordingRuleMatcher.fold("News"), 10, guide, emptyList(), 0)
        assertEquals(listOf(own), showings)
    }

    @Test fun aRealRepeatIsKeptWhileBothFeedCopiesAreCollapsed() {
        val first = programme(1, 600_000, 3_600_000)
        val repeat = programme(1, 7_200_000, 10_800_000)
        val guide = EpgDedupe.collapse(listOf(programme(2, 900_000, 3_900_000), repeat, first,
            programme(2, 7_500_000, 11_100_000)), 1)
        assertEquals(listOf(first, repeat), RecordingRuleMatcher.showingsToSchedule(
            RecordingRuleMatcher.fold("News"), 10, guide, emptyList(), 0))
    }
}
