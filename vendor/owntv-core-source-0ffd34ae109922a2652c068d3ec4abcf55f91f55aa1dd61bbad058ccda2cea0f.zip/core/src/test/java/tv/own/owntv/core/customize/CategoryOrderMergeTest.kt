package tv.own.owntv.core.customize

import org.junit.Assert.assertEquals
import org.junit.Test

class CategoryOrderMergeTest {
    @Test fun editingOnePlaylistPreservesTheOtherPlaylist() {
        val first = mergeCategoryOrder(emptyList(), listOf("1:b", "1:a", "1:c"))
        val both = mergeCategoryOrder(first, listOf("2:y", "2:x"))
        val changed = mergeCategoryOrder(both, listOf("1:c", "1:b", "1:a"))
        assertEquals(listOf("1:c", "1:b", "1:a"), changed.filter { it.startsWith("1:") })
        assertEquals(listOf("2:y", "2:x"), changed.filter { it.startsWith("2:") })
    }

    @Test fun sharedCustomCategoryDoesNotJumpAheadOfTheOtherPlaylist() {
        val merged = mergeCategoryOrder(listOf("1:a", "1:b", "custom:shared"), listOf("custom:shared", "2:y", "2:x"))
        assertEquals(listOf("1:a", "1:b", "custom:shared", "2:y", "2:x"), merged)
    }

    @Test fun hiddenCategoriesAndOtherPlaylistsKeepTheirRelativeOrder() {
        val merged = mergeCategoryOrder(listOf("2:y", "1:a", "1:hidden", "2:x", "1:b"), listOf("1:b", "1:a"))
        assertEquals(listOf("2:y", "1:b", "1:a", "1:hidden", "2:x"), merged)
        assertEquals(listOf("1:hidden", "2:x"), merged.filter { it in setOf("1:hidden", "2:x") })
    }

    @Test fun anEmptyRailCannotEraseSavedOrdering() {
        val stored = listOf("1:b", "1:a", "2:x")
        assertEquals(stored, mergeCategoryOrder(stored, emptyList()))
    }

    @Test fun overlappingAndRepeatedKeysAppearOnlyOnce() {
        assertEquals(listOf("custom:one", "1:a", "2:x"),
            mergeCategoryOrder(listOf("1:a", "custom:one", "2:x"), listOf("custom:one", "1:a", "1:a")))
    }
}
