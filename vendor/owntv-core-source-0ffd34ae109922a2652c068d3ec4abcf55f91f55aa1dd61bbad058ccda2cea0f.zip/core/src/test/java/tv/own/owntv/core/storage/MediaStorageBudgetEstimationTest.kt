package tv.own.owntv.core.storage

import org.junit.Assert.*
import org.junit.Test

class MediaStorageBudgetEstimationTest {
    @Test
    fun `estimateDurationMs handles zero and negative bytes safely`() {
        assertEquals(0L, MediaStorageBudget.estimateDurationMs(0L))
        assertEquals(0L, MediaStorageBudget.estimateDurationMs(-1000L))
    }

    @Test
    fun `estimateDurationMs calculates conservative duration based on 5 Mbps plus safety margin`() {
        // CONSERVATIVE_BYTES_PER_SECOND = (5_000_000 * 1.10 / 8) = 687_500 bytes/sec
        assertEquals(687_500L, MediaStorageBudget.CONSERVATIVE_BYTES_PER_SECOND)

        // 1 hour of recording = 3600 seconds * 687_500 = 2_475_000_000 bytes
        val oneHourBytes = 2_475_000_000L
        val estimatedMs = MediaStorageBudget.estimateDurationMs(oneHourBytes)
        assertEquals(3_600_000L, estimatedMs) // exactly 1 hour in ms

        // 2 hours = 7_200_000 ms
        assertEquals(7_200_000L, MediaStorageBudget.estimateDurationMs(oneHourBytes * 2))
    }

    @Test
    fun `Info usableBytes respects reserve floor and quota`() {
        // Unknown volume returns 0 usable bytes
        val unknown = MediaStorageBudget.Info(known = false, free = 10_000_000_000L)
        assertEquals(0L, unknown.usableBytes)
        assertEquals(0L, unknown.estimatedRemainingMs)

        // Known volume: free is 10 GB, reserve is 3 GB -> usable is 7 GB
        val normal = MediaStorageBudget.Info(known = true, free = 10_000_000_000L, reserve = 3_000_000_000L)
        assertEquals(7_000_000_000L, normal.usableBytes)
        assertTrue(normal.estimatedRemainingMs > 0L)

        // Known volume where free is below reserve -> usable is 0
        val lowSpace = MediaStorageBudget.Info(known = true, free = 2_000_000_000L, reserve = 3_000_000_000L)
        assertEquals(0L, lowSpace.usableBytes)
        assertEquals(0L, lowSpace.estimatedRemainingMs)

        // Known volume with quota: free minus reserve is 7 GB, but quota minus used is only 2 GB -> usable is 2 GB
        val quotaConstrained = MediaStorageBudget.Info(
            known = true,
            free = 10_000_000_000L,
            reserve = 3_000_000_000L,
            quota = 5_000_000_000L,
            used = 3_000_000_000L
        )
        assertEquals(2_000_000_000L, quotaConstrained.usableBytes)
    }
}
