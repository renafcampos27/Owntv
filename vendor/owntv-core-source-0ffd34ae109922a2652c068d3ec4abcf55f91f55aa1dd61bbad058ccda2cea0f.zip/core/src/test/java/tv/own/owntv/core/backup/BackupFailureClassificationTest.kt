package tv.own.owntv.core.backup

import java.io.File
import java.nio.ByteBuffer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class BackupFailureClassificationTest {
    @get:Rule val folder = TemporaryFolder()
    private fun packed() = BackupContainer.pack(BackupContainer.Payload("""{"version":14,"profiles":[]}""", null), "valid")
    private fun openFailure(bytes: ByteArray): Throwable? {
        val file = File(folder.root, "test.own").apply { writeBytes(bytes) }
        return runCatching { BackupContainer.open(file, "valid") }.exceptionOrNull()
    }

    @Test fun malformedKeyHeaderIsCorruptionRatherThanWrongPassword() {
        val bytes = packed()
        val magicLength = 8
        val headerLength = ByteBuffer.wrap(bytes, magicLength, 4).int
        val oldEnd = magicLength + 4 + headerLength
        val header = JSONObject(String(bytes, magicLength + 4, headerLength)).put("salt", "").toString().toByteArray()
        val corrupt = bytes.copyOf(magicLength) + ByteBuffer.allocate(4).putInt(header.size).array() +
            header + bytes.copyOfRange(oldEnd, bytes.size)
        val failure = openFailure(corrupt)
        assertNotNull(failure)
        assertFalse(failure is BackupManager.WrongPasswordException)
    }

    @Test fun structurallyTruncatedEncryptedBlobIsNotReportedAsWrongPassword() {
        val bytes = packed()
        val end = 12 + ByteBuffer.wrap(bytes, 8, 4).int
        val failure = openFailure(bytes.copyOf(end + 10))
        assertTrue(failure is IllegalArgumentException)
        assertFalse(failure is BackupManager.WrongPasswordException)
    }

    @Test fun wrongPasswordStillRequestsAuthentication() {
        val file = File(folder.root, "valid.own").apply { writeBytes(packed()) }
        assertTrue(runCatching { BackupContainer.open(file, "wrong") }.exceptionOrNull() is BackupManager.WrongPasswordException)
    }
}
