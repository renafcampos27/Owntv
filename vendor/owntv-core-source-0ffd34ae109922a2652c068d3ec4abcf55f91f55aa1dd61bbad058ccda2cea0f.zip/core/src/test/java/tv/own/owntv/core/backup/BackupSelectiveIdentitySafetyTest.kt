package tv.own.owntv.core.backup

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import tv.own.owntv.core.database.entity.ProfileEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.util.Pin
import java.io.File
import java.io.IOException

class BackupSelectiveIdentitySafetyTest {
    @get:Rule val temporary = TemporaryFolder()
    @Test fun completeExportCannotSilentlyWriteSensitiveMetadataWithoutEncryption() {
        listOf(null, "", "   ").forEach { assertTrue(runCatching { requireBackupExportPassphrase(it) }.isFailure) }
        assertEquals(" passphrase with spaces ", requireBackupExportPassphrase(" passphrase with spaces "))
    }
    @Test fun authenticationFailureDoesNotHideStructuralOrOperationalFailure() {
        assertTrue(runCatching { authenticateBackupFields { throw javax.crypto.AEADBadTagException() } }
            .exceptionOrNull() is BackupManager.WrongPasswordException)
        val malformed = IllegalArgumentException("synthetic invalid metadata")
        assertSame(malformed, runCatching { authenticateBackupFields { throw malformed } }.exceptionOrNull())
        val cancelled = CancellationException("cancelled authentication")
        assertSame(cancelled, runCatching { authenticateBackupFields { throw cancelled } }.exceptionOrNull())
    }
    private fun source(id: Long, user: String = "alice") = SourceEntity(id = id, name = "Same name",
        type = SourceType.XTREAM, url = "https://provider.invalid", username = user, password = "not-an-identity")
    private fun profile(id: Long, name: String = "Viewer", kids: Boolean = false, pin: String? = null) =
        ProfileEntity(id = id, name = name, avatarColor = 0, isKids = kids, pinHash = pin)

    @Test fun selectiveSourceMetadataMapsRotatedIdsWithoutPublishingCredentials() {
        val original = source(4)
        val wire = BackupPortableIdentity.export(listOf(original))
        val moved = original.copy(id = 42, password = "rotated")
        assertEquals(mapOf(4L to 42L), BackupPortableIdentity.resolve(JSONArray(wire.toString()), listOf(source(4, "bob"), moved)))
        assertFalse(wire.toString().contains(original.url)); assertFalse(wire.toString().contains("alice"))
        assertFalse(wire.toString().contains("not-an-identity"))
        assertTrue(BackupPortableIdentity.resolve(wire, listOf(source(4, "bob"))).isEmpty())
    }

    @Test fun identityEncodingCannotCollideOnDelimiterAndStalkerMacFormatting() {
        assertNotEquals(BackupPortableIdentity.fingerprint(source(1).copy(url = "https://p|alice", username = "x")),
            BackupPortableIdentity.fingerprint(source(1).copy(url = "https://p", username = "alice|x")))
        val portal = source(1).copy(type = SourceType.STALKER, username = null, mac = "00:1a:79:aa:bb:01")
        assertEquals(BackupPortableIdentity.fingerprint(portal), BackupPortableIdentity.fingerprint(portal.copy(mac = "001A79AABB01")))
        assertNotEquals(BackupPortableIdentity.fingerprint(portal), BackupPortableIdentity.fingerprint(portal.copy(mac = "00:1A:79:AA:BB:02")))
    }

    @Test fun duplicateSourceClaimsAndAmbiguousProfilesNeverChooseFirstOrLast() {
        val row = source(4)
        assertTrue(BackupPortableIdentity.resolve(BackupPortableIdentity.export(listOf(row)), listOf(row.copy(id = 9), row.copy(id = 10))).isEmpty())
        assertTrue(BackupPortableIdentity.resolve(BackupPortableIdentity.export(listOf(row, row.copy(id = 5))), listOf(row.copy(id = 9))).isEmpty())
        assertNull(BackupPortableIdentity.uniqueProfile(listOf(profile(1), profile(2, " viewer ")), profile(88)))
        assertNull(matchSourceForRestore(listOf(row, row.copy(id = 6)), row.copy(id = 77)))
        val portals = listOf(row.copy(type = SourceType.STALKER, mac = "00:1A:79:AA:BB:01"),
            row.copy(id = 6, type = SourceType.STALKER, mac = "00:1A:79:AA:BB:02"))
        assertNull(matchSourceForRestore(portals, row.copy(type = SourceType.STALKER, mac = null)))
    }

    @Test fun userDataAndCustomizationsNeverBorrowUnmappedNumericIds() {
        val identities = BackupRestoreIdentity(mapOf(1L to 8L), mapOf(4L to 42L))
        val original = JSONObject().put("p", 1).put("src", 4).put("rid", "123").put("ctx", "4:LIVE:News")
        val mapped = identities.userDataRow(original)!!
        assertEquals(8L, mapped.getLong("p")); assertEquals(42L, mapped.getLong("src"))
        assertEquals("42:LIVE:News", mapped.getString("ctx")); assertEquals(4L, original.getLong("src"))
        assertNull(identities.userDataRow(JSONObject(original.toString()).put("src", 99)))
        assertNull(identities.userDataRow(JSONObject(original.toString()).put("p", 99)))
        val custom = JSONObject(identities.customization("""{"hiddenCats":["4:LIVE:a","99:LIVE:b","custom:one"],"movedFrom":{"4:LIVE:x":"99:LIVE:b","4:LIVE:y":"4:LIVE:a"},"customCats":[{"id":"custom:one","name":"Own"}],"epgMatch":{"99:LIVE:z":"epg","4:LIVE:y":"epg"}}"""))
        assertEquals(listOf("42:LIVE:a", "custom:one"), (0 until custom.getJSONArray("hiddenCats").length()).map { custom.getJSONArray("hiddenCats").getString(it) })
        assertFalse(custom.getJSONObject("movedFrom").has("42:LIVE:x"))
        assertEquals("42:LIVE:a", custom.getJSONObject("movedFrom").getString("42:LIVE:y"))
        assertFalse(custom.getJSONObject("epgMatch").has("99:LIVE:z"))
        assertEquals("Own", custom.getJSONArray("customCats").getJSONObject(0).getString("name"))
        assertTrue(identities.skipped >= 4)
    }

    @Test fun existingProtectionRemainsUnlessLocalPinAuthorizesTheSpecificLocalProfile() {
        val local = profile(8, kids = true, pin = Pin.hash("1234"))
        val incoming = profile(1, kids = false, pin = Pin.hash("9999"))
        val preserved = BackupProfileProtection.apply(local, incoming, emptyMap())
        assertTrue(preserved.isKids); assertEquals(local.pinHash, preserved.pinHash)
        assertEquals(local.pinHash, BackupProfileProtection.apply(local, incoming, mapOf(1L to "1234")).pinHash)
        val allowed = BackupProfileProtection.apply(local, incoming, mapOf(8L to "1234"))
        assertFalse(allowed.isKids); assertEquals(incoming.pinHash, allowed.pinHash)
        assertTrue(runCatching { BackupProfileProtection.apply(local, incoming, mapOf(8L to "wrong")) }.exceptionOrNull() is BackupManager.ProfileProtectionAuthorizationException)
        assertEquals(local.pinHash, BackupProfileProtection.apply(local, incoming.copy(pinHash = null), mapOf(8L to "1234")).pinHash)
    }

    @Test fun explicitConfirmationForUnlockedProfileDoesNotAuthorizeANewlyAddedPin() {
        val incoming = profile(1, kids = false)
        val unlocked = profile(8, kids = true)
        assertTrue(BackupProfileProtection.apply(unlocked, incoming, emptyMap()).isKids)
        assertFalse(BackupProfileProtection.apply(unlocked, incoming, mapOf(8L to "")).isKids)
        assertTrue(runCatching { BackupProfileProtection.apply(unlocked.copy(pinHash = Pin.hash("1234")), incoming, mapOf(8L to "")) }.isFailure)
    }

    @Test fun selectedReadFailureOrCancellationNeverPublishesOverLastValidBackup() = runBlocking {
        val file = File(temporary.root, "last.own")
        BackupManager.writeAtomically(file, "valid")
        val failure = runCatching {
            val data = readRequiredBackupSection<String>("playback preferences") { throw IOException("synthetic read failure") }
            BackupManager.writeAtomically(file, data)
        }.exceptionOrNull()
        assertTrue(failure is IOException); assertEquals("valid", file.readText())
        val cancelled = CancellationException("cancelled export")
        assertSame(cancelled, runCatching { readRequiredBackupSection("subtitles") { throw cancelled } }.exceptionOrNull())
        assertEquals("valid", file.readText())
    }

    @Test fun manualFileNameCannotEscapeTheBackupFolder() {
        listOf("OwnTV.own", "OwnTV-20261020-a8c.own").forEach(::validateBackupFileName)
        listOf("../else.own", "..\\else.own", "C:else.own", "wrong.zip", "a\u0000.own", "").forEach {
            assertTrue("Should reject filename", runCatching { validateBackupFileName(it) }.isFailure)
        }
    }
}
