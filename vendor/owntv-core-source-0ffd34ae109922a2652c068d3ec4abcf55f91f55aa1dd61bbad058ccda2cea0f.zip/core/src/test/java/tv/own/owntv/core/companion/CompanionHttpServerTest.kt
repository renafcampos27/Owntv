package tv.own.owntv.core.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.sync.SyncScopeChoice

/**
 * Tests the pure parse/auth logic of the companion server (no socket bound). The JSON branch relies
 * on `org.json`, which is only a stub in plain JVM unit tests, so it is exercised on-device; the
 * form-encoded path (what the HTML form actually submits) is fully covered here.
 */
class CompanionHttpServerTest {

    private val protocol = CompanionHttpProtocol
    private val form = "application/x-www-form-urlencoded"

    // ---- PIN comparison ----

    @Test
    fun `pin matches only when equal and same length`() {
        assertTrue(protocol.pinEquals("123456", "123456"))
        assertFalse(protocol.pinEquals("123456", "123457"))
        assertFalse(protocol.pinEquals("12345", "123456"))
        assertFalse(protocol.pinEquals("", "123456"))
    }

    // ---- query / form parsing ----

    @Test
    fun `parseQuery decodes pairs and plus-as-space`() {
        val map = protocol.parseQuery("a=1&b=hello+world&c=")
        assertEquals("1", map["a"])
        assertEquals("hello world", map["b"])
        assertEquals("", map["c"])
    }

    // ---- Xtream ----

    @Test
    fun `xtream form parses all fields`() {
        val body = "type=xtream&name=My+IPTV&server=http://h:80&user=u&pass=p&userAgent=UA&epgUrl=http://e" +
            "&syncLive=now&syncMovies=later&syncSeries=off&isDefault=on&autoRefresh=HOURS_6"
        val p = protocol.parsePayload(form, body, SourceType.XTREAM)!!
        assertEquals(SourceType.XTREAM, p.type)
        assertEquals("My IPTV", p.name)
        assertEquals("http://h:80", p.server)
        assertEquals("u", p.user)
        assertEquals("p", p.pass)
        assertEquals("UA", p.userAgent)
        assertEquals("http://e", p.epgUrl)
        assertEquals("HOURS_6", p.autoRefresh)
        assertEquals(SyncScopeChoice.Now, p.syncLive)
        assertEquals(SyncScopeChoice.Later, p.syncMovies)
        assertEquals(SyncScopeChoice.Off, p.syncSeries)
        assertTrue(p.isDefault)
    }

    @Test
    fun `xtream missing credentials is rejected`() {
        assertNull(protocol.parsePayload(form, "type=xtream&server=http://h", SourceType.XTREAM))
    }

    @Test
    fun `legacy boolean sync fields map to Now or Off`() {
        val off = protocol.parsePayload(
            form,
            "type=xtream&server=h&user=u&pass=p&syncLive=false&syncMovies=false&syncSeries=false&isDefault=false",
            SourceType.XTREAM,
        )!!
        assertEquals(SyncScopeChoice.Off, off.syncLive)
        assertEquals(SyncScopeChoice.Off, off.syncMovies)
        assertEquals(SyncScopeChoice.Off, off.syncSeries)
        assertFalse(off.isDefault)

        val on = protocol.parsePayload(
            form,
            "type=xtream&server=h&user=u&pass=p&syncLive=true&syncMovies=on&syncSeries=1",
            SourceType.XTREAM,
        )!!
        assertEquals(SyncScopeChoice.Now, on.syncLive)
        assertEquals(SyncScopeChoice.Now, on.syncMovies)
        assertEquals(SyncScopeChoice.Now, on.syncSeries)
    }

    // ---- M3U ----

    @Test
    fun `m3u form parses with url alias and only needs the url`() {
        val p = protocol.parsePayload(form, "type=m3u&name=P&url=http://x/p.m3u", SourceType.M3U)!!
        assertEquals(SourceType.M3U, p.type)
        assertEquals("http://x/p.m3u", p.server)
        assertEquals("P", p.name)
    }

    @Test
    fun `m3u without a url is rejected`() {
        assertNull(protocol.parsePayload(form, "type=m3u&name=P", SourceType.M3U))
    }

    /**
     * Uploading a playlist from the companion page: the browser reads the file and posts its text as
     * JSON, because a file input cannot ride in a urlencoded body and the TV has no multipart parser.
     * The URL is then legitimately absent — a submission with neither is still rejected below.
     */
    @Test
    fun `m3u accepts an uploaded playlist instead of a url`() {
        // Built with JSONObject rather than hand-written: the playlist text contains newlines, which
        // must be escaped, and that is exactly what the browser's JSON.stringify does.
        val playlist = "#EXTM3U\n#EXTINF:-1,A\nhttp://h/a.ts\n"
        val body = org.json.JSONObject()
            .put("type", "m3u").put("name", "Jio")
            .put("playlistFileName", "drm-test.m3u")
            .put("playlistFile", playlist)
            .toString()
        val p = protocol.parsePayload("application/json", body, SourceType.M3U)!!
        assertEquals(playlist, p.playlistContent)
        assertEquals(SourceType.M3U, p.type)
        assertEquals("drm-test.m3u", p.playlistFileName)
        assertTrue(p.playlistContent.startsWith("#EXTM3U"))
        // The controller fills this in once the file is on disk; the protocol leaves it blank.
        assertEquals("", p.server)
    }

    @Test
    fun `m3u with neither a url nor a file is still rejected`() {
        assertNull(protocol.parsePayload("application/json", """{"type":"m3u","name":"P"}""", SourceType.M3U))
        assertNull(protocol.parsePayload("application/json", """{"type":"m3u","playlistFile":"  "}""", SourceType.M3U))
    }

    /** A playlist is far larger than a form field, so `/m3u` must get the upload-sized body limit. */
    @Test
    fun `the m3u endpoint accepts an upload-sized body`() {
        assertEquals(CompanionHttpProtocol.UPLOAD_BODY_LIMIT, protocol.maxBodyBytes("/m3u"))
        assertEquals(CompanionHttpProtocol.FORM_BODY_LIMIT, protocol.maxBodyBytes("/xtream"))
    }

    // ---- Stalker ----

    @Test
    fun `stalker form needs portal and mac`() {
        val p = protocol.parsePayload(
            form,
            "type=stalker&portalUrl=http://h/c/&mac=00:1A:79:AA:BB:CC&sn=SERIAL-1" +
                "&device_id=DEVICE-1&deviceId2=DEVICE-2&signature=SIG-1",
            SourceType.STALKER,
        )!!
        assertEquals(SourceType.STALKER, p.type)
        assertEquals("http://h/c/", p.portalUrl)
        assertEquals("00:1A:79:AA:BB:CC", p.mac)
        assertEquals("SERIAL-1", p.serialNumber)
        assertEquals("DEVICE-1", p.deviceId)
        assertEquals("DEVICE-2", p.deviceId2)
        assertEquals("SIG-1", p.signature)
    }

    @Test
    fun `stalker missing mac is rejected`() {
        assertNull(protocol.parsePayload(form, "type=stalker&portalUrl=http://h/c/", SourceType.STALKER))
    }

    // ---- fallback type ----

    @Test
    fun `blank type falls back to the endpoint's type`() {
        val p = protocol.parsePayload(form, "server=h&user=u&pass=p", SourceType.XTREAM)!!
        assertEquals(SourceType.XTREAM, p.type)
    }

    // ---- robustness ----

    // ---- body cap (C1) ----

    private fun read(body: String, contentLength: String, limit: Int): String? =
        protocol.readBody(
            java.io.BufferedInputStream(java.io.ByteArrayInputStream(body.toByteArray())),
            mapOf("content-length" to contentLength),
            limit,
        )

    @Test
    fun `uploads get the large cap and forms the small one`() {
        assertEquals(CompanionHttpProtocol.UPLOAD_BODY_LIMIT, protocol.maxBodyBytes("/backup"))
        assertEquals(CompanionHttpProtocol.UPLOAD_BODY_LIMIT, protocol.maxBodyBytes("/background"))
        assertEquals(CompanionHttpProtocol.FORM_BODY_LIMIT, protocol.maxBodyBytes("/"))
        assertEquals(CompanionHttpProtocol.FORM_BODY_LIMIT, protocol.maxBodyBytes("/xtream"))
    }

    @Test
    fun `a body within the cap is read whole`() {
        assertEquals("pin=123456", read("pin=123456", "10", CompanionHttpProtocol.FORM_BODY_LIMIT))
        assertEquals("", read("", "0", CompanionHttpProtocol.FORM_BODY_LIMIT))
    }

    @Test
    fun `an oversized Content-Length is rejected without allocating it`() {
        // The pre-fix code did ByteArray(2_000_000_000) here — an unauthenticated OOM from the LAN.
        assertNull(read("", "2000000000", CompanionHttpProtocol.FORM_BODY_LIMIT))
        assertNull(read("", (CompanionHttpProtocol.UPLOAD_BODY_LIMIT + 1).toString(), CompanionHttpProtocol.UPLOAD_BODY_LIMIT))
    }

    @Test
    fun `a body longer than the cap is cut off even when the header lies small`() {
        assertNull(read("x".repeat(200), "200", 64))
    }

    @Test(expected = java.io.EOFException::class)
    fun `a truncated body is refused before a partial payload is accepted`() {
        read("abc", "500", CompanionHttpProtocol.FORM_BODY_LIMIT)
    }

    @Test(timeout = 10_000)
    fun `cut-off backup upload never reaches importer and listener remains usable`() {
        val server = testServer()
        val imported = java.util.concurrent.atomic.AtomicInteger()
        val port = java.net.ServerSocket(0).use { it.localPort }
        try {
            server.start(port, "123456", null, mode = CompanionMode.BACKUP_RESTORE,
                onBackup = { imported.incrementAndGet() })
            java.net.Socket("127.0.0.1", port).use { socket ->
                socket.soTimeout = 5_000
                socket.getOutputStream().write(("POST /backup HTTP/1.1\r\nHost: localhost\r\n" +
                    "X-Companion-Pin: 123456\r\nContent-Length: 1000\r\nContent-Type: application/json\r\n\r\n{}")
                    .toByteArray())
                socket.shutdownOutput()
                socket.getInputStream().readBytes()
            }
            assertEquals(0, imported.get())
            // Another connection is still served: the failed client cannot kill the accept loop.
            assertEquals(401, request(port, "POST", "/backup", pinHeader = "000000").statusCode)
        } finally {
            server.stop()
        }
    }

    /** A JSON null must be dropped, not turned into the string "null" — the sender omits optional
     *  fields that way, and a literal "null" would be stored as the user-agent or EPG URL. */
    @Test
    fun `json null values are ignored rather than stringified`() {
        val p = protocol.parsePayload(
            "application/json",
            """{"type":"m3u","name":"P","url":"http://x/p.m3u","userAgent":null,"epgUrl":null}""",
            SourceType.M3U,
        )!!
        assertEquals("", p.userAgent)
        assertEquals("", p.epgUrl)
        assertEquals("P", p.name)
    }

    @Test
    fun `malformed json body does not throw and yields null`() {
        // org.json is stubbed in unit tests; parsePayload must swallow it, not crash the accept thread.
        assertNull(protocol.parsePayload("application/json", "{ this is not json", SourceType.XTREAM))
    }

    // ---- O3 + B4: streaming backup download & CompanionMode route permission matrix ----

    @org.junit.Rule
    @JvmField
    val tempFolder = org.junit.rules.TemporaryFolder()

    private data class HttpResponse(
        val statusCode: Int,
        val headers: Map<String, String>,
        val body: ByteArray,
    )

    private fun testServer(): CompanionHttpServer {
        val fakeContext = android.content.ContextWrapper(null)
        val fakePrefs = java.lang.reflect.Proxy.newProxyInstance(
            android.content.SharedPreferences::class.java.classLoader,
            arrayOf(android.content.SharedPreferences::class.java),
        ) { _, method, args ->
            when (method.name) {
                "getString" -> args?.getOrNull(1) as? String ?: ""
                else -> null
            }
        } as android.content.SharedPreferences
        val localeStore = tv.own.owntv.core.i18n.LocaleStore.overPreferences(fakePrefs)
        return CompanionHttpServer(fakeContext, localeStore)
    }

    private fun request(
        port: Int,
        method: String,
        path: String,
        pinHeader: String? = null,
        contentType: String = "application/x-www-form-urlencoded",
        body: String = "",
    ): HttpResponse {
        java.net.Socket("127.0.0.1", port).use { sock ->
            sock.soTimeout = 5_000
            val bodyBytes = body.toByteArray(Charsets.UTF_8)
            val req = buildString {
                append(method).append(' ').append(path).append(" HTTP/1.1\r\n")
                append("Host: 127.0.0.1\r\n")
                if (pinHeader != null) append("X-Companion-Pin: ").append(pinHeader).append("\r\n")
                if (method == "POST") {
                    append("Content-Type: ").append(contentType).append("\r\n")
                    append("Content-Length: ").append(bodyBytes.size).append("\r\n")
                }
                append("\r\n")
            }
            val out = sock.getOutputStream()
            out.write(req.toByteArray(Charsets.UTF_8))
            if (bodyBytes.isNotEmpty()) out.write(bodyBytes)
            out.flush()

            val raw = sock.getInputStream().readBytes()
            val sep = "\r\n\r\n".toByteArray(Charsets.UTF_8)
            var splitAt = -1
            for (i in 0..raw.size - sep.size) {
                if (raw[i] == sep[0] && raw[i + 1] == sep[1] && raw[i + 2] == sep[2] && raw[i + 3] == sep[3]) {
                    splitAt = i
                    break
                }
            }
            check(splitAt >= 0) { "Malformed HTTP response" }
            val headerLines = String(raw, 0, splitAt, Charsets.UTF_8).split("\r\n")
            val statusCode = headerLines.first().split(' ')[1].toInt()
            val headers = LinkedHashMap<String, String>()
            for (line in headerLines.drop(1)) {
                val idx = line.indexOf(':')
                if (idx > 0) headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
            }
            val responseBody = raw.copyOfRange(splitAt + 4, raw.size)
            return HttpResponse(statusCode, headers, responseBody)
        }
    }

    @Test
    fun `GET backup streams multi-chunk file with valid token and returns 404 when missing`() {
        val server = testServer()
        try {
            val backupFile = tempFolder.newFile("owntv-backup.own")
            // 64 KB (> 8 KB stream buffer) to exercise multi-chunk copyTo streaming
            val expectedBytes = ByteArray(64 * 1024) { (it * 31 + 7).toByte() }
            backupFile.writeBytes(expectedBytes)

            server.start(
                port = 0,
                pin = "123456",
                fontBytes = null,
                mode = CompanionMode.BACKUP_DOWNLOAD,
                downloadFile = backupFile,
            )
            val port = server.boundPort

            // Missing or wrong PIN -> 401
            assertEquals(401, request(port, "GET", "/backup.own", pinHeader = "000000").statusCode)

            // Valid PIN -> 200 and exact streamed payload
            val ok = request(port, "GET", "/backup.own", pinHeader = "123456")
            assertEquals(200, ok.statusCode)
            assertEquals(expectedBytes.size.toString(), ok.headers["content-length"])
            org.junit.Assert.assertArrayEquals(expectedBytes, ok.body)

            // Deleted file -> 404
            assertTrue(backupFile.delete())
            assertEquals(404, request(port, "GET", "/backup.own", pinHeader = "123456").statusCode)
        } finally {
            server.close()
        }
    }

    @Test
    fun `LOCAL_SYNC allows hello pair backup download and backup upload in same session and blocks other routes with 403`() {
        val server = testServer()
        try {
            val backupFile = tempFolder.newFile("sync-export.own")
            val exportedBytes = "exported-container-bytes".toByteArray(Charsets.UTF_8)
            backupFile.writeBytes(exportedBytes)
            var uploadedBackup: String? = null

            server.start(
                port = 0,
                pin = "654321",
                fontBytes = null,
                mode = CompanionMode.LOCAL_SYNC,
                downloadFile = backupFile,
                onBackup = { uploadedBackup = it },
                syncInfo = { """{"name":"Living Room TV"}""" },
                onPair = { _, _, _ -> "paired-secret-token" },
                pairedSecrets = { setOf("paired-secret-token") },
            )
            val port = server.boundPort

            // /sync/hello works with PIN and with paired secret
            val hello = request(port, "GET", "/sync/hello", pinHeader = "paired-secret-token")
            assertEquals(200, hello.statusCode)
            assertTrue(String(hello.body, Charsets.UTF_8).contains("Living Room TV"))

            // /sync/pair works with PIN
            val pair = request(port, "POST", "/sync/pair", pinHeader = "654321", body = "name=Phone&id=dev1")
            assertEquals(200, pair.statusCode)
            assertTrue(String(pair.body, Charsets.UTF_8).contains("paired-secret-token"))

            // GET /backup.own AND POST /backup both succeed in the same LOCAL_SYNC session
            val download = request(port, "GET", "/backup.own", pinHeader = "paired-secret-token")
            assertEquals(200, download.statusCode)
            org.junit.Assert.assertArrayEquals(exportedBytes, download.body)

            val upload = request(
                port,
                "POST",
                "/backup",
                pinHeader = "paired-secret-token",
                contentType = "text/plain",
                body = """{"version":21}""",
            )
            assertEquals(200, upload.statusCode)
            assertEquals("""{"version":21}""", uploadedBackup)

            // Non-LOCAL_SYNC routes are rejected with 403 even with valid PIN
            assertEquals(403, request(port, "POST", "/xtream", pinHeader = "654321", body = "server=http://h&user=u&pass=p").statusCode)
            assertEquals(403, request(port, "POST", "/m3u", pinHeader = "654321", body = "url=http://h/p.m3u").statusCode)
            assertEquals(403, request(port, "POST", "/stalker", pinHeader = "654321", body = "portalUrl=http://h/c/&mac=00:1A:79:00:00:01").statusCode)
            assertEquals(403, request(port, "POST", "/background", pinHeader = "654321", body = "data:image/png;base64,AQID").statusCode)
            assertEquals(403, request(port, "POST", "/tmdbkey", pinHeader = "654321", body = "abcd1234abcd1234").statusCode)
            assertEquals(403, request(port, "POST", "/serviceconfig", pinHeader = "654321", body = "apiKey=abcd1234abcd1234").statusCode)
        } finally {
            server.close()
        }
    }

    @Test
    fun `each CompanionMode strictly authorizes only its own endpoints and rejects others with 403`() {
        val server = testServer()
        try {
            val backupFile = tempFolder.newFile("mode-matrix.own").apply { writeBytes(byteArrayOf(1, 2, 3)) }
            val pin = "112233"

            // 1. ADD_SOURCE: only /xtream, /m3u, /stalker allowed
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.ADD_SOURCE, downloadFile = backupFile)
            var port = server.boundPort
            assertEquals(200, request(port, "POST", "/xtream", pinHeader = pin, body = "server=http://h&user=u&pass=p").statusCode)
            assertEquals(200, request(port, "POST", "/m3u", pinHeader = pin, body = "url=http://h/p.m3u").statusCode)
            assertEquals(200, request(port, "POST", "/stalker", pinHeader = pin, body = "portalUrl=http://h/c/&mac=00:1A:79:00:00:01").statusCode)
            assertEquals(403, request(port, "GET", "/sync/hello", pinHeader = pin).statusCode)
            assertEquals(403, request(port, "POST", "/sync/pair", pinHeader = pin, body = "name=Phone").statusCode)
            assertEquals(403, request(port, "GET", "/backup.own", pinHeader = pin).statusCode)
            assertEquals(403, request(port, "POST", "/backup", pinHeader = pin, body = "{}").statusCode)
            assertEquals(403, request(port, "POST", "/background", pinHeader = pin, body = "data:image/png;base64,AQID").statusCode)
            assertEquals(403, request(port, "POST", "/tmdbkey", pinHeader = pin, body = "abcd1234abcd1234").statusCode)
            assertEquals(403, request(port, "POST", "/serviceconfig", pinHeader = pin, body = "apiKey=abcd1234abcd1234").statusCode)

            // 2. BACKUP_RESTORE: only POST /backup allowed (GET /backup.own is 403)
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.BACKUP_RESTORE, downloadFile = backupFile)
            port = server.boundPort
            assertEquals(200, request(port, "POST", "/backup", pinHeader = pin, body = """{"v":1}""").statusCode)
            assertEquals(403, request(port, "GET", "/backup.own", pinHeader = pin).statusCode)
            assertEquals(403, request(port, "GET", "/sync/hello", pinHeader = pin).statusCode)
            assertEquals(403, request(port, "POST", "/xtream", pinHeader = pin, body = "server=http://h&user=u&pass=p").statusCode)

            // 3. BACKUP_DOWNLOAD: only GET /backup.own allowed (POST /backup is 403)
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.BACKUP_DOWNLOAD, downloadFile = backupFile)
            port = server.boundPort
            assertEquals(200, request(port, "GET", "/backup.own", pinHeader = pin).statusCode)
            assertEquals(403, request(port, "POST", "/backup", pinHeader = pin, body = """{"v":1}""").statusCode)
            assertEquals(403, request(port, "GET", "/sync/hello", pinHeader = pin).statusCode)

            // 4. IMAGE_UPLOAD: only POST /background allowed
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.IMAGE_UPLOAD)
            port = server.boundPort
            assertEquals(200, request(port, "POST", "/background", pinHeader = pin, body = "data:image/png;base64,AQID").statusCode)
            assertEquals(403, request(port, "POST", "/backup", pinHeader = pin, body = "{}").statusCode)
            assertEquals(403, request(port, "POST", "/tmdbkey", pinHeader = pin, body = "abcd1234abcd1234").statusCode)

            // 5. TMDB_KEY: only POST /tmdbkey allowed
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.TMDB_KEY)
            port = server.boundPort
            assertEquals(200, request(port, "POST", "/tmdbkey", pinHeader = pin, body = "abcd1234abcd1234").statusCode)
            assertEquals(403, request(port, "POST", "/serviceconfig", pinHeader = pin, body = "apiKey=abcd1234abcd1234").statusCode)
            assertEquals(403, request(port, "POST", "/xtream", pinHeader = pin, body = "server=http://h&user=u&pass=p").statusCode)

            // 6. TMDB_CONFIG & OPEN_SUBTITLES_CONFIG: only POST /serviceconfig allowed, and service type must match
            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.TMDB_CONFIG)
            port = server.boundPort
            assertEquals(200, request(port, "POST", "/serviceconfig", pinHeader = pin, body = "apiKey=abcd1234abcd1234").statusCode)
            // Submitting OpenSubtitles account credentials in TMDB_CONFIG mode is rejected with 403
            assertEquals(403, request(port, "POST", "/serviceconfig", pinHeader = pin, body = "apiKey=abcd1234abcd1234&username=alice&password=secret").statusCode)
            assertEquals(403, request(port, "POST", "/tmdbkey", pinHeader = pin, body = "abcd1234abcd1234").statusCode)

            server.start(port = 0, pin = pin, fontBytes = null, mode = CompanionMode.OPEN_SUBTITLES_CONFIG)
            port = server.boundPort
            assertEquals(200, request(port, "POST", "/serviceconfig", pinHeader = pin, body = "apiKey=abcd1234abcd1234&username=alice&password=secret").statusCode)
            assertEquals(403, request(port, "POST", "/tmdbkey", pinHeader = pin, body = "abcd1234abcd1234").statusCode)
        } finally {
            server.close()
        }
    }
}
