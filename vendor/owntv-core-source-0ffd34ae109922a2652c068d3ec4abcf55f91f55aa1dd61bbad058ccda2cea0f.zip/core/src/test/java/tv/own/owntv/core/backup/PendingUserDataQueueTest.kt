package tv.own.owntv.core.backup

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class PendingUserDataQueueTest {
    private fun row(id: Int) = JSONArray().put(JSONObject().put("p", 1).put("src", id).put("kind", "fav"))

    @Test fun `append during resolution survives replacement of the resolved snapshot`() = runBlocking {
        var stored: String? = row(1).toString()
        val queue = PendingUserDataQueue({ stored }, { stored = it })
        val entered = CompletableDeferred<Unit>()
        val finish = CompletableDeferred<Unit>()
        val resolving = async(start = CoroutineStart.UNDISPATCHED) {
            queue.resolve { entered.complete(Unit); finish.await(); JSONArray() to 0 }
        }
        entered.await()
        val adding = async(start = CoroutineStart.UNDISPATCHED) { queue.append(row(2)) }
        assertFalse(adding.isCompleted)
        finish.complete(Unit)
        resolving.await(); adding.await()
        assertEquals(1, JSONArray(stored!!).length())
        assertEquals(2, JSONArray(stored!!).getJSONObject(0).getInt("src"))
    }

    @Test fun `concurrent resolvers cannot both apply the same snapshot`() = runBlocking {
        var stored: String? = row(1).toString()
        val queue = PendingUserDataQueue({ stored }, { stored = it })
        val finish = CompletableDeferred<Unit>()
        var applied = 0
        val first = async(start = CoroutineStart.UNDISPATCHED) {
            queue.resolve { applied += it.length(); finish.await(); JSONArray() to 0 }
        }
        val second = async(start = CoroutineStart.UNDISPATCHED) {
            queue.resolve { applied += it.length(); JSONArray() to 0 }
        }
        finish.complete(Unit)
        first.await(); second.await()
        assertEquals(1, applied)
        assertNull(stored)
    }

    @Test fun `cancelled resolution leaves original pending data and releases the lock`() = runBlocking {
        var stored: String? = row(1).toString()
        val queue = PendingUserDataQueue({ stored }, { stored = it })
        val resolving = async(start = CoroutineStart.UNDISPATCHED) {
            queue.resolve { awaitCancellation() }
        }
        resolving.cancelAndJoin()
        queue.append(row(2))
        assertEquals(2, JSONArray(stored!!).length())
    }

    @Test fun `failed resolution preserves the snapshot and appends remain deduplicated`() = runBlocking {
        var stored: String? = row(1).toString()
        val queue = PendingUserDataQueue({ stored }, { stored = it })
        try { queue.resolve { throw IllegalStateException("synthetic storage failure") }; fail() }
        catch (_: IllegalStateException) { }
        queue.append(row(1))
        assertEquals(1, JSONArray(stored!!).length())
        queue.append(row(2))
        assertEquals(2, JSONArray(stored!!).length())
    }
}
