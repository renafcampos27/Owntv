package tv.own.owntv.core.backup

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.model.MediaType

class SnapshotPurgeBatchesTest {
    @Test fun batchesKeepProfileTypeAndOperationSeparatedBelowTheSqliteLimit() {
        val rows = (1L..2_000L).map { SnapshotRow("member", 1, MediaType.LIVE, it) } +
            SnapshotRow("member", 1, MediaType.MOVIE, 7) + SnapshotRow("member", 2, MediaType.LIVE, 8) +
            SnapshotRow("order", 1, MediaType.LIVE, 9)
        val batches = snapshotPurgeBatches(rows)
        assertEquals(listOf(900, 900, 200, 1, 1, 1), batches.map { it.itemIds.size })
        assertEquals((1L..2_000L).toList(), batches.filter {
            it.kind == "member" && it.profileId == 1L && it.type == MediaType.LIVE
        }.flatMap { it.itemIds })
        assertEquals(2L, batches[4].profileId)
        assertEquals("order", batches[5].kind)
    }

    @Test fun duplicateMembershipAcrossFoldersIsDeletedOnlyOncePerBatch() {
        val rows = listOf(SnapshotRow("order", 1, MediaType.LIVE, 5), SnapshotRow("order", 1, MediaType.LIVE, 5),
            SnapshotRow("fav", 1, MediaType.LIVE, 6), SnapshotRow("member", 1, MediaType.LIVE, 5))
        assertEquals(listOf(listOf(5L), listOf(5L)), snapshotPurgeBatches(rows).map { it.itemIds })
    }

    @Test fun emptySnapshotDoesNotProduceAnUnscopedDelete() {
        assertTrue(snapshotPurgeBatches(emptyList()).isEmpty())
        assertTrue(snapshotPurgeBatches(listOf(SnapshotRow("sort", 1, MediaType.SERIES, 1))).isEmpty())
    }

    @Test fun batchLimitsCannotExceedLegacySqliteBindings() {
        for (size in listOf(0, -1, 999, 1000)) {
            assertTrue(runCatching { snapshotPurgeBatches(emptyList(), size) }.exceptionOrNull() is IllegalArgumentException)
        }
    }
}
