package tv.own.owntv.core.epg

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.ChannelEntity

class ArchivePlaybackConfigTest {
    private val template = "https://example.test/archive/{streamId}/index-{utc}-{duration}.m3u8?username={username}&password={password}"
    @Test fun `archive configuration round trips and remaps source ids`() {
        val rows = listOf(ArchivePlaybackConfig(7, templates = listOf(template), manifestType = "hls"),
            ArchivePlaybackConfig(7, "100", "Old name", listOf(template), "mpd"))
        assertEquals(rows, ArchivePlaybackConfig.decode(ArchivePlaybackConfig.encode(rows)))
        assertEquals(rows.map { it.copy(sourceId = 50) }, ArchivePlaybackConfig.remap(rows, mapOf(7L to 50L)))
        assertTrue(ArchivePlaybackConfig.remap(rows, emptyMap()).isEmpty())
    }
    @Test fun `channel override takes precedence after a channel rename and does not leak to other lists`() {
        val playlist = ArchivePlaybackConfig(7, templates = listOf(template))
        val channelRow = ArchivePlaybackConfig(7, "100", "Old name", listOf(template), "mpd")
        val channel = ChannelEntity(sourceId = 7, name = "New name", streamUrl = "https://example.test/live", remoteId = "100")
        assertEquals(channelRow, ArchivePlaybackConfig.resolve(listOf(playlist, channelRow), channel))
        assertEquals(playlist, ArchivePlaybackConfig.resolve(listOf(playlist, channelRow), channel.copy(remoteId = "101")))
        assertNull(ArchivePlaybackConfig.resolve(listOf(playlist, channelRow), channel.copy(sourceId = 8)))
        val byName = channelRow.copy(remoteId = null, channelName = "New name")
        assertEquals(byName, ArchivePlaybackConfig.resolve(listOf(playlist, byName), channel))
    }
    @Test fun `invalid and live templates are rejected before requests`() {
        assertTrue(ArchivePlaybackConfig.isValidTemplate(template))
        assertTrue(ArchivePlaybackConfig.isValidTemplate("https://example.test/{Y}/{m}/{d}/{H}/{M}?duration={duration}"))
        listOf("https://example.test/live.m3u8", "file:///archive/{utc}/{duration}",
            "https://user:pass@example.test/{utc}/{duration}", "$template#fragment", "$template&x={unsupported}",
            "https://example.test/{utc}").forEach { assertFalse(it, ArchivePlaybackConfig.isValidTemplate(it)) }
        assertTrue(ArchivePlaybackConfig.decode("invalid json").isEmpty())
    }
}
