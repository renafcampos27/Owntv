package tv.own.owntv.core.sync.local

import java.io.File
import java.nio.file.Files
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LocalSyncB3Test {

    @Test
    fun `outgoing push preparation preserves hosted backup container and vice versa`() {
        val baseDir = Files.createTempDirectory("local-sync-test").toFile()
        try {
            val hostDir = LocalSyncManager.prepareOutgoingDir(baseDir, LocalSyncManager.OUTGOING_HOST_DIR)
            val hostedBackup = File(hostDir, "hosted-backup.own").apply { writeText("host-payload") }
            assertTrue(hostedBackup.exists())

            // Preparing a push export must NOT wipe the hosted container served on /backup.own
            val pushDir = LocalSyncManager.prepareOutgoingDir(baseDir, LocalSyncManager.OUTGOING_PUSH_DIR)
            val pushBackup = File(pushDir, "push-backup.own").apply { writeText("push-payload") }
            assertTrue(hostedBackup.exists())
            assertEquals("host-payload", hostedBackup.readText())
            assertTrue(pushBackup.exists())

            // Preparing a subsequent push export wipes only the previous push file
            val secondPushDir = LocalSyncManager.prepareOutgoingDir(baseDir, LocalSyncManager.OUTGOING_PUSH_DIR)
            assertFalse(pushBackup.exists())
            assertTrue(hostedBackup.exists())
            val secondPushBackup = File(secondPushDir, "push-backup-2.own").apply { writeText("push-2") }

            // Re-preparing host directory wipes only the old hosted file, leaving push intact
            LocalSyncManager.prepareOutgoingDir(baseDir, LocalSyncManager.OUTGOING_HOST_DIR)
            assertFalse(hostedBackup.exists())
            assertTrue(secondPushBackup.exists())
        } finally {
            baseDir.deleteRecursively()
        }
    }

    @Test
    fun `discovery coordinator serialises resolutions and removes lost queued services`() {
        val resolvedCalls = mutableListOf<String>()
        val lostCallbacks = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { resolvedCalls += it },
            onLostResolved = { lostCallbacks += it },
        )

        coordinator.onServiceFound("TV-LivingRoom")
        coordinator.onServiceFound("TV-Bedroom")
        coordinator.onServiceFound("Phone-Renato")
        // Duplicate while queued should not be enqueued twice
        coordinator.onServiceFound("TV-Bedroom")

        // Only the first service is resolving right now
        assertEquals(listOf("TV-LivingRoom"), resolvedCalls)

        // Bedroom disappears before its turn to resolve
        coordinator.onServiceLost("TV-Bedroom")
        assertTrue(lostCallbacks.isEmpty())

        // LivingRoom finishes -> Phone-Renato should be resolved next, skipping Bedroom
        assertTrue(coordinator.onResolveFinished("TV-LivingRoom", accepted = true))
        assertEquals(listOf("TV-LivingRoom", "Phone-Renato"), resolvedCalls)
        assertTrue(coordinator.onResolveFinished("Phone-Renato", accepted = true))
    }

    @Test
    fun `discovery coordinator suppresses in-flight service lost before resolve completes`() {
        val resolvedCalls = mutableListOf<String>()
        val lostCallbacks = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { resolvedCalls += it },
            onLostResolved = { lostCallbacks += it },
        )

        coordinator.onServiceFound("TV-Kitchen")
        assertEquals(listOf("TV-Kitchen"), resolvedCalls)

        // Lost while resolveService is still in flight
        coordinator.onServiceLost("TV-Kitchen")
        assertFalse(coordinator.onResolveFinished("TV-Kitchen", accepted = true))
        assertTrue(lostCallbacks.isEmpty())
    }

    @Test
    fun `discovery coordinator notifies onLostResolved when already-resolved service disappears`() {
        val resolvedCalls = mutableListOf<String>()
        val lostCallbacks = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { resolvedCalls += it },
            onLostResolved = { lostCallbacks += it },
        )

        coordinator.onServiceFound("TV-Office")
        assertTrue(coordinator.onResolveFinished("TV-Office", accepted = true))

        coordinator.onServiceLost("TV-Office")
        assertEquals(listOf("TV-Office"), lostCallbacks)

        // Losing again is a no-op
        coordinator.onServiceLost("TV-Office")
        assertEquals(listOf("TV-Office"), lostCallbacks)
    }

    @Test
    fun `discovery coordinator resolves re-announced service after in-flight cancellation`() {
        val resolvedCalls = mutableListOf<String>()
        val lostCallbacks = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { resolvedCalls += it },
            onLostResolved = { lostCallbacks += it },
        )

        coordinator.onServiceFound("TV-Patio")
        coordinator.onServiceLost("TV-Patio")
        // Re-announced before the first resolve callback returned
        coordinator.onServiceFound("TV-Patio")

        // First (cancelled) resolve finishes and must NOT emit, but must start the second resolve
        assertFalse(coordinator.onResolveFinished("TV-Patio", accepted = true))
        assertEquals(listOf("TV-Patio", "TV-Patio"), resolvedCalls)

        // Second resolve succeeds and emits
        assertTrue(coordinator.onResolveFinished("TV-Patio", accepted = true))
    }

    @Test
    fun `discovery coordinator ignores duplicate onServiceFound while uncancelled resolve is in flight`() {
        val resolvedCalls = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { resolvedCalls += it },
            onLostResolved = {},
        )

        coordinator.onServiceFound("TV-Lounge")
        // Duplicate mDNS packet while TV-Lounge is already in-flight and not cancelled
        coordinator.onServiceFound("TV-Lounge")

        assertTrue(coordinator.onResolveFinished("TV-Lounge", accepted = true))
        // Must only have resolved once, not queued a redundant second resolve
        assertEquals(listOf("TV-Lounge"), resolvedCalls)
    }

    @Test
    fun `discovery coordinator recovers queue when resolve throws synchronously`() {
        val resolvedCalls = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = { item ->
                resolvedCalls += item
                if (item.startsWith("TV-Broken")) throw IllegalStateException("NSD busy")
            },
            onLostResolved = {},
        )

        // 1. Throwing on initial resolve must clear inFlightName so the next found item resolves
        coordinator.onServiceFound("TV-Broken-1")
        coordinator.onServiceFound("TV-First")
        assertEquals(listOf("TV-Broken-1", "TV-First"), resolvedCalls)

        // 2. Throwing on a queued item popped by onResolveFinished must advance to the following item
        coordinator.onServiceFound("TV-Broken-2")
        coordinator.onServiceFound("TV-Healthy")
        coordinator.onServiceFound("TV-After-Healthy")
        assertTrue(coordinator.onResolveFinished("TV-First", accepted = true))
        assertEquals(listOf("TV-Broken-1", "TV-First", "TV-Broken-2", "TV-Healthy"), resolvedCalls)

        // 3. Stale callback for an old service must not clobber TV-Healthy or pop TV-After-Healthy early
        assertFalse(coordinator.onResolveFinished("TV-First", accepted = true))
        assertEquals(listOf("TV-Broken-1", "TV-First", "TV-Broken-2", "TV-Healthy"), resolvedCalls)

        assertTrue(coordinator.onResolveFinished("TV-Healthy", accepted = true))
        assertEquals(
            listOf("TV-Broken-1", "TV-First", "TV-Broken-2", "TV-Healthy", "TV-After-Healthy"),
            resolvedCalls,
        )
        assertTrue(coordinator.onResolveFinished("TV-After-Healthy", accepted = true))
    }

    @Test
    fun `discovery coordinator orders onAccepted before onLostResolved in FIFO sequence`() {
        val events = mutableListOf<String>()
        val coordinator = DiscoveryCoordinator<String>(
            nameOf = { it },
            resolve = {},
            onLostResolved = { events += "lost:$it" },
        )

        coordinator.onServiceFound("TV-Fast")
        coordinator.onResolveFinished(
            serviceName = "TV-Fast",
            accepted = true,
            onAccepted = { events += "found:TV-Fast" },
        )
        coordinator.onServiceLost("TV-Fast")

        assertEquals(listOf("found:TV-Fast", "lost:TV-Fast"), events)
    }
}
