package tv.own.owntv.core.live

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import tv.own.owntv.core.customize.CustomizeKeys
import tv.own.owntv.core.customize.SectionCustomizations
import tv.own.owntv.core.database.entity.ChannelEntity

class LiveCategoryVisibilityTest {
    private val channel = ChannelEntity(id = 1, sourceId = 1, categoryId = 10, name = "SIC", streamUrl = "")
    private val custom = LiveKey.Custom("custom:test")

    @Test fun customMemberSurvivesHiddenProviderFolder() {
        assertTrue(isChannelVisible(channel, SectionCustomizations(), setOf(10L), custom))
    }
    @Test fun ordinaryListsStillHideProviderFolder() {
        for (key in listOf(LiveKey.All, LiveKey.Folder(10), LiveKey.Catchup, LiveKey.History, LiveKey.Favorites)) {
            assertFalse(isChannelVisible(channel, SectionCustomizations(), setOf(10L), key))
        }
    }
    @Test fun individuallyHiddenMemberRemainsHidden() {
        val settings = SectionCustomizations(hiddenItems = mapOf(CustomizeKeys.channel(channel) to channel.name))
        assertFalse(isChannelVisible(channel, settings, setOf(10L), custom))
    }
    @Test fun kidsRestrictionCannotBeBypassedByCustomMembership() {
        assertFalse(isChannelVisible(channel, SectionCustomizations(), setOf(10L), custom, setOf(10L)))
    }
    @Test fun unrelatedRestrictionDoesNotHideMember() {
        assertTrue(isChannelVisible(channel, SectionCustomizations(), setOf(10L), custom, setOf(20L)))
    }
    @Test fun hiddenCustomCategoryDoesNotExposeItsMembers() {
        assertFalse(isChannelVisible(channel, SectionCustomizations(hiddenCategories = setOf(custom.id)), emptySet(), custom))
    }
    @Test fun uncategorizedChannelRemainsVisible() {
        assertTrue(isChannelVisible(channel.copy(categoryId = null), SectionCustomizations(), setOf(10L), custom, setOf(10L)))
    }
}
