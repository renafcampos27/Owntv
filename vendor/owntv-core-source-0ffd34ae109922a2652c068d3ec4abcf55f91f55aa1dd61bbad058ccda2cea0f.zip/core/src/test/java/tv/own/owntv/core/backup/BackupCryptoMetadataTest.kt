package tv.own.owntv.core.backup

import java.io.File
import java.nio.ByteBuffer
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class BackupCryptoMetadataTest {
    @get:Rule val folder = TemporaryFolder()

    private fun metadata(): JSONObject = BackupCrypto.cryptoBlock(ByteArray(16) { it.toByte() })
    private fun encoded(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
    private val key by lazy { BackupCrypto.deriveKey("secret".toCharArray(), ByteArray(16), 1_000) }

    @Test fun `current and legacy field metadata keep the same derived key`() {
        val salt = ByteArray(16) { it.toByte() }
        // Historical field JSON uses this exact metadata and algorithm, independently of the new reader.
        val legacy = JSONObject("""{"scheme":"field-aes-gcm","kdf":"PBKDF2WithHmacSHA256","iterations":210000,"salt":"AAECAwQFBgcICQoLDA0ODw=="}""")
        val spec = PBEKeySpec("secret".toCharArray(), salt, 210_000, 256)
        val historicalKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        assertArrayEquals(historicalKey, BackupCrypto.deriveKey("secret", legacy)!!.encoded)
        assertArrayEquals(historicalKey, BackupCrypto.deriveKey("secret", metadata())!!.encoded)
    }

    @Test fun `iteration metadata rejects coercion overflow and excessive work`() {
        val invalid = listOf<Any>(0, -1, 2_000_001, Int.MAX_VALUE, 4_294_968_296L,
            Long.MAX_VALUE, 210_000.0, 210_000.5, "210000", true, JSONObject.NULL)
        for (value in invalid) {
            assertNull("Invalid iteration value must not reach PBKDF2: $value",
                BackupCrypto.deriveKey("secret", metadata().put("iterations", value)))
        }
        assertNull(BackupCrypto.deriveKey("secret", metadata().apply { remove("iterations") }))
        // No arbitrary new security minimum invalidates historical/test files with a small count.
        assertNotNull(BackupCrypto.deriveKey("secret", metadata().put("iterations", 1)))
        assertNotNull(BackupCrypto.deriveKey("secret", metadata().put("iterations", 1_000L)))
    }

    @Test fun `parsed fractional exponent and overflowing JSON iterations are rejected`() {
        for (raw in listOf("210000.5", "2.1e5", "4295177296", "9223372036854775808")) {
            val json = JSONObject(metadata().toString().replace("210000", raw))
            assertNull(BackupCrypto.deriveKey("secret", json))
        }
    }

    @Test fun `all metadata fields require their actual supported types`() {
        assertNull(BackupCrypto.deriveKey("secret", null))
        for (name in listOf("scheme", "kdf", "salt")) {
            assertNull(BackupCrypto.deriveKey("secret", metadata().apply { remove(name) }))
            assertNull(BackupCrypto.deriveKey("secret", metadata().put(name, true)))
            assertNull(BackupCrypto.deriveKey("secret", metadata().put(name, JSONObject.NULL)))
        }
        assertNull(BackupCrypto.deriveKey("secret", metadata().put("kdf", "PBKDF2WithHmacSHA1")))
        assertNull(BackupCrypto.deriveKey("secret", metadata().put("scheme", "unknown")))
    }

    @Test fun `caller chooses container scheme without weakening field readers`() {
        val containerHeader = metadata().put("iterations", 1).put("scheme", "container-aes-gcm")
        assertNull(BackupCrypto.deriveKey("secret", containerHeader))
        assertNotNull(BackupCrypto.deriveKey("secret", containerHeader, "container-aes-gcm"))
        assertNull(BackupCrypto.deriveKey("secret", metadata(), "container-aes-gcm"))
    }

    @Test fun `salt must be bounded valid base64 before derivation`() {
        for (value in listOf("", "!!", "A".repeat(2_000), encoded(ByteArray(7)), encoded(ByteArray(65)))) {
            assertNull(BackupCrypto.deriveKey("secret", metadata().put("iterations", 1).put("salt", value)))
        }
        for (size in listOf(8, 16, 64)) {
            val wrapped = encoded(ByteArray(size)).chunked(8).joinToString("\r\n")
            assertNotNull(BackupCrypto.deriveKey("secret", metadata().put("iterations", 1).put("salt", wrapped)))
        }
    }

    @Test fun `direct derivation applies the same safety budget`() {
        for (iterations in listOf(0, -1, 2_000_001, Int.MAX_VALUE)) {
            assertTrue(runCatching { BackupCrypto.deriveKey("secret".toCharArray(), ByteArray(16), iterations) }
                .exceptionOrNull() is IllegalArgumentException)
        }
    }

    @Test fun `encrypted fields including empty text still round trip`() {
        for (value in listOf("", "palavra-passe çá", "https://example.invalid/conta")) {
            val sealed = BackupCrypto.encrypt(key, value)
            assertEquals(value, BackupCrypto.decrypt(key, sealed))
        }
    }

    @Test fun `nonce and ciphertext shapes are checked before cipher initialization`() {
        val valid = BackupCrypto.encrypt(key, "text")
        for (badIv in listOf("", "!", "A".repeat(2_000), encoded(ByteArray(11)), encoded(ByteArray(13)))) {
            assertTrue(runCatching { BackupCrypto.decrypt(key, JSONObject(valid.toString()).put("iv", badIv)) }
                .exceptionOrNull() is IllegalArgumentException)
        }
        for (size in listOf(0, 1, 15)) {
            assertTrue(runCatching { BackupCrypto.decrypt(key, JSONObject(valid.toString()).put("ct", encoded(ByteArray(size)))) }
                .exceptionOrNull() is IllegalArgumentException)
        }
        for (name in listOf("iv", "ct")) {
            assertTrue(runCatching { BackupCrypto.decrypt(key, JSONObject(valid.toString()).put(name, false)) }.isFailure)
        }
    }

    @Test fun `field ciphertext has an encoded allocation budget`() {
        val oversized = "A".repeat(4 * ((16 * 1024 * 1024 + 2) / 3) + 1_025)
        val sealed = JSONObject().put("iv", encoded(ByteArray(12))).put("ct", oversized)
        assertTrue(runCatching { BackupCrypto.decrypt(key, sealed) }.exceptionOrNull() is IllegalArgumentException)
    }

    @Test fun `ciphertext and tag tampering remain authentication failures`() {
        val sealed = BackupCrypto.encrypt(key, "secret text")
        val ct = Base64.getDecoder().decode(sealed.getString("ct"))
        ct[ct.lastIndex] = (ct.last().toInt() xor 1).toByte()
        sealed.put("ct", encoded(ct))
        assertTrue(runCatching { BackupCrypto.decrypt(key, sealed) }.exceptionOrNull() is javax.crypto.AEADBadTagException)
    }

    @Test fun `container metadata errors are corruption and not wrong password`() {
        val original = BackupContainer.pack(BackupContainer.Payload("""{"version":25}""", null), "secret")
        val invalid = listOf<Pair<String, Any>>(
            "scheme" to BackupCrypto.SCHEME, "scheme" to "future-unknown",
            "kdf" to "other", "iterations" to "210000", "iterations" to Int.MAX_VALUE,
            "iterations" to 210_000.5, "salt" to "",
        )
        for ((name, value) in invalid) {
            val file = File(folder.root, "$name.own").apply { writeBytes(replaceHeader(original) { put(name, value) }) }
            val failure = runCatching { BackupContainer.open(file, "secret") }.exceptionOrNull()
            assertNotNull(failure)
            assertFalse(failure is BackupManager.WrongPasswordException)
        }
    }

    @Test fun `encrypted container remains readable through full and lightweight paths`() {
        val payload = BackupContainer.Payload("""{"version":25,"sources":[]}""", null,
            subtitles = mapOf("1.srt" to "subtitle".toByteArray()))
        val file = File(folder.root, "valid.own").apply { writeBytes(BackupContainer.pack(payload, "secret")) }
        val read = BackupContainer.open(file, "secret")
        assertEquals(payload.json, read.json)
        assertArrayEquals(payload.subtitles.getValue("1.srt"), read.subtitles.getValue("1.srt"))
        assertEquals(payload.json, BackupContainer.readJson(file, "secret"))
        assertTrue(runCatching { BackupContainer.open(file, "wrong") }.exceptionOrNull() is BackupManager.WrongPasswordException)
    }

    @Test fun `truncated encrypted body is rejected before metadata derivation`() {
        val packed = BackupContainer.pack(BackupContainer.Payload("{}", null), "secret")
        val mutated = replaceHeader(packed) { put("iterations", Int.MAX_VALUE) }
        val headerEnd = 12 + ByteBuffer.wrap(mutated, 8, 4).int
        val file = File(folder.root, "short.own").apply { writeBytes(mutated.copyOf(headerEnd + 27)) }
        val failure = runCatching { BackupContainer.open(file, "secret") }.exceptionOrNull()
        assertTrue(failure is IllegalArgumentException)
        assertEquals("Truncated encrypted backup", failure?.message)
    }

    private fun replaceHeader(bytes: ByteArray, change: JSONObject.() -> Unit): ByteArray {
        val length = ByteBuffer.wrap(bytes, 8, 4).int
        val end = 12 + length
        val updated = JSONObject(String(bytes, 12, length, Charsets.UTF_8)).apply(change).toString().toByteArray()
        return bytes.copyOf(8) + ByteBuffer.allocate(4).putInt(updated.size).array() + updated + bytes.copyOfRange(end, bytes.size)
    }
}
