package tv.own.owntv.core.epg

import org.junit.Assert.*
import org.junit.Test

class CatchupFormatsTest {
    private val ts = "https://example.test/timeshift/user/pass/60/2026-10-08:10-00/123.ts"
    private val hls = ts.removeSuffix("ts") + "m3u8"
    private val php = CatchupUrl.timeshiftPhpAlternate(ts)!!

    @Test fun automaticAdvancesOnlyToDifferentAddressesOfSameProgramme() {
        assertEquals(listOf(ts, php, hls), CatchupFormats.candidates(ts, CatchupFormat.AUTO))
        assertEquals(php, CatchupFormats.next(ts, ts, CatchupFormat.AUTO, true, 404, false))
        assertEquals(hls, CatchupFormats.next(ts, php, CatchupFormat.AUTO, true, 404, false))
        assertNull(CatchupFormats.next(ts, hls, CatchupFormat.AUTO, true, 404, false))
        assertEquals(listOf(hls, ts, php), CatchupFormats.candidates(hls, CatchupFormat.AUTO))
    }

    @Test fun chosenFormatControlsInitialAddressAndAllowedAlternatives() {
        assertEquals(hls, CatchupFormats.initial(ts, CatchupFormat.HLS))
        assertEquals(ts, CatchupFormats.initial(hls, CatchupFormat.TS))
        assertEquals(listOf(ts, php), CatchupFormats.candidates(hls, CatchupFormat.TS))
        assertEquals(listOf(hls), CatchupFormats.candidates(ts, CatchupFormat.HLS))
        assertNull(CatchupFormats.next(hls, hls, CatchupFormat.HLS, true, 404, false))
    }

    @Test fun authExpirySessionLimitsAndStartedPlaybackNeverChangeFormat() {
        for (status in listOf(401, 403, 410, 429, 500, 503)) {
            assertNull(CatchupFormats.next(ts, ts, CatchupFormat.AUTO, true, status, true))
        }
        assertNull(CatchupFormats.next(ts, ts, CatchupFormat.AUTO, false, 404, false))
        assertNull(CatchupFormats.next(ts, ts, CatchupFormat.AUTO, true, null, false))
        assertEquals(php, CatchupFormats.next(ts, ts, CatchupFormat.AUTO, true, null, true))
    }

    @Test fun queryTokensSurviveAndUnknownLiveOrFileAddressesAreNeverInvented() {
        assertEquals(hls + "?token=test", CatchupFormats.initial(ts + "?token=test", CatchupFormat.HLS))
        assertTrue(CatchupFormats.candidates(ts + "?token=test", CatchupFormat.AUTO)[1].endsWith("&token=test"))
        for (url in listOf("https://example.test/live/user/pass/123.ts", "https://example.test/programme.mp4", "content://recordings/12")) {
            assertEquals(url, CatchupFormats.initial(url, CatchupFormat.HLS))
            assertEquals(listOf(url), CatchupFormats.candidates(url, CatchupFormat.AUTO))
            assertNull(CatchupFormats.next(url, url, CatchupFormat.AUTO, true, 404, false))
        }
        assertNull(CatchupUrl.timeshiftFormat(ts, "mp4"))
    }
}
