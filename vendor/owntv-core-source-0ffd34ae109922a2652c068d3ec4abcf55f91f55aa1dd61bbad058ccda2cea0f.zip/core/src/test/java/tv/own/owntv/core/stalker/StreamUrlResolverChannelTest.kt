package tv.own.owntv.core.stalker

import java.lang.reflect.Proxy
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Test
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class StreamUrlResolverChannelTest {

    @Test
    fun `resolve channel rewrites ts to m3u8 when preferHls is true`() = runBlocking {
        val resolver = buildResolver()
        val channel = ChannelEntity(
            id = 1L,
            sourceId = 10L,
            name = "RTP 1",
            streamUrl = "http://provider.invalid/live/user/pass/101.ts?token=abc",
        )

        val resolved = resolver.resolve(channel, preferHls = true)
        assertEquals("http://provider.invalid/live/user/pass/101.m3u8?token=abc", resolved)
    }

    @Test
    fun `resolve channel respects Xtream source preferHls when preferHls argument is false`() = runBlocking {
        val xtreamSource = SourceEntity(
            id = 20L,
            name = "Xtream Source",
            type = SourceType.XTREAM,
            url = "http://provider.invalid",
            preferHls = true,
        )
        val resolver = buildResolver(sources = mapOf(20L to xtreamSource))
        val channel = ChannelEntity(
            id = 2L,
            sourceId = 20L,
            name = "SIC",
            streamUrl = "http://provider.invalid/live/user/pass/202.ts",
        )

        val resolved = resolver.resolve(channel, preferHls = false)
        assertEquals("http://provider.invalid/live/user/pass/202.m3u8", resolved)
    }

    @Test
    fun `resolve channel keeps ts when neither preferHls nor source preferHls is set`() = runBlocking {
        val m3uSource = SourceEntity(
            id = 30L,
            name = "M3U Source",
            type = SourceType.M3U,
            url = "http://provider.invalid/playlist.m3u",
            preferHls = false,
        )
        val resolver = buildResolver(sources = mapOf(30L to m3uSource))
        val channel = ChannelEntity(
            id = 3L,
            sourceId = 30L,
            name = "TVI",
            streamUrl = "http://provider.invalid/live/user/pass/303.ts",
        )

        val resolved = resolver.resolve(channel, preferHls = false)
        assertEquals("http://provider.invalid/live/user/pass/303.ts", resolved)
    }

    @Test
    fun `resolve Stalker channel mints link via create_link`() = runBlocking {
        val stalkerSource = SourceEntity(
            id = 40L,
            name = "Stalker Portal",
            type = SourceType.STALKER,
            url = "http://portal.invalid/c",
            mac = "00:1A:79:11:22:33",
        )
        var capturedCmd: String? = null
        val resolver = buildResolver(
            sources = mapOf(40L to stalkerSource),
            onCreateLink = { cmd ->
                capturedCmd = cmd
                "http://edge.invalid/live/stream_404.m3u8?token=xyz"
            },
        )
        val channel = ChannelEntity(
            id = 4L,
            sourceId = 40L,
            name = "Stalker Live",
            streamUrl = "ffrt http://localhost/ch/404",
        )

        val resolved = resolver.resolve(channel, preferHls = true, source = stalkerSource)
        assertEquals("ffrt http://localhost/ch/404", capturedCmd)
        assertEquals("http://edge.invalid/live/stream_404.m3u8?token=xyz", resolved)
    }

    private fun buildResolver(
        sources: Map<Long, SourceEntity> = emptyMap(),
        onCreateLink: (String) -> String = { "http://edge.invalid/default.m3u8" },
    ): StreamUrlResolver {
        val client = object : StalkerClient(OkHttpClient()) {
            override suspend fun createLink(
                apiBase: String,
                mac: String,
                token: String,
                userAgent: String?,
                cmd: String,
                type: String,
                episode: Int?,
            ): String = onCreateLink(cmd)
        }
        val auth = object : StalkerAuthManager(client) {
            override suspend fun <T> withAuthRetry(
                creds: StalkerCredentials,
                block: suspend (StalkerSession) -> T,
            ): T = block(
                StalkerSession(
                    apiBase = "${creds.portalUrl}/portal.php",
                    token = "test-token",
                    expiresAtMs = Long.MAX_VALUE,
                    profile = emptyMap(),
                ),
            )
        }
        val sourceDao = Proxy.newProxyInstance(
            SourceDao::class.java.classLoader,
            arrayOf(SourceDao::class.java),
        ) { _, method, args ->
            when (method.name) {
                "getById" -> sources[args?.get(0) as? Long]
                else -> null
            }
        } as SourceDao
        return StreamUrlResolver(auth, client, sourceDao)
    }
}
