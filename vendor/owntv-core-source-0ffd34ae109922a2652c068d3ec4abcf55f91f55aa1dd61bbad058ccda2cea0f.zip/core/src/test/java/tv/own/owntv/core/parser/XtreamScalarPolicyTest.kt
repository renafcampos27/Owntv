package tv.own.owntv.core.parser
import org.junit.Assert.*
import org.junit.Test
class XtreamScalarPolicyTest {
    @Test fun booleansCannotBecomeTitlesIdsOrUrls() {
        assertNull(XtreamScalarPolicy.text(true)); assertNull(XtreamScalarPolicy.text(false))
        assertEquals("123", XtreamScalarPolicy.text(123)); assertEquals("title", XtreamScalarPolicy.text("title"))
    }
    @Test fun flagsKeepTheirExplicitBooleanAndNumericSemantics() {
        assertTrue(XtreamScalarPolicy.flag("true", false)); assertTrue(XtreamScalarPolicy.flag("1", false))
        assertFalse(XtreamScalarPolicy.flag("false", true)); assertFalse(XtreamScalarPolicy.flag("0", true))
        assertTrue(XtreamScalarPolicy.flag("unexpected", true)); assertFalse(XtreamScalarPolicy.flag("unexpected", false))
    }
}
