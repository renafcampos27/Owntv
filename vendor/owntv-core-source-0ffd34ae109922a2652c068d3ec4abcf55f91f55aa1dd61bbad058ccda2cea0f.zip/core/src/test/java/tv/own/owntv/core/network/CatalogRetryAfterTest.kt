package tv.own.owntv.core.network

import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.runBlocking
import okhttp3.*
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test

class CatalogRetryAfterTest {
    @Test fun longestDeadlineKeepsItsOwnStatusAndExpiresTogether() {
        var now = 0L
        val policy = CatalogCooldowns { now }
        policy.defer("account", 60_000, 503)
        policy.defer("account", 1_000, 429)
        assertEquals(CatalogCooldowns.Pending(60_000, 503), policy.pending("account"))
        policy.defer("account", 70_000, 429)
        assertEquals(CatalogCooldowns.Pending(70_000, 429), policy.pending("account"))
        now = 70_000
        assertNull(policy.pending("account"))
    }

    @Test fun authenticationHeadersSeparateIndependentAccountsWithoutRetainingSecrets() {
        val policy = CatalogCooldowns()
        fun request(auth: String, cookie: String) = Request.Builder()
            .url("https://host.invalid/list.m3u").header("Authorization", auth).header("Cookie", cookie).build()
        val first = policy.key(request("Bearer first", "session=one"))
        assertNotEquals(first, policy.key(request("Bearer second", "session=one")))
        assertNotEquals(first, policy.key(request("Bearer first", "session=two")))
        assertEquals(64, first.length)
        assertFalse(first.contains("Bearer"))
    }
    @Test fun acceptsSecondsAndHttpDatesWithBoundedInvalidInput() {
        assertEquals(60_000L, catalogRetryAfterMillis("60"))
        val now = 1_700_000_000_000L
        val date = DateTimeFormatter.RFC_1123_DATE_TIME.format(Instant.ofEpochMilli(now + 60_000).atZone(ZoneOffset.UTC))
        assertEquals(60_000L, catalogRetryAfterMillis(date, now))
        for (text in listOf(null, "", "-1", "NaN", "9999999999999999999999999999")) assertNull(catalogRetryAfterMillis(text))
        assertEquals(86_400_000L, catalogRetryAfterMillis("999999999"))
    }
    @Test fun accountCooldownSpansActionsButDoesNotCrossAccountsOrProviders() {
        var now = 0L
        val policy = CatalogCooldowns { now }
        fun request(host: String, user: String, action: String) = Request.Builder()
            .url("https://$host/panel/player_api.php?username=$user&password=p&action=$action").build()
        val key = policy.key(request("a.invalid", "one", "list"))
        policy.defer(key, 60_000)
        assertEquals(60_000L, policy.remaining(policy.key(request("a.invalid", "one", "guide"))))
        assertEquals(0L, policy.remaining(policy.key(request("a.invalid", "two", "guide"))))
        assertEquals(0L, policy.remaining(policy.key(request("b.invalid", "one", "guide"))))
        assertFalse(key.contains("password"))
        now = 60_001
        assertEquals(0L, policy.remaining(key))
    }
    @Test fun retryAfter60DoesNotRetryOrStartASecondRequestImmediately() = runBlocking {
        val requests = AtomicInteger()
        val client = HttpClient(OkHttpClient.Builder().addInterceptor { chain ->
            requests.incrementAndGet()
            Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(429).message("Limited")
                .header("Retry-After", "60").body("".toResponseBody()).build()
        }.build())
        repeat(2) {
            val failure = runCatching { client.get("https://host.invalid/player_api.php?username=u&password=secret", maxAttempts = 3) { fail("No body parsing") } }.exceptionOrNull()
            assertTrue(failure is HttpClient.HttpStatusException)
            assertTrue((failure as HttpClient.HttpStatusException).retryAfterMillis!! > 50_000)
            assertFalse(failure.message!!.contains("secret"))
        }
        assertEquals(1, requests.get())
    }
}
