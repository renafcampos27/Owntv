package tv.own.owntv.core.recording

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.asResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.buffer
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import tv.own.owntv.core.customize.CustomizationStore
import tv.own.owntv.core.database.OwnTVDatabase
import tv.own.owntv.core.database.dao.ChannelDao
import tv.own.owntv.core.database.dao.DownloadDao
import tv.own.owntv.core.database.dao.EpgDao
import tv.own.owntv.core.database.dao.RecordingDao
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.DownloadEntity
import tv.own.owntv.core.database.entity.RecordingEntity
import tv.own.owntv.core.database.entity.RecordingRuleEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.epg.EpgSourceStore
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.live.OpenStreamRegistry
import tv.own.owntv.core.model.RecordingFailure
import tv.own.owntv.core.model.RecordingStatus
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.ConnectivityObserver
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.parser.XtreamClient
import tv.own.owntv.core.settings.SettingsRepository
import tv.own.owntv.core.stalker.StalkerAuthManager
import tv.own.owntv.core.stalker.StalkerClient
import tv.own.owntv.core.stalker.StreamUrlResolver
import tv.own.owntv.core.storage.MediaStorageBudget
import tv.own.owntv.core.storage.StorageVolumeInfo
import java.io.File
import java.io.InterruptedIOException
import java.lang.reflect.Proxy
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class RecordingEngineOperationsTest {

    @get:Rule
    val temp = TemporaryFolder()

    private lateinit var rootDir: File
    private lateinit var context: Context
    private lateinit var recordingDao: InMemoryRecordingDao
    private lateinit var sourceDao: SourceDao
    private lateinit var channelDao: ChannelDao
    private lateinit var downloadDao: DownloadDao
    private lateinit var settings: SettingsRepository
    private lateinit var streams: OpenStreamRegistry
    private lateinit var activityTracker: RecordingActivityTracker
    private lateinit var storageBudget: MediaStorageBudget
    private val nowMs = AtomicLong(1_000_000L)

    @Before
    fun setUp() {
        rootDir = temp.newFolder("owntv-recording-ops")
        StorageVolumeInfo.testResolver = { _, stored ->
            val file = File(stored)
            val dir = if (file.isDirectory) file else file.parentFile ?: rootDir
            StorageVolumeInfo(
                key = "internal",
                root = dir,
                removable = false,
                free = 50L * 1024 * 1024 * 1024,
                total = 100L * 1024 * 1024 * 1024,
                maxFileBytes = Long.MAX_VALUE,
            )
        }
        val prefs = InMemorySharedPreferences()
        context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getFilesDir(): File = File(rootDir, "files").apply { mkdirs() }
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = prefs
            override fun getSystemService(name: String): Any? = null
            override fun getSystemServiceName(serviceClass: Class<*>): String? = null
        }
        val localeStore = LocaleStore(prefs, null)
        val dataStore = InMemoryPreferencesDataStore()
        settings = SettingsRepository(context, localeStore, dataStore)
        runBlocking {
            settings.setActiveProfile(1L)
            settings.setDownloadRoot(rootDir.absolutePath)
        }
        recordingDao = InMemoryRecordingDao()
        val source = SourceEntity(
            id = 1L,
            name = "Test M3U",
            type = SourceType.M3U,
            url = "https://example.invalid/playlist.m3u",
            maxConnections = 4,
        )
        val channel = ChannelEntity(
            id = 10L,
            sourceId = 1L,
            name = "Channel One",
            streamUrl = "https://example.invalid/live.m3u8",
            catchup = true,
            catchupDays = 7,
        )
        sourceDao = proxyDao(SourceDao::class.java) { method, _ ->
            when (method.name) {
                "getById" -> source
                else -> null
            }
        }
        channelDao = proxyDao(ChannelDao::class.java) { method, _ ->
            when (method.name) {
                "getById" -> channel
                "recordingCandidates" -> listOf(channel)
                else -> null
            }
        }
        downloadDao = proxyDao(DownloadDao::class.java) { method, _ ->
            when (method.name) {
                "storageRows" -> emptyList<DownloadEntity>()
                else -> null
            }
        }
        streams = OpenStreamRegistry()
        activityTracker = RecordingActivityTracker()
        storageBudget = MediaStorageBudget(context, settings, recordingDao, downloadDao)
    }

    @After
    fun tearDown() {
        StorageVolumeInfo.testResolver = null
    }

    /**
     * 1. Parar e guardar (`stopAndAwait` / `stop(id, cancelFinalization = false)`):
     * Cancels capture, closes the in-flight HTTP call, runs `finishHlsSession` to consolidate
     * captured segments into the target `.ts` file, cleans up the spool directory, and marks
     * the recording playable (`PARTIAL`, `finalizationFailure = NONE`).
     */
    @Test
    fun stopAndSaveConsolidatesHlsSegmentsAndMarksRecordingPlayable() = runBlocking {
        val seg1 = tsPacket(1)
        val seg2 = tsPacket(2)
        val seg3Started = CountDownLatch(1)
        val seg3Canceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXTINF:6.0,
                        seg3.ts
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> bytesResponse(chain, seg2)
                    url.endsWith("seg3.ts") -> blockingSegmentResponse(chain, seg3Started, seg3Canceled)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "stop-and-save.ts")
        val row = RecordingEntity(
            id = 101L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/live.m3u8",
            title = "Evening News",
            programmeStartMs = nowMs.get() - 60_000L,
            programmeStopMs = nowMs.get() + 600_000L,
            startMs = nowMs.get() - 60_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch { engine.drainQueue {} }
        try {
            assertTrue("Expected seg3 request to start", seg3Started.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingStatus.RECORDING, runningRow.status)
            assertEquals(12_000L, runningRow.capturedDurationMs)

            // Stop and save via RecordingManager.stopAndAwait
            assertTrue(manager.stopAndAwait(runningRow))
            assertTrue("Expected in-flight HTTP call to be cancelled on stop", seg3Canceled.await(5, TimeUnit.SECONDS))

            val savedRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingStatus.PARTIAL, savedRow.status)
            assertEquals(RecordingFailure.NONE, savedRow.failure)
            assertEquals(RecordingFailure.NONE, savedRow.finalizationFailure)
            assertTrue(RecordingIntegrity.canPlay(savedRow))
            assertTrue("Consolidated target file must exist", targetFile.isFile)
            assertArrayEquals(seg1 + seg2, targetFile.readBytes())
            assertEquals((seg1.size + seg2.size).toLong(), savedRow.bytes)
            assertFalse("Spool directory must be cleaned up after consolidation", File(rootDir, ".owntv-hls-${row.id}").exists())
            assertEquals(0, streams.openOn(1L).recording)
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 1b. Parar e guardar quando o utilizador pára manualmente uma gravação de diferido (catch-up)
     * antes do fim: consolida os segmentos capturados num ficheiro reproduzível e marca `PARTIAL`.
     */
    @Test
    fun stopAndSaveOnCatchUpBeforeEndConsolidatesAndMarksPartialPlayable() = runBlocking {
        val seg1 = tsPacket(11)
        val seg2Started = CountDownLatch(1)
        val seg2Canceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:0
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> blockingSegmentResponse(chain, seg2Started, seg2Canceled)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "catchup-stop-save.ts")
        val row = RecordingEntity(
            id = 102L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Archive Show",
            programmeStartMs = 100_000L,
            programmeStopMs = 200_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch { engine.drainQueue {} }
        try {
            assertTrue(seg2Started.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            assertTrue(manager.stopAndAwait(runningRow))
            assertTrue(seg2Canceled.await(5, TimeUnit.SECONDS))

            val savedRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingStatus.PARTIAL, savedRow.status)
            assertEquals(RecordingFailure.NONE, savedRow.finalizationFailure)
            assertTrue(RecordingIntegrity.canPlay(savedRow))
            assertTrue(targetFile.isFile)
            assertArrayEquals(seg1, targetFile.readBytes())
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 2. Apagar (`delete` / `stop(id, cancelFinalization = true)`):
     * Cancels capture and finalization, waits for release, and deletes all spool/target files
     * and the database row.
     */
    @Test
    fun deleteCancelsCaptureAndFinalizationAndRemovesFilesAndDatabaseRow() = runBlocking {
        val seg1 = tsPacket(21)
        val seg2Started = CountDownLatch(1)
        val seg2Canceled = CountDownLatch(1)
        val finalizationProgressCalled = AtomicBoolean(false)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> blockingSegmentResponse(chain, seg2Started, seg2Canceled)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "to-delete.ts")
        val spoolDir = File(rootDir, ".owntv-hls-201")
        val row = RecordingEntity(
            id = 201L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/live.m3u8",
            title = "Delete Me",
            programmeStartMs = nowMs.get() - 60_000L,
            programmeStopMs = nowMs.get() + 600_000L,
            startMs = nowMs.get() - 60_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch {
            engine.drainQueue { progress ->
                if (!seg2Started.await(0, TimeUnit.MILLISECONDS)) return@drainQueue
                if (seg2Canceled.count == 0L) finalizationProgressCalled.set(true)
            }
        }
        try {
            assertTrue(seg2Started.await(5, TimeUnit.SECONDS))
            assertTrue("Spool checkpoint must exist while capturing", File(spoolDir, "checkpoint.json").isFile)

            val runningRow = recordingDao.getById(row.id)!!
            val result = manager.delete(runningRow)
            assertEquals(RecordingDeleteResult.SUCCESS, result)
            assertTrue(seg2Canceled.await(5, TimeUnit.SECONDS))
            assertFalse("Finalization must not run when deleting", finalizationProgressCalled.get())
            assertNull("Database row must be deleted", recordingDao.getById(row.id))
            assertFalse("Target file must not exist after delete", targetFile.exists())
            assertFalse("Spool directory must be removed after delete", spoolDir.exists())
            assertEquals(0, streams.openOn(1L).recording)
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 3. Pausar um download de diferido (`pauseArchive`):
     * Cancels capture, does NOT finalize or discard the spool, preserves `checkpoint.json` and
     * committed segment files on disk, and marks the row `PARTIAL` with `archivePaused = true`
     * so it can be resumed.
     */
    @Test
    fun pauseArchivePreservesSpoolAndCheckpointForResumption() = runBlocking {
        val seg1 = tsPacket(31)
        val seg2Started = CountDownLatch(1)
        val seg2Canceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:10
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> blockingSegmentResponse(chain, seg2Started, seg2Canceled)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "paused-archive.ts")
        val spoolDir = File(rootDir, ".owntv-hls-301")
        val row = RecordingEntity(
            id = 301L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Paused Archive Programme",
            programmeStartMs = 100_000L,
            programmeStopMs = 200_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch { engine.drainQueue {} }
        try {
            assertTrue(seg2Started.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            assertTrue(ArchiveResumePolicy.canPause(runningRow))

            assertTrue("Expected pauseArchive to succeed", manager.pauseArchive(runningRow))
            assertTrue(seg2Canceled.await(5, TimeUnit.SECONDS))

            val pausedRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingStatus.PARTIAL, pausedRow.status)
            assertTrue(pausedRow.archivePaused)
            assertNull(pausedRow.finalizationFailure)
            assertEquals(6_000L, pausedRow.capturedDurationMs)
            assertNotNull(pausedRow.hlsCheckpoint)
            assertTrue(ArchiveResumePolicy.canResume(pausedRow))
            assertTrue("Retained archive spool must remain available on disk", engine.retainedArchiveAvailable(pausedRow))
            assertTrue(File(spoolDir, "checkpoint.json").isFile)
            assertFalse("Paused archive must not be consolidated into final target file yet", targetFile.exists())
            assertEquals(0, streams.openOn(1L).recording)
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 4. Terminar o motor (cancelling the `CoroutineScope` running `engine.drainQueue`):
     * Cancels capture and any in-progress finalization in a controlled manner (observing the
     * engine scope's `Job`), records `incomplete = true` (`PARTIAL`), and preserves the HLS spool
     * on disk so a subsequent engine run recovers and consolidates the recording.
     */
    @Test
    fun engineScopeShutdownCancelsInControlledMannerAndPreservesRecoverableSpool() = runBlocking {
        val seg1 = tsPacket(41)
        val seg2 = tsPacket(42)
        val seg3Started = CountDownLatch(1)
        val seg3Canceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXTINF:6.0,
                        seg3.ts
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> bytesResponse(chain, seg2)
                    url.endsWith("seg3.ts") -> blockingSegmentResponse(chain, seg3Started, seg3Canceled)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val targetFile = File(rootDir, "engine-shutdown.ts")
        val spoolDir = File(rootDir, ".owntv-hls-401")
        val stopAt = nowMs.get() + 60_000L
        val row = RecordingEntity(
            id = 401L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/live.m3u8",
            title = "Interrupted By Engine Shutdown",
            programmeStartMs = nowMs.get() - 60_000L,
            programmeStopMs = stopAt,
            startMs = nowMs.get() - 60_000L,
            stopMs = stopAt,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = engineScope.launch { engine.drainQueue {} }
        assertTrue(seg3Started.await(5, TimeUnit.SECONDS))

        // Shut down the engine's scope while recording is active
        engineScope.coroutineContext[Job]!!.cancelAndJoin()
        drainJob.join()
        assertTrue(seg3Canceled.await(5, TimeUnit.SECONDS))

        val afterShutdown = recordingDao.getById(row.id)!!
        assertEquals(RecordingStatus.PARTIAL, afterShutdown.status)
        assertEquals(RecordingFailure.NONE, afterShutdown.finalizationFailure)
        assertEquals((seg1.size + seg2.size).toLong(), afterShutdown.bytes)
        assertFalse("Target file must not be promoted when engine scope shuts down mid-capture", targetFile.exists())
        assertTrue("Spool checkpoint must be preserved for recovery after engine shutdown", File(spoolDir, "checkpoint.json").isFile)
        assertEquals(0, streams.openOn(1L).recording)

        // When the engine runs again after the recording window has closed, recoverInterruptedHlsRecordings
        // consolidates the preserved spool into the playable target file without requiring status == RECORDING.
        nowMs.set(stopAt + 1_000L)
        withTimeout(5_000L) {
            engine.drainQueue {}
        }

        val recovered = recordingDao.getById(row.id)!!
        assertEquals(RecordingStatus.PARTIAL, recovered.status)
        assertEquals(RecordingFailure.NONE, recovered.failure)
        assertEquals(RecordingFailure.NONE, recovered.captureFailure)
        assertEquals(RecordingFailure.NONE, recovered.finalizationFailure)
        assertTrue(RecordingIntegrity.canPlay(recovered))
        assertTrue("Recovered target file must exist after next drainQueue", targetFile.isFile)
        assertArrayEquals(seg1 + seg2, targetFile.readBytes())
        assertFalse("Spool directory must be cleaned up after recovery consolidation", spoolDir.exists())
    }

    /**
     * 1c. Parar e guardar chamado enquanto a finalização já está em curso:
     * não cancela `finalizationJob` e aguarda até que a consolidação termine.
     */
    @Test
    fun stopAndSaveDuringInProgressFinalizationWaitsWithoutCancellingFinalization() = runBlocking {
        val seg1 = tsPacket(51)
        val seg2 = tsPacket(52)
        val finalizationMidpoint = CountDownLatch(1)
        val proceedFinalization = CountDownLatch(1)
        val progressCalls = AtomicLong(0L)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> bytesResponse(chain, seg2)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "stop-mid-finalization.ts")
        val row = RecordingEntity(
            id = 501L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Mid Finalization Stop",
            programmeStartMs = 100_000L,
            programmeStopMs = 200_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch {
            engine.drainQueue {
                // Calls 1 & 2 are capture of seg1 & seg2; call 3 is inside finishHlsSession after seg1 is copied
                if (progressCalls.incrementAndGet() == 3L) {
                    finalizationMidpoint.countDown()
                    proceedFinalization.await(5, TimeUnit.SECONDS)
                }
            }
        }
        try {
            assertTrue("Expected finalization to reach midpoint", finalizationMidpoint.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            val stopFinished = AtomicBoolean(false)
            val stopJob = launch(Dispatchers.IO) {
                assertTrue(manager.stopAndAwait(runningRow))
                stopFinished.set(true)
            }
            delay(50)
            assertFalse("stopAndAwait must wait for finalization to complete", stopFinished.get())
            proceedFinalization.countDown()
            stopJob.join()
            assertTrue(stopFinished.get())

            val savedRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingFailure.NONE, savedRow.finalizationFailure)
            assertTrue(RecordingIntegrity.canPlay(savedRow))
            assertTrue(targetFile.isFile)
            assertArrayEquals(seg1 + seg2, targetFile.readBytes())
        } finally {
            proceedFinalization.countDown()
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 1d. Parar e guardar num stream contínuo Raw MPEG-TS:
     * cancela a leitura HTTP em curso sem classificar o cancelamento como `RecordingFailure.NETWORK`.
     */
    @Test
    fun stopAndSaveOnRawTsStreamCancelsHttpAndMarksPartialWithoutNetworkFailure() = runBlocking {
        val initialPayload = (0 until 24).fold(ByteArray(0)) { acc, i -> acc + tsPacket(81 + i) }
        val streamBlocking = CountDownLatch(1)
        val streamCanceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val call = chain.call()
                val initial = Buffer().write(initialPayload)
                var initialConsumed = false
                val source: BufferedSource = object : ForwardingSource(initial) {
                    override fun read(sink: Buffer, byteCount: Long): Long {
                        if (!initialConsumed) {
                            val n = super.read(sink, byteCount)
                            if (n != -1L) return n
                            initialConsumed = true
                        }
                        streamBlocking.countDown()
                        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
                        while (!call.isCanceled() && System.nanoTime() < deadline) {
                            try {
                                Thread.sleep(20)
                            } catch (_: InterruptedException) {
                                streamCanceled.countDown()
                                throw InterruptedIOException("interrupted")
                            }
                        }
                        if (call.isCanceled()) {
                            streamCanceled.countDown()
                            throw InterruptedIOException("Canceled")
                        }
                        return -1L
                    }
                }.buffer()

                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(source.asResponseBody("video/mp2t".toMediaType(), -1L))
                    .build()
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "stop-raw-live.ts")
        val row = RecordingEntity(
            id = 502L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/live.ts",
            title = "Raw Live Show",
            programmeStartMs = nowMs.get() - 60_000L,
            programmeStopMs = nowMs.get() + 600_000L,
            startMs = nowMs.get() - 60_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch { engine.drainQueue {} }
        try {
            assertTrue(streamBlocking.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            assertTrue(manager.stopAndAwait(runningRow))
            assertTrue(streamCanceled.await(5, TimeUnit.SECONDS))
            drainJob.join()

            val savedRow = recordingDao.getById(row.id)!!
            assertEquals(RecordingStatus.PARTIAL, savedRow.status)
            assertEquals(RecordingFailure.NONE, savedRow.failure)
            assertEquals(RecordingFailure.NONE, savedRow.captureFailure)
            assertEquals(RecordingFailure.NONE, savedRow.finalizationFailure)
            assertTrue(RecordingIntegrity.canPlay(savedRow))
            assertArrayEquals(initialPayload, targetFile.readBytes())
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 2b. Apagar chamado enquanto a finalização já está em curso:
     * cancela `finalizationJob`, aborta a promoção do ficheiro e remove spool, destino e linha da BD.
     */
    @Test
    fun deleteDuringInProgressFinalizationCancelsFinalizationAndCleansUp() = runBlocking {
        val seg1 = tsPacket(61)
        val seg2 = tsPacket(62)
        val finalizationMidpoint = CountDownLatch(1)
        val proceedFinalization = CountDownLatch(1)
        val progressCalls = AtomicLong(0L)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> bytesResponse(chain, seg2)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "delete-mid-finalization.ts")
        val spoolDir = File(rootDir, ".owntv-hls-601")
        val row = RecordingEntity(
            id = 601L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Mid Finalization Delete",
            programmeStartMs = 100_000L,
            programmeStopMs = 200_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch {
            engine.drainQueue {
                if (progressCalls.incrementAndGet() == 3L) {
                    finalizationMidpoint.countDown()
                    proceedFinalization.await(5, TimeUnit.SECONDS)
                }
            }
        }
        try {
            assertTrue(finalizationMidpoint.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            val deleteDeferred = launch(Dispatchers.IO) {
                val res = manager.delete(runningRow)
                assertEquals(RecordingDeleteResult.SUCCESS, res)
            }
            delay(50)
            proceedFinalization.countDown()
            deleteDeferred.join()

            assertNull(recordingDao.getById(row.id))
            assertFalse(targetFile.exists())
            assertFalse(spoolDir.exists())
        } finally {
            proceedFinalization.countDown()
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 3b. Pausar diferido na 3.ª tentativa de retry de um segmento:
     * propaga `CancellationException` sem registar uma falha permanente (`gapCount = 0`) no `checkpoint.json`.
     */
    @Test
    fun pauseArchiveOnThirdRetryAttemptDoesNotRecordBogusGapInCheckpoint() = runBlocking {
        val seg1 = tsPacket(91)
        val seg2Attempts = AtomicLong(0L)
        val thirdAttemptStarted = CountDownLatch(1)
        val thirdAttemptCanceled = CountDownLatch(1)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> {
                        val attempt = seg2Attempts.incrementAndGet()
                        if (attempt < 3L) {
                            errorResponse(chain, 503)
                        } else {
                            blockingSegmentResponse(chain, thirdAttemptStarted, thirdAttemptCanceled)
                        }
                    }
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val manager = createManager(engine)
        val targetFile = File(rootDir, "pause-third-retry.ts")
        val spoolDir = File(rootDir, ".owntv-hls-702")
        val row = RecordingEntity(
            id = 702L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Archive Retry Pause",
            programmeStartMs = 100_000L,
            programmeStopMs = 160_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val drainScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = drainScope.launch { engine.drainQueue {} }
        try {
            assertTrue(thirdAttemptStarted.await(5, TimeUnit.SECONDS))
            val runningRow = recordingDao.getById(row.id)!!
            assertTrue(manager.pauseArchive(runningRow))
            assertTrue(thirdAttemptCanceled.await(5, TimeUnit.SECONDS))
            drainJob.join()

            val pausedRow = recordingDao.getById(row.id)!!
            assertTrue(pausedRow.archivePaused)
            assertEquals(0, pausedRow.gapCount)
            assertEquals(0L, pausedRow.missingDurationMs)
            val checkpointFile = File(spoolDir, "checkpoint.json")
            assertTrue(checkpointFile.isFile)
            val checkpointText = checkpointFile.readText()
            assertFalse("Paused retry must not record seg2.ts as skipped in checkpoint.json", checkpointText.contains("seg2.ts"))
        } finally {
            drainJob.cancelAndJoin()
        }
    }

    /**
     * 4b. Terminar o motor (`engineScope` cancelado) enquanto a finalização está em curso:
     * cancela `finalizationJob`, preserva o spool em disco e marca `PARTIAL` (`incomplete = true`).
     */
    @Test
    fun engineScopeShutdownDuringFinalizationCancelsFinalizationAndPreservesSpool() = runBlocking {
        val seg1 = tsPacket(71)
        val seg2 = tsPacket(72)
        val finalizationMidpoint = CountDownLatch(1)
        val proceedFinalization = CountDownLatch(1)
        val progressCalls = AtomicLong(0L)

        val client = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url.toString()
                when {
                    url.endsWith(".m3u8") -> textResponse(
                        chain,
                        """
                        #EXTM3U
                        #EXT-X-VERSION:3
                        #EXT-X-TARGETDURATION:6
                        #EXT-X-MEDIA-SEQUENCE:1
                        #EXTINF:6.0,
                        seg1.ts
                        #EXTINF:6.0,
                        seg2.ts
                        #EXT-X-ENDLIST
                        """.trimIndent(),
                        "application/vnd.apple.mpegurl",
                    )
                    url.endsWith("seg1.ts") -> bytesResponse(chain, seg1)
                    url.endsWith("seg2.ts") -> bytesResponse(chain, seg2)
                    else -> errorResponse(chain, 404)
                }
            })
            .build()

        val engine = createEngine(client)
        val targetFile = File(rootDir, "shutdown-mid-finalization.ts")
        val spoolDir = File(rootDir, ".owntv-hls-701")
        val row = RecordingEntity(
            id = 701L,
            profileId = 1L,
            sourceId = 1L,
            channelId = 10L,
            channelName = "Channel One",
            streamUrl = "https://example.invalid/archive.m3u8",
            title = "Mid Finalization Engine Shutdown",
            programmeStartMs = 100_000L,
            programmeStopMs = 200_000L,
            startMs = nowMs.get() - 10_000L,
            stopMs = nowMs.get() + 600_000L,
            status = RecordingStatus.SCHEDULED,
            filePath = targetFile.absolutePath,
        )
        recordingDao.upsert(row)

        val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val drainJob = engineScope.launch {
            engine.drainQueue {
                if (progressCalls.incrementAndGet() == 3L) {
                    finalizationMidpoint.countDown()
                    proceedFinalization.await(5, TimeUnit.SECONDS)
                }
            }
        }
        assertTrue(finalizationMidpoint.await(5, TimeUnit.SECONDS))
        val shutdownJob = launch(Dispatchers.IO) {
            engineScope.coroutineContext[Job]!!.cancelAndJoin()
        }
        delay(50)
        proceedFinalization.countDown()
        shutdownJob.join()
        drainJob.join()

        val afterShutdown = recordingDao.getById(row.id)!!
        assertEquals(RecordingStatus.PARTIAL, afterShutdown.status)
        assertEquals(RecordingFailure.NONE, afterShutdown.finalizationFailure)
        assertFalse("Target file must not be promoted when finalization is cancelled by engine shutdown", targetFile.exists())
        assertTrue("Spool checkpoint must remain intact on disk", File(spoolDir, "checkpoint.json").isFile)

        withTimeout(5_000L) {
            engine.drainQueue {}
        }
        val recovered = recordingDao.getById(row.id)!!
        assertEquals(RecordingStatus.PARTIAL, recovered.status)
        assertTrue(RecordingIntegrity.canPlay(recovered))
        assertTrue(targetFile.isFile)
        assertArrayEquals(seg1 + seg2, targetFile.readBytes())
        assertFalse(spoolDir.exists())
    }

    @Test
    fun interruptedRawArchiveNeverAppendsASecondCompleteResponse() = runBlocking {
        val prefix = (0 until 50).flatMap { tsPacket(it).asIterable() }.toByteArray()
        val requests = AtomicLong(0)
        val client = OkHttpClient.Builder().addInterceptor { chain ->
            if (requests.incrementAndGet() > 1) bytesResponse(chain, prefix + prefix)
            else {
                val source = object : ForwardingSource(Buffer().write(prefix)) {
                    override fun read(sink: Buffer, byteCount: Long): Long {
                        val count = super.read(sink, byteCount)
                        if (count == -1L) throw java.io.IOException("archive connection interrupted")
                        return count
                    }
                }.buffer()
                bytesResponse(chain, prefix).newBuilder()
                    .body(source.asResponseBody("video/mp2t".toMediaType(), -1L)).build()
            }
        }.build()
        val file = File(rootDir, "interrupted-archive.ts")
        val row = RecordingEntity(id = 901, profileId = 1, sourceId = 1, channelId = 10,
            channelName = "Channel One", streamUrl = "https://example.invalid/archive.ts", title = "Archive",
            programmeStartMs = 100_000, programmeStopMs = 200_000,
            startMs = nowMs.get() - 10_000, stopMs = nowMs.get() + 600_000,
            status = RecordingStatus.SCHEDULED, filePath = file.absolutePath)
        recordingDao.upsert(row)
        val engine = createEngine(client)
        withTimeout(5_000) { engine.drainQueue {} }
        assertEquals(1L, requests.get())
        assertArrayEquals(prefix, file.readBytes())
        assertEquals(RecordingStatus.PARTIAL, recordingDao.getById(row.id)!!.status)
        assertEquals(RecordingFailure.NETWORK, recordingDao.getById(row.id)!!.captureFailure)
    }

    @Test
    fun unrequestedPartialArchiveResponseIsNeverMarkedComplete() = runBlocking {
        val payload = (0 until 30).flatMap { tsPacket(it).asIterable() }.toByteArray()
        val requests = AtomicLong()
        val client = OkHttpClient.Builder().addInterceptor { chain ->
            requests.incrementAndGet()
            bytesResponse(chain, payload).newBuilder().code(206)
                .header("Content-Range", "bytes 0-${payload.size - 1}/${payload.size * 2}").build()
        }.build()
        val file = File(rootDir, "partial-response.ts")
        val row = RecordingEntity(id = 904, profileId = 1, sourceId = 1, channelId = 10,
            channelName = "Channel One", streamUrl = "https://example.invalid/archive.ts", title = "Archive",
            programmeStartMs = 100_000, programmeStopMs = 200_000,
            startMs = nowMs.get() - 10_000, stopMs = nowMs.get() + 600_000,
            status = RecordingStatus.SCHEDULED, filePath = file.absolutePath)
        recordingDao.upsert(row)
        withTimeout(5_000) { createEngine(client).drainQueue {} }
        assertEquals(1L, requests.get())
        assertEquals(0L, file.length())
        assertEquals(RecordingFailure.ARCHIVE_CHANGED, recordingDao.getById(row.id)!!.captureFailure)
        assertFalse(recordingDao.getById(row.id)!!.status == RecordingStatus.COMPLETED)
    }

    @Test
    fun initialAndPlaylistRetryAfterAreRetainedAndWaitingIsCancelable() = runBlocking {
        for (playlistFailure in listOf(false, true)) {
            val requests = AtomicLong(0)
            val refusal = CountDownLatch(1)
            val client = OkHttpClient.Builder().addInterceptor { chain ->
                val number = requests.incrementAndGet()
                if (playlistFailure && number == 1L) textResponse(chain,
                    "#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXT-X-MEDIA-SEQUENCE:1\n#EXTINF:6,\nseg.ts\n", "application/vnd.apple.mpegurl")
                else {
                    refusal.countDown()
                    errorResponse(chain, 429).newBuilder().header("Retry-After", "30").build()
                }
            }.build()
            val row = RecordingEntity(id = if (playlistFailure) 903 else 902, profileId = 1, sourceId = 1,
                channelId = 10, channelName = "Channel One", streamUrl = "https://example.invalid/live.m3u8",
                title = "Provider wait", programmeStartMs = nowMs.get() - 10_000,
                programmeStopMs = nowMs.get() + 600_000, startMs = nowMs.get() - 10_000,
                stopMs = nowMs.get() + 600_000, status = RecordingStatus.SCHEDULED,
                filePath = File(rootDir, "wait-${playlistFailure}.ts").absolutePath)
            recordingDao.upsert(row)
            val engine = createEngine(client)
            val worker = launch(Dispatchers.IO) { engine.drainQueue {} }
            try {
                assertTrue(refusal.await(5, TimeUnit.SECONDS))
                delay(3_400) // The old local retry was 3 s, earlier than the provider's 30 s.
                assertEquals(if (playlistFailure) 2L else 1L, requests.get())
                withTimeout(2_000) { engine.stop(row.id, cancelFinalization = true); worker.join() }
            } finally { worker.cancelAndJoin() }
        }
    }

    private fun createEngine(client: OkHttpClient): RecordingEngine {
        val stalkerClient = StalkerClient(client)
        val stalkerAuth = StalkerAuthManager(stalkerClient)
        val resolver = StreamUrlResolver(stalkerAuth, stalkerClient)
        val connectivity = ConnectivityObserver(context)
        return RecordingEngine(
            context = context,
            recordingDao = recordingDao,
            channelDao = channelDao,
            client = client,
            sourceDao = sourceDao,
            streamUrlResolver = resolver,
            streams = streams,
            settings = settings,
            connectivity = connectivity,
            activityTracker = activityTracker,
            storageBudget = storageBudget,
            clock = { nowMs.get() },
        )
    }

    private fun createManager(engine: RecordingEngine): RecordingManager {
        val scheduler = RecordingScheduler(context, recordingDao) { nowMs.get() }
        val epgDao = proxyDao(EpgDao::class.java) { _, _ -> null }
        val db = Class.forName("tv.own.owntv.core.database.OwnTVDatabase_Impl")
            .getDeclaredConstructor()
            .newInstance() as OwnTVDatabase
        val customize = CustomizationStore(context)
        val epgSourceStore = EpgSourceStore(context)
        val xtream = XtreamClient(HttpClient(OkHttpClient()))
        val stalkerClient = StalkerClient(OkHttpClient())
        val resolver = StreamUrlResolver(StalkerAuthManager(stalkerClient), stalkerClient)
        return RecordingManager(
            context = context,
            recordingDao = recordingDao,
            sourceDao = sourceDao,
            settings = settings,
            streams = streams,
            engine = engine,
            scheduler = scheduler,
            channelDao = channelDao,
            epgDao = epgDao,
            db = db,
            customize = customize,
            epgSourceStore = epgSourceStore,
            archiveXtream = xtream,
            archiveResolver = resolver,
            storageBudget = storageBudget,
        )
    }

    private fun tsPacket(seed: Int): ByteArray = ByteArray(188) { index ->
        if (index == 0) 0x47.toByte() else ((seed + index) and 0xFF).toByte()
    }

    private fun textResponse(chain: Interceptor.Chain, body: String, contentType: String): Response =
        Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(200)
            .message("OK")
            .body(body.toResponseBody(contentType.toMediaType()))
            .build()

    private fun bytesResponse(chain: Interceptor.Chain, bytes: ByteArray): Response =
        Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(200)
            .message("OK")
            .body(bytes.toResponseBody("video/mp2t".toMediaType()))
            .build()

    private fun errorResponse(chain: Interceptor.Chain, code: Int): Response =
        Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(code)
            .message("Error")
            .body("".toResponseBody("text/plain".toMediaType()))
            .build()

    private fun blockingSegmentResponse(
        chain: Interceptor.Chain,
        started: CountDownLatch,
        canceled: CountDownLatch,
    ): Response {
        val call = chain.call()
        val source: BufferedSource = object : ForwardingSource(Buffer()) {
            override fun read(sink: Buffer, byteCount: Long): Long {
                started.countDown()
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(10)
                while (!call.isCanceled() && System.nanoTime() < deadline) {
                    try {
                        Thread.sleep(20)
                    } catch (_: InterruptedException) {
                        canceled.countDown()
                        throw InterruptedIOException("interrupted")
                    }
                }
                if (call.isCanceled()) {
                    canceled.countDown()
                    throw InterruptedIOException("canceled")
                }
                return -1L
            }

            override fun close() {
                if (call.isCanceled()) canceled.countDown()
                super.close()
            }
        }.buffer()

        return Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(200)
            .message("OK")
            .body(source.asResponseBody("video/mp2t".toMediaType(), -1L))
            .build()
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> proxyDao(iface: Class<T>, handler: (java.lang.reflect.Method, Array<out Any?>?) -> Any?): T =
        Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            handler(method, args)
        } as T

    private class InMemoryRecordingDao : RecordingDao {
        private val rows = MutableStateFlow<Map<Long, RecordingEntity>>(emptyMap())
        private val nextId = AtomicLong(1_000L)

        override suspend fun storageRows(): List<RecordingEntity> =
            rows.value.values.filter { it.filePath != null }

        override suspend fun upsert(recording: RecordingEntity): Long {
            val id = if (recording.id > 0L) recording.id else nextId.getAndIncrement()
            val saved = recording.copy(id = id)
            rows.value = rows.value + (id to saved)
            return id
        }

        override suspend fun update(recording: RecordingEntity) {
            if (rows.value.containsKey(recording.id)) {
                rows.value = rows.value + (recording.id to recording)
            }
        }

        override suspend fun delete(recording: RecordingEntity) {
            rows.value = rows.value - recording.id
        }

        override suspend fun getById(id: Long): RecordingEntity? = rows.value[id]

        override suspend fun setArchivePaused(id: Long, paused: Boolean, timestamp: Long) {
            val current = rows.value[id] ?: return
            rows.value = rows.value + (id to current.copy(archivePaused = paused, updatedAt = timestamp))
        }

        override fun observeForProfile(profileId: Long): Flow<List<RecordingEntity>> =
            rows.map { map -> map.values.filter { it.profileId == profileId }.sortedByDescending { it.startMs } }

        override fun observeRunning(): Flow<List<RecordingEntity>> =
            rows.map { map -> map.values.filter { it.status == RecordingStatus.RECORDING }.sortedBy { it.startMs } }

        override suspend fun running(): List<RecordingEntity> =
            rows.value.values.filter { it.status == RecordingStatus.RECORDING }.sortedBy { it.startMs }

        override suspend fun scheduled(): List<RecordingEntity> =
            rows.value.values.filter { it.status == RecordingStatus.SCHEDULED }.sortedBy { it.startMs }

        override suspend fun dueAt(now: Long): List<RecordingEntity> =
            rows.value.values.filter {
                (it.status == RecordingStatus.SCHEDULED || it.status == RecordingStatus.RECORDING) &&
                    it.startMs <= now && it.stopMs > now
            }.sortedBy { it.startMs }

        override suspend fun runningCountForSource(sourceId: Long): Int =
            rows.value.values.count { it.sourceId == sourceId && it.status == RecordingStatus.RECORDING }

        override suspend fun overlapping(sourceId: Long, startMs: Long, stopMs: Long, excludeId: Long): List<RecordingEntity> =
            rows.value.values.filter {
                it.sourceId == sourceId && it.id != excludeId &&
                    (it.status == RecordingStatus.SCHEDULED || it.status == RecordingStatus.RECORDING) &&
                    it.startMs < stopMs && it.stopMs > startMs
            }.sortedBy { it.startMs }

        override suspend fun forProgramme(profileId: Long, channelId: Long, programmeStartMs: Long): RecordingEntity? =
            rows.value.values.firstOrNull {
                it.profileId == profileId && it.channelId == channelId &&
                    it.programmeStartMs == programmeStartMs && it.recoveryAttempt == 0
            }

        override suspend fun insertRecovery(recording: RecordingEntity): Long = upsert(recording)

        override suspend fun activeRecoveryFor(originId: Long): RecordingEntity? =
            rows.value.values.filter {
                it.recoveryOfId == originId &&
                    (it.status == RecordingStatus.SCHEDULED || it.status == RecordingStatus.RECORDING)
            }.maxByOrNull { it.recoveryAttempt }

        override suspend fun nextRecoveryAttempt(profileId: Long, channelId: Long, programmeStartMs: Long): Int =
            (rows.value.values.filter {
                it.profileId == profileId && it.channelId == channelId && it.programmeStartMs == programmeStartMs
            }.maxOfOrNull { it.recoveryAttempt } ?: 0) + 1

        override suspend fun updateProgress(
            id: Long,
            status: RecordingStatus,
            failure: RecordingFailure,
            bytes: Long,
            filePath: String?,
            startedAt: Long?,
            endedAt: Long?,
            timestamp: Long,
        ) {
            val current = rows.value[id] ?: return
            rows.value = rows.value + (
                id to current.copy(
                    status = status,
                    failure = failure,
                    bytes = bytes,
                    filePath = filePath,
                    startedAt = startedAt,
                    endedAt = endedAt,
                    updatedAt = timestamp,
                )
                )
        }

        override suspend fun updateCapture(
            id: Long,
            capturedDurationMs: Long,
            missingDurationMs: Long,
            gapCount: Int,
            hlsCheckpoint: String?,
            timestamp: Long,
        ) {
            val current = rows.value[id] ?: return
            rows.value = rows.value + (
                id to current.copy(
                    capturedDurationMs = capturedDurationMs,
                    missingDurationMs = missingDurationMs,
                    gapCount = gapCount,
                    hlsCheckpoint = hlsCheckpoint,
                    updatedAt = timestamp,
                )
                )
        }

        override suspend fun updateFailures(
            id: Long,
            captureFailure: RecordingFailure?,
            finalizationFailure: RecordingFailure?,
            timestamp: Long,
        ) {
            val current = rows.value[id] ?: return
            rows.value = rows.value + (
                id to current.copy(
                    captureFailure = captureFailure,
                    finalizationFailure = finalizationFailure,
                    updatedAt = timestamp,
                )
                )
        }

        override suspend fun upsertRule(rule: RecordingRuleEntity): Long = 1L
        override suspend fun deleteRule(rule: RecordingRuleEntity) {}
        override fun observeRules(profileId: Long): Flow<List<RecordingRuleEntity>> = MutableStateFlow(emptyList())
        override suspend fun enabledRules(): List<RecordingRuleEntity> = emptyList()
        override suspend fun findRule(profileId: Long, channelId: Long, titleKey: String): RecordingRuleEntity? = null
    }

    private class InMemorySharedPreferences : SharedPreferences {
        private val data = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = HashMap(data)
        override fun getString(key: String?, defValue: String?): String? = data[key] as? String ?: defValue
        @Suppress("UNCHECKED_CAST")
        override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? =
            (data[key] as? Set<String>)?.toMutableSet() ?: defValues
        override fun getInt(key: String?, defValue: Int): Int = data[key] as? Int ?: defValue
        override fun getLong(key: String?, defValue: Long): Long = data[key] as? Long ?: defValue
        override fun getFloat(key: String?, defValue: Float): Float = data[key] as? Float ?: defValue
        override fun getBoolean(key: String?, defValue: Boolean): Boolean = data[key] as? Boolean ?: defValue
        override fun contains(key: String?): Boolean = data.containsKey(key)
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            private val edits = HashMap<String, Any?>()
            private var clearAll = false
            override fun putString(key: String, value: String?): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor = apply { edits[key] = values }
            override fun putInt(key: String, value: Int): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putLong(key: String, value: Long): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putFloat(key: String, value: Float): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor = apply { edits[key] = value }
            override fun remove(key: String): SharedPreferences.Editor = apply { edits[key] = null }
            override fun clear(): SharedPreferences.Editor = apply { clearAll = true }
            override fun commit(): Boolean {
                if (clearAll) data.clear()
                edits.forEach { (k, v) -> if (v == null) data.remove(k) else data[k] = v }
                return true
            }
            override fun apply() { commit() }
        }
        override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
    }

    private class InMemoryPreferencesDataStore : DataStore<Preferences> {
        private val mutex = Mutex()
        private val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (t: Preferences) -> Preferences): Preferences =
            mutex.withLock {
                val updated = transform(state.value)
                state.value = updated
                updated
            }
    }
}
