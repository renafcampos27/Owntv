package tv.own.owntv.core.parser

import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import java.net.InetAddress
import java.net.ServerSocket

class XtreamM3uImportTest {
    @Test fun escapedLinkRetainsDecodedCredentialsAndServerSubdirectory() {
        val parsed = requireNotNull(XtreamM3uLink.parse(" https://host.example:8080/panel/get.php?username=u%2Bv&amp;password=p%26q%2Bz&amp;output=hls "))
        assertEquals("https://host.example:8080/panel", parsed.server)
        assertEquals("u+v", parsed.username)
        assertEquals("p&q+z", parsed.password)
        assertTrue(parsed.preferHls)
    }

    @Test fun ordinarySignedUrlIsNotConvertedOrPercentDecoded() {
        val url = "https://host.example/list.m3u?sig=p%26q&amp;x=1"
        assertNull(XtreamM3uLink.parse(url))
        assertEquals("https://host.example/list.m3u?sig=p%26q&x=1", XtreamM3uLink.clean(url))
        assertNull(XtreamM3uLink.parse("file:///get.php?username=u&password=p"))
        assertNull(XtreamM3uLink.parse("https://host.example/get.php?username=u"))
    }

    @Test(timeout = 10_000) fun confirmedApiImportsOnlyTvAndPreservesIdentityAndHls() = runBlocking {
        withApi("""{"user_info":{"auth":1,"status":"Active"}}""") { origin, client, request ->
            val draft = SourceEntity(name = "My list", type = SourceType.M3U,
                url = "$origin/get.php?username=u%2Bv&amp;password=p%26q&amp;output=ts",
                userAgent = "OwnTV-test", httpReferer = "https://identity.example/", epgUrl = "https://guide.example/epg.xml")
            val actual = client.resolveM3uImport(draft, onlyTv = true, hlsOnly = true)
            assertEquals(SourceType.XTREAM, actual.type)
            assertEquals(origin, actual.url)
            assertEquals("u+v", actual.username)
            assertEquals("p&q", actual.password)
            assertEquals(draft.name, actual.name)
            assertEquals(draft.userAgent, actual.userAgent)
            assertEquals(draft.epgUrl, actual.epgUrl)
            assertEquals(draft.httpReferer, actual.httpReferer)
            assertTrue(actual.syncLive && actual.preferHls)
            assertFalse(actual.syncMovies || actual.syncSeries)
            val headers = request.await().lowercase()
            assertTrue(headers.contains("user-agent: owntv-test"))
            assertTrue(headers.contains("referer: https://identity.example/"))
        }
    }

    @Test(timeout = 10_000) fun unrelatedJsonDoesNotConvertM3u() = runBlocking {
        withApi("{}") { origin, client, _ ->
            val draft = SourceEntity(name = "M3U", type = SourceType.M3U, url = "$origin/get.php?username=u&amp;password=p")
            val actual = client.resolveM3uImport(draft, true, true)
            assertEquals(SourceType.M3U, actual.type)
            assertEquals("$origin/get.php?username=u&password=p", actual.url)
            assertNull(actual.username)
        }
    }

    @Test(timeout = 10_000) fun callerCancellationClosesProbeAndDoesNotFallBackToImport() = runBlocking {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val http = OkHttpClient()
        val entered = CompletableDeferred<Unit>()
        val peer = async(Dispatchers.IO) {
            server.accept().use { socket ->
                socket.soTimeout = 3_000
                val reader = socket.getInputStream().bufferedReader()
                while (!reader.readLine().isNullOrEmpty()) { }
                entered.complete(Unit)
                assertEquals(-1, socket.getInputStream().read())
            }
        }
        val probe = async {
            XtreamClient(HttpClient(http)).resolveM3uImport(SourceEntity(name = "test", type = SourceType.M3U,
                url = "http://127.0.0.1:${server.localPort}/get.php?username=u&password=p"), true, true)
        }
        try {
            withTimeout(3_000) { entered.await() }
            withTimeout(2_000) { probe.cancelAndJoin(); peer.await() }
            assertTrue(probe.isCancelled)
        } finally {
            probe.cancel(); peer.cancel(); server.close()
            http.connectionPool.evictAll(); http.dispatcher.executorService.shutdown()
        }
    }

    private suspend fun withApi(body: String, test: suspend (String, XtreamClient, Deferred<String>) -> Unit) = coroutineScope {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val http = OkHttpClient()
        val peer = async(Dispatchers.IO) {
            server.accept().use { socket ->
                socket.soTimeout = 3_000
                val reader = socket.getInputStream().bufferedReader()
                val lines = mutableListOf<String>()
                while (true) { val line = reader.readLine() ?: break; if (line.isEmpty()) break; lines += line }
                val payload = body.toByteArray()
                socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: ${payload.size}\r\nConnection: close\r\n\r\n".toByteArray() + payload)
                lines.joinToString("\n")
            }
        }
        try {
            test("http://127.0.0.1:${server.localPort}", XtreamClient(HttpClient(http)), peer)
            peer.await()
            Unit
        } finally {
            peer.cancel(); server.close()
            http.connectionPool.evictAll(); http.dispatcher.executorService.shutdown()
        }
    }
}
