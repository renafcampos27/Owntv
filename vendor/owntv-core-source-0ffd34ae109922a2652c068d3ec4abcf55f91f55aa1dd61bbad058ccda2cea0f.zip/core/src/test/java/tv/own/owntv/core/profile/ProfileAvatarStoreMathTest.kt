package tv.own.owntv.core.profile

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProfileAvatarStoreMathTest {

    @get:Rule
    val folder = TemporaryFolder()

    @Test
    fun `small picture preserves sample size 1`() {
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(120, 200, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(512, 512, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(400, 400, ProfileAvatarStore.SIZE_PX))
    }

    @Test
    fun `rectangular image keeps smaller dimension above target size`() {
        // 1600x900 has min dimension 900. 900 / 2 = 450 < 512, so sample size must remain 1 to avoid loss of quality
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(1600, 900, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(900, 1600, ProfileAvatarStore.SIZE_PX))
    }

    @Test
    fun `large camera pictures downsample by powers of two to minimize memory usage`() {
        // 3000x4000 (12MP): min dimension 3000. 3000 / 4 = 750 >= 512; 3000 / 8 = 375 < 512 -> sample size = 4
        assertEquals(4, ProfileAvatarStore.calculateInSampleSize(3000, 4000, ProfileAvatarStore.SIZE_PX))

        // 4000x4000: min dimension 4000. 4000 / 4 = 1000 >= 512; 4000 / 8 = 500 < 512 -> sample size = 4
        assertEquals(4, ProfileAvatarStore.calculateInSampleSize(4000, 4000, ProfileAvatarStore.SIZE_PX))

        // 8000x6000 (48MP): min dimension 6000. 6000 / 8 = 750 >= 512; 6000 / 16 = 375 < 512 -> sample size = 8
        assertEquals(8, ProfileAvatarStore.calculateInSampleSize(8000, 6000, ProfileAvatarStore.SIZE_PX))

        // 1024x1024: 1024 / 2 = 512 >= 512; 1024 / 4 = 256 < 512 -> sample size = 2
        assertEquals(2, ProfileAvatarStore.calculateInSampleSize(1024, 1024, ProfileAvatarStore.SIZE_PX))

        // 2048x2048: 2048 / 4 = 512 >= 512; 2048 / 8 = 256 < 512 -> sample size = 4
        assertEquals(4, ProfileAvatarStore.calculateInSampleSize(2048, 2048, ProfileAvatarStore.SIZE_PX))
    }

    @Test
    fun `edge and invalid dimensions return 1 safely without loop or overflow`() {
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(0, 500, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(500, 0, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(-10, 500, ProfileAvatarStore.SIZE_PX))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(1000, 1000, 0))
        assertEquals(1, ProfileAvatarStore.calculateInSampleSize(1000, 1000, -100))
    }

    @Test
    fun `replaceAtomically creates new destination when target does not exist`() {
        val src = File(folder.root, "source.tmp").apply { writeText("new_content") }
        val target = File(folder.root, "avatar.jpg")

        assertTrue(ProfileAvatarStore.replaceAtomically(src, target))
        assertEquals("new_content", target.readText())
        assertTrue(!src.exists())
    }

    @Test
    fun `replaceAtomically replaces existing target without losing data`() {
        val src = File(folder.root, "source.tmp").apply { writeText("v2_data") }
        val target = File(folder.root, "avatar.jpg").apply { writeText("v1_data") }

        assertTrue(ProfileAvatarStore.replaceAtomically(src, target))
        assertEquals("v2_data", target.readText())
        assertTrue(!src.exists())
    }
}
