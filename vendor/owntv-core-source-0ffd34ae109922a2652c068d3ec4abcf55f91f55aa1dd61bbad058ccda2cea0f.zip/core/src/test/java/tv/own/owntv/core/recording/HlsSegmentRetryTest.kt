package tv.own.owntv.core.recording

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class HlsSegmentRetryTest {

    private fun segment(sequence: Long, token: String = "init", isGap: Boolean = false) =
        HlsMediaPlaylist.Segment(
            uri = "$sequence.ts?token=$token",
            durationSecs = 6.0,
            sequence = sequence,
            gap = isGap,
        )

    @Test
    fun `terminal HTTP errors abort immediately without retrying`() = runBlocking {
        val terminalCodes = listOf(400, 401, 403, 404, 405, 410, 414, 416)
        for (code in terminalCodes) {
            assertTrue("Expected $code to be terminal", HlsHttpPolicy.isTerminal(code))
            var attempts = 0
            var refreshes = 0
            val result = HlsSegmentRetry.capture(
                sequence = 10,
                initial = listOf(segment(10)),
                segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
                refresh = { refreshes++; listOf(segment(10)) },
                capture = { _, _ ->
                    attempts++
                    HlsSegmentDownloadResult.Failure(httpCode = code, isTerminal = HlsHttpPolicy.isTerminal(code))
                },
                wait = { fail("Terminal error should not wait") },
            )
            assertFalse("Expected capture to fail for terminal code $code", result)
            assertEquals("Terminal code $code should not retry", 1, attempts)
            assertEquals("Terminal code $code should not trigger playlist refresh", 0, refreshes)
        }
    }

    @Test
    fun `transient error retries with default incremental backoff and succeeds on fresh uri`() = runBlocking {
        var attempts = 0
        var refreshes = 0
        val recordedDelays = mutableListOf<Long>()
        val requestedUris = mutableListOf<String>()

        val result = HlsSegmentRetry.capture(
            sequence = 42,
            initial = listOf(segment(42, "token-1")),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = {
                refreshes++
                listOf(segment(42, "token-${refreshes + 1}"))
            },
            capture = { _, seg ->
                attempts++
                requestedUris.add(seg.uri)
                if (attempts < 3) {
                    HlsSegmentDownloadResult.Failure(httpCode = 503, isTerminal = false)
                } else {
                    HlsSegmentDownloadResult.Success
                }
            },
            wait = { recordedDelays.add(it) },
        )

        assertTrue(result)
        assertEquals(3, attempts)
        assertEquals(2, refreshes)
        assertEquals(listOf("42.ts?token=token-1", "42.ts?token=token-2", "42.ts?token=token-3"), requestedUris)
        assertEquals(listOf(500L, 1000L), recordedDelays)
    }

    @Test
    fun `retry honors Retry-After integer seconds header`() = runBlocking {
        var attempts = 0
        val recordedDelays = mutableListOf<Long>()

        val result = HlsSegmentRetry.capture(
            sequence = 7,
            initial = listOf(segment(7)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { listOf(segment(7)) },
            capture = { _, _ ->
                attempts++
                if (attempts == 1) {
                    HlsSegmentDownloadResult.Failure(
                        httpCode = 429,
                        retryAfterHeader = "3",
                        isTerminal = false,
                    )
                } else {
                    HlsSegmentDownloadResult.Success
                }
            },
            wait = { recordedDelays.add(it) },
        )

        assertTrue(result)
        assertEquals(2, attempts)
        assertEquals(listOf(3000L), recordedDelays)
    }

    @Test
    fun `excessive Retry-After beyond MAX_WAIT_MS aborts retry early`() = runBlocking {
        var attempts = 0
        var refreshed = false

        val result = HlsSegmentRetry.capture(
            sequence = 7,
            initial = listOf(segment(7)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { refreshed = true; listOf(segment(7)) },
            capture = { _, _ ->
                attempts++
                HlsSegmentDownloadResult.Failure(
                    httpCode = 429,
                    retryAfterHeader = "15", // 15s > MAX_WAIT_MS (10s)
                    isTerminal = false,
                )
            },
            wait = { fail("Should not wait when server requests excessive delay") },
        )

        assertFalse(result)
        assertEquals(1, attempts)
        assertFalse("Should not refresh playlist when backoff is refused", refreshed)
    }

    @Test
    fun `retry honors RFC1123 HTTP date Retry-After header with clock`() = runBlocking {
        var attempts = 0
        val recordedDelays = mutableListOf<Long>()
        val fixedClock = 1_700_000_000_000L // arbitrary fixed epoch ms

        val result = HlsSegmentRetry.capture(
            sequence = 8,
            initial = listOf(segment(8)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { listOf(segment(8)) },
            clock = { fixedClock },
            capture = { _, _ ->
                attempts++
                if (attempts == 1) {
                    // Wed, 15 Nov 2023 22:13:25 GMT = 1700086405000L
                    // Let's use date 4 seconds after fixedClock
                    val targetMs = fixedClock + 4000L
                    val dateHeader = java.time.Instant.ofEpochMilli(targetMs)
                        .atZone(java.time.ZoneOffset.UTC)
                        .format(java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME)
                    HlsSegmentDownloadResult.Failure(
                        httpCode = 503,
                        retryAfterHeader = dateHeader,
                        isTerminal = false,
                    )
                } else {
                    HlsSegmentDownloadResult.Success
                }
            },
            wait = { recordedDelays.add(it) },
        )

        assertTrue(result)
        assertEquals(2, attempts)
        assertEquals(listOf(4000L), recordedDelays)
    }

    @Test
    fun `expired sequence missing or marked gap on refresh aborts retry`() = runBlocking {
        var attempts = 0
        // Case 1: Sequence completely rolled off the sliding playlist window
        val droppedResult = HlsSegmentRetry.capture(
            sequence = 1,
            initial = listOf(segment(1)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { listOf(segment(2), segment(3)) },
            capture = { _, _ -> attempts++; HlsSegmentDownloadResult.Failure(httpCode = 500) },
            wait = { },
        )
        assertFalse(droppedResult)
        assertEquals(1, attempts)

        // Case 2: Sequence becomes a gap on refresh
        attempts = 0
        val gapResult = HlsSegmentRetry.capture(
            sequence = 5,
            initial = listOf(segment(5)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { listOf(segment(5, isGap = true)) },
            capture = { _, _ -> attempts++; HlsSegmentDownloadResult.Failure(httpCode = 500) },
            wait = { },
        )
        assertFalse(gapResult)
        assertEquals(1, attempts)
    }

    @Test
    fun `cancellation during wait throws CancellationException and terminates`() = runBlocking {
        var attempts = 0
        try {
            HlsSegmentRetry.capture(
                sequence = 99,
                initial = listOf(segment(99)),
                segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
                refresh = { listOf(segment(99)) },
                capture = { _, _ -> attempts++; HlsSegmentDownloadResult.Failure(httpCode = 500) },
                wait = { throw CancellationException("Recording cancelled") },
            )
            fail("Expected CancellationException")
        } catch (_: CancellationException) {
            assertEquals(1, attempts)
        }
    }

    @Test
    fun `refresh throwing IOException during retry returns false gracefully without throwing`() = runBlocking {
        var attempts = 0
        var refreshes = 0
        val result = HlsSegmentRetry.capture(
            sequence = 12,
            initial = listOf(segment(12)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = {
                refreshes++
                throw java.io.IOException("Network connection reset")
            },
            capture = { _, _ ->
                attempts++
                HlsSegmentDownloadResult.Failure(httpCode = 503)
            },
            wait = { },
        )
        assertFalse("Capture should safely return false on refresh error", result)
        assertEquals(1, attempts)
        assertEquals(1, refreshes)
    }

    @Test
    fun `retry with invalid or negative Retry-After header falls back to default backoff`() = runBlocking {
        var attempts = 0
        val recordedDelays = mutableListOf<Long>()
        val result = HlsSegmentRetry.capture(
            sequence = 15,
            initial = listOf(segment(15)),
            segmentOf = { list, seq -> list.firstOrNull { it.sequence == seq } },
            refresh = { listOf(segment(15)) },
            capture = { _, _ ->
                attempts++
                if (attempts == 1) {
                    HlsSegmentDownloadResult.Failure(
                        httpCode = 429,
                        retryAfterHeader = "-5", // negative / invalid -> falls back to default
                        isTerminal = false,
                    )
                } else {
                    HlsSegmentDownloadResult.Success
                }
            },
            wait = { recordedDelays.add(it) },
        )
        assertTrue(result)
        assertEquals(2, attempts)
        assertEquals(listOf(500L), recordedDelays)
    }
}
