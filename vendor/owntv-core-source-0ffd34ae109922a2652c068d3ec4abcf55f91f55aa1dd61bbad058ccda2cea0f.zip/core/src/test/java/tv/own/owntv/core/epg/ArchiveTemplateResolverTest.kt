package tv.own.owntv.core.epg

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class ArchiveTemplateResolverTest {
    private val source = SourceEntity(id = 7, name = "Provider", type = SourceType.XTREAM,
        url = "https://x", username = "u/a", password = "p &?")
    private val channel = ChannelEntity(sourceId = 7, name = "Channel", streamUrl = "https://x/live.ts", remoteId = "42")
    private val start = 1_609_459_200_000L
    private val end = start + 3_600_000L
    private val base = "https://x/timeshift/u/p/60/2021-01-01:00-00/42.ts"

    private fun resolve(rows: List<ArchivePlaybackConfig>, baseUrl: String? = base) =
        ArchiveTemplateResolver.resolve(baseUrl, CatchupFormat.AUTO, channel, source, start, end, rows)

    @Test fun keepsStandardCandidatesBeforeProviderDeclaredFormats() {
        val result = resolve(listOf(ArchivePlaybackConfig(7,
            templates = listOf("https://x/archive/{streamId}/{utc}/{duration}.mpd"), manifestType = "mpd")))!!
        assertEquals(base, result.url)
        assertEquals(listOfNotNull(CatchupUrl.timeshiftPhpAlternate(base),
            CatchupUrl.timeshiftFormat(base, "m3u8"), "https://x/archive/42/1609459200/3600.mpd"), result.alternatives)
        assertEquals(mapOf("https://x/archive/42/1609459200/3600.mpd" to "mpd"), result.manifestTypes)
    }

    @Test fun exactChannelOverrideWinsAndCredentialsAreEncoded() {
        val playlist = ArchivePlaybackConfig(7, templates = listOf("https://x/list?start={utc}&duration={duration}"))
        val specific = ArchivePlaybackConfig(7, remoteId = "42", templates = listOf(
            "https://x/{username}/{password}/{streamId}?start={utc}&end={end}"), manifestType = "hls")
        val result = resolve(listOf(playlist, specific), null)!!
        assertEquals("https://x/u%2Fa/p%20%26%3F/42?start=1609459200&end=1609462800", result.url)
        assertTrue(result.alternatives.isEmpty())
        assertEquals("hls", result.manifestTypes[result.url])
    }

    @Test fun refusesInvalidOrIncompleteIntervalsAndUnknownPlaceholders() {
        val templates = listOf("https://x/live.ts", "https://x/a?start={utc}",
            "https://x/a?start={utc}&end={end}&unknown={mystery}")
        assertNull(resolve(listOf(ArchivePlaybackConfig(7, templates = templates)), null))
        assertNull(resolve(listOf(ArchivePlaybackConfig(7,
            templates = listOf("https://x/a?start={utc}&end={end}#fragment"))), null))
        assertNull(ArchiveTemplateResolver.resolve(base, CatchupFormat.AUTO, channel, source,
            start, start, emptyList()))
        assertNull(ArchiveTemplateResolver.resolve(base, CatchupFormat.AUTO, channel, source.copy(id = 8),
            start, end, emptyList()))
    }

    @Test fun missingRequiredCredentialsDoNotYieldAMalformedRequest() {
        val row = ArchivePlaybackConfig(7, templates = listOf("https://x/{password}?start={utc}&duration={duration}"))
        assertNull(ArchiveTemplateResolver.resolve(null, CatchupFormat.AUTO, channel,
            source.copy(password = null), start, end, listOf(row)))
    }

    @Test fun acceptsUtcCalendarTemplateDeduplicatesAndCapsAlternatives() {
        val calendar = "https://x/{Y}-{m}-{d}/{H}-{M}?duration={duration}"
        val result = resolve(listOf(ArchivePlaybackConfig(7, templates = listOf(calendar, calendar,
            "https://x/a?start={utc}&duration={duration}", "https://x/ignored?start={utc}&duration={duration}"))))!!
        assertEquals(4, result.alternatives.size)
        assertEquals("https://x/2021-01-01/00-00?duration=3600", result.alternatives[2])
        assertFalse(result.alternatives.any { "ignored" in it })
    }

    @Test fun usesTheAlreadyCorrectedRequestIntervalWithoutApplyingAnotherShift() {
        val correctedStart = CatchupUrl.requestStartMs(start, 60)
        val row = ArchivePlaybackConfig(7, templates = listOf(
            "https://x/{Y}-{m}-{d}/{H}-{M}?start={utc}&end={end}&duration={duration}"))
        val result = ArchiveTemplateResolver.resolve(null, CatchupFormat.AUTO, channel, source,
            correctedStart, correctedStart + (end - start), listOf(row))!!
        assertEquals("https://x/2021-01-01/01-00?start=1609462800&end=1609466400&duration=3600", result.url)
    }
}
