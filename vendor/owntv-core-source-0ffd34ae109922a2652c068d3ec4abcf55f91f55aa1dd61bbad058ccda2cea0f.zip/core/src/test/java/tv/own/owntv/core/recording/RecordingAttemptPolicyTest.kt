package tv.own.owntv.core.recording

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class RecordingAttemptPolicyTest {
    @Test fun `raw archive preserves partial bytes while live and segmented captures may retry`() {
        assertFalse(RecordingAttemptPolicy.mayRetry(true, 10, false))
        assertTrue(RecordingAttemptPolicy.mayRetry(true, 0, false))
        assertTrue(RecordingAttemptPolicy.mayRetry(false, 10, false))
        assertTrue(RecordingAttemptPolicy.mayRetry(true, 10, true))
    }

    @Test fun `provider wait uses monotonic time and never retries after recording window`() = runBlocking {
        var elapsed = 0L
        assertTrue(RecordingAttemptPolicy.awaitRetry(30_000, 40_000, { elapsed }, { elapsed }, { elapsed += it }))
        assertEquals(30_000, elapsed)
        elapsed = 0
        assertFalse(RecordingAttemptPolicy.awaitRetry(30_000, 10_000, { elapsed }, { elapsed }, { elapsed += it }))
        assertEquals(10_000, elapsed)
    }

    @Test fun `provider wait propagates cancellation immediately`() = runBlocking {
        try {
            RecordingAttemptPolicy.awaitRetry(30_000, 40_000, { 0 }, { 0 }, { throw CancellationException() })
            fail("Cancellation must propagate")
        } catch (_: CancellationException) { }
    }

    @Test fun `archive correction shifts both endpoints once without changing duration`() {
        val original = 1_000L..121_000L
        for (shift in listOf(-60, 0, 60)) {
            val corrected = RecordingAttemptPolicy.archiveWindow(original.first, original.last, shift)
            assertEquals(120_000L, corrected.last - corrected.first)
            assertEquals(original.first + shift * 60_000L, corrected.first)
        }
    }

    @Test fun `mux success requires successful stop and nonempty output`() {
        val order = mutableListOf<String>()
        assertTrue(RecordingMuxCompletion.complete({ order += "copy" }, { order += "stop" }, { order += "validate"; true }))
        assertEquals(listOf("copy", "stop", "validate"), order)
        assertFalse(RecordingMuxCompletion.complete({}, {}, { false }))
        var validated = false
        try {
            RecordingMuxCompletion.complete({}, { throw IllegalStateException("index failed") }, { validated = true; true })
            fail("Failed container finalization must not become success")
        } catch (_: IllegalStateException) { }
        assertFalse(validated)
    }

    @Test fun `mux cancellation is not swallowed`() {
        try {
            RecordingMuxCompletion.complete({ throw CancellationException() }, {}, { true })
            fail("Cancellation must propagate")
        } catch (_: CancellationException) { }
    }
}
