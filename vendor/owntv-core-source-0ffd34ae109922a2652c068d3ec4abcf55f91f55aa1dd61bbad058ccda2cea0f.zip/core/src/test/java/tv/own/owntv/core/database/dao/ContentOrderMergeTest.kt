package tv.own.owntv.core.database.dao

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.ContentOrderEntity
import tv.own.owntv.core.model.MediaType

class ContentOrderMergeTest {
    private fun row(item: Long, position: Int, profile: Long = 1, context: String = "all", type: MediaType = MediaType.LIVE) =
        ContentOrderEntity(id = item + 100, profileId = profile, mediaType = type, contextKey = context, itemId = item, position = position)

    @Test fun inactiveItemsKeepTheirOrderAndIdentity() {
        val existing = listOf(row(4, 4), row(2, 1), row(3, 2), row(1, 0))
        val result = mergeContentOrder(1, MediaType.LIVE, "all", listOf(3, 1), existing)
        assertEquals(listOf(3L, 1L, 2L, 4L), result.map { it.itemId })
        assertEquals(listOf(0, 1, 2, 3), result.map { it.position })
        assertEquals(existing.first().id, result.last().id)
        assertEquals(listOf(4L, 2L, 3L, 1L), existing.map { it.itemId })
    }

    @Test fun unrelatedProfilesContextsAndTypesAreNeverCopiedIntoTheEditedContext() {
        val existing = listOf(row(2, 0, profile = 9), row(3, 0, context = "folder"), row(4, 0, type = MediaType.MOVIE), row(5, 0))
        val result = mergeContentOrder(1, MediaType.LIVE, "all", listOf(1), existing)
        assertEquals(listOf(1L, 5L), result.map { it.itemId })
        assertTrue(result.all { it.profileId == 1L && it.contextKey == "all" && it.mediaType == MediaType.LIVE })
    }

    @Test fun duplicateDraftIdsCannotCreateDuplicatePositions() {
        val result = mergeContentOrder(1, MediaType.LIVE, "all", listOf(2, 2, 1), listOf(row(2, 0), row(3, 1)))
        assertEquals(listOf(2L, 1L, 3L), result.map { it.itemId })
        assertEquals(listOf(0, 1, 2), result.map { it.position })
    }

    @Test fun emptyDraftPreservesEveryRetainedItem() {
        assertEquals(listOf(2L, 1L), mergeContentOrder(1, MediaType.LIVE, "all", emptyList(), listOf(row(1, 8), row(2, 4))).map { it.itemId })
    }
}
