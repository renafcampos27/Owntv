package tv.own.owntv.core.settings

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.player.EnginePreference

class Phase23BatchPlaybackPatchTest {
    private val target = ManualTsChannel(1, "1", "Legacy")
    private val outside = ManualTsChannel(1, "2", "Outside")

    @Test fun `audio-only patch preserves legacy format and engine and unrelated legacy`() {
        val result = phase23PatchPlaybackBatch(emptyList(), listOf(target, outside), listOf(target)) {
            it.copy(audioDelayMs = 150)
        }
        assertEquals(listOf(outside), result.legacy)
        assertEquals(ChannelPlaybackOptions(engine = EnginePreference.EXO_ONLY,
            format = ChannelStreamFormat.TS, audioDelayMs = 150), result.rows.single().options)
    }

    @Test fun `partial modern row keeps legacy TS plus every unchanged field`() {
        val current = ChannelPlaybackConfig(target, ChannelPlaybackOptions(reserveSecs = 20, extraSecs = 4))
        val result = phase23PatchPlaybackBatch(listOf(current), listOf(target), listOf(target)) {
            it.copy(audioDelayMs = -50)
        }
        assertEquals(current.options.copy(engine = EnginePreference.EXO_ONLY,
            format = ChannelStreamFormat.TS, audioDelayMs = -50), result.rows.single().options)
    }

    @Test fun `explicit inheritance removes the migrated choices and untouched modern row is exact`() {
        val outsideRow = ChannelPlaybackConfig(outside, ChannelPlaybackOptions(format = ChannelStreamFormat.HLS))
        val result = phase23PatchPlaybackBatch(listOf(outsideRow), listOf(target), listOf(target)) {
            it.copy(engine = null, format = null)
        }
        assertEquals(listOf(outsideRow), result.rows)
        assertTrue(result.legacy.isEmpty())
    }

    @Test fun `modern format takes priority and duplicate targets patch once`() {
        val row = ChannelPlaybackConfig(target, ChannelPlaybackOptions(engine = EnginePreference.MPV_ONLY,
            format = ChannelStreamFormat.HLS))
        var calls = 0
        val result = phase23PatchPlaybackBatch(listOf(row), listOf(target), listOf(target, target)) {
            calls++; it.copy(reserveSecs = 15)
        }
        assertEquals(1, calls)
        assertEquals(row.options.copy(reserveSecs = 15), result.rows.single().options)
    }
}
