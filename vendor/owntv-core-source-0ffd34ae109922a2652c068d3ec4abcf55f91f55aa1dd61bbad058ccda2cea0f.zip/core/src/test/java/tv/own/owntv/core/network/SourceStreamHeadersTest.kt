package tv.own.owntv.core.network

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class SourceStreamHeadersTest {
    private fun source(type: SourceType) = SourceEntity(name = "source", type = type,
        url = "http://example.invalid", httpReferer = "https://identity.invalid")
    @Test fun explicitChannelIdentityOverridesSourceDefault() {
        val headers = StreamHeaders.decode(StreamHeaders.forSource(source(SourceType.M3U),
            "referer: https://channel.invalid\nCookie: test"))
        assertEquals("https://channel.invalid", headers["Referer"])
        assertEquals("test", headers["Cookie"])
    }
    @Test fun sourceRefererIsNotGlobalOrPortalIdentity() {
        assertNull(StreamHeaders.forSource(null, null))
        assertNull(StreamHeaders.forSource(source(SourceType.STALKER), null))
        assertEquals("https://identity.invalid", StreamHeaders.decode(
            StreamHeaders.forSource(source(SourceType.XTREAM), null))["Referer"])
    }
}
