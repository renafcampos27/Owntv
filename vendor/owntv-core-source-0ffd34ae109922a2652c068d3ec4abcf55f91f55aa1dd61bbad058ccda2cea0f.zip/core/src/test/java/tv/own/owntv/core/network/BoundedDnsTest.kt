package tv.own.owntv.core.network

import okhttp3.Dns
import org.junit.Assert.*
import org.junit.Test
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

class BoundedDnsTest {
    @Test fun `timeout is bounded and same host shares the underlying lookup`() {
        val release=CountDownLatch(1);val count=AtomicInteger()
        val dns=BoundedDns(Dns { count.incrementAndGet();release.await();listOf(InetAddress.getByAddress(byteArrayOf(127,0,0,1))) },30,10)
        try {
            repeat(2) { try { dns.lookup("test.invalid");fail("Expected deadline") } catch (_: UnknownHostException) {} }
            assertEquals(1,count.get())
        } finally { release.countDown() }
    }
    @Test fun `last successful answer expires and is never an indefinite fallback`() {
        var now=1L;var fail=false
        val address=InetAddress.getByAddress(byteArrayOf(127,0,0,1))
        val dns=BoundedDns(Dns { if(fail) throw UnknownHostException();listOf(address) },100,10,{now})
        assertEquals(listOf(address),dns.lookup("test.invalid"));fail=true
        assertEquals(listOf(address),dns.lookup("test.invalid"))
        now+=300_001
        try { dns.lookup("test.invalid");fail("Expired answer must not be returned") } catch (_: UnknownHostException) {}
    }
}
