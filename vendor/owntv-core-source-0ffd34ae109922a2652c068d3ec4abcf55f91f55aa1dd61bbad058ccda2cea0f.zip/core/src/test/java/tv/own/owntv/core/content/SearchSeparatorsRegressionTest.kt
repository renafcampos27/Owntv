package tv.own.owntv.core.content

import org.junit.Assert.*
import org.junit.Test

class SearchSeparatorsRegressionTest {
    @Test fun punctuationSeparatesIndexedWordsInsteadOfJoiningThem() {
        assertEquals("RTP* 1*", SearchReader.ftsQuery("RTP-1"))
        assertEquals("SIC* HD*", SearchReader.ftsQuery("SIC_HD"))
        assertEquals("PT* Odisseia*", SearchReader.ftsQuery("PT: Odisseia"))
        assertEquals("São* João*", SearchReader.ftsQuery("São/João"))
        assertNull(SearchReader.ftsQuery("-- : \""))
    }
}
