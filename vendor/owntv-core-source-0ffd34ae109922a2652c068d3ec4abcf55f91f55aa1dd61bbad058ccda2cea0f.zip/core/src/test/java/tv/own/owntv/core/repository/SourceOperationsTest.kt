package tv.own.owntv.core.repository

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class SourceOperationsTest {
    @Test fun sameNamesAreNotAnIdentityAndPasswordEditsChangeRevision() {
        val source = tv.own.owntv.core.database.entity.SourceEntity(id = 1, name = "Same name",
            type = tv.own.owntv.core.model.SourceType.XTREAM, url = "https://host.invalid", username = "u", password = "p")
        assertNotEquals(source.catalogConfigurationKey(), source.copy(password = "fixed").catalogConfigurationKey())
        assertEquals(source.catalogConfigurationKey(), source.copy(lastSyncAt = 1000, name = "Renamed").catalogConfigurationKey())
        assertNotEquals(source.catalogConfigurationKey(), source.copy(url = "https://other.invalid").catalogConfigurationKey())
        assertEquals(source.connectionConfigurationKey(), source.copy(epgUrl = "https://guide.invalid", syncLive = false,
            preferHls = true).connectionConfigurationKey())
    }
    @Test fun editJoinsCancelledOldWorkBeforeSavingAndNextReadSeesNewConfig() = runBlocking {
        val operations = SourceOperations()
        val entered = CompletableDeferred<Unit>()
        val closing = CompletableDeferred<Unit>()
        val allowClose = CompletableDeferred<Unit>()
        var config = "old"
        val old = launch { operations.sync(1) {
            entered.complete(Unit)
            try { awaitCancellation() } finally { withContext(NonCancellable) {
                closing.complete(Unit); allowClose.await()
            } }
        } }
        entered.await()
        val edit = async { operations.edit(1) { config = "new" } }
        closing.await()
        yield()
        assertFalse(edit.isCompleted)
        assertEquals("old", config)
        allowClose.complete(Unit)
        edit.await(); old.join()
        assertEquals("new", operations.sync(1) { config })
    }
    @Test fun independentSourcesCanUpdateWhileAnotherSourceIsBusy() = runBlocking {
        val operations = SourceOperations()
        val entered = CompletableDeferred<Unit>()
        val busy = launch { operations.sync(1) { entered.complete(Unit); awaitCancellation() } }
        entered.await()
        assertEquals(2, operations.edit(2) { 2 })
        busy.cancelAndJoin()
        assertEquals(3, operations.sync(1) { 3 })
    }
}
