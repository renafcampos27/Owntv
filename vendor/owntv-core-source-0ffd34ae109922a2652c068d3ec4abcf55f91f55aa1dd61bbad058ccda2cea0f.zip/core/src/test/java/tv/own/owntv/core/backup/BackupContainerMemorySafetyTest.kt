package tv.own.owntv.core.backup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BackupContainerMemorySafetyTest {

    @get:Rule
    val folder = TemporaryFolder()

    private val validJson = """{"version":14,"profiles":[]}"""

    @Test
    fun `normal container round-trips within safe memory limits`() {
        val file = File(folder.root, "normal.own")
        val payload = BackupContainer.Payload(
            json = validJson,
            wallpaper = BackupContainer.Asset("bg.jpg", byteArrayOf(1, 2, 3, 4)),
            subtitles = mapOf("sub1.srt" to byteArrayOf(10, 20)),
            avatars = mapOf("av1.jpg" to byteArrayOf(30, 40)),
        )
        file.writeBytes(BackupContainer.pack(payload, passphrase = null))

        assertEquals(BackupContainer.Kind.CONTAINER, BackupContainer.probe(file))
        val read = BackupContainer.open(file)
        assertEquals(validJson, read.json)
        assertEquals("bg.jpg", read.wallpaper?.name)
        assertEquals(1, read.subtitles.size)
        assertEquals(1, read.avatars.size)
    }

    @Test
    fun `oversized file is rejected by probe and open before reading into memory`() {
        val file = File(folder.root, "giant.own")
        // Create sparse-like or padded file larger than MAX_FILE_BYTES
        FileOutputStream(file).use { out ->
            val chunk = ByteArray(1024 * 1024)
            repeat(33) {
                out.write(chunk)
            }
        }
        assertTrue(file.length() > BackupContainer.MAX_FILE_BYTES)

        assertEquals(BackupContainer.Kind.UNKNOWN, BackupContainer.probe(file))
        try {
            BackupContainer.open(file)
            fail("Expected oversized file to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `legacy JSON larger than MAX_JSON_BYTES is rejected`() {
        val file = File(folder.root, "giant.json")
        FileOutputStream(file).use { out ->
            val chunk = ByteArray(1024 * 1024)
            repeat(17) {
                out.write(chunk)
            }
        }
        assertTrue(file.length() > BackupContainer.MAX_JSON_BYTES && file.length() <= BackupContainer.MAX_FILE_BYTES)

        try {
            BackupContainer.open(file)
            fail("Expected oversized legacy json to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `container exceeding MAX_ENTRY_COUNT is rejected without unbounded processing`() {
        val file = File(folder.root, "many_entries.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                for (i in 0..505) {
                    zos.putNextEntry(ZipEntry("${BackupContainer.SUBTITLE_DIR}sub_$i.srt"))
                    zos.write(byteArrayOf(1, 2))
                    zos.closeEntry()
                }
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected container with excessive entries to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `zip entry expanding beyond individual limit is rejected during streaming`() {
        val file = File(folder.root, "inflated_entry.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                // Write an avatar entry that expands to > MAX_AVATAR_BYTES (2 MB)
                zos.putNextEntry(ZipEntry("${BackupContainer.AVATAR_DIR}avatar_bomb.jpg"))
                val chunk = ByteArray(64 * 1024) // compresses well
                repeat(40) { // 2.5 MB decompressed
                    zos.write(chunk)
                }
                zos.closeEntry()

                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected oversized zip entry expansion to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `zip expanding beyond MAX_TOTAL_DECOMPRESSED_BYTES is aborted`() {
        val file = File(folder.root, "total_expansion_bomb.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                // 20 subtitle files of 1.8 MB each = 36 MB total decompressed (> 32 MB max total)
                val chunk = ByteArray(64 * 1024)
                for (i in 0 until 20) {
                    zos.putNextEntry(ZipEntry("${BackupContainer.SUBTITLE_DIR}sub_$i.srt"))
                    repeat(28) { // ~1.8 MB each
                        zos.write(chunk)
                    }
                    zos.closeEntry()
                }
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected total expansion exceeding cap to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `readJson extracts json string without decompressing or allocating binary assets`() {
        val file = File(folder.root, "with_assets.own")
        val payload = BackupContainer.Payload(
            json = validJson,
            wallpaper = BackupContainer.Asset("bg.jpg", byteArrayOf(1, 2, 3, 4)),
            subtitles = mapOf("sub1.srt" to byteArrayOf(10, 20)),
            avatars = mapOf("av1.jpg" to byteArrayOf(30, 40)),
        )
        file.writeBytes(BackupContainer.pack(payload, passphrase = null))

        val json = BackupContainer.readJson(file)
        assertEquals(validJson, json)
    }

    @Test
    fun `container with zip slip path traversal is rejected immediately`() {
        val file = File(folder.root, "traversal.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry("${BackupContainer.WALLPAPER_DIR}../evil.jpg"))
                zos.write(byteArrayOf(1, 2, 3))
                zos.closeEntry()
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected zip traversal entry to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `container with unrecognized file entry is rejected immediately`() {
        val file = File(folder.root, "unknown_entry.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry("untrusted_payload.exe"))
                zos.write(byteArrayOf(1, 2, 3))
                zos.closeEntry()
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected unknown entry to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `container with unrecognized file entry before json is rejected by readJson`() {
        val file = File(folder.root, "unknown_before_json.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry("untrusted_payload.exe"))
                zos.write(byteArrayOf(1, 2, 3))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }

        try {
            BackupContainer.readJson(file)
            fail("Expected readJson to reject unrecognized entry before json")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `container with backslash or colon path traversal is rejected`() {
        val file = File(folder.root, "backslash_traversal.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry("${BackupContainer.WALLPAPER_DIR}\\evil.jpg"))
                zos.write(byteArrayOf(1, 2, 3))
                zos.closeEntry()
            }
        }

        try {
            BackupContainer.open(file)
            fail("Expected backslash traversal to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    private fun localZipEntry(name: String, content: ByteArray): ByteArray {
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x50, 0x4B, 0x03, 0x04)) // PK\x03\x04
        out.write(byteArrayOf(20, 0)) // version
        out.write(byteArrayOf(0, 0)) // flags
        out.write(byteArrayOf(0, 0)) // compression: STORED (0)
        out.write(byteArrayOf(0, 0, 0, 0)) // time/date
        val crc = java.util.zip.CRC32().apply { update(content) }.value.toInt()
        out.write(byteArrayOf(crc.toByte(), (crc ushr 8).toByte(), (crc ushr 16).toByte(), (crc ushr 24).toByte()))
        val size = content.size
        out.write(byteArrayOf(size.toByte(), (size ushr 8).toByte(), (size ushr 16).toByte(), (size ushr 24).toByte()))
        out.write(byteArrayOf(size.toByte(), (size ushr 8).toByte(), (size ushr 16).toByte(), (size ushr 24).toByte()))
        val nameLen = nameBytes.size
        out.write(byteArrayOf(nameLen.toByte(), (nameLen ushr 8).toByte()))
        out.write(byteArrayOf(0, 0)) // extra len
        out.write(nameBytes)
        out.write(content)
        return out.toByteArray()
    }

    @Test
    fun `container with duplicate json entry is rejected`() {
        val file = File(folder.root, "duplicate_json.own")
        val entry1 = localZipEntry(BackupContainer.JSON_ENTRY, validJson.toByteArray(Charsets.UTF_8))
        val entry2 = localZipEntry(BackupContainer.JSON_ENTRY, """{"version":14,"profiles":[{"name":"injected"}]}""".toByteArray(Charsets.UTF_8))
        file.writeBytes(entry1 + entry2)

        try {
            BackupContainer.open(file)
            fail("Expected duplicate json entry to be rejected")
        } catch (_: IllegalStateException) {
            // expected
        }
    }

    @Test
    fun `readJson bounds and validates recognized asset preceding json`() {
        val file = File(folder.root, "wallpaper_before_json.own")
        FileOutputStream(file).use { fos ->
            ZipOutputStream(fos).use { zos ->
                zos.putNextEntry(ZipEntry("${BackupContainer.WALLPAPER_DIR}bg.jpg"))
                zos.write(byteArrayOf(1, 2, 3, 4, 5))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry(BackupContainer.JSON_ENTRY))
                zos.write(validJson.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }

        val json = BackupContainer.readJson(file)
        assertEquals(validJson, json)
    }

    @Test
    fun `decryptBytes decrypts slice within larger buffer without copying`() {
        val key = BackupCrypto.deriveKey("slice-pass".toCharArray(), BackupCrypto.newSalt(), 1000)
        val plaintext = "payload-inside-slice-buffer".toByteArray(Charsets.UTF_8)
        val encrypted = BackupCrypto.encryptBytes(key, plaintext)
        val prefix = byteArrayOf(0x4F, 0x57, 0x4E, 0x54, 0x56, 0x42, 0x4B, 0x31, 0, 0, 0, 4, 1, 2, 3, 4)
        val suffix = byteArrayOf(99, 98, 97, 96, 95)
        val combined = prefix + encrypted + suffix

        val out = BackupCrypto.decryptBytes(key, combined, prefix.size, encrypted.size)
        org.junit.Assert.assertArrayEquals(plaintext, out)
    }

    @Test
    fun `decryptBytes rejects invalid offset and truncated length bounds`() {
        val key = BackupCrypto.deriveKey("bounds-pass".toCharArray(), BackupCrypto.newSalt(), 1000)
        val encrypted = BackupCrypto.encryptBytes(key, byteArrayOf(1, 2, 3, 4))

        // Negative offset
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, -1, encrypted.size) }.exceptionOrNull() is IllegalArgumentException)
        // Length < IV_BYTES (12) + GCM tag (16) = 28
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, 0, 27) }.exceptionOrNull() is IllegalArgumentException)
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, 0, 12) }.exceptionOrNull() is IllegalArgumentException)
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, 0, 0) }.exceptionOrNull() is IllegalArgumentException)
        // Offset + length > blob.size
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, 4, encrypted.size) }.exceptionOrNull() is IllegalArgumentException)
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, encrypted, Int.MAX_VALUE, 28) }.exceptionOrNull() is IllegalArgumentException)
    }

    @Test
    fun `decryptBytes rejects GCM tag or ciphertext tampering in slice`() {
        val key = BackupCrypto.deriveKey("gcm-pass".toCharArray(), BackupCrypto.newSalt(), 1000)
        val wrongKey = BackupCrypto.deriveKey("other-pass".toCharArray(), BackupCrypto.newSalt(), 1000)
        val plaintext = "authenticated-backup-content".toByteArray(Charsets.UTF_8)
        val prefix = ByteArray(24) { it.toByte() }
        val encrypted = BackupCrypto.encryptBytes(key, plaintext)
        val buffer = prefix + encrypted

        // Wrong key fails GCM authentication
        assertTrue(runCatching { BackupCrypto.decryptBytes(wrongKey, buffer, prefix.size, encrypted.size) }.isFailure)

        // Flip bit in IV inside slice
        val ivTampered = buffer.copyOf().also { it[prefix.size] = (it[prefix.size].toInt() xor 0x01).toByte() }
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, ivTampered, prefix.size, encrypted.size) }.isFailure)

        // Flip bit in ciphertext body inside slice
        val ctTampered = buffer.copyOf().also { it[prefix.size + 14] = (it[prefix.size + 14].toInt() xor 0x01).toByte() }
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, ctTampered, prefix.size, encrypted.size) }.isFailure)

        // Flip bit in trailing GCM tag inside slice
        val tagTampered = buffer.copyOf().also { it[it.lastIndex] = (it[it.lastIndex].toInt() xor 0x01).toByte() }
        assertTrue(runCatching { BackupCrypto.decryptBytes(key, tagTampered, prefix.size, encrypted.size) }.isFailure)
    }

    @Test
    fun `encrypted container round-trips open and readJson and rejects tampering or wrong password`() {
        val file = File(folder.root, "sealed.own")
        val payload = BackupContainer.Payload(
            json = validJson,
            wallpaper = BackupContainer.Asset("bg.jpg", byteArrayOf(7, 8, 9, 10)),
            subtitles = mapOf("1_en.srt" to byteArrayOf(11, 22, 33)),
            avatars = mapOf("1_av.jpg" to byteArrayOf(44, 55)),
        )
        val packed = BackupContainer.pack(payload, passphrase = "correct-horse-battery-staple")
        file.writeBytes(packed)

        assertEquals(BackupContainer.Kind.ENCRYPTED_CONTAINER, BackupContainer.probe(file))
        val opened = BackupContainer.open(file, "correct-horse-battery-staple")
        assertEquals(validJson, opened.json)
        org.junit.Assert.assertArrayEquals(byteArrayOf(7, 8, 9, 10), opened.wallpaper?.bytes)
        org.junit.Assert.assertArrayEquals(byteArrayOf(11, 22, 33), opened.subtitles["1_en.srt"])
        org.junit.Assert.assertArrayEquals(byteArrayOf(44, 55), opened.avatars["1_av.jpg"])
        assertEquals(validJson, BackupContainer.readJson(file, "correct-horse-battery-staple"))

        // Wrong or missing password throws WrongPasswordException
        assertTrue(runCatching { BackupContainer.open(file, "wrong-password") }.exceptionOrNull() is BackupManager.WrongPasswordException)
        assertTrue(runCatching { BackupContainer.open(file, null) }.exceptionOrNull() is BackupManager.WrongPasswordException)
        assertTrue(runCatching { BackupContainer.readJson(file, "wrong-password") }.exceptionOrNull() is BackupManager.WrongPasswordException)

        // Tampered GCM tag in container file throws WrongPasswordException before any zip parsing
        val tamperedFile = File(folder.root, "tampered.own")
        val tamperedBytes = packed.copyOf().also { it[it.lastIndex] = (it[it.lastIndex].toInt() xor 0xFF).toByte() }
        tamperedFile.writeBytes(tamperedBytes)
        assertTrue(runCatching { BackupContainer.open(tamperedFile, "correct-horse-battery-staple") }.exceptionOrNull() is BackupManager.WrongPasswordException)
        assertTrue(runCatching { BackupContainer.readJson(tamperedFile, "correct-horse-battery-staple") }.exceptionOrNull() is BackupManager.WrongPasswordException)
    }
}
