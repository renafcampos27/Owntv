package tv.own.owntv.core.backup

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.PlaybackQuirkEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class BackupRestoreIdentityTest {
    @Test fun `real source identity matching prevents a selective restore collision and permits remapping`() {
        val incoming = SourceEntity(id = 4, name = "A", type = SourceType.XTREAM,
            url = "https://provider-a.invalid", username = "alice")
        val unrelated = incoming.copy(name = "B", url = "https://provider-b.invalid", username = "bob")
        val json = PlaybackDatabaseBackup.encode(PlaybackQuirkEntity("4:LIVE:123", 4, "LIVE", "EXO"))
        val match = matchSourceForRestore(listOf(unrelated), incoming)
        assertNull(match)
        val missing = if (match == null) emptyMap() else mapOf(incoming.id to match.id)
        assertNull(PlaybackDatabaseBackup.decode(json, missing, setOf(unrelated.id)))
        val moved = incoming.copy(id = 42)
        val resolved = matchSourceForRestore(listOf(unrelated, moved), incoming)!!
        val mapping = mapOf(incoming.id to resolved.id)
        val row = PlaybackDatabaseBackup.decode(JSONObject(json.toString()), mapping, setOf(4, 42))!!
        assertEquals(42L, row.sourceId); assertEquals("42:LIVE:123", row.contentKey)
    }
    @Test fun `equal source numbers do not establish identity`() {
        val identity = BackupRestoreIdentity(emptyMap(), emptyMap())
        assertNull(identity.engineKey("4:LIVE:123"))
        assertNull(identity.typedKey("movie:4:123"))
        assertNull(identity.source(4))
        assertEquals(3, identity.skipped)
    }
    @Test fun `resolved source maps stable and typed keys without touching provider ids`() {
        val identity = BackupRestoreIdentity(mapOf(1L to 8L), mapOf(4L to 9L))
        assertEquals("9:LIVE:123", identity.engineKey("4:LIVE:123"))
        assertEquals("episode:9:show:S1E2", identity.typedKey("episode:4:show:S1E2"))
        assertEquals("HOME", identity.profileMap(JSONObject().put("1", "HOME")).getString("8"))
        assertEquals(0, identity.skipped)
    }
    @Test fun `legacy URLs local files and negative source namespaces remain compatible`() {
        val identity = BackupRestoreIdentity(emptyMap(), emptyMap())
        val url = "https://example.invalid/live/test-user/test-pass/1.m3u8"
        assertEquals(url, identity.engineKey(url))
        assertEquals("file:/recording.ts", identity.engineKey("file:/recording.ts"))
        assertEquals("-1:LIVE:file", identity.engineKey("-1:LIVE:file"))
        assertEquals(-1L, identity.source(-1))
        assertEquals(0, identity.skipped)
    }
    @Test fun `unresolved profile map entries are filtered even with a nonempty map`() {
        val identity = BackupRestoreIdentity(mapOf(2L to 7L), emptyMap())
        val result = identity.profileMap(JSONObject().put("1", "foreign").put("2", "resolved"))
        assertFalse(result.has("1")); assertEquals("resolved", result.getString("7"))
        assertEquals(1, identity.skipped)
    }
}
