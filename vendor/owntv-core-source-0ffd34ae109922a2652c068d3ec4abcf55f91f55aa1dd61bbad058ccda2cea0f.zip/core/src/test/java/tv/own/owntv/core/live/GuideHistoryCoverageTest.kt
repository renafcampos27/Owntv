package tv.own.owntv.core.live

import org.junit.Assert.*
import org.junit.Test

class GuideHistoryCoverageTest {
    private val hour = 3_600_000L
    private val now = 48 * hour

    @Test fun partialStoredWindowRequestsOnlyMissingOlderPrefix() {
        assertEquals(24 * hour to 36 * hour, GuideHistoryCoverage.missingPrefix(24 * hour, 42 * hour, 36 * hour, now))
        assertEquals(24 * hour to 30 * hour, GuideHistoryCoverage.missingPrefix(24 * hour, 30 * hour, 36 * hour, now))
    }

    @Test fun coveredCurrentFutureAndEmptyWindowsDoNotFetchHistory() {
        assertNull(GuideHistoryCoverage.missingPrefix(24 * hour, 42 * hour, 23 * hour, now))
        assertNull(GuideHistoryCoverage.missingPrefix(42 * hour, 50 * hour, 46 * hour, now))
        assertNull(GuideHistoryCoverage.missingPrefix(50 * hour, 54 * hour, 52 * hour, now))
        assertNull(GuideHistoryCoverage.missingPrefix(24 * hour, 24 * hour, 36 * hour, now))
        assertNull(GuideHistoryCoverage.missingPrefix(24 * hour, 42 * hour, null, now))
    }
}
