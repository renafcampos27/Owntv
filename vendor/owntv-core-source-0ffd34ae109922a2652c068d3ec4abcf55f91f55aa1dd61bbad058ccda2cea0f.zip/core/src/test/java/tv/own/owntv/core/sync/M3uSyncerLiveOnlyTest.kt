package tv.own.owntv.core.sync

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import java.io.File
import java.lang.reflect.Proxy
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import tv.own.owntv.core.customize.CustomizationStore
import tv.own.owntv.core.database.BulkInsertHelper
import tv.own.owntv.core.database.OwnTVDatabase
import tv.own.owntv.core.database.dao.CategoryDao
import tv.own.owntv.core.database.dao.ChannelDao
import tv.own.owntv.core.database.dao.MovieDao
import tv.own.owntv.core.database.dao.SeriesDao
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.CategoryEntity
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.ContentHashProjection
import tv.own.owntv.core.database.entity.EpisodeEntity
import tv.own.owntv.core.database.entity.MovieEntity
import tv.own.owntv.core.database.entity.SeasonEntity
import tv.own.owntv.core.database.entity.SeriesEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.model.MediaType
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.parser.M3uParser
import tv.own.owntv.core.settings.SettingsRepository

class M3uSyncerLiveOnlyTest {

    @get:Rule
    val temp = TemporaryFolder()

    private lateinit var context: Context
    private lateinit var settings: SettingsRepository
    private lateinit var customize: CustomizationStore
    private lateinit var bulkInsertHelper: BulkInsertHelper

    @Before
    fun setUp() {
        val rootDir = temp.newFolder("owntv-m3u-sync-test")
        val prefs = InMemorySharedPreferences()
        context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getFilesDir(): File = File(rootDir, "files").apply { mkdirs() }
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = prefs
        }
        val localeStore = LocaleStore(prefs, null)
        settings = SettingsRepository(context, localeStore, InMemoryPreferencesDataStore())
        customize = CustomizationStore(context)
        val db = Class.forName("tv.own.owntv.core.database.OwnTVDatabase_Impl")
            .getDeclaredConstructor()
            .newInstance() as OwnTVDatabase
        bulkInsertHelper = BulkInsertHelper(db)
    }

    @Test
    fun `live-only M3U sync imports only live channels and skips movies and series`() = runBlocking {
        val insertedCategories = mutableListOf<CategoryEntity>()
        val insertedChannels = mutableListOf<ChannelEntity>()
        val insertedMovies = mutableListOf<MovieEntity>()
        val insertedSeries = mutableListOf<SeriesEntity>()
        var moviesHashQueried = false
        var seriesHashQueried = false
        var moviesPruned = false
        var seriesPruned = false

        val syncer = buildSyncer(
            playlist = MIXED_PLAYLIST,
            insertedCategories = insertedCategories,
            insertedChannels = insertedChannels,
            insertedMovies = insertedMovies,
            insertedSeries = insertedSeries,
            onMoviesHashQuery = { moviesHashQueried = true },
            onSeriesHashQuery = { seriesHashQueried = true },
            onMoviesPrune = { moviesPruned = true },
            onSeriesPrune = { seriesPruned = true },
        )

        val source = SourceEntity(
            id = 7L,
            name = "Mixed M3U",
            type = SourceType.M3U,
            url = "https://example.invalid/mixed.m3u",
            lastSyncAt = 1_000L,
        )
        val stats = SyncStatsCollector(source.id)
        syncer.sync(
            s = source,
            progress = SyncCounters(SyncContentTypes.LIVE_ONLY) {},
            stats = stats,
            contentTypes = SyncContentTypes.LIVE_ONLY,
        )

        assertEquals(2, insertedChannels.size)
        assertEquals(listOf("RTP 1 HD", "SIC HD"), insertedChannels.map { it.name })
        assertTrue("Movies must not be inserted in LIVE_ONLY mode", insertedMovies.isEmpty())
        assertTrue("Series must not be inserted in LIVE_ONLY mode", insertedSeries.isEmpty())
        assertEquals(setOf(MediaType.LIVE), insertedCategories.map { it.mediaType }.toSet())
        assertFalse("Movie hashes must not be queried in LIVE_ONLY mode", moviesHashQueried)
        assertFalse("Series hashes must not be queried in LIVE_ONLY mode", seriesHashQueried)
        assertFalse("Existing movies must not be pruned in LIVE_ONLY mode", moviesPruned)
        assertFalse("Existing series must not be pruned in LIVE_ONLY mode", seriesPruned)
        assertEquals(2, stats.processedCounts["channels"])
        assertFalse(stats.processedCounts.containsKey("movies"))
        assertFalse(stats.processedCounts.containsKey("series"))
    }

    @Test
    fun `full M3U sync imports live channels, movies and series when all types are enabled`() = runBlocking {
        val insertedCategories = mutableListOf<CategoryEntity>()
        val insertedChannels = mutableListOf<ChannelEntity>()
        val insertedMovies = mutableListOf<MovieEntity>()
        val insertedSeries = mutableListOf<SeriesEntity>()

        val syncer = buildSyncer(
            playlist = MIXED_PLAYLIST,
            insertedCategories = insertedCategories,
            insertedChannels = insertedChannels,
            insertedMovies = insertedMovies,
            insertedSeries = insertedSeries,
        )

        val source = SourceEntity(
            id = 8L,
            name = "Mixed M3U Full",
            type = SourceType.M3U,
            url = "https://example.invalid/mixed.m3u",
            lastSyncAt = 1_000L,
        )
        val stats = SyncStatsCollector(source.id)
        syncer.sync(
            s = source,
            progress = SyncCounters(SyncContentTypes.ALL) {},
            stats = stats,
            contentTypes = SyncContentTypes.ALL,
        )

        assertEquals(2, insertedChannels.size)
        assertEquals(1, insertedMovies.size)
        assertEquals("Matrix, The (1999)", insertedMovies.single().name)
        assertEquals(1, insertedSeries.size)
        assertEquals("Dark", insertedSeries.single().name)
        assertEquals(
            setOf(MediaType.LIVE, MediaType.MOVIE, MediaType.SERIES),
            insertedCategories.map { it.mediaType }.toSet(),
        )
    }

    @Test
    fun `rescueTruncatedKeys short-circuits immediately when stored map is empty`() {
        val empty = emptyMap<String, StoredRow>()
        val result = M3uSyncer.rescueTruncatedKeys(
            empty,
            listOf("Movie, The (1999)\u0001Movies" to "The (1999)\u0001Movies"),
        )
        assertSame(empty, result)
    }

    @Test fun `empty html and incomplete catalogues do not prune or report success`() = runBlocking {
        for (body in listOf("#EXTM3U\n", "<html>server error</html>", "#EXTM3U\n#EXTINF:-1,Missing URL\n")) {
            var pruned = false
            val channels = mutableListOf<ChannelEntity>()
            val syncer = buildSyncer(body, mutableListOf(), channels, mutableListOf(), mutableListOf(),
                onLivePrune = { pruned = true })
            val source = SourceEntity(id = 99, name = "Existing", type = SourceType.M3U,
                url = "https://example.invalid/list.m3u", lastSyncAt = 1000)
            val result = runCatching { syncer.sync(source, SyncCounters(SyncContentTypes.LIVE_ONLY) {},
                SyncStatsCollector(source.id), SyncContentTypes.LIVE_ONLY) }
            assertTrue(result.exceptionOrNull() is java.io.IOException)
            assertFalse(pruned)
            assertTrue(channels.isEmpty())
        }
    }

    private fun buildSyncer(
        playlist: String,
        insertedCategories: MutableList<CategoryEntity>,
        insertedChannels: MutableList<ChannelEntity>,
        insertedMovies: MutableList<MovieEntity>,
        insertedSeries: MutableList<SeriesEntity>,
        onMoviesHashQuery: () -> Unit = {},
        onSeriesHashQuery: () -> Unit = {},
        onMoviesPrune: () -> Unit = {},
        onSeriesPrune: () -> Unit = {},
        onLivePrune: () -> Unit = {},
    ): M3uSyncer {
        var nextCategoryId = 100L
        val categoryDao = proxyDao(CategoryDao::class.java) { method, args ->
            when (method.name) {
                "findByRemoteIds" -> emptyList<CategoryEntity>()
                "insertAll" -> {
                    @Suppress("UNCHECKED_CAST")
                    val list = args?.get(0) as? List<CategoryEntity> ?: emptyList()
                    insertedCategories.addAll(list)
                    list.map { nextCategoryId++ }
                }
                "updateAll" -> Unit
                "remoteIdsForSource" -> emptyList<String>()
                "deleteByRemoteIds" -> Unit
                else -> null
            }
        }
        val channelDao = proxyDao(ChannelDao::class.java) { method, args ->
            when (method.name) {
                "contentHashesForSource" -> emptyList<ContentHashProjection>()
                "insertAll" -> {
                    @Suppress("UNCHECKED_CAST")
                    val list = args?.get(0) as? List<ChannelEntity> ?: emptyList()
                    insertedChannels.addAll(list)
                    Unit
                }
                "updateAll" -> Unit
                "remoteIdsForSource" -> { onLivePrune(); insertedChannels.mapNotNull { it.remoteId } }
                "deleteByRemoteIds" -> Unit
                "deleteNullRemoteIds" -> Unit
                else -> null
            }
        }
        val movieDao = proxyDao(MovieDao::class.java) { method, args ->
            when (method.name) {
                "contentHashesForSource" -> {
                    onMoviesHashQuery()
                    emptyList<ContentHashProjection>()
                }
                "insertAll" -> {
                    @Suppress("UNCHECKED_CAST")
                    val list = args?.get(0) as? List<MovieEntity> ?: emptyList()
                    insertedMovies.addAll(list)
                    Unit
                }
                "updateAll" -> Unit
                "remoteIdsForSource" -> {
                    onMoviesPrune()
                    emptyList<String>()
                }
                "deleteByRemoteIds" -> {
                    onMoviesPrune()
                    Unit
                }
                "deleteNullRemoteIds" -> {
                    onMoviesPrune()
                    Unit
                }
                else -> null
            }
        }
        var nextSeriesId = 500L
        var nextSeasonId = 900L
        val seriesDao = proxyDao(SeriesDao::class.java) { method, args ->
            when (method.name) {
                "contentHashesForSource" -> {
                    onSeriesHashQuery()
                    emptyList<ContentHashProjection>()
                }
                "upsertSeriesReturnIds" -> {
                    @Suppress("UNCHECKED_CAST")
                    val list = args?.get(0) as? List<SeriesEntity> ?: emptyList()
                    insertedSeries.addAll(list)
                    list.map { nextSeriesId++ }
                }
                "upsertSeasonsReturnIds" -> {
                    @Suppress("UNCHECKED_CAST")
                    val list = args?.get(0) as? List<SeasonEntity> ?: emptyList()
                    list.map { nextSeasonId++ }
                }
                "upsertEpisodes" -> Unit
                "updateSeries" -> Unit
                "deleteSeasons" -> Unit
                "deleteEpisodes" -> Unit
                "remoteIdsForSource" -> {
                    onSeriesPrune()
                    emptyList<String>()
                }
                "deleteByRemoteIds" -> {
                    onSeriesPrune()
                    Unit
                }
                "deleteNullRemoteIds" -> {
                    onSeriesPrune()
                    Unit
                }
                else -> null
            }
        }
        val sourceDao = proxyDao(SourceDao::class.java) { method, _ ->
            when (method.name) {
                "update" -> Unit
                "profileIdsForSource" -> emptyList<Long>()
                else -> if (List::class.java.isAssignableFrom(method.returnType)) emptyList<Any>() else null
            }
        }

        val okHttp = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .body(playlist.toResponseBody("audio/x-mpegurl".toMediaType()))
                    .build()
            })
            .build()

        val support = SyncSupport(
            categoryDao = categoryDao,
            channelDao = channelDao,
            movieDao = movieDao,
            seriesDao = seriesDao,
            sourceDao = sourceDao,
            customize = customize,
            settings = settings,
        )
        return M3uSyncer(
            context = context,
            sourceDao = sourceDao,
            categoryDao = categoryDao,
            channelDao = channelDao,
            movieDao = movieDao,
            seriesDao = seriesDao,
            m3u = M3uParser(),
            http = HttpClient(okHttp),
            bulkInsertHelper = bulkInsertHelper,
            support = support,
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> proxyDao(iface: Class<T>, handler: (java.lang.reflect.Method, Array<out Any?>?) -> Any?): T =
        Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            handler(method, args)
        } as T

    private class InMemorySharedPreferences : SharedPreferences {
        private val data = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = HashMap(data)
        override fun getString(key: String?, defValue: String?): String? = data[key] as? String ?: defValue
        @Suppress("UNCHECKED_CAST")
        override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? =
            (data[key] as? Set<String>)?.toMutableSet() ?: defValues
        override fun getInt(key: String?, defValue: Int): Int = data[key] as? Int ?: defValue
        override fun getLong(key: String?, defValue: Long): Long = data[key] as? Long ?: defValue
        override fun getFloat(key: String?, defValue: Float): Float = data[key] as? Float ?: defValue
        override fun getBoolean(key: String?, defValue: Boolean): Boolean = data[key] as? Boolean ?: defValue
        override fun contains(key: String?): Boolean = data.containsKey(key)
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            private val edits = HashMap<String, Any?>()
            private var clearAll = false
            override fun putString(key: String, value: String?): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor = apply { edits[key] = values }
            override fun putInt(key: String, value: Int): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putLong(key: String, value: Long): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putFloat(key: String, value: Float): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor = apply { edits[key] = value }
            override fun remove(key: String): SharedPreferences.Editor = apply { edits[key] = null }
            override fun clear(): SharedPreferences.Editor = apply { clearAll = true }
            override fun commit(): Boolean {
                if (clearAll) data.clear()
                edits.forEach { (k, v) -> if (v == null) data.remove(k) else data[k] = v }
                return true
            }
            override fun apply() { commit() }
        }
        override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
    }

    private class InMemoryPreferencesDataStore : DataStore<Preferences> {
        private val mutex = Mutex()
        private val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (t: Preferences) -> Preferences): Preferences =
            mutex.withLock {
                val updated = transform(state.value)
                state.value = updated
                updated
            }
    }

    private companion object {
        val MIXED_PLAYLIST = """
            #EXTM3U
            #EXTINF:-1 tvg-id="rtp1.pt" group-title="Portugal",RTP 1 HD
            http://provider.invalid/live/user/pass/101.ts
            #EXTINF:-1 tvg-id="sic.pt" group-title="Portugal",SIC HD
            http://provider.invalid/live/user/pass/102.ts
            #EXTINF:-1 tvg-type="movie" group-title="Action",Matrix, The (1999)
            http://provider.invalid/movie/user/pass/500.mp4
            #EXTINF:-1 tvg-type="series" group-title="Sci-Fi",Dark S01E01
            http://provider.invalid/series/user/pass/900.mkv
        """.trimIndent()
    }
}
