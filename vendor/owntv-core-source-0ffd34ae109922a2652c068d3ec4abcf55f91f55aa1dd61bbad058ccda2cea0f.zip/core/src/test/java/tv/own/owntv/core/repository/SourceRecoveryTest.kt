package tv.own.owntv.core.repository

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class SourceRecoveryTest {
    @Test fun retryKeepsSettingsOutsideTheSetupForm() {
        val old = SourceEntity(id = 42, name = "Old", type = SourceType.XTREAM, url = "https://old.invalid",
            livePrerollSecs = 5, liveEnginePreference = "EXOPLAYER", liveLatencyCustomSecs = 11,
            liveReserveCustomSecs = 30, liveTuneTimeoutSecs = 15, catchupOffsetMin = 60,
            catchupTimezone = "Europe/Lisbon", importPortalEpg = false, createdAt = 123)
        val draft = SourceEntity(name = "Edited", type = SourceType.XTREAM, url = "https://new.invalid",
            username = "user", password = "new", preferHls = true, syncMovies = false, syncSeries = false)
        assertEquals(old.copy(name = draft.name, url = draft.url, username = draft.username, password = draft.password,
            preferHls = true, syncMovies = false, syncSeries = false), draft.recoverOnto(old))
    }

    @Test fun m3uRetryDoesNotResetHiddenSyncSettingsOrKeepOldStalkerIdentity() {
        val old = SourceEntity(id = 5, name = "List", type = SourceType.STALKER, url = "https://old.invalid",
            mac = "AA:BB:CC:DD:EE:FF", syncMovies = false, syncSeries = false, livePrerollSecs = 8)
        val recovered = SourceEntity(name = "List", type = SourceType.M3U, url = "https://new.invalid/list.m3u").recoverOnto(old)
        assertEquals(SourceType.M3U, recovered.type)
        assertNull(recovered.mac)
        assertFalse(recovered.syncMovies)
        assertFalse(recovered.syncSeries)
        assertEquals(8, recovered.livePrerollSecs)
        assertEquals(5L, recovered.id)
    }
}
