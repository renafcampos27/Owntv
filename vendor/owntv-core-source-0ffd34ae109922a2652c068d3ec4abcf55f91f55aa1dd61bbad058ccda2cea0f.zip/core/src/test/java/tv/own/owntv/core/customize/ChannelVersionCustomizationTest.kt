package tv.own.owntv.core.customize

import org.junit.Assert.*
import org.junit.Test

class ChannelVersionCustomizationTest {
    @Test fun explicitlyEnabledPriorityIsPersistedRatherThanTreatedAsEmpty() {
        assertTrue(SectionCustomizations().isEmpty)
        val enabled = SectionCustomizations(prioritizeChannelVersions = true)
        assertFalse(enabled.isEmpty)
        assertEquals(enabled, CustomizationStore.parse(CustomizationStore.serialize(enabled)))
    }

    @Test fun priorityDefaultsOffAndNewValuesSurviveSerializationWithHiddenItems() {
        assertFalse(CustomizationStore.parse("{}").groupChannelVersions)
        assertFalse(CustomizationStore.parse("{}").prioritizeChannelVersions)
        val expected = SectionCustomizations(groupChannelVersions = true, prioritizeChannelVersions = true,
            channelVersionOrders = mapOf("1:pt:rtp 1" to "[\"20\",\"10\"]"), hiddenItems = mapOf("1:20" to "RTP 1 HD"))
        assertEquals(expected, CustomizationStore.parse(CustomizationStore.serialize(expected)))
        assertFalse(expected.isEmpty)
    }

    @Test fun savedOrderAloneIsNotDiscardedWhenBothOptionsAreDisabled() {
        val expected = SectionCustomizations(prioritizeChannelVersions = false, channelVersionOrders = mapOf("2:sic" to "[\"b\",\"a\"]"))
        assertFalse(expected.isEmpty)
        assertEquals(expected, CustomizationStore.parse(CustomizationStore.serialize(expected)))
    }

    @Test fun manualGroupsAloneArePersistedWithoutEnablingGroupingOrPriority() {
        val expected = SectionCustomizations(prioritizeChannelVersions = false, channelVersionGroups = mapOf("2:123" to "2:sic"))
        assertFalse(expected.isEmpty)
        assertEquals(expected, CustomizationStore.parse(CustomizationStore.serialize(expected)))
    }
}
