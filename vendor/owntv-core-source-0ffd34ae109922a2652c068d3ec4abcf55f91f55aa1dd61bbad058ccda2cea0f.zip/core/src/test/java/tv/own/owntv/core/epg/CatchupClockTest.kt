package tv.own.owntv.core.epg

import java.util.TimeZone
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class CatchupClockTest {
    private val source = SourceEntity(name = "List", type = SourceType.XTREAM, url = "https://example.test")
    private val fallback = TimeZone.getTimeZone("Europe/Lisbon")
    @Test fun unsetSourceUsesGlobalZone() { assertSame(fallback, CatchupClock.resolve(source, fallback)) }
    @Test fun manualSourceUsesItsOwnUtcOffset() {
        assertEquals(3_600_000, CatchupClock.resolve(source.copy(catchupTimezone = "MANUAL", catchupOffsetMin = 60), fallback).rawOffset)
    }
    @Test fun invalidManualOffsetFallsBackSafely() {
        assertSame(fallback, CatchupClock.resolve(source.copy(catchupTimezone = "MANUAL", catchupOffsetMin = 9999), fallback))
    }
    @Test fun timezoneDoesNotShiftProgrammeTimestamps() {
        val p = tv.own.owntv.core.database.entity.EpgProgrammeEntity(sourceId = 1, epgChannelId = "c", startMs = 1, stopMs = 2, title = "News")
        CatchupClock.resolve(source.copy(catchupTimezone = "MANUAL", catchupOffsetMin = 60), fallback)
        assertEquals(1L, p.startMs)
        assertEquals(1L, p.displayStartMs)
    }
}
