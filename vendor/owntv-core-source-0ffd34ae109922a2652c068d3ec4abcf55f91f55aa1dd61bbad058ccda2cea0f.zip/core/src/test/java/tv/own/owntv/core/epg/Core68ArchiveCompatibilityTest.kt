package tv.own.owntv.core.epg

import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.*
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.parser.M3uParser
import tv.own.owntv.core.parser.xtreamServerTimeZone
import java.util.TimeZone

class Core68ArchiveCompatibilityTest {
    private val start = 1_609_459_200_000L
    @Test fun `provider templates support formatted instants units and current timestamp`() {
        assertEquals("20210101-00-00/60/120/1609466400", CatchupUrl.fromTemplate(
            "{utc:Ymd-H-M}/{duration:60}/{offset:60}/{timestamp}", start, start + 3_600_000, start + 7_200_000))
        assertEquals("1609459200", CatchupUrl.fromTemplate("{timestamp}", start, start + 60_000,
            start + 7_200_000, legacyTimestampAsStart = true))
        assertEquals("{duration:0}", CatchupUrl.fromTemplate("{duration:0}", start, start + 60_000))
    }
    @Test fun `list correction is independent from the manual correction and does not change duration`() {
        assertEquals("http://x/archive?start=1609464600&duration=3600", CatchupUrl.forM3u(
            "http://x/live", "append", "http://x/archive?start={start}&duration={duration}",
            CatchupUrl.requestStartMs(start, 60), CatchupUrl.requestStartMs(start + 3_600_000, 60),
            correctionMin = 30))
    }
    @Test fun `old timeshift days inherit header correction while an explicit mode wins`() = runBlocking {
        val rows = mutableListOf<tv.own.owntv.core.parser.M3uEntry>()
        M3uParser().parse(("#EXTM3U catchup-correction=\"1\"\n" +
            "#EXTINF:-1 timeshift=\"5\",A\nhttp://x/a\n" +
            "#EXTINF:-1 timeshift=\"7\" catchup=\"none\" catchup-correction=\"-1.5\",B\nhttp://x/b\n").byteInputStream()) { rows += it }
        assertEquals("shift", rows[0].catchup); assertEquals(5, rows[0].catchupDays)
        assertEquals(60, rows[0].catchupCorrectionMin)
        assertEquals("none", rows[1].catchup); assertEquals(-90, rows[1].catchupCorrectionMin)
    }
    @Test fun `rounding the server request never adds correction to the displayed clock`() {
        assertEquals(start, CatchupClock.effectiveDisplayStart(start + 47_000, start + 3_647_000, true))
        assertEquals(start + 47_000, CatchupClock.effectiveDisplayStart(start + 47_000, start + 3_647_000, false))
    }
    @Test fun `automatic timezone respects per source manual and device choices`() {
        val fallback = TimeZone.getTimeZone("UTC")
        val source = SourceEntity(id = 1, name = "test", type = SourceType.XTREAM, url = "http://x",
            serverTimeZone = "Europe/Lisbon")
        assertEquals("UTC", CatchupClock.resolve(source, fallback).id)
        assertEquals("Europe/Lisbon", CatchupClock.resolve(source, fallback, true).id)
        assertEquals(3_600_000, CatchupClock.resolve(source.copy(catchupTimezone = "MANUAL", catchupOffsetMin = 60), fallback, true).rawOffset)
        assertEquals("UTC", CatchupClock.resolve(source.copy(serverTimeZone = "invalid"), fallback, true).id)
        assertEquals("Europe/Lisbon", xtreamServerTimeZone("Europe/Lisbon", null, null))
        assertEquals("GMT+01:00", xtreamServerTimeZone(null, "2021-01-01 01:00:00", start / 1000))
        assertNull(xtreamServerTimeZone("invalid", null, null))
    }
}
