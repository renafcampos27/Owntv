package tv.own.owntv.core.recording

import org.junit.Assert.*
import org.junit.Test
import java.nio.file.Files
import java.time.*
import javax.crypto.Cipher
import javax.crypto.spec.*

class Core65RecordingTest {
    @Test fun `error documents never become binary recordings`() {
        for (text in listOf("<html>403</html>", "\uFEFF #EXTM3U\nfile", "{\"error\":403}"))
            assertTrue(RecordingMediaProbe.isErrorDocument(text.toByteArray()))
        assertFalse(RecordingMediaProbe.isErrorDocument(byteArrayOf(0x47,0x40,0x00,0x10)))
    }
    @Test fun `keys are tracked per segment and NONE clears only later segments`() {
        val p = HlsMediaPlaylist.parse("""#EXTM3U
            #EXT-X-KEY:METHOD=AES-128,URI="one"
            #EXTINF:6,
            a.ts
            #EXT-X-KEY:METHOD=AES-128,URI="two",IV=0x00000000000000000000000000000002
            #EXTINF:6,
            b.ts
            #EXT-X-KEY:METHOD=NONE
            #EXTINF:6,
            c.ts""".trimIndent())
        assertFalse(p.invalid);assertFalse(p.isEncrypted)
        assertEquals("one",p.segments[0].key?.uri);assertEquals("two",p.segments[1].key?.uri)
        assertNull(p.segments[2].key)
        assertEquals(7.toByte(),HlsAes.ivFor(p.segments[0].key!!,7).last())
    }
    @Test fun `invalid key IV and encrypted init without IV are refused`() {
        for (key in listOf("METHOD=AES-128,URI=\"key\",IV=0x01", "METHOD=AES-128")) {
            assertTrue(HlsMediaPlaylist.parse("#EXTM3U\n#EXT-X-KEY:$key\n#EXTINF:6,\na.ts").invalid)
        }
        assertTrue(HlsMediaPlaylist.parse("#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI=\"key\"\n#EXT-X-MAP:URI=\"init\"\n#EXTINF:6,\na.m4s").invalid)
    }
    @Test fun `AES round trip streams a segment and rejects corrupt padding without replacing it`() {
        val directory=Files.createTempDirectory("hls-aes-test").toFile()
        try {
            val key=ByteArray(16){it.toByte()};val iv=ByteArray(16)
            val plain=ByteArray(100_001){(it%251).toByte()}
            val cipher=Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(Cipher.ENCRYPT_MODE,SecretKeySpec(key,"AES"),IvParameterSpec(iv))
            val encoded=cipher.doFinal(plain)
            val file=java.io.File(directory,"segment")
            file.writeBytes(encoded);HlsAes.decryptFile(file,key,iv);assertArrayEquals(plain,file.readBytes())
            file.writeBytes(encoded.copyOf(encoded.size-1))
            try { HlsAes.decryptFile(file,key,iv);fail("Truncated AES must fail") } catch (_: javax.crypto.IllegalBlockSizeException) {}
            assertEquals((encoded.size-1).toLong(),file.length());assertFalse(java.io.File(directory,"segment.clear").exists())
        } finally { directory.deleteRecursively() }
    }
    @Test fun `manual overnight scheduling follows DST not a fixed 24 hour addition`() {
        val zone=ZoneId.of("Europe/Lisbon")
        val start=LocalDateTime.of(2026,3,28,23,0).atZone(zone).toInstant().toEpochMilli()
        val end=LocalDateTime.of(2026,3,28,3,0).atZone(zone).toInstant().toEpochMilli()
        val result=RecordingSchedule.manualWindow(start,end,start-1,zone)!!
        assertEquals(3*3_600_000L,result.last-result.first)
        assertNull(RecordingSchedule.manualWindow(start,start+60_000,start+120_000,zone))
        assertNull(RecordingSchedule.manualWindow(start,start+26*3_600_000L,start-1,zone))
    }
}
