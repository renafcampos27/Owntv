package tv.own.owntv.core.network

import okhttp3.Dns

/** Resolver and generations captured together for one lookup; no socket is bound to a Network. */
data class DnsLookupContext(
    val resolver: Dns,
    val dnsGeneration: Long = 0,
    val networkGeneration: Long = 0,
    val cacheable: Boolean = true,
)

/** Uses observed identity, not validation/metering/transport metadata, as the network boundary. */
internal class PlaybackDnsContext(private val dns: () -> DnsConfigHolder.ResolverSnapshot) {
    private data class NetworkIdentity(val known: Boolean, val id: Long?)
    private var network: NetworkIdentity? = null
    private var generation = 0L

    @Synchronized fun updateNetwork(state: ConnectivityState) {
        val next = NetworkIdentity(state.observationKnown, state.networkId.takeIf { state.observationKnown })
        if (next != network) { generation++; network = next }
    }

    @Synchronized fun capture(): DnsLookupContext {
        val captured = dns()
        return DnsLookupContext(captured.resolver, captured.generation, generation,
            cacheable = network?.known == true && network?.id != null)
    }
}
