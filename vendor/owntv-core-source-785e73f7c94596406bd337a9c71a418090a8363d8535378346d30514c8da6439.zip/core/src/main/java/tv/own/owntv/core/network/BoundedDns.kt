package tv.own.owntv.core.network

import okhttp3.Dns
import java.net.InetAddress
import java.net.UnknownHostException
import java.util.concurrent.*

/** Limits the caller's wait; Android's underlying resolver can continue after a timeout. */
class BoundedDns(
    private val delegate: Dns = Dns.SYSTEM,
    private val timeoutMs: Long = 5_000,
    private val cachedWaitMs: Long = 1_000,
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val captureContext: () -> DnsLookupContext = { DnsLookupContext(delegate) },
    private val executor: Executor = EXECUTOR,
) : Dns {
    private data class Key(val hostname: String, val dnsGeneration: Long, val networkGeneration: Long)
    private data class Answer(val addresses: List<InetAddress>, val timeMs: Long)
    private val answers = object : LinkedHashMap<Key, Answer>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Key, Answer>?) = size > 64
    }
    private val inFlight = ConcurrentHashMap<Key, FutureTask<List<InetAddress>>>()

    private fun current(context: DnsLookupContext): Boolean {
        val next = captureContext()
        return context.cacheable && next.cacheable && context.dnsGeneration == next.dnsGeneration &&
            context.networkGeneration == next.networkGeneration
    }

    private fun valid(answer: Answer): Boolean = nowMs() - answer.timeMs in 0..300_000L

    override fun lookup(hostname: String): List<InetAddress> {
        val context = captureContext()
        val key = Key(hostname, context.dnsGeneration, context.networkGeneration)
        val previous = synchronized(answers) { answers[key]?.takeIf { context.cacheable && valid(it) } }
        fun fallback(): List<InetAddress>? = previous?.takeIf { valid(it) && current(context) }?.addresses?.toList()
        lateinit var task: FutureTask<List<InetAddress>>
        task = object : FutureTask<List<InetAddress>>(Callable {
            val result = context.resolver.lookup(hostname).toList()
            if (result.isEmpty()) throw UnknownHostException("Empty DNS answer")
            val completedAt = nowMs()
            // Publish before FutureTask wakes callers, including after all their waits expired.
            // The per-key map lock also excludes a replacement task from publishing out of order.
            inFlight.compute(key) { _, active ->
                if (active === task && current(context)) {
                    synchronized(answers) { answers[key] = Answer(result.toList(), completedAt) }
                }
                active
            }
            result
        }) {
            override fun done() { inFlight.remove(key, this) }
        }
        val pending = inFlight.compute(key) { _, active -> if (active == null || active.isDone) task else active }!!
        if (pending === task) try { executor.execute(task) } catch (_: RejectedExecutionException) {
            inFlight.remove(key, task)
            return fallback() ?: throw UnknownHostException("DNS resolver busy")
        }
        try {
            val result = pending.get(if (previous == null) timeoutMs else cachedWaitMs, TimeUnit.MILLISECONDS)
            return result.toList()
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            throw UnknownHostException("DNS lookup interrupted").apply { initCause(e) }
        } catch (e: ExecutionException) {
            return fallback() ?: throw UnknownHostException("DNS lookup failed").apply { initCause(e.cause) }
        } catch (e: TimeoutException) {
            return fallback() ?: throw UnknownHostException("DNS lookup timed out").apply { initCause(e) }
        }
    }
    private companion object {
        val EXECUTOR = ThreadPoolExecutor(4, 4, 30, TimeUnit.SECONDS, ArrayBlockingQueue<Runnable>(64),
            ThreadFactory { Thread(it, "owntv-live-dns").apply { isDaemon = true } })
    }
}
