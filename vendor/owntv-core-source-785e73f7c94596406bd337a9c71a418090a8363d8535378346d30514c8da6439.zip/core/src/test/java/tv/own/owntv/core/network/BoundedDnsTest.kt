package tv.own.owntv.core.network

import okhttp3.Dns
import org.junit.Assert.*
import org.junit.Test
import java.net.*
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

class BoundedDnsTest {
    @Test fun `late success is available after the next native lookup fails without reducing query count`() {
        val release = CountDownLatch(1)
        val queries = AtomicInteger()
        Worker().use { pool ->
            val dns = BoundedDns(Dns {
                if (queries.incrementAndGet() == 1) { release.await(); listOf(first) }
                else throw UnknownHostException("fixture failure")
            }, 30, 10, executor = pool)
            try {
                assertThrows(UnknownHostException::class.java) { dns.lookup("late.invalid") }
                release.countDown(); pool.finished()
                assertEquals(listOf(first), dns.lookup("late.invalid"))
                assertEquals(2, queries.get())
                println("phase2b_after late_success_preserved=true subsequent_fallback_succeeded=true native_queries=2")
            } finally { release.countDown() }
        }
    }

    @Test fun `validity starts at completion and cache reads do not extend it`() {
        val now = AtomicLong(100)
        val release = CountDownLatch(1)
        val calls = AtomicInteger()
        Worker().use { pool ->
            val dns = BoundedDns(Dns {
                if (calls.incrementAndGet() == 1) { release.await(); listOf(first) }
                else throw UnknownHostException()
            }, 30, 10, now::get, executor = pool)
            try {
                assertThrows(UnknownHostException::class.java) { dns.lookup("expiry.invalid") }
                now.set(1_000); release.countDown(); pool.finished()
                now.set(301_000)
                assertEquals(listOf(first), dns.lookup("expiry.invalid"))
                now.incrementAndGet()
                assertThrows(UnknownHostException::class.java) { dns.lookup("expiry.invalid") }
            } finally { release.countDown() }
        }
    }

    @Test fun `dns generation change separates pending requests and old completion`() = changedContext(false)
    @Test fun `network generation change separates pending requests and old completion`() = changedContext(true)

    private fun changedContext(networkChange: Boolean) {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val failNew = AtomicBoolean()
        val old = Dns { entered.countDown(); release.await(); listOf(first) }
        val next = Dns { if (failNew.get()) throw UnknownHostException() else listOf(second) }
        val context = AtomicReference(DnsLookupContext(old, 1, 1))
        val caller = Executors.newSingleThreadExecutor()
        Worker(2).use { pool ->
            val dns = BoundedDns(old, 2_000, 10, captureContext = context::get, executor = pool)
            try {
                val pending = caller.submit<List<InetAddress>> { dns.lookup("changed.invalid") }
                assertTrue(entered.await(3, TimeUnit.SECONDS))
                context.set(DnsLookupContext(next, if (networkChange) 1 else 2, if (networkChange) 2 else 1))
                assertEquals(listOf(second), dns.lookup("changed.invalid"))
                failNew.set(true); release.countDown()
                assertEquals("The original caller retains its captured resolver", listOf(first), pending.get(3, TimeUnit.SECONDS))
                pool.finished(2)
                assertEquals(listOf(second), dns.lookup("changed.invalid"))
            } finally { release.countDown(); caller.shutdownNow() }
        }
    }

    @Test fun `empty and failed answers are not cached`() {
        val queries = AtomicInteger()
        Worker().use { pool ->
            val dns = BoundedDns(Dns {
                when (queries.incrementAndGet()) {
                    1 -> emptyList()
                    2 -> throw UnknownHostException()
                    else -> listOf(first)
                }
            }, 1_000, 10, executor = pool)
            repeat(2) { assertThrows(UnknownHostException::class.java) { dns.lookup("empty.invalid") } }
            assertEquals(listOf(first), dns.lookup("empty.invalid"))
            assertEquals(3, queries.get())
        }
    }

    @Test fun `cache is isolated from mutable delegate results and caller copies`() {
        val raw = mutableListOf(first, second)
        val fail = AtomicBoolean()
        Worker().use { pool ->
            val dns = BoundedDns(Dns { if (fail.get()) throw UnknownHostException() else raw }, 1_000, 10, executor = pool)
            (dns.lookup("copies.invalid") as MutableList).clear()
            raw.clear(); fail.set(true)
            val fallback = dns.lookup("copies.invalid")
            assertEquals(listOf(first, second), fallback)
            (fallback as MutableList).clear()
            assertEquals(listOf(first, second), dns.lookup("copies.invalid"))
        }
    }

    @Test fun `saturation uses only a valid cached answer and recovers when capacity returns`() {
        val release = CountDownLatch(1)
        val started = CountDownLatch(1)
        val now = AtomicLong(1)
        Worker(1, 1).use { pool ->
            val dns = BoundedDns(Dns { listOf(first) }, 1_000, 10, now::get, executor = pool)
            assertEquals(listOf(first), dns.lookup("cached.invalid")); pool.finished()
            try {
                pool.execute { started.countDown(); release.await() }
                assertTrue(started.await(3, TimeUnit.SECONDS))
                pool.execute { release.await() }
                assertEquals(listOf(first), dns.lookup("cached.invalid"))
                assertThrows(UnknownHostException::class.java) { dns.lookup("uncached.invalid") }
                now.addAndGet(300_001)
                assertThrows(UnknownHostException::class.java) { dns.lookup("cached.invalid") }
                release.countDown(); pool.finished(2)
                assertEquals(listOf(first), dns.lookup("cached.invalid"))
            } finally { release.countDown() }
        }
    }

    @Test fun `interrupting the waiting caller preserves its interrupt and does not cancel native resolution`() {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val queries = AtomicInteger()
        val interrupted = CompletableFuture<Pair<Throwable, Boolean>>()
        Worker().use { pool ->
            val dns = BoundedDns(Dns {
                if (queries.incrementAndGet() == 1) { entered.countDown(); release.await(); listOf(first) }
                else throw UnknownHostException()
            }, 5_000, 10, executor = pool)
            val caller = Thread {
                try { dns.lookup("interrupt.invalid"); interrupted.complete(AssertionError("Expected interruption") to false) }
                catch (error: Throwable) { interrupted.complete(error to Thread.currentThread().isInterrupted) }
            }
            try {
                caller.start(); assertTrue(entered.await(3, TimeUnit.SECONDS)); caller.interrupt()
                val (error, flag) = interrupted.get(3, TimeUnit.SECONDS)
                assertTrue(error is UnknownHostException)
                assertTrue(error.cause is InterruptedException)
                assertTrue(flag)
                release.countDown(); pool.finished()
                assertEquals(listOf(first), dns.lookup("interrupt.invalid"))
            } finally { release.countDown(); caller.interrupt(); caller.join(3_000) }
        }
    }

    @Test fun `cached answers remain bounded to 64 entries`() {
        val fail = AtomicBoolean()
        Worker().use { pool ->
            val dns = BoundedDns(Dns { if (fail.get()) throw UnknownHostException() else listOf(first) }, 1_000, 10, executor = pool)
            repeat(65) { assertEquals(listOf(first), dns.lookup("host$it.invalid")) }
            fail.set(true)
            assertThrows(UnknownHostException::class.java) { dns.lookup("host0.invalid") }
            assertEquals(listOf(first), dns.lookup("host64.invalid"))
        }
    }

    @Test fun `unknown network still resolves but does not cache and known identity enables fallback`() {
        val fail = AtomicBoolean()
        val resolver = Dns { if (fail.get()) throw UnknownHostException() else listOf(first) }
        val context = PlaybackDnsContext { DnsConfigHolder.ResolverSnapshot(0, resolver) }
        Worker().use { pool ->
            val dns = BoundedDns(resolver, 1_000, 10, captureContext = context::capture, executor = pool)
            assertEquals(listOf(first), dns.lookup("unknown.invalid"))
            fail.set(true)
            assertThrows(UnknownHostException::class.java) { dns.lookup("unknown.invalid") }
            context.updateNetwork(ConnectivityState(networkId = 1))
            fail.set(false); assertEquals(listOf(first), dns.lookup("unknown.invalid"))
            fail.set(true); assertEquals(listOf(first), dns.lookup("unknown.invalid"))
        }
    }

    private val first = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))
    private val second = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 2))
    private class Worker(threads: Int = 1, capacity: Int = 64) : ThreadPoolExecutor(
        threads, threads, 30, TimeUnit.SECONDS, ArrayBlockingQueue<Runnable>(capacity),
        ThreadFactory { task -> Thread(task, "dns-fixture").apply { isDaemon = true } },
    ), AutoCloseable {
        private val completions = LinkedBlockingQueue<Unit>()
        override fun afterExecute(task: Runnable, error: Throwable?) { completions.offer(Unit) }
        fun finished(count: Int = 1) { repeat(count) { assertNotNull(completions.poll(3, TimeUnit.SECONDS)) } }
        override fun close() { shutdownNow(); assertTrue(awaitTermination(3, TimeUnit.SECONDS)) }
    }

    @Test fun `timeout is bounded and same host shares the underlying lookup`() {
        val release=CountDownLatch(1);val count=AtomicInteger()
        val dns=BoundedDns(Dns { count.incrementAndGet();release.await();listOf(InetAddress.getByAddress(byteArrayOf(127,0,0,1))) },30,10)
        try {
            repeat(2) { try { dns.lookup("test.invalid");fail("Expected deadline") } catch (_: UnknownHostException) {} }
            assertEquals(1,count.get())
        } finally { release.countDown() }
    }
    @Test fun `last successful answer expires and is never an indefinite fallback`() {
        var now=1L;var fail=false
        val address=InetAddress.getByAddress(byteArrayOf(127,0,0,1))
        val dns=BoundedDns(Dns { if(fail) throw UnknownHostException();listOf(address) },100,10,{now})
        assertEquals(listOf(address),dns.lookup("test.invalid"));fail=true
        assertEquals(listOf(address),dns.lookup("test.invalid"))
        now+=300_001
        try { dns.lookup("test.invalid");fail("Expired answer must not be returned") } catch (_: UnknownHostException) {}
    }
}
