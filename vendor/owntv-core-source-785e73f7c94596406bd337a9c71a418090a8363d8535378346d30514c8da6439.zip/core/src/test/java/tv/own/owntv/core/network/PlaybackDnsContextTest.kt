package tv.own.owntv.core.network

import okhttp3.Dns
import org.junit.Assert.*
import org.junit.Test

class PlaybackDnsContextTest {
    private val snapshot = DnsConfigHolder.ResolverSnapshot(0, Dns { emptyList() })

    @Test fun sameNetworkReplayAndCapabilityChangesDoNotInvalidateAnswers() {
        val context = PlaybackDnsContext { snapshot }
        context.updateNetwork(ConnectivityState(networkId = 7))
        val initial = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 7))
        context.updateNetwork(ConnectivityState(networkId = 7, validated = true, internet = true, metered = true, transport = "ethernet"))
        assertEquals(initial, context.capture())
        assertTrue(context.capture().cacheable)
    }

    @Test fun networkSwitchAndReturnNeverReuseThePreviousGeneration() {
        val context = PlaybackDnsContext { snapshot }
        context.updateNetwork(ConnectivityState(networkId = 1))
        val first = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 2))
        val second = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 1))
        val returned = context.capture()
        assertTrue(first.networkGeneration < second.networkGeneration)
        assertTrue(second.networkGeneration < returned.networkGeneration)
        assertSame(snapshot.resolver, returned.resolver)
    }

    @Test fun lostOrUnknownObservationDisablesCacheWithoutInventingNetworkValidation() {
        val context = PlaybackDnsContext { snapshot }
        assertFalse(context.capture().cacheable)
        context.updateNetwork(ConnectivityState(networkId = 1))
        val known = context.capture()
        assertTrue(known.cacheable) // No requirement for internet/validated capability.
        context.updateNetwork(ConnectivityState(networkId = 1, observationKnown = false))
        val unknown = context.capture()
        assertFalse(unknown.cacheable)
        context.updateNetwork(ConnectivityState(networkId = 2, observationKnown = false))
        assertEquals(unknown, context.capture())
        context.updateNetwork(ConnectivityState())
        assertFalse(context.capture().cacheable)
        context.updateNetwork(ConnectivityState(networkId = 1))
        assertTrue(context.capture().networkGeneration > known.networkGeneration)
    }
}
