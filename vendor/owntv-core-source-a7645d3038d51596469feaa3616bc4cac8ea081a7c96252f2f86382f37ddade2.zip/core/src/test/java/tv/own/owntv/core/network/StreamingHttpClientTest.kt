package tv.own.owntv.core.network

import com.sun.net.httpserver.HttpServer
import okhttp3.Call
import okhttp3.Callback
import okhttp3.EventListener
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.net.InetSocketAddress
import java.util.concurrent.CompletableFuture
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class StreamingHttpClientTest {
    @Test fun boundedLiveDnsUsesCapturedSettingsAndIsSharedWithoutChangingBaseDns() {
        val address = java.net.InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))
        val fail = java.util.concurrent.atomic.AtomicBoolean()
        val captured = java.util.concurrent.atomic.AtomicReference(DnsConfigHolder.ResolverSnapshot(0,
            okhttp3.Dns { if (fail.get()) throw java.net.UnknownHostException() else listOf(address) }))
        val ready = CountDownLatch(1)
        val states = kotlinx.coroutines.flow.flow {
            emit(ConnectivityState(networkId = 1))
            ready.countDown()
        }
        val base = OkHttpClient.Builder().dns { throw java.net.UnknownHostException("base fixture DNS") }.build()
        val streaming = StreamingHttpClient(base, dnsSnapshot = captured::get, networkStates = states)
        val liveDns = streaming.liveDns
        try {
            assertTrue(ready.await(3, TimeUnit.SECONDS))
            assertSame(base.dns, streaming.client.dns)
            val first = streaming.client.newBuilder().dns(liveDns).build()
            val second = streaming.client.newBuilder().dns(liveDns).build()
            assertSame(first.dns, second.dns)
            assertEquals(listOf(address), first.dns.lookup("live.invalid"))
            fail.set(true)
            assertEquals(listOf(address), second.dns.lookup("live.invalid"))
            captured.set(DnsConfigHolder.ResolverSnapshot(1, okhttp3.Dns { throw java.net.UnknownHostException() }))
            assertThrows(java.net.UnknownHostException::class.java) { second.dns.lookup("live.invalid") }
            assertThrows(java.net.UnknownHostException::class.java) { streaming.client.dns.lookup("live.invalid") }
        } finally {
            streaming.evictAll(); base.connectionPool.evictAll()
            streaming.client.dispatcher.executorService.shutdownNow(); base.dispatcher.executorService.shutdownNow()
        }
    }

    @Test fun imageHeaderWaitsDoNotQueueLiveDnsFallbackAndIdleEvictionKeepsBothQueuesReusable() {
        QueueFixture().use { fixture ->
            val base = fixture.client()
            val images = base.newBuilder().build()
            val ready = CountDownLatch(1)
            val queries = java.util.concurrent.atomic.AtomicInteger()
            val resolver = okhttp3.Dns {
                if (queries.incrementAndGet() == 1) listOf(java.net.InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1)))
                else throw java.net.UnknownHostException("transient fixture DNS")
            }
            val states = kotlinx.coroutines.flow.flow { emit(ConnectivityState(networkId = 1)); ready.countDown() }
            val streaming = StreamingHttpClient(base, dnsSnapshot = { DnsConfigHolder.ResolverSnapshot(0, resolver) }, networkStates = states)
            val playback = streaming.client.newBuilder().dns(streaming.liveDns).build()
            assertTrue(ready.await(3, TimeUnit.SECONDS))
            streaming.liveDns.lookup("queue.invalid")
            assertNotSame(base.dispatcher, playback.dispatcher)
            assertSame(base.dispatcher, images.dispatcher)
            assertEquals(64, playback.dispatcher.maxRequests)
            assertEquals(5, playback.dispatcher.maxRequestsPerHost)
            val pendingImages = fixture.occupy(images)
            streaming.evictAll()
            val queuedFor = AtomicLong(-1)
            val queuedAt = AtomicLong()
            val live = playback.newBuilder().eventListener(object : EventListener() {
                override fun dispatcherQueueStart(call: Call, dispatcher: okhttp3.Dispatcher) {
                    queuedAt.set(System.nanoTime())
                }
                override fun dispatcherQueueEnd(call: Call, dispatcher: okhttp3.Dispatcher) {
                    queuedFor.set(System.nanoTime() - queuedAt.get())
                }
            }).build()
            val result = fixture.enqueue(live, "/live/channel.m3u8")
            assertTrue(result.get(5, TimeUnit.SECONDS).startsWith("#EXTM3U"))
            assertEquals(0, playback.dispatcher.queuedCallsCount())
            assertEquals(5, images.dispatcher.runningCallsCount())
            assertEquals(1L, fixture.release.count)
            assertTrue(pendingImages.none { it.isDone })
            assertFalse(playback.dispatcher.executorService.isShutdown)
            assertFalse(images.dispatcher.executorService.isShutdown)
            assertEquals(1, fixture.count("/live/channel.m3u8"))
            assertEquals("HLS used the cached Live DNS answer after a fresh native failure", 2, queries.get())
            fixture.release.countDown()
            pendingImages.forEach { assertEquals("image", it.get(5, TimeUnit.SECONDS)) }
            println("phase2a_isolated shared=false queueMs=${queuedFor.get() / 1_000_000.0} limits=64/5 imageCallsStillPending=5")
        }
    }

    @Test fun derivedEnginesReusePlaybackQueueAndPreserveBaseTransportSettings() {
        val dns = okhttp3.Dns { listOf(java.net.InetAddress.getLoopbackAddress()) }
        val identity = okhttp3.Interceptor { it.proceed(it.request()) }
        val network = okhttp3.Interceptor { it.proceed(it.request()) }
        val base = OkHttpClient.Builder().dns(dns)
            .connectTimeout(1_100, TimeUnit.MILLISECONDS).readTimeout(1_200, TimeUnit.MILLISECONDS)
            .writeTimeout(1_300, TimeUnit.MILLISECONDS).callTimeout(1_400, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(false).protocols(listOf(okhttp3.Protocol.HTTP_1_1))
            .addInterceptor(identity).addNetworkInterceptor(network).build()
        val streaming = StreamingHttpClient(base)
        val playback = streaming.client
        val engines = List(4) { playback.newBuilder().build() }
        try {
            assertSame(playback, streaming.client)
            engines.forEach {
                assertSame(playback.dispatcher, it.dispatcher)
                assertSame(playback.connectionPool, it.connectionPool)
            }
            assertNotSame(base.dispatcher, playback.dispatcher)
            assertNotSame(base.connectionPool, playback.connectionPool)
            assertSame(base.dns, playback.dns)
            assertSame(base.proxySelector, playback.proxySelector)
            assertSame(base.proxyAuthenticator, playback.proxyAuthenticator)
            assertSame(base.authenticator, playback.authenticator)
            assertSame(base.sslSocketFactory, playback.sslSocketFactory)
            assertSame(base.x509TrustManager, playback.x509TrustManager)
            assertSame(base.hostnameVerifier, playback.hostnameVerifier)
            assertSame(base.certificatePinner, playback.certificatePinner)
            assertEquals(base.protocols, playback.protocols)
            assertEquals(base.connectionSpecs, playback.connectionSpecs)
            assertEquals(base.connectTimeoutMillis, playback.connectTimeoutMillis)
            assertEquals(base.readTimeoutMillis, playback.readTimeoutMillis)
            assertEquals(base.writeTimeoutMillis, playback.writeTimeoutMillis)
            assertEquals(base.callTimeoutMillis, playback.callTimeoutMillis)
            assertEquals(base.retryOnConnectionFailure, playback.retryOnConnectionFailure)
            assertEquals(base.followRedirects, playback.followRedirects)
            assertEquals(base.followSslRedirects, playback.followSslRedirects)
            assertSame(identity, playback.interceptors.first())
            assertSame(streaming.playbackTls, playback.interceptors.last())
            assertSame(network, playback.networkInterceptors.first())
            assertSame(streaming.playbackTls.redirectGuard, playback.networkInterceptors.last())
            assertEquals(64, playback.dispatcher.maxRequests)
            assertEquals(5, playback.dispatcher.maxRequestsPerHost)
        } finally {
            streaming.evictAll()
            base.connectionPool.evictAll()
            playback.dispatcher.executorService.shutdownNow()
            base.dispatcher.executorService.shutdownNow()
        }
    }

    @Test fun playbackRetainsHostLimitAndCancelingQueuedCallDoesNotSendItOrStopImages() {
        QueueFixture().use { fixture ->
            val images = fixture.client()
            val playback = StreamingHttpClient(images).client
            val pending = fixture.occupy(playback)
            val old = playback.newCall(fixture.request("/live/cancelled.m3u8"))
            val oldResult = fixture.enqueue(playback, old)
            assertEquals(1, playback.dispatcher.queuedCallsCount())
            old.cancel()
            assertTrue(old.isCanceled())
            assertEquals("#EXTM3U", fixture.enqueue(images, "/live/image-client-check").get(5, TimeUnit.SECONDS).lineSequence().first())
            assertEquals(5, playback.dispatcher.runningCallsCount())
            fixture.release.countDown()
            pending.forEach { assertEquals("image", it.get(5, TimeUnit.SECONDS)) }
            try {
                oldResult.get(5, TimeUnit.SECONDS)
                fail("Canceled queued request must fail without reaching the server")
            } catch (expected: ExecutionException) {
                assertTrue(expected.cause is IOException)
            }
            assertEquals(0, fixture.count("/live/cancelled.m3u8"))
            assertTrue(fixture.enqueue(playback, "/live/next.m3u8").get(5, TimeUnit.SECONDS).startsWith("#EXTM3U"))
        }
    }

    private class QueueFixture : AutoCloseable {
        val release = CountDownLatch(1)
        private val busy = CountDownLatch(5)
        private val requests = ConcurrentHashMap<String, AtomicInteger>()
        private val workers = Executors.newCachedThreadPool { task ->
            Thread(task, "streaming-queue-test").apply { isDaemon = true }
        }
        private val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0).apply {
            executor = workers
            createContext("/") { exchange ->
                exchange.use {
                    requests.computeIfAbsent(exchange.requestURI.path) { AtomicInteger() }.incrementAndGet()
                    val body = if (exchange.requestURI.path.startsWith("/image/")) {
                        busy.countDown()
                        check(release.await(10, TimeUnit.SECONDS))
                        "image"
                    } else {
                        "#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6,\nsegment.ts\n"
                    }.toByteArray()
                    exchange.sendResponseHeaders(200, body.size.toLong())
                    exchange.responseBody.use { it.write(body) }
                }
            }
            start()
        }
        private val clients = mutableListOf<OkHttpClient>()
        private val calls = mutableListOf<Call>()

        fun client(): OkHttpClient = OkHttpClient.Builder()
            .dns { listOf(java.net.InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))) }
            .retryOnConnectionFailure(false)
            .readTimeout(5, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .build().also { clients += it }

        fun occupy(images: OkHttpClient): List<CompletableFuture<String>> = (0 until 5)
            .map { enqueue(images, "/image/$it") }.also {
                assertTrue("All five asynchronous image requests must be waiting for headers", busy.await(5, TimeUnit.SECONDS))
                assertEquals(5, images.dispatcher.runningCallsCount())
            }

        fun enqueue(client: OkHttpClient, path: String): CompletableFuture<String> {
            return enqueue(client, client.newCall(request(path)))
        }

        fun request(path: String): Request = Request.Builder()
            .url("http://queue.invalid:${server.address.port}$path").build()

        fun count(path: String): Int = requests[path]?.get() ?: 0

        fun enqueue(client: OkHttpClient, call: Call): CompletableFuture<String> {
            clients += client
            val result = CompletableFuture<String>()
            call.also { calls += it }.enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) { result.completeExceptionally(e) }
                    override fun onResponse(call: Call, response: Response) {
                        try { result.complete(response.use { it.body.string() }) }
                        catch (error: Exception) { result.completeExceptionally(error) }
                    }
                })
            return result
        }

        override fun close() {
            release.countDown()
            calls.forEach { it.cancel() }
            server.stop(0)
            clients.map { it.connectionPool }.distinct().forEach { it.evictAll() }
            clients.map { it.dispatcher }.distinct().forEach { it.executorService.shutdownNow() }
            workers.shutdownNow()
        }
    }
}
