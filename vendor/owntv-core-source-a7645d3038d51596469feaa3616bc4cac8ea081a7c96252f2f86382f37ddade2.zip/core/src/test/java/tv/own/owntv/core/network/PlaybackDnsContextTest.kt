package tv.own.owntv.core.network

import okhttp3.Dns
import org.junit.Assert.*
import org.junit.Test

class PlaybackDnsContextTest {
    private val snapshot = DnsConfigHolder.ResolverSnapshot(0, Dns { emptyList() })

    @Test fun sameNetworkReplayAndCapabilityChangesDoNotInvalidateAnswers() {
        val context = PlaybackDnsContext { snapshot }
        context.updateNetwork(ConnectivityState(networkId = 7))
        val initial = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 7))
        context.updateNetwork(ConnectivityState(networkId = 7, validated = true, internet = true, metered = true, transport = "ethernet"))
        assertEquals(initial, context.capture())
    }

    @Test fun networkSwitchAndReturnNeverReuseThePreviousGeneration() {
        val context = PlaybackDnsContext { snapshot }
        context.updateNetwork(ConnectivityState(networkId = 1))
        val first = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 2))
        val second = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 1))
        val returned = context.capture()
        assertTrue(first.networkGeneration < second.networkGeneration)
        assertTrue(second.networkGeneration < returned.networkGeneration)
        assertSame(snapshot.resolver, returned.resolver)
    }

    @Test fun unknownObservationPreservesFallbackWhileKnownLossChangesContext() {
        val context = PlaybackDnsContext { snapshot }
        val initial = context.capture()
        context.updateNetwork(ConnectivityState(networkId = 1))
        val known = context.capture()
        assertTrue(known.networkGeneration > initial.networkGeneration)
        context.updateNetwork(ConnectivityState(networkId = 1, observationKnown = false))
        val unknown = context.capture()
        assertEquals(known, unknown)
        context.updateNetwork(ConnectivityState(networkId = 2, observationKnown = false))
        assertEquals(unknown, context.capture())
        context.updateNetwork(ConnectivityState())
        assertTrue(context.capture().networkGeneration > known.networkGeneration)
        context.updateNetwork(ConnectivityState(networkId = 1))
        assertTrue(context.capture().networkGeneration > known.networkGeneration)
    }
}
