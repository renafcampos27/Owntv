package tv.own.owntv.core.network

import kotlinx.coroutines.flow.emptyFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class DnsConfigHolderTest {
    @Test fun `generation changes only for a different configuration including switch back`() {
        val holder = DnsConfigHolder(emptyFlow())
        val initial = holder.capture()
        holder.configure(DnsConfig())
        assertSame(initial, holder.capture())
        val selected = DnsConfig(enabled = true, dohUrl = "invalid-fixture-url")
        holder.configure(selected)
        assertEquals(initial.generation + 1, holder.capture().generation)
        val captured = holder.capture()
        holder.configure(selected.copy())
        assertSame(captured, holder.capture())
        holder.configure(DnsConfig())
        assertEquals(initial.generation + 2, holder.capture().generation)
    }

    @Test fun `captured resolver retains its configuration after the live holder changes`() {
        val holder = DnsConfigHolder(emptyFlow(), DnsConfig(enabled = true, dohUrl = "invalid-fixture-url"), false)
        val captured = holder.capture()
        holder.configure(DnsConfig())
        assertThrows(IllegalArgumentException::class.java) { captured.resolver.lookup("127.0.0.1") }
        assertTrue(holder.dns.lookup("127.0.0.1").all { it.isLoopbackAddress })
    }

    @Test fun `concurrent capture always pairs generation with its own resolver`() {
        val selected = DnsConfig(enabled = true, dohUrl = "invalid-fixture-url")
        val holder = DnsConfigHolder(emptyFlow(), selected, false)
        val worker = Thread { repeat(300) { holder.configure(DnsConfig()); holder.configure(selected) } }
        try {
            worker.start()
            repeat(300) {
                val captured = holder.capture()
                if (captured.generation % 2 == 0L) {
                    assertThrows(IllegalArgumentException::class.java) { captured.resolver.lookup("127.0.0.1") }
                } else {
                    assertTrue(captured.resolver.lookup("127.0.0.1").all { it.isLoopbackAddress })
                }
            }
        } finally { worker.join(3_000) }
        assertTrue(!worker.isAlive)
    }


    @Test
    fun `initial config is available before flow collection`() {
        val selected = DnsConfig(
            enabled = true,
            dohUrl = DohPresets.CLOUDFLARE,
        )

        val holder = DnsConfigHolder(
            configFlow = emptyFlow(),
            initialConfig = selected,
            fallbackToSystem = false,
        )

        assertEquals(selected, holder.snapshot())
    }

    @Test
    fun `strict lookup does not hide a broken custom server with system dns`() {
        val holder = DnsConfigHolder(
            configFlow = emptyFlow(),
            initialConfig = DnsConfig(enabled = true, dohUrl = "not-a-valid-url"),
            fallbackToSystem = false,
        )

        assertThrows(IllegalArgumentException::class.java) {
            holder.dns.lookup("dns.google")
        }
    }
}
