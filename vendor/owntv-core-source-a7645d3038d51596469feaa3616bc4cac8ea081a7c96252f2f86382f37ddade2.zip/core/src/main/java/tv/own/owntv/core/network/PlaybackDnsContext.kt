package tv.own.owntv.core.network

import okhttp3.Dns

/** Resolver and generations captured together for one lookup; no socket is bound to a Network. */
data class DnsLookupContext(
    val resolver: Dns,
    val dnsGeneration: Long = 0,
    val networkGeneration: Long = 0,
)

/** Uses observed identity, not validation/metering/transport metadata, as the network boundary. */
internal class PlaybackDnsContext(private val dns: () -> DnsConfigHolder.ResolverSnapshot) {
    private var observed = false
    private var networkId: Long? = null
    private var generation = 0L

    @Synchronized fun updateNetwork(state: ConnectivityState) {
        // An unavailable observation is not evidence of a network switch or a disconnection.
        if (!state.observationKnown) return
        if (!observed || networkId != state.networkId) {
            generation++; networkId = state.networkId; observed = true
        }
    }

    @Synchronized fun capture(): DnsLookupContext {
        val captured = dns()
        return DnsLookupContext(captured.resolver, captured.generation, generation)
    }
}
