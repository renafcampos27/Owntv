package tv.own.owntv.core.backup

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class SettingsBackupValidationTest {
    private fun validate(key: String, value: Any) = SettingsBackupValidation.validate(
        JSONObject().put(key, value), setOf("live_latency_mode", "live_reserve_mode"),
        setOf("seek_step_sec", "live_rewind_step_sec", "audio_delay_ms"), emptySet(),
        setOf("sub_scale", "sub_scale_mpv", "sub_scale_exo"), emptySet(), emptyMap())

    @Test fun `navigation steps cannot disable or overflow seek after restore`() {
        validate("seek_step_sec", 10); validate("live_rewind_step_sec", 120)
        for ((key, value) in listOf("seek_step_sec" to 0, "live_rewind_step_sec" to -1,
            "audio_delay_ms" to 5001, "live_latency_mode" to "invalid", "sub_scale_exo" to 0.0)) {
            assertThrows(IllegalArgumentException::class.java) { validate(key, value) }
        }
    }
    @Test fun `existing meaningful settings and future optional keys remain readable`() {
        validate("audio_delay_ms", -5000); validate("audio_delay_ms", 5000)
        validate("sub_scale", 0.5); validate("sub_scale_mpv", 2.0)
        validate("live_reserve_mode", "BALANCED"); validate("future_optional", "unchanged")
    }
}
