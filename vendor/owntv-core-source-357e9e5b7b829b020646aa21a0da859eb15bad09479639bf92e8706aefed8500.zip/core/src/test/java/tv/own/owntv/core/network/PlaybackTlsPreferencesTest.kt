package tv.own.owntv.core.network

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.backup.BackupRestoreIdentity
import tv.own.owntv.core.backup.filterBySourceId
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.settings.SettingsRepository

class PlaybackTlsPreferencesTest {
    private class MemoryStore : DataStore<Preferences> {
        val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (Preferences) -> Preferences): Preferences =
            transform(state.value).also { state.value = it }
    }
    private fun repo(store: DataStore<Preferences>): SettingsRepository {
        val editor = java.lang.reflect.Proxy.newProxyInstance(SharedPreferences.Editor::class.java.classLoader,
            arrayOf(SharedPreferences.Editor::class.java)) { proxy, method, _ ->
            when (method.name) { "commit" -> true; "apply" -> null; else -> proxy }
        } as SharedPreferences.Editor
        val preferences = java.lang.reflect.Proxy.newProxyInstance(SharedPreferences::class.java.classLoader,
            arrayOf(SharedPreferences::class.java)) { _, method, args ->
            when (method.name) { "edit" -> editor; "getAll" -> emptyMap<String, Any>(); "contains" -> false; else -> args?.lastOrNull() }
        } as SharedPreferences
        val context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = preferences
        }
        return SettingsRepository(context, LocaleStore.from(context), store)
    }

    @Test fun policySurvivesClosingAndReopeningARealDataStoreFile() = runBlocking<Unit> {
        val folder = java.nio.file.Files.createTempDirectory("owntv-tls-preferences").toFile()
        val file = folder.resolve("settings.preferences_pb")
        val job = SupervisorJob()
        val store = PreferenceDataStoreFactory.create(scope = CoroutineScope(job + Dispatchers.IO), produceFile = { file })
        val settings = repo(store)
        try {
            assertEquals(PlaybackTlsPolicy.STRICT, settings.playbackTlsConfig.first().effective(7))
            // One committed write suffices to prove persistence. Android's FileStorage.renameTo
            // cannot replace an existing file on the Windows JVM host; that is not Android I/O.
            settings.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.AUTO_HOSTNAME)
            job.cancelAndJoin()
            val secondJob = SupervisorJob()
            try {
                val reopened = repo(PreferenceDataStoreFactory.create(scope = CoroutineScope(secondJob + Dispatchers.IO), produceFile = { file }))
                val config = reopened.playbackTlsConfig.first()
                assertEquals(PlaybackTlsPolicy.STRICT, config.global)
                assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.effective(7))
                assertEquals(PlaybackTlsPolicy.STRICT, config.effective(8))
            } finally { secondJob.cancelAndJoin() }
        } finally { job.cancelAndJoin(); folder.listFiles()?.forEach { it.delete() }; folder.delete() }
    }

    @Test fun backupsScopeAndRemapPlaylistPoliciesAndUnknownValuesFailClosed() = runBlocking<Unit> {
        val original = repo(MemoryStore())
        original.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.AUTO_HOSTNAME)
        original.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.AUTO_HOSTNAME)
        original.setPlaybackTlsPolicy(8, PlaybackTlsPolicy.STRICT)
        val selected = filterBySourceId(original.exportPlaybackTlsSources(), setOf(7))
        assertFalse(selected.has("8"))
        val remapped = BackupRestoreIdentity(emptyMap(), mapOf(7L to 91L)).sourceMap(selected)
        val restored = repo(MemoryStore())
        restored.importSettings(original.exportSettings())
        restored.importPlaybackTlsSources(remapped, setOf(91, 92))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, restored.playbackTlsConfig.first().sources[91])
        assertFalse(restored.playbackTlsConfig.first().sources.containsKey(7))
        restored.importPlaybackTlsSources(JSONObject().put("92", "AUTO_FULL").put("999", "AUTO_HOSTNAME"), setOf(91, 92))
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().effective(92))
        assertFalse(restored.playbackTlsConfig.first().sources.containsKey(999))
        assertEquals(PlaybackTlsPolicy.STRICT, PlaybackTlsPolicy.parse("unknown"))
        restored.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.STRICT)
        restored.setPlaybackTlsPolicy(92, PlaybackTlsPolicy.AUTO_HOSTNAME)
        restored.importPlaybackTlsSources(JSONObject(), setOf(91, 92), setOf(92))
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().effective(92))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, restored.playbackTlsConfig.first().sources[91])
    }
}
