package tv.own.owntv.core.network

import com.sun.net.httpserver.HttpsConfigurator
import com.sun.net.httpserver.HttpsServer
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Assert.*
import org.junit.Test
import java.net.InetSocketAddress
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.util.concurrent.TimeUnit
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

class PlaybackTlsInterceptorTest {
    private val password = "owntv-test-only".toCharArray()
    private fun resource(name: String) = requireNotNull(javaClass.getResourceAsStream("/tls/$name"))
    private fun server(cert: String, port: Int = 0, status: Int = 200, redirect: String? = null, close: Boolean = false,
                       observe: (com.sun.net.httpserver.HttpExchange) -> Unit = {}): HttpsServer {
        val keys = KeyStore.getInstance("PKCS12").apply { resource("$cert.p12").use { load(it, password) } }
        val km = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(keys, password) }
        val ssl = SSLContext.getInstance("TLS").apply { init(km.keyManagers, null, null) }
        return HttpsServer.create(InetSocketAddress("127.0.0.1", port), 0).apply {
            httpsConfigurator = HttpsConfigurator(ssl)
            createContext("/") { exchange ->
                observe(exchange)
                if (redirect != null) exchange.responseHeaders.add("Location", redirect)
                if (close) exchange.responseHeaders.add("Connection", "close")
                val body = "#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:4,\nsegment.ts\n".toByteArray()
                exchange.sendResponseHeaders(status, body.size.toLong())
                exchange.responseBody.use { it.write(body) }
            }
            start()
        }
    }
    private val trust: X509TrustManager get() {
        val ks = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
            load(null, null)
            setCertificateEntry("test-ca", resource("ca.pem").use { CertificateFactory.getInstance("X.509").generateCertificate(it) })
        }
        return TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()).apply { init(ks) }
            .trustManagers.filterIsInstance<X509TrustManager>().single()
    }
    private fun client(tls: PlaybackTlsInterceptor, trusted: Boolean = true): OkHttpClient {
        val builder = OkHttpClient.Builder().retryOnConnectionFailure(false)
            .dns { listOf(java.net.InetAddress.getByName("127.0.0.1")) }
            .connectTimeout(2, TimeUnit.SECONDS).readTimeout(2, TimeUnit.SECONDS)
            .addInterceptor(tls).addNetworkInterceptor(tls.redirectGuard)
        if (trusted) {
            val tm = trust
            builder.sslSocketFactory(SSLContext.getInstance("TLS").apply { init(null, arrayOf(tm), null) }.socketFactory, tm)
        }
        return builder.build()
    }
    private fun get(client: OkHttpClient, server: HttpsServer, scope: PlaybackTlsScope?, path: String = "/"): Int =
        client.newCall(Request.Builder().url("https://localhost:${server.address.port}$path")
            .tag(PlaybackTlsScope::class.java, scope).build()).execute().use { it.body.string(); it.code }
    private fun auto(tls: PlaybackTlsInterceptor, id: Long = 1): PlaybackTlsScope {
        tls.configure(PlaybackTlsConfig(sources = mapOf(id to PlaybackTlsPolicy.AUTO_HOSTNAME)))
        return tls.scope(id)!!
    }

    @Test fun validTlsUsesOneNativeCallAndWrongHostnameRetriesInsideTheSameCall() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add)
        val scope = auto(tls); val client = client(tls)
        val good = server("correct"); val wrong = server("wrong")
        try {
            assertEquals(200, get(client, good, scope))
            assertEquals("TLS_STRICT_OK", events.single().reason)
            assertEquals(200, get(client, wrong, scope))
            assertEquals(1, events.count { it.reason == "TLS_HOSTNAME_RECOVERED" })
            assertEquals(200, get(client, wrong, scope, "/segment.ts"))
            assertEquals(2, events.size)
        } finally { good.stop(0); wrong.stop(0) }
    }

    @Test fun invalidToCorrectToInvalidOnSameEndpointAutomaticallyReturnsToStrict() {
        var clock = 0L
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(nowMs = { clock }, report = events::add, ttlMs = 100)
        val scope = auto(tls); val client = client(tls)
        var server = server("wrong", close = true); val port = server.address.port
        try {
            assertEquals(200, get(client, server, scope))
            server.stop(0); server = server("correct", port, close = true); clock = 101
            assertEquals(200, get(client, server, scope))
            assertTrue(events.any { it.reason == "TLS_RECHECK_STRICT_OK" })
            server.stop(0); server = server("wrong", port, close = true)
            // The established correct socket is gone: a new handshake observes the regression.
            assertEquals(200, get(client, server, scope))
            assertEquals(2, events.count { it.reason == "TLS_HOSTNAME_RECOVERED" })
        } finally { server.stop(0) }
    }

    @Test fun strictAndUnscopedAndOtherPlaylistCannotBorrowTheException() {
        val tls = PlaybackTlsInterceptor(); val scope = auto(tls); val client = client(tls); val server = server("wrong")
        try {
            assertEquals(200, get(client, server, scope))
            for (other in listOf(null, tls.scope(2), PlaybackTlsScope(0, PlaybackTlsPolicy.AUTO_HOSTNAME, "invalid"))) {
                try { get(client, server, other); fail("A different source must remain strict") }
                catch (_: SSLPeerUnverifiedException) { }
            }
            tls.configure(PlaybackTlsConfig())
            try { get(client, server, scope); fail("Disabling AUTO must invalidate the old scope") }
            catch (_: SSLPeerUnverifiedException) { }
            tls.configure(PlaybackTlsConfig(PlaybackTlsPolicy.AUTO_HOSTNAME, enabledSources = emptySet()))
            try { get(client, server, scope); fail("Disabled playlists must remain strict") }
            catch (_: SSLPeerUnverifiedException) { }
        } finally { server.stop(0) }
    }

    @Test fun unknownCaAndPinFailureAreNeverBypassed() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls); val server = server("correct")
        try {
            try { get(client(tls, trusted = false), server, scope); fail("Unknown CA must fail") }
            catch (_: SSLException) { }
            val pinned = client(tls).newBuilder().certificatePinner(CertificatePinner.Builder()
                .add("localhost", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=").build()).build()
            try { get(pinned, server, scope); fail("Pin failure must fail") }
            catch (_: SSLPeerUnverifiedException) { }
            assertTrue(events.isEmpty())
        } finally { server.stop(0) }
    }

    @Test fun httpErrorsDoNotTriggerTlsFallback() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls); val client = client(tls)
        for (code in listOf(401, 403, 404)) {
            val server = server("correct", status = code)
            try { assertEquals(code, get(client, server, scope)) } finally { server.stop(0) }
        }
        assertTrue(events.none { it.mode == "HOSTNAME_ONLY" })
    }

    @Test fun expiredCertificateAndPinOnMismatchedHostnameRemainRejected() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls)
        val expired = server("expired"); val wrong = server("wrong")
        try {
            try { get(client(tls), expired, scope); fail("Expired certificate must fail") }
            catch (_: SSLException) { }
            val pinned = client(tls).newBuilder().certificatePinner(CertificatePinner.Builder()
                .add("localhost", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=").build()).build()
            try { get(pinned, wrong, scope); fail("Hostname recovery cannot bypass pinning") }
            catch (_: SSLPeerUnverifiedException) { }
            assertTrue(events.isEmpty())
        } finally { expired.stop(0); wrong.stop(0) }
    }

    @Test fun crossHostRedirectMismatchFailsClosedAndHttpDowngradeIsRejected() {
        val tls = PlaybackTlsInterceptor(); val scope = auto(tls); val client = client(tls)
        val target = server("wrong")
        val origin = server("correct", status = 302, redirect = "https://127.0.0.1:${target.address.port}/")
        val downgrade = server("correct", status = 302, redirect = "http://127.0.0.1:1/")
        try {
            try { get(client, origin, scope); fail("Redirect host must not inherit localhost bypass") }
            catch (_: SSLPeerUnverifiedException) { }
            try { get(client, downgrade, scope); fail("HTTPS to HTTP must be rejected") }
            catch (_: java.io.IOException) { }
        } finally { target.stop(0); origin.stop(0); downgrade.stop(0) }
    }

    @Test fun healthySegmentsReuseTheSameStrictConnection() {
        val tls = PlaybackTlsInterceptor(); val scope = auto(tls)
        val connects = java.util.concurrent.atomic.AtomicInteger()
        val client = client(tls).newBuilder().eventListener(object : okhttp3.EventListener() {
            override fun secureConnectStart(call: okhttp3.Call) { connects.incrementAndGet() }
        }).build()
        val server = server("correct")
        try {
            repeat(8) { assertEquals(200, get(client, server, scope, "/segment$it.ts")) }
            assertEquals("No per-segment verifier identity or pool churn", 1, connects.get())
        } finally { server.stop(0) }
    }

    @Test fun cancellationInFallbackRetainsOneNativeCallAndNeverLearnsSuccess() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls)
        val handshakes = java.util.concurrent.atomic.AtomicInteger()
        val calls = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<okhttp3.Call, Boolean>())
        val client = client(tls).newBuilder().eventListener(object : okhttp3.EventListener() {
            override fun secureConnectStart(call: okhttp3.Call) {
                calls.add(call)
                if (handshakes.incrementAndGet() == 2) call.cancel()
            }
        }).build()
        val server = server("wrong")
        try {
            try { get(client, server, scope); fail("Canceled fallback must fail") }
            catch (_: java.io.IOException) { }
            assertEquals(2, handshakes.get())
            assertEquals(1, calls.size)
            assertTrue(events.isEmpty())
        } finally { server.stop(0) }
    }

    @Test fun expiredRevalidationIsSingleFlightAndOtherSegmentsCanContinue() {
        var clock = 0L
        val due = java.util.concurrent.CountDownLatch(1)
        val release = java.util.concurrent.CountDownLatch(1)
        val events = java.util.concurrent.CopyOnWriteArrayList<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(nowMs = { clock }, ttlMs = 100, report = {
            events.add(it)
            if (it.reason == "TLS_RECHECK_DUE") { due.countDown(); check(release.await(3, TimeUnit.SECONDS)) }
        })
        val scope = auto(tls); val client = client(tls); val server = server("wrong")
        val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
        try {
            get(client, server, scope); clock = 101
            val future = worker.submit<Int> { get(client, server, scope) }
            assertTrue(due.await(3, TimeUnit.SECONDS))
            assertEquals(200, get(client, server, scope, "/segment.ts"))
            release.countDown()
            assertEquals(200, future.get(3, TimeUnit.SECONDS))
            assertEquals(1, events.count { it.reason == "TLS_RECHECK_DUE" })
            assertEquals(1, events.count { it.reason == "TLS_RECHECK_STILL_INVALID" })
        } finally { release.countDown(); worker.shutdownNow(); server.stop(0) }
    }

    @Test fun headersSurviveRecoveryButPrivateHeadersDoNotFollowAnotherOrigin() {
        val tls = PlaybackTlsInterceptor(); val scope = auto(tls); val client = client(tls)
        var received: com.sun.net.httpserver.Headers? = null
        val wrong = server("wrong", observe = { received = it.requestHeaders })
        fun request(server: HttpsServer) = Request.Builder().url("https://localhost:${server.address.port}/")
            .tag(PlaybackTlsScope::class.java, scope).header("Range", "bytes=0-31")
            .header("User-Agent", "OwnTV-Test").header("Authorization", "test-only")
            .header("Cookie", "test-only").header("X-Private", "test-only").build()
        try {
            client.newCall(request(wrong)).execute().use { it.body.string() }
            assertEquals("bytes=0-31", received!!.getFirst("Range"))
            assertEquals("test-only", received!!.getFirst("Authorization"))
        } finally { wrong.stop(0) }
        val target = server("correct", observe = { received = it.requestHeaders })
        val origin = server("correct", status = 302, redirect = "https://127.0.0.1:${target.address.port}/")
        try {
            client.newCall(request(origin)).execute().use { assertEquals(200, it.code); it.body.string() }
            val headers = requireNotNull(received)
            assertNull(headers.getFirst("Authorization"))
            assertNull(headers.getFirst("Cookie"))
            assertNull(headers.getFirst("X-Private"))
            assertEquals("OwnTV-Test", headers.getFirst("User-Agent"))
        } finally { target.stop(0); origin.stop(0) }
    }

    @Test fun nonIdempotentRequestsAndDnsErrorsCannotAuthorizeFallback() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls); val server = server("wrong")
        try {
            val request = Request.Builder().url("https://localhost:${server.address.port}/")
                .tag(PlaybackTlsScope::class.java, scope).method("DELETE", null).build()
            try { client(tls).newCall(request).execute().close(); fail("DELETE must stay strict") }
            catch (_: SSLPeerUnverifiedException) { }
            val noDns = client(tls).newBuilder().dns { throw java.net.UnknownHostException("controlled test") }.build()
            try { get(noDns, server, scope); fail("DNS failure must propagate") }
            catch (_: java.net.UnknownHostException) { }
            assertTrue(events.isEmpty())
        } finally { server.stop(0) }
    }

    @Test fun timeoutAndGenericSslErrorsCannotAuthorizeFallback() {
        val events = mutableListOf<PlaybackTlsEvent>()
        val tls = PlaybackTlsInterceptor(report = events::add); val scope = auto(tls)
        val server = server("correct", observe = { Thread.sleep(200) })
        try {
            val slow = client(tls).newBuilder().readTimeout(50, TimeUnit.MILLISECONDS).build()
            try { get(slow, server, scope); fail("Timeout must propagate") }
            catch (_: java.io.IOException) { }
            val broken = client(tls).newBuilder().addInterceptor { throw SSLException("controlled protocol error") }.build()
            try { get(broken, server, scope); fail("Generic SSL error must propagate") }
            catch (_: SSLException) { }
            assertTrue(events.isEmpty())
        } finally { server.stop(0) }
    }
}
