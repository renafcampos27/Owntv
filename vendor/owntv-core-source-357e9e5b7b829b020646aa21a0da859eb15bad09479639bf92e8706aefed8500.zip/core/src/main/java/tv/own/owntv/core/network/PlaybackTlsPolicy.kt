package tv.own.owntv.core.network

/** V1 deliberately cannot opt out of certificate-chain or pin validation. */
enum class PlaybackTlsPolicy { STRICT, AUTO_HOSTNAME;
    companion object {
        fun parse(raw: String?): PlaybackTlsPolicy = entries.firstOrNull { it.name == raw } ?: STRICT
    }
}

data class PlaybackTlsConfig(
    val global: PlaybackTlsPolicy = PlaybackTlsPolicy.STRICT,
    val sources: Map<Long, PlaybackTlsPolicy> = emptyMap(),
    /** Derived from the source DAO, not backed up; null is for standalone transport fixtures. */
    val enabledSources: Set<Long>? = null,
) {
    fun effective(sourceId: Long): PlaybackTlsPolicy =
        if (sourceId <= 0 || enabledSources?.contains(sourceId) == false) PlaybackTlsPolicy.STRICT else sources[sourceId] ?: global
}

/** Local-only immutable context; never transmitted in HTTP headers. */
data class PlaybackTlsScope(
    val sourceId: Long,
    val policy: PlaybackTlsPolicy,
    val sessionKey: String,
    val diagnostics: ((PlaybackTlsEvent) -> Unit)? = null,
)

data class PlaybackTlsEvent(val sourceId: Long, val host: String, val mode: String, val reason: String)
