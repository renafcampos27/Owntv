package tv.own.owntv.core.network

import okhttp3.ConnectionPool
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ProtocolException
import java.util.LinkedHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocketFactory

/** Playback only. Uses native Calls; never changes the application client or its trust manager. */
class PlaybackTlsInterceptor(
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val report: (PlaybackTlsEvent) -> Unit = {},
    private val ttlMs: Long = 15 * 60_000L,
    private val maxEndpoints: Int = 128,
) : Interceptor {
    private data class Key(val sourceId: Long, val scheme: String, val host: String, val port: Int)
    private class Attempt { var mismatch: Pair<String, Int>? = null }
    private class Endpoint(val key: Key, delegate: HostnameVerifier) {
        val lock = Any()
        val attempt = ThreadLocal<Attempt>()
        // Stable identity preserves OkHttp socket reuse. Only the per-call evidence is thread-local.
        val strictVerifier = HostnameVerifier { host, session ->
            delegate.verify(host, session).also { if (!it) attempt.get()?.mismatch = host to session.peerPort }
        }
        val hostnameVerifier = HostnameVerifier { host, session ->
            (host == key.host && session.peerPort == key.port) || delegate.verify(host, session)
        }
        @Volatile var strictPool = pool()
        val hostnamePool = pool()
        var strictFactory: SSLSocketFactory? = null
        var hostname = false
        var nextRecheck = 0L
        var epoch = 0L
        var retired = false
        var strictReported = false
        val rechecking = AtomicBoolean(false)
        fun closeIdle() { strictPool.evictAll(); hostnamePool.evictAll() }
    }
    @Volatile private var config = PlaybackTlsConfig()
    private val entries = LinkedHashMap<Key, Endpoint>(16, .75f, true)

    fun configure(value: PlaybackTlsConfig) {
        synchronized(entries) {
            config = value
            val removed = entries.values.filter { value.effective(it.key.sourceId) != PlaybackTlsPolicy.AUTO_HOSTNAME }
            removed.forEach { endpoint ->
                synchronized(endpoint.lock) { endpoint.retired = true; endpoint.epoch++ }
                entries.remove(endpoint.key)
            }
            // Evict only idle playback sockets. Active response bodies keep their native Call owner.
            removed.forEach { it.closeIdle() }
        }
    }

    fun scope(sourceId: Long?, diagnostics: ((PlaybackTlsEvent) -> Unit)? = null): PlaybackTlsScope? = sourceId?.takeIf { it > 0 }?.let {
        PlaybackTlsScope(it, config.effective(it), java.util.UUID.randomUUID().toString(), diagnostics)
    }

    fun evictIdleConnections() = synchronized(entries) { entries.values.forEach { it.closeIdle() } }

    private fun allowed(scope: PlaybackTlsScope): Boolean = scope.sourceId > 0 &&
        scope.policy == PlaybackTlsPolicy.AUTO_HOSTNAME && config.effective(scope.sourceId) == scope.policy

    private fun endpoint(key: Key, verifier: HostnameVerifier): Endpoint = synchronized(entries) {
        entries[key] ?: Endpoint(key, verifier).also { created ->
            entries[key] = created
            if (entries.size > maxEndpoints) {
                val oldest = entries.entries.iterator().next()
                synchronized(oldest.value.lock) { oldest.value.retired = true; oldest.value.epoch++ }
                oldest.value.closeIdle()
                entries.remove(oldest.key)
            }
        }
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val scope = request.tag(PlaybackTlsScope::class.java)
        if (scope == null || !allowed(scope) || !request.url.isHttps || (request.method != "GET" && request.method != "HEAD")) {
            return chain.proceed(request)
        }
        val key = Key(scope.sourceId, request.url.scheme, request.url.host, request.url.port)
        val state = endpoint(key, chain.hostnameVerifier)
        val snapshot = synchronized(state.lock) { Triple(state.hostname, state.nextRecheck, state.epoch) }
        val recheck = snapshot.first && nowMs() >= snapshot.second && state.rechecking.compareAndSet(false, true)
        if (snapshot.first && !recheck) return hostname(chain, scope, state, snapshot.third, learn = false)

        val probePool = if (recheck) pool() else synchronized(state.lock) { state.strictPool }
        // A fresh TLS context also prevents TLS-session resumption from hiding the server's new cert.
        val probeFactory = try { if (recheck) {
            val trust = chain.x509TrustManagerOrNull
                ?: throw IOException("TLS strict revalidation requires the playback trust manager")
            SSLContext.getInstance("TLS").apply { init(null, arrayOf(trust), null) }.socketFactory
        } else synchronized(state.lock) { state.strictFactory }
        } catch (failure: Exception) {
            if (recheck) { state.rechecking.set(false); probePool.evictAll() }
            throw failure
        }
        val attempt = Attempt()
        state.attempt.set(attempt)
        var adoptedProbe = false
        try {
            canceled(chain)
            if (recheck) event(scope, state, "STRICT", "TLS_RECHECK_DUE")
            var strict = chain.withConnectionPool(probePool).withHostnameVerifier(state.strictVerifier)
            if (probeFactory != null) strict = strict.withSslSocketFactory(probeFactory, chain.x509TrustManagerOrNull)
            try {
                val response = strict.proceed(request)
                if (recheck) {
                    synchronized(state.lock) {
                        if (!state.retired && state.epoch == snapshot.third && allowed(scope)) {
                            state.strictPool.evictAll()
                            state.strictPool = probePool
                            state.strictFactory = probeFactory
                            state.hostname = false
                            state.strictReported = true
                            state.epoch++
                            adoptedProbe = true
                        }
                    }
                    if (adoptedProbe) { state.hostnamePool.evictAll(); event(scope, state, "STRICT", "TLS_RECHECK_STRICT_OK") }
                } else {
                    val first = synchronized(state.lock) {
                        if (state.strictReported || state.retired) false else { state.strictReported = true; true }
                    }
                    if (first) event(scope, state, "STRICT", "TLS_STRICT_OK")
                }
                return response
            } catch (error: SSLPeerUnverifiedException) {
                canceled(chain)
                // Redirect mismatches are deliberately not recoverable in V1. Pin errors do not
                // produce evidence in our strict verifier and cannot enter this branch's retry.
                val eligible = attempt.mismatch == (key.host to key.port) && allowed(scope) &&
                    synchronized(state.lock) { !state.retired && state.epoch == snapshot.third }
                if (!eligible) throw error
                return hostname(chain, scope, state, snapshot.third, learn = true, recheck = recheck)
            }
        } finally {
            state.attempt.remove()
            if (recheck) {
                state.rechecking.set(false)
                if (!adoptedProbe) probePool.evictAll()
            }
        }
    }

    private fun hostname(chain: Interceptor.Chain, scope: PlaybackTlsScope, state: Endpoint,
                         epoch: Long, learn: Boolean, recheck: Boolean = false): Response {
        canceled(chain)
        val eligible = synchronized(state.lock) {
            !state.retired && state.epoch == epoch && (learn || state.hostname)
        }
        if (!allowed(scope) || !eligible) {
            // A segment can have taken its snapshot before another request completed a strict
            // recheck. Never let that stale snapshot start a new permissive connection afterwards.
            var strict = chain.withHostnameVerifier(state.strictVerifier)
                .withConnectionPool(synchronized(state.lock) { state.strictPool })
            synchronized(state.lock) { state.strictFactory }?.let {
                strict = strict.withSslSocketFactory(it, chain.x509TrustManagerOrNull)
            }
            return strict.proceed(chain.request())
        }
        val response = chain.withConnectionPool(state.hostnamePool)
            .withHostnameVerifier(state.hostnameVerifier).proceed(chain.request())
        if (learn && response.isSuccessful) {
            val changed = synchronized(state.lock) {
                if (!state.retired && state.epoch == epoch && allowed(scope)) {
                    val transition = !state.hostname
                    state.hostname = true
                    state.nextRecheck = nowMs() + ttlMs
                    transition || recheck
                } else false
            }
            if (changed) event(scope, state, "HOSTNAME_ONLY", if (recheck) "TLS_RECHECK_STILL_INVALID" else "TLS_HOSTNAME_RECOVERED")
        }
        return response
    }

    private fun canceled(chain: Interceptor.Chain) {
        if (chain.call().isCanceled()) throw InterruptedIOException("Canceled")
    }

    private fun event(scope: PlaybackTlsScope, state: Endpoint, mode: String, reason: String) {
        // These fields contain no URLs, headers, certificate objects, sessions, or exception text.
        val event = PlaybackTlsEvent(state.key.sourceId, state.key.host, mode, reason)
        runCatching { report(event) }
        runCatching { scope.diagnostics?.invoke(event) }
    }

    /** AUTO calls only: prevent protocol downgrade and cross-origin leakage of private headers. */
    val redirectGuard: Interceptor = Interceptor { chain ->
        val initial = chain.call().request()
        val scope = initial.tag(PlaybackTlsScope::class.java)
        val target = chain.request()
        if (scope == null || scope.policy != PlaybackTlsPolicy.AUTO_HOSTNAME || !initial.url.isHttps) chain.proceed(target)
        else {
            if (!target.url.isHttps) throw ProtocolException("TLS playback redirect to HTTP refused")
            val crossOrigin = initial.url.host != target.url.host || initial.url.port != target.url.port
            val safe = if (!crossOrigin) target else target.newBuilder().apply {
                target.headers.names().filter { it.lowercase() !in SAFE_REDIRECT_HEADERS }.forEach { removeHeader(it) }
            }.build()
            chain.proceed(safe)
        }
    }

    companion object {
        private fun pool() = ConnectionPool(5, 5, TimeUnit.MINUTES)
        private val SAFE_REDIRECT_HEADERS = setOf("host", "user-agent", "range", "accept", "accept-encoding", "connection", "cache-control")
    }
}
