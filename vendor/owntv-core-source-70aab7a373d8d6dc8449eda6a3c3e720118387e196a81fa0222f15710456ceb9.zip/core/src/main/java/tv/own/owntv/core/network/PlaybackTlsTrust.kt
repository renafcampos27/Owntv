package tv.own.owntv.core.network

import java.net.Socket
import java.security.cert.CertPathBuilderException
import java.security.cert.CertPathValidatorException
import java.security.cert.CertificateException
import java.security.cert.CertificateExpiredException
import java.security.cert.CertificateNotYetValidException
import java.security.cert.PKIXReason
import java.security.cert.X509Certificate
import javax.net.ssl.SSLEngine
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509ExtendedTrustManager
import javax.net.ssl.X509TrustManager

internal enum class PlaybackCertificateFailure { EXPIRED, UNTRUSTED_CHAIN }

/** Typed certificate failures only. Protocol, cipher, pin and network errors are not evidence. */
internal fun certificateFailure(error: Throwable): PlaybackCertificateFailure? {
    var current: Throwable? = error
    var candidate: PlaybackCertificateFailure? = null
    val visited = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable, Boolean>())
    while (current != null && visited.size < 16 && visited.add(current)) {
        when (current) {
            is CertificateNotYetValidException -> return null
            is CertificateExpiredException -> candidate = PlaybackCertificateFailure.EXPIRED
            is CertPathBuilderException -> if (candidate == null) candidate = PlaybackCertificateFailure.UNTRUSTED_CHAIN
            is CertPathValidatorException -> {
                when (current.reason) {
                    CertPathValidatorException.BasicReason.EXPIRED -> candidate = PlaybackCertificateFailure.EXPIRED
                    PKIXReason.NO_TRUST_ANCHOR, CertPathValidatorException.BasicReason.UNSPECIFIED ->
                        if (candidate == null) candidate = PlaybackCertificateFailure.UNTRUSTED_CHAIN
                    else -> return null // Never hide a denied reason deeper in a path-builder error.
                }
            }
        }
        current = current.cause
    }
    return if (current == null) candidate else null
}

internal data class PlaybackTlsPeer(val host: String, val port: Int)

/**
 * A per-endpoint TLS-context manager, never installed on the shared HTTP client or Android.
 * Basic callbacks have no endpoint proof and always delegate strictly. Last resort is available
 * only in the socket/engine callback for the exact approved destination. Other redirects stay strict.
 */
internal class PlaybackTlsTrust(
    private val delegate: X509TrustManager,
    private val endpoint: PlaybackTlsPeer,
    private val lastResort: Boolean,
    private val rejected: (PlaybackTlsPeer?, PlaybackCertificateFailure) -> Unit = { _, _ -> },
) : X509ExtendedTrustManager() {
    override fun getAcceptedIssuers(): Array<X509Certificate> = delegate.acceptedIssuers
    override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) = delegate.checkClientTrusted(chain, authType)
    override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String, socket: Socket) =
        (delegate as? X509ExtendedTrustManager)?.checkClientTrusted(chain, authType, socket) ?: delegate.checkClientTrusted(chain, authType)
    override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String, engine: SSLEngine) =
        (delegate as? X509ExtendedTrustManager)?.checkClientTrusted(chain, authType, engine) ?: delegate.checkClientTrusted(chain, authType)

    override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) = delegate.checkServerTrusted(chain, authType)

    override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String, socket: Socket) {
        val session = (socket as? SSLSocket)?.handshakeSession
        val peer = session?.peerHost?.let { PlaybackTlsPeer(it, session.peerPort) }
        validate(chain, peer) {
            (delegate as? X509ExtendedTrustManager)?.checkServerTrusted(chain, authType, socket)
                ?: delegate.checkServerTrusted(chain, authType)
        }
    }

    override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String, engine: SSLEngine) {
        val peer = engine.peerHost?.let { PlaybackTlsPeer(it, engine.peerPort) }
        validate(chain, peer) {
            (delegate as? X509ExtendedTrustManager)?.checkServerTrusted(chain, authType, engine)
                ?: delegate.checkServerTrusted(chain, authType)
        }
    }

    private inline fun validate(chain: Array<X509Certificate>, peer: PlaybackTlsPeer?, strict: () -> Unit) {
        if (chain.isEmpty()) throw CertificateException("Empty playback certificate chain")
        if (lastResort && peer == endpoint) return
        try { strict() }
        catch (failure: CertificateException) {
            certificateFailure(failure)?.let { rejected(peer, it) }
            throw failure
        }
    }
}
