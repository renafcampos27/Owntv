package tv.own.owntv.core.network

import okhttp3.ConnectionPool
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ProtocolException
import java.util.LinkedHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLPeerUnverifiedException
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/** Playback only. Uses native Calls; never changes the application client or its trust manager. */
class PlaybackTlsInterceptor(
    private val nowMs: () -> Long = { System.nanoTime() / 1_000_000 },
    private val report: (PlaybackTlsEvent) -> Unit = {},
    private val ttlMs: Long = 15 * 60_000L,
    private val maxEndpoints: Int = 128,
) : Interceptor {
    private enum class Mode { STRICT, HOSTNAME_ONLY, UNVERIFIED }
    private data class Key(val sourceId: Long, val scheme: String, val host: String, val port: Int)
    private data class ChainFailure(val peer: PlaybackTlsPeer?, val reason: PlaybackCertificateFailure)
    private class Attempt {
        var mismatch: PlaybackTlsPeer? = null
        var chainFailure: ChainFailure? = null
    }
    private class Endpoint(val key: Key, val policy: PlaybackTlsPolicy, delegate: HostnameVerifier, trust: X509TrustManager?) {
        val lock = Any()
        val peer = PlaybackTlsPeer(key.host, key.port)
        val attempt = ThreadLocal<Attempt>()
        // Stable verifier identities preserve pooling; evidence belongs only to this Call's thread.
        val strictVerifier = HostnameVerifier { host, session ->
            delegate.verify(host, session).also { if (!it) attempt.get()?.mismatch = PlaybackTlsPeer(host, session.peerPort) }
        }
        val hostnameVerifier = HostnameVerifier { host, session ->
            (host == key.host && session.peerPort == key.port) || delegate.verify(host, session)
        }
        val strictTrust = if (policy == PlaybackTlsPolicy.AUTO_FULL && trust != null) {
            PlaybackTlsTrust(trust, peer, lastResort = false) { target, reason ->
                attempt.get()?.chainFailure = ChainFailure(target, reason)
            }
        } else trust
        val unverifiedTrust by lazy {
            PlaybackTlsTrust(requireNotNull(trust), peer, lastResort = true)
        }
        val unverifiedFactory by lazy { factory(unverifiedTrust) }
        @Volatile var strictPool = pool()
        val hostnamePool = pool()
        val unverifiedPool = pool()
        var strictFactory: SSLSocketFactory? = if (policy == PlaybackTlsPolicy.AUTO_FULL) {
            factory(strictTrust ?: throw IOException("Missing playback trust manager"))
        } else null
        var mode = Mode.STRICT
        var nextRecheck = 0L
        var epoch = 0L
        var retired = false
        var strictReported = false
        val rechecking = AtomicBoolean(false)
        fun closeIdle() { strictPool.evictAll(); hostnamePool.evictAll(); unverifiedPool.evictAll() }
    }
    @Volatile private var config = PlaybackTlsConfig()
    private val entries = LinkedHashMap<Key, Endpoint>(16, .75f, true)

    fun configure(value: PlaybackTlsConfig) {
        synchronized(entries) {
            config = value
            val removed = entries.values.filter { value.effective(it.key.sourceId) != it.policy }
            removed.forEach { endpoint ->
                synchronized(endpoint.lock) { endpoint.retired = true; endpoint.epoch++ }
                entries.remove(endpoint.key)
            }
            removed.forEach { it.closeIdle() }
        }
    }

    fun scope(sourceId: Long?, diagnostics: ((PlaybackTlsEvent) -> Unit)? = null): PlaybackTlsScope? = sourceId?.takeIf { it > 0 }?.let {
        PlaybackTlsScope(it, config.effective(it), java.util.UUID.randomUUID().toString(), diagnostics)
    }

    fun evictIdleConnections() = synchronized(entries) { entries.values.forEach { it.closeIdle() } }

    private fun allowed(scope: PlaybackTlsScope): Boolean = scope.sourceId > 0 &&
        scope.policy != PlaybackTlsPolicy.STRICT && config.effective(scope.sourceId) == scope.policy

    private fun endpoint(key: Key, scope: PlaybackTlsScope, chain: Interceptor.Chain): Endpoint? = synchronized(entries) {
        // Configure and endpoint creation share this monitor. An old scope cannot repopulate the
        // cache with its previous policy after a concurrent settings change removed that entry.
        if (!allowed(scope)) return@synchronized null
        entries[key] ?: Endpoint(key, scope.policy, chain.hostnameVerifier, chain.x509TrustManagerOrNull).also { created ->
            entries[key] = created
            if (entries.size > maxEndpoints) {
                val oldest = entries.entries.iterator().next()
                synchronized(oldest.value.lock) { oldest.value.retired = true; oldest.value.epoch++ }
                oldest.value.closeIdle()
                entries.remove(oldest.key)
            }
        }
    }

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val scope = request.tag(PlaybackTlsScope::class.java)
        if (scope == null || !allowed(scope) || !request.url.isHttps || (request.method != "GET" && request.method != "HEAD")) {
            return chain.proceed(request)
        }
        val key = Key(scope.sourceId, request.url.scheme, request.url.host, request.url.port)
        val state = endpoint(key, scope, chain) ?: return chain.proceed(request)
        val snapshot = synchronized(state.lock) { Triple(state.mode, state.nextRecheck, state.epoch) }
        val recheck = snapshot.first != Mode.STRICT && nowMs() >= snapshot.second && state.rechecking.compareAndSet(false, true)
        state.attempt.set(Attempt())
        var probePool: ConnectionPool? = null
        var adoptedProbe = false
        try {
            if (snapshot.first != Mode.STRICT && !recheck) {
                return recover(chain, scope, state, snapshot.third, snapshot.first, learn = false)
            }
            val strictPool = if (recheck) pool().also { probePool = it } else synchronized(state.lock) { state.strictPool }
            // Fresh TLS context also excludes session resumption with the old server certificate.
            val strictFactory = if (recheck) factory(state.strictTrust ?: throw IOException("Missing playback trust manager"))
                else synchronized(state.lock) { state.strictFactory }
            canceled(chain)
            if (recheck) event(scope, state, Mode.STRICT, "TLS_RECHECK_DUE")
            try {
                val response = strict(chain, state, strictPool, strictFactory).proceed(request)
                if (recheck) {
                    synchronized(state.lock) {
                        if (!state.retired && state.epoch == snapshot.third && allowed(scope)) {
                            state.strictPool.evictAll()
                            state.strictPool = strictPool
                            state.strictFactory = strictFactory
                            state.mode = Mode.STRICT
                            state.strictReported = true
                            state.epoch++
                            adoptedProbe = true
                        }
                    }
                    if (adoptedProbe) {
                        state.hostnamePool.evictAll(); state.unverifiedPool.evictAll()
                        event(scope, state, Mode.STRICT, "TLS_RECHECK_STRICT_OK")
                    }
                } else {
                    val first = synchronized(state.lock) {
                        if (state.strictReported || state.retired) false else { state.strictReported = true; true }
                    }
                    if (first) event(scope, state, Mode.STRICT, "TLS_STRICT_OK")
                }
                return response
            } catch (error: IOException) {
                canceled(chain)
                val attempt = state.attempt.get()
                if (error is SSLPeerUnverifiedException && attempt?.mismatch == state.peer) {
                    return recover(chain, scope, state, snapshot.third, Mode.HOSTNAME_ONLY, learn = true, recheck = recheck)
                }
                if (fullEligible(error, scope, state)) {
                    return recover(chain, scope, state, snapshot.third, Mode.UNVERIFIED, learn = true, recheck = recheck)
                }
                throw error
            }
        } finally {
            state.attempt.remove()
            if (recheck) {
                state.rechecking.set(false)
                if (!adoptedProbe) probePool?.evictAll()
            }
        }
    }

    private fun fullEligible(error: IOException, scope: PlaybackTlsScope, state: Endpoint): Boolean {
        val evidence = state.attempt.get()?.chainFailure ?: return false
        return scope.policy == PlaybackTlsPolicy.AUTO_FULL && evidence.peer == state.peer &&
            evidence.reason == certificateFailure(error)
    }

    private fun strict(chain: Interceptor.Chain, state: Endpoint,
                       selectedPool: ConnectionPool = synchronized(state.lock) { state.strictPool },
                       selectedFactory: SSLSocketFactory? = synchronized(state.lock) { state.strictFactory }): Interceptor.Chain {
        var result = chain.withHostnameVerifier(state.strictVerifier).withConnectionPool(selectedPool)
        if (selectedFactory != null) result = result.withSslSocketFactory(selectedFactory, state.strictTrust)
        return result
    }

    private fun recover(chain: Interceptor.Chain, scope: PlaybackTlsScope, state: Endpoint,
                        epoch: Long, mode: Mode, learn: Boolean, recheck: Boolean = false): Response {
        canceled(chain)
        val eligible = synchronized(state.lock) { !state.retired && state.epoch == epoch && (learn || state.mode == mode) }
        if (!allowed(scope) || !eligible || (mode == Mode.UNVERIFIED && scope.policy != PlaybackTlsPolicy.AUTO_FULL)) {
            return strict(chain, state).proceed(chain.request())
        }
        var retry = chain.withHostnameVerifier(state.hostnameVerifier)
        retry = if (mode == Mode.UNVERIFIED) {
            retry.withConnectionPool(state.unverifiedPool).withSslSocketFactory(state.unverifiedFactory, state.unverifiedTrust)
        } else {
            retry.withConnectionPool(state.hostnamePool).let { selected ->
                synchronized(state.lock) { state.strictFactory }?.let { selected.withSslSocketFactory(it, state.strictTrust) } ?: selected
            }
        }
        val response = try {
            // A certificate failure from an earlier tier/route is not evidence for this attempt.
            state.attempt.get()?.apply { mismatch = null; chainFailure = null }
            retry.proceed(chain.request())
        }
        catch (error: IOException) {
            canceled(chain)
            if (mode == Mode.HOSTNAME_ONLY && fullEligible(error, scope, state)) {
                return recover(chain, scope, state, epoch, Mode.UNVERIFIED, learn = true, recheck = recheck)
            }
            throw error
        }
        if (learn && response.isSuccessful) {
            val changed = synchronized(state.lock) {
                if (!state.retired && state.epoch == epoch && allowed(scope)) {
                    val transition = state.mode != mode
                    state.mode = mode
                    state.nextRecheck = nowMs() + ttlMs
                    transition || recheck
                } else false
            }
            if (changed) event(scope, state, mode, if (recheck) "TLS_RECHECK_STILL_INVALID"
                else if (mode == Mode.UNVERIFIED) "TLS_UNVERIFIED_RECOVERED" else "TLS_HOSTNAME_RECOVERED")
        }
        return response
    }

    private fun canceled(chain: Interceptor.Chain) {
        if (chain.call().isCanceled()) throw InterruptedIOException("Canceled")
    }

    private fun event(scope: PlaybackTlsScope, state: Endpoint, mode: Mode, reason: String) {
        val event = PlaybackTlsEvent(state.key.sourceId, state.key.host, mode.name, reason)
        runCatching { report(event) }
        runCatching { scope.diagnostics?.invoke(event) }
    }

    /** All AUTO calls: never transfer private headers or unverified trust to another origin. */
    val redirectGuard: Interceptor = Interceptor { chain ->
        val initial = chain.call().request()
        val scope = initial.tag(PlaybackTlsScope::class.java)
        val target = chain.request()
        if (scope == null || scope.policy == PlaybackTlsPolicy.STRICT || !initial.url.isHttps) chain.proceed(target)
        else {
            if (!target.url.isHttps) throw ProtocolException("TLS playback redirect to HTTP refused")
            val crossOrigin = initial.url.host != target.url.host || initial.url.port != target.url.port
            val safe = if (!crossOrigin) target else target.newBuilder().apply {
                target.headers.names().filter { it.lowercase() !in SAFE_REDIRECT_HEADERS }.forEach { removeHeader(it) }
            }.build()
            chain.proceed(safe)
        }
    }

    companion object {
        private fun pool() = ConnectionPool(5, 5, TimeUnit.MINUTES)
        private fun factory(trust: X509TrustManager): SSLSocketFactory =
            SSLContext.getInstance("TLS").apply { init(null, arrayOf(trust), null) }.socketFactory
        private val SAFE_REDIRECT_HEADERS = setOf("host", "user-agent", "range", "accept", "accept-encoding", "connection", "cache-control")
    }
}
