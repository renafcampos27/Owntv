package tv.own.owntv.core.network

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.backup.BackupRestoreIdentity
import tv.own.owntv.core.backup.filterBySourceId
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.settings.SettingsRepository

class PlaybackTlsPreferencesTest {
    private class MemoryStore : DataStore<Preferences> {
        val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (Preferences) -> Preferences): Preferences =
            transform(state.value).also { state.value = it }
    }
    private fun repo(store: DataStore<Preferences>): SettingsRepository {
        val editor = java.lang.reflect.Proxy.newProxyInstance(SharedPreferences.Editor::class.java.classLoader,
            arrayOf(SharedPreferences.Editor::class.java)) { proxy, method, _ ->
            when (method.name) { "commit" -> true; "apply" -> null; else -> proxy }
        } as SharedPreferences.Editor
        val preferences = java.lang.reflect.Proxy.newProxyInstance(SharedPreferences::class.java.classLoader,
            arrayOf(SharedPreferences::class.java)) { _, method, args ->
            when (method.name) { "edit" -> editor; "getAll" -> emptyMap<String, Any>(); "contains" -> false; else -> args?.lastOrNull() }
        } as SharedPreferences
        val context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = preferences
        }
        return SettingsRepository(context, LocaleStore.from(context), store)
    }

    @Test fun hostnameDefaultAppliesToOldPreferencesWithoutOverridingPlaylistChoices() = runBlocking<Unit> {
        val settings = repo(MemoryStore())
        // An older installation or backup has settings, but no TLS global key yet.
        settings.importSettings(JSONObject().put("live_hls_only", true))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, settings.playbackTlsConfig.first().global)
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, settings.playbackTlsConfig.first().effective(7))
        settings.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.STRICT)
        settings.setPlaybackTlsPolicy(8, PlaybackTlsPolicy.AUTO_FULL)
        settings.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.STRICT)
        settings.setPlaybackTlsPolicy(null, null)
        val config = settings.playbackTlsConfig.first()
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.global)
        assertEquals(PlaybackTlsPolicy.STRICT, config.effective(7))
        assertEquals(PlaybackTlsPolicy.AUTO_FULL, config.effective(8))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.effective(9))
        val backup = settings.exportSettings()
        assertEquals("AUTO_HOSTNAME", backup.getString("playback_tls_global"))
        val restored = repo(MemoryStore())
        restored.importSettings(backup)
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, restored.playbackTlsConfig.first().global)
    }

    @Test fun explicitStrictSurvivesRestoreAndUnknownGlobalRemainsStrict() = runBlocking<Unit> {
        val settings = repo(MemoryStore())
        settings.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.STRICT)
        val restored = repo(MemoryStore())
        restored.importSettings(settings.exportSettings())
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().global)
        restored.importSettings(JSONObject().put("playback_tls_global", "FUTURE_POLICY"))
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().global)
        assertEquals(PlaybackTlsPolicy.STRICT, PlaybackTlsConfig().global)
        assertEquals(PlaybackTlsPolicy.STRICT, PlaybackTlsPolicy.parse(null))
    }

    @Test fun policySurvivesClosingAndReopeningARealDataStoreFile() = runBlocking<Unit> {
        val folder = java.nio.file.Files.createTempDirectory("owntv-tls-preferences").toFile()
        val file = folder.resolve("settings.preferences_pb")
        val job = SupervisorJob()
        val store = PreferenceDataStoreFactory.create(scope = CoroutineScope(job + Dispatchers.IO), produceFile = { file })
        val settings = repo(store)
        try {
            assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, settings.playbackTlsConfig.first().effective(7))
            // One committed write suffices to prove persistence. Android's FileStorage.renameTo
            // cannot replace an existing file on the Windows JVM host; that is not Android I/O.
            settings.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.AUTO_FULL)
            job.cancelAndJoin()
            val secondJob = SupervisorJob()
            try {
                val reopened = repo(PreferenceDataStoreFactory.create(scope = CoroutineScope(secondJob + Dispatchers.IO), produceFile = { file }))
                val config = reopened.playbackTlsConfig.first()
                assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.global)
                assertEquals(PlaybackTlsPolicy.AUTO_FULL, config.effective(7))
                assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.effective(8))
            } finally { secondJob.cancelAndJoin() }
        } finally { job.cancelAndJoin(); folder.listFiles()?.forEach { it.delete() }; folder.delete() }
    }

    @Test fun backupsScopeAndRemapPlaylistPoliciesAndUnknownValuesFailClosed() = runBlocking<Unit> {
        val original = repo(MemoryStore())
        original.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.AUTO_HOSTNAME)
        original.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.AUTO_HOSTNAME)
        original.setPlaybackTlsPolicy(8, PlaybackTlsPolicy.STRICT)
        val selected = filterBySourceId(original.exportPlaybackTlsSources(), setOf(7))
        assertFalse(selected.has("8"))
        val remapped = BackupRestoreIdentity(emptyMap(), mapOf(7L to 91L)).sourceMap(selected)
        val restored = repo(MemoryStore())
        restored.importSettings(original.exportSettings())
        restored.importPlaybackTlsSources(remapped, setOf(91, 92))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, restored.playbackTlsConfig.first().sources[91])
        assertFalse(restored.playbackTlsConfig.first().sources.containsKey(7))
        restored.importPlaybackTlsSources(JSONObject().put("92", "FUTURE_POLICY").put("999", "AUTO_HOSTNAME"), setOf(91, 92))
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().effective(92))
        assertFalse(restored.playbackTlsConfig.first().sources.containsKey(999))
        assertEquals(PlaybackTlsPolicy.STRICT, PlaybackTlsPolicy.parse("unknown"))
        restored.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.STRICT)
        restored.setPlaybackTlsPolicy(92, PlaybackTlsPolicy.AUTO_HOSTNAME)
        restored.importPlaybackTlsSources(JSONObject(), setOf(91, 92), setOf(92))
        assertEquals(PlaybackTlsPolicy.STRICT, restored.playbackTlsConfig.first().effective(92))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, restored.playbackTlsConfig.first().sources[91])
    }
    @Test fun fullGlobalAndIndependentOverridesSurviveBackupRestore() = runBlocking<Unit> {
        val original = repo(MemoryStore())
        original.setPlaybackTlsPolicy(null, PlaybackTlsPolicy.AUTO_FULL)
        original.setPlaybackTlsPolicy(7, PlaybackTlsPolicy.STRICT)
        original.setPlaybackTlsPolicy(8, PlaybackTlsPolicy.AUTO_HOSTNAME)
        val restored = repo(MemoryStore())
        restored.importSettings(original.exportSettings())
        val mapped = BackupRestoreIdentity(emptyMap(), mapOf(7L to 91L, 8L to 92L)).sourceMap(original.exportPlaybackTlsSources())
        restored.importPlaybackTlsSources(mapped, setOf(91, 92), setOf(91, 92))
        val config = restored.playbackTlsConfig.first()
        assertEquals(PlaybackTlsPolicy.AUTO_FULL, config.global)
        assertEquals(PlaybackTlsPolicy.STRICT, config.effective(91))
        assertEquals(PlaybackTlsPolicy.AUTO_HOSTNAME, config.effective(92))
        assertEquals(PlaybackTlsPolicy.AUTO_FULL, config.effective(93))
    }

}
