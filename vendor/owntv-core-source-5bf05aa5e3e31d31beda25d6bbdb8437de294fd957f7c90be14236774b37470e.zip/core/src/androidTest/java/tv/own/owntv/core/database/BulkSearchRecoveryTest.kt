package tv.own.owntv.core.database

import androidx.room.Room
import androidx.room.execSQL
import androidx.room.useWriterConnection
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteDriver
import androidx.sqlite.SQLiteStatement
import androidx.sqlite.driver.bundled.BundledSQLiteDriver
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Actual Room transactions and writer configuration; requires an Android device/emulator to run. */
@RunWith(AndroidJUnit4::class)
class BulkSearchRecoveryTest {
    private class FaultDriver : SQLiteDriver by BundledSQLiteDriver() {
        private val delegate = BundledSQLiteDriver()
        val fault = AtomicReference<((String) -> Unit)?>(null)
        override fun open(fileName: String): SQLiteConnection {
            val connection = delegate.open(fileName)
            return object : SQLiteConnection by connection {
                override fun prepare(sql: String): SQLiteStatement {
                    fault.get()?.invoke(sql)
                    return connection.prepare(sql)
                }
            }
        }
    }
    private fun database(driver: SQLiteDriver) = Room.inMemoryDatabaseBuilder(
        InstrumentationRegistry.getInstrumentation().targetContext, OwnTVDatabase::class.java,
    ).setDriver(driver).build()
    private suspend fun names(db: OwnTVDatabase, type: String): Set<String> = db.useWriterConnection { c ->
        c.usePrepared("SELECT name FROM sqlite_master WHERE type=? AND tbl_name='channels'") { q ->
            q.bindText(1, type); buildSet { while (q.step()) add(q.getText(0)) }
        }
    }
    @Test fun thirdDropFailureRollsBackBeforeCaptureAndRetryWorks() = runBlocking {
        val driver = FaultDriver(); val db = database(driver)
        try {
            val before = names(db, "index"); val triggers = names(db, "trigger")
            var drops = 0; var entered = false
            driver.fault.set { sql -> if (sql.startsWith("DROP INDEX") && ++drops == 3) error("third DROP") }
            val helper = BulkInsertHelper(db)
            try { helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true) { entered = true }; fail("Expected failure") }
            catch (_: IllegalStateException) { }
            driver.fault.set(null)
            assertFalse(entered); assertEquals(before, names(db, "index")); assertEquals(triggers, names(db, "trigger"))
            helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true) { }
            assertEquals(before, names(db, "index")); assertEquals(triggers, names(db, "trigger"))
        } finally { db.close() }
    }
    @Test fun failedRestoreIsAtomicAndRetriedBeforeAnotherWriterEnters() = runBlocking {
        val driver = FaultDriver(); val db = database(driver)
        try {
            val before = names(db, "index"); val helper = BulkInsertHelper(db)
            var creates = 0
            try {
                helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = true) {
                    driver.fault.set { sql -> if (sql.startsWith("CREATE INDEX") && ++creates == 2) error("restore interrupted") }
                }
                fail("Expected failure")
            } catch (_: IllegalStateException) { }
            driver.fault.set(null)
            val retired = names(db, "index")
            assertTrue(before.size > retired.size)
            assertFalse(names(db, "trigger").contains("room_fts_content_sync_channels_fts_AFTER_INSERT"))
            helper.withOptimizedBulkInsert("channels", "channels_fts", eligible = false) {
                assertEquals(before, names(db, "index"))
                assertTrue(names(db, "trigger").contains("room_fts_content_sync_channels_fts_AFTER_INSERT"))
            }
        } finally { db.close() }
    }
    @Test fun unmanagedIndexIsNeverRetired() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            db.useWriterConnection { it.execSQL("CREATE INDEX extra_channel_name ON channels(name)") }
            BulkInsertHelper(db).withOptimizedBulkInsert("channels", "channels_fts", eligible = true) {
                assertTrue(names(db, "index").contains("extra_channel_name"))
            }
            assertTrue(names(db, "index").contains("extra_channel_name"))
        } finally { db.close() }
    }
    @Test fun roomWriterAlreadyEnablesRecursiveTriggers() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            repeat(3) {
                db.useWriterConnection { c -> c.usePrepared("PRAGMA recursive_triggers") { q ->
                    assertTrue(q.step()); assertEquals(1L, q.getLong(0))
                } }
            }
        } finally { db.close() }
    }
}
