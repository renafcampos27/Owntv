package tv.own.owntv.core.network

import org.junit.Assert.*
import org.junit.Test

class NetworkConfigInputTest {
    @Test fun plainDnsUsesExactlyTheSelectedPort() {
        assertEquals(DnsConfig(true, "192.168.1.1", 5353), NetworkConfigInput.dns(" 192.168.1.1:5353 "))
        assertNull(NetworkConfigInput.dns("dns.example:invalid"))
        assertNull(NetworkConfigInput.dns("dns.example:65536"))
        assertNull(NetworkConfigInput.dns("dns.example:"))
    }
    @Test fun ipv6RoundTripsWithAndWithoutPort() {
        for (text in listOf("2001:4860:4860::8888", "[2001:4860:4860::8888]:5353", "[::1]")) {
            val cfg = NetworkConfigInput.dns(text)!!
            assertEquals(cfg, NetworkConfigInput.dns(NetworkConfigInput.dnsText(cfg)))
        }
        assertNull(NetworkConfigInput.dns("[::1]:0"))
        assertNull(NetworkConfigInput.dns("[::1]garbage"))
    }
    @Test fun onlyHttpsWithoutCredentialsOrFragmentIsAcceptedAsDoh() {
        assertEquals("https://dns.example/dns-query", NetworkConfigInput.dns("https://dns.example/dns-query")!!.dohUrl)
        for (v in listOf("http://dns.example/dns-query", "https://user:pass@dns.example/dns-query", "https://dns.example/#x", "")) assertNull(NetworkConfigInput.dns(v))
    }
    @Test fun proxyRejectsInvalidEndpointsWithoutTouchingPassword() {
        assertNull(NetworkConfigInput.proxy("proxy.example/path", 8080, "", ""))
        assertNull(NetworkConfigInput.proxy("proxy.example", 0, "", ""))
        val cfg = NetworkConfigInput.proxy(" [::1] ", 3128, " user ", " secret ")!!
        assertEquals("::1", cfg.host); assertEquals(" secret ", cfg.password)
        assertEquals("user", cfg.username)
    }
    @Test fun locationsAllowPrivateHttpAndLocalFilesWithoutAcceptingOtherSchemes() {
        for (value in listOf("http://192.168.1.10:8080/list.m3u", "https://example.test/a?u=x&p=y", "/storage/USB/My list.m3u", "content://provider/document/12", "file:///storage/list.m3u"))
            assertTrue(value, NetworkConfigInput.sourceLocation(value))
        for (value in listOf("", "not a location", "ftp://example.test/list", "content:", "https://"))
            assertFalse(value, NetworkConfigInput.sourceLocation(value))
        assertFalse(NetworkConfigInput.sourceLocation("content://provider/document/12", allowLocal = false))
    }
}
