package tv.own.owntv.core.recording

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.model.RecordingFailure

class RecordingActionTest {
    @Test fun staleOwnerCannotStartAnOperation() = runBlocking {
        val result = runRecordingAction({ false }) { error("must not run") }
        assertEquals(RecordingActionResult.Superseded, result)
    }
    @Test fun operationSuccessAndSpecificRefusalsStayDistinct() = runBlocking {
        assertEquals(RecordingActionResult.Done, runRecordingAction({ true }) { RecordingFailure.NONE })
        for (reason in listOf(RecordingFailure.NO_SPACE, RecordingFailure.NO_CONNECTION, RecordingFailure.STORAGE_UNAVAILABLE))
            assertEquals(RecordingActionResult.Failed(reason), runRecordingAction({ true }) { reason })
    }
    @Test fun profileChangeDuringOperationSuppressesItsLateError() = runBlocking {
        var current = true
        assertEquals(RecordingActionResult.Superseded, runRecordingAction({ current }) {
            current = false; throw java.io.FileNotFoundException()
        })
    }
    @Test fun operationalExceptionsHaveConservativeReasons() = runBlocking {
        for ((error, reason) in listOf(java.io.FileNotFoundException() to RecordingFailure.STORAGE_UNAVAILABLE,
            SecurityException() to RecordingFailure.STORAGE_UNAVAILABLE,
            java.net.SocketTimeoutException() to RecordingFailure.NETWORK,
            java.io.IOException() to RecordingFailure.UNKNOWN,
            java.nio.file.FileSystemException("target", null, "ENOSPC") to RecordingFailure.NO_SPACE)) {
            val result = runRecordingAction({ true }) { throw error } as RecordingActionResult.Failed
            assertEquals(reason, result.reason)
            assertSame(error, result.cause)
        }
    }
    @Test fun cancellationIsNeverConvertedToRecordingFailure() = runBlocking {
        val cancelled = CancellationException("owner changed")
        try { runRecordingAction({ true }) { throw cancelled }; fail("Expected cancellation") }
        catch (caught: CancellationException) { assertSame(cancelled, caught) }
    }
    @Test fun unverifiableOwnerCannotStartOrPublishAnAction() = runBlocking {
        assertEquals(RecordingActionResult.Superseded, runRecordingAction({ throw java.io.IOException() }) {
            error("must not run")
        })
    }

}
