package tv.own.owntv.core.backup

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException

class BackupSubtitleAssetsTest {
    @get:Rule val folder = TemporaryFolder()
    @Test fun selectedAssetsCannotSilentlyDisappearOrExceedTheBudget() {
        val file = folder.newFile()
        for (asset in listOf(file, File(folder.root, "absent"))) {
            assertTrue(runCatching { readSubtitleBackupAsset(asset, 10) }.exceptionOrNull() is IOException)
        }
        file.writeBytes(byteArrayOf(1, 2, 3))
        assertTrue(runCatching { readSubtitleBackupAsset(file, 2) }.exceptionOrNull() is IOException)
        assertArrayEquals(byteArrayOf(1, 2, 3), readSubtitleBackupAsset(file, 3))
    }
}
