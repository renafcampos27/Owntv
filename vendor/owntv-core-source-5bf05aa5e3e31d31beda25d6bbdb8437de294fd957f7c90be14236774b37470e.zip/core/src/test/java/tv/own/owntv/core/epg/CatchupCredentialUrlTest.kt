package tv.own.owntv.core.epg

import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.parser.XtreamClient
import java.util.TimeZone

class CatchupCredentialUrlTest {
    private val start = 1_609_459_200_000L
    private val end = start + 3_600_000L
    private val utc = TimeZone.getTimeZone("UTC")
    private val client = XtreamClient(HttpClient(OkHttpClient()))
    private val identities = listOf("u&v", "u+v", "u%v", "u/v", "u?v", "u#v", "u%2Fv", "ação 空")

    private fun source(identity: String) = SourceEntity(
        name = "Test", type = SourceType.XTREAM, url = "https://example.test:8443/panel/",
        username = identity, password = "p:$identity",
    )

    private fun assertAccount(url: HttpUrl, source: SourceEntity) {
        assertEquals(source.username, url.queryParameter("username"))
        assertEquals(source.password, url.queryParameter("password"))
        assertEquals(listOf(source.username), url.queryParameterValues("username"))
        assertEquals(listOf(source.password), url.queryParameterValues("password"))
        assertEquals("123", url.queryParameter("stream"))
        assertEquals("60", url.queryParameter("duration"))
        assertEquals("2021-01-01:00-00", url.queryParameter("start"))
    }

    @Test fun archivePathToPhpPreservesLogicalCredentialsAndProviderSubdirectory() {
        for (identity in identities) {
            val source = source(identity)
            val path = client.timeshiftUrl(source, "123", start, 60, utc, "ts")
            val php = CatchupUrl.timeshiftPhpAlternate(path)!!.toHttpUrl()
            assertAccount(php, source)
            assertEquals("/panel/streaming/timeshift.php", php.encodedPath)
            assertEquals(8443, php.port)
            assertEquals(setOf("username", "password", "stream", "start", "duration"), php.queryParameterNames)
        }
    }

    @Test fun m3uXtreamAndXcPreserveLogicalCredentials() {
        for (identity in identities) {
            val source = source(identity).copy(url = "https://example.test:8443/")
            val live = client.liveUrl(source, "123").removeSuffix("ts") + "m3u8"
            for (type in listOf("xc", "xtream")) {
                val php = CatchupUrl.forM3u(live, type, null, start, end, utc)!!.toHttpUrl()
                assertAccount(php, source)
                assertEquals("/streaming/timeshift.php", php.encodedPath)
                assertEquals(8443, php.port)
            }
        }
    }

    @Test fun phpFallbackKeepsEncodedQueryTokensVerbatim() {
        val tokens = "token=a%2fb%26c%3Dd+e&token=second&flag&empty=&sig=%252F"
        val original = client.timeshiftUrl(source("u+v"), "123", start, 60, utc, "m3u8") + "?" + tokens
        val php = CatchupUrl.timeshiftPhpAlternate(original)!!.toHttpUrl()
        assertAccount(php, source("u+v"))
        assertTrue(php.encodedQuery!!.endsWith("&$tokens"))
        assertEquals(listOf("a/b&c=d e", "second"), php.queryParameterValues("token"))
        assertEquals("%2F", php.queryParameter("sig"))
    }

    @Test fun m3uXcKeepsExistingTokensIncludingForCompactLivePaths() {
        for (prefix in listOf("/live", "")) {
            val live = "https://example.test$prefix/u%2Bv/p%26q/123.ts?token=x%2Fy+z&token=second&flag"
            val php = CatchupUrl.forM3u(live, "xc", null, start, end, utc)!!.toHttpUrl()
            assertEquals("u+v", php.queryParameter("username"))
            assertEquals("p&q", php.queryParameter("password"))
            assertTrue(php.encodedQuery!!.endsWith("&token=x%2Fy+z&token=second&flag"))
        }
    }

    @Test fun formatFallbackUsesCorrectCredentialsAndKeepsStrictHlsPolicy() {
        val source = source("u+%2F&v")
        val original = client.timeshiftUrl(source, "123", start, 60, utc, "ts") + "?token=a%2Fb"
        val candidates = CatchupFormats.candidates(original, CatchupFormat.AUTO)
        assertEquals(3, candidates.size)
        assertAccount(candidates[1].toHttpUrl(), source)
        assertTrue(candidates[1].endsWith("&token=a%2Fb"))
        val hlsOnly = CatchupFormats.candidates(original, CatchupFormat.HLS)
        assertEquals(1, hlsOnly.size)
        assertTrue(hlsOnly.single().contains(".m3u8?token=a%2Fb"))
    }

    @Test fun m3uCorrectionAndProviderTimezoneAreAppliedExactlyOnce() {
        val live = "https://example.test/live/u%2Bv/p%26q/123.m3u8"
        val url = CatchupUrl.forM3u(live, "xc", null, start, end,
            TimeZone.getTimeZone("GMT+02:00"), correctionMin = 60)!!.toHttpUrl()
        assertEquals("2021-01-01:03-00", url.queryParameter("start"))
        assertEquals("60", url.queryParameter("duration"))
    }

    @Test fun unrecognizedAddressesDoNotAcquirePhpAlternatives() {
        for (url in listOf("file:///timeshift/u/p/60/start/123.ts", "https://example.test/live/u/p/123.ts",
            "https://example.test/timeshift/u/p/60/start/123.mp4", "not a url")) {
            assertNull(CatchupUrl.timeshiftPhpAlternate(url))
        }
    }
}
