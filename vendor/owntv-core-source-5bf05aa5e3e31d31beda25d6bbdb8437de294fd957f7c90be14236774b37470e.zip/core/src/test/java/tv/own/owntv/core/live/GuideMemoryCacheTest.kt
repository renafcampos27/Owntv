package tv.own.owntv.core.live

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.junit.Assert.*
import org.junit.Test

class GuideMemoryCacheTest {
    @Test fun leastRecentlyUsedIsEvictedWithoutChangingTheAnswer() {
        val cache = GuideMemoryCache<Int, List<Int>>(2, 100) { it.size.toLong() }
        val answer = listOf(1, 2, 3)
        cache[1] = answer; cache[2] = listOf(4)
        assertSame(answer, cache[1])
        cache[3] = listOf(5)
        assertNull(cache[2]); assertSame(answer, cache[1]); assertEquals(listOf(5), cache[3])
    }
    @Test fun weightBoundsRetentionAndOversizedAnswersAreNotTruncated() {
        val cache = GuideMemoryCache<Int, List<Int>>(20, 5) { it.size.toLong() }
        cache[1] = listOf(1, 2, 3); cache[2] = listOf(4, 5, 6)
        assertNull(cache[1]); assertEquals(3, cache.retainedWeight())
        val large = (1..100).toList(); cache[3] = large
        assertNull(cache[3]); assertEquals(100, large.size); assertEquals(1, cache.size())
    }
    @Test fun replacementRemovalAndClearReleaseTheWeight() {
        val cache = GuideMemoryCache<Int, Long>(2, Long.MAX_VALUE) { it }
        cache[1] = Long.MAX_VALUE; cache[1] = 1; cache[2] = Long.MAX_VALUE - 1
        assertEquals(Long.MAX_VALUE, cache.retainedWeight())
        cache.remove(2); assertEquals(1, cache.retainedWeight())
        cache.clear(); assertEquals(0, cache.size()); assertEquals(0, cache.retainedWeight())
    }
    @Test fun actualGuidePolicyInvalidatesSourceIdentityOffsetAndManualMatches() {
        val channel = tv.own.owntv.core.database.entity.ChannelEntity(id = 1, sourceId = 7,
            name = "Channel", streamUrl = "https://example.invalid/live", remoteId = "42", epgChannelId = "guide")
        val original = tv.own.owntv.core.customize.SectionCustomizations()
        val signature = guideCacheSignature(channel, original, 0)
        val key = tv.own.owntv.core.customize.CustomizeKeys.channel(channel)
        for (changed in listOf(channel.copy(sourceId = 8), channel.copy(remoteId = "43"),
            channel.copy(epgChannelId = "other"), channel.copy(streamUrl = "https://example.invalid/new"))) {
            assertNotEquals(signature, guideCacheSignature(changed, original, 0))
        }
        assertNotEquals(signature, guideCacheSignature(channel, original, 60))
        assertNotEquals(signature, guideCacheSignature(channel, original.copy(epgMatches = mapOf(key to "manual")), 0))
        assertNotEquals(signature, guideCacheSignature(channel, original.copy(epgFallbacks = mapOf(key to "fallback")), 0))
        assertEquals(signature, guideCacheSignature(channel, original.copy(epgShifts = mapOf(key to "0")), 60))
    }
    @Test fun concurrentReadsWritesAndInvalidationStayBounded() {
        val cache = GuideMemoryCache<Int, Long>(32, 100) { it }
        val pool = Executors.newFixedThreadPool(4)
        try {
            val work = (0..3).map { worker -> pool.submit {
                repeat(2000) { n ->
                    cache[worker * 2000 + n] = 4
                    cache[n]; if (n % 19 == 0) cache.remove(n); if (n % 97 == 0) cache.clear()
                    assertTrue(cache.size() <= 32); assertTrue(cache.retainedWeight() <= 100)
                }
            } }
            work.forEach { it.get(10, TimeUnit.SECONDS) }
        } finally { pool.shutdownNow() }
    }
    @Test fun textWeightUsesLongAndIncludesDescriptions() {
        assertEquals(266L, guideTextWeight("abc", "de"))
        assertEquals(256L, guideTextWeight("", null))
    }
}
