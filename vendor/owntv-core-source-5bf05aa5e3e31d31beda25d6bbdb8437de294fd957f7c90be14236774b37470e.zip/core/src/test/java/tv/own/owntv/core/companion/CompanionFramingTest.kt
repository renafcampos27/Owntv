package tv.own.owntv.core.companion

import org.junit.Assert.*
import org.junit.Test

class CompanionFramingTest {
    @Test fun invalidNegativeAndUnsupportedFramingCannotAllocateOrReadAnUnboundedBody() {
        for (headers in listOf(mapOf("content-length" to "-1"), mapOf("content-length" to "bad"),
            mapOf("content-length" to "3", "transfer-encoding" to "chunked"))) {
            assertNull(CompanionHttpProtocol.readBody("abc".byteInputStream().buffered(), headers, 16))
        }
        assertEquals("", CompanionHttpProtocol.readBody("abc".byteInputStream().buffered(), emptyMap(), 16))
        assertEquals("abc", CompanionHttpProtocol.readBody("abc".byteInputStream().buffered(), mapOf("content-length" to "3"), 16))
    }
}
