package tv.own.owntv.core.database

import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import java.io.File
import java.lang.reflect.Proxy
import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

/** Production schema healing exercised on SQLite, with deterministic partial-failure injection. */
class SearchSchemaRecoveryTest {
    private val entities get() = JSONObject(File("schemas/tv.own.owntv.core.database.OwnTVDatabase/51.json").readText())
        .getJSONObject("database").getJSONArray("entities")
    private fun sql(db: Connection, text: String) { db.createStatement().use { it.execute(text) } }
    private fun bootstrap(db: Connection) {
        val all = entities
        for (i in 0 until all.length()) {
            val e = all.getJSONObject(i); val table = e.getString("tableName")
            sql(db, e.getString("createSql").replace("\${TABLE_NAME}", table))
            val indices = e.optJSONArray("indices")
            if (indices != null) for (n in 0 until indices.length()) sql(db, indices.getJSONObject(n).getString("createSql").replace("\${TABLE_NAME}", table))
            val triggers = e.optJSONArray("contentSyncTriggers")
            if (triggers != null) for (n in 0 until triggers.length()) sql(db, triggers.getString(n))
        }
        // Room 2.8.5 configures this on writer connections in InvalidationTracker.configureConnection.
        sql(db, "PRAGMA recursive_triggers=1")
    }
    private fun database(block: (Connection) -> Unit) {
        Class.forName("org.sqlite.JDBC")
        DriverManager.getConnection("jdbc:sqlite::memory:").use { bootstrap(it); block(it) }
    }
    private fun hits(db: Connection, word: String): Int = db.prepareStatement("SELECT COUNT(*) FROM channels_fts WHERE channels_fts MATCH ?").use { q ->
        q.setString(1, word); q.executeQuery().use { r -> r.next(); r.getInt(1) }
    }
    private fun channel(db: Connection, name: String, replace: Boolean = false) = sql(db,
        "INSERT ${if (replace) "OR REPLACE" else ""} INTO channels (id,sourceId,name,streamUrl,sortOrder,catchup,catchupDays) VALUES (1,1,'$name','https://example.invalid',0,0,0)")
    private fun driver(connection: Connection, before: (String) -> Unit = {}): SQLiteConnection = Proxy.newProxyInstance(
        SQLiteConnection::class.java.classLoader, arrayOf(SQLiteConnection::class.java),
    ) { _, method, args ->
        when (method.name) {
            "prepare" -> {
                val sql = args!![0] as String
                before(sql)
                val stmt = connection.prepareStatement(sql)
                var executed = false
                var rows: ResultSet? = null
                Proxy.newProxyInstance(SQLiteStatement::class.java.classLoader, arrayOf(SQLiteStatement::class.java)) { _, m, a ->
                    when (m.name) {
                        "step" -> { if (!executed) { executed = true; if (stmt.execute()) rows = stmt.resultSet }; rows?.next() ?: false }
                        "getColumnNames" -> (1..stmt.metaData.columnCount).map { stmt.metaData.getColumnName(it) }
                        "getColumnCount" -> stmt.metaData.columnCount
                        "getColumnName" -> stmt.metaData.getColumnName((a!![0] as Int) + 1)
                        "getText" -> rows!!.getString((a!![0] as Int) + 1)
                        "getLong" -> rows!!.getLong((a!![0] as Int) + 1)
                        "getInt" -> rows!!.getInt((a!![0] as Int) + 1)
                        "bindText" -> { stmt.setString(a!![0] as Int, a[1] as String); null }
                        "close" -> { stmt.close(); null }
                        else -> error("Unsupported migration statement method: ${m.name}")
                    }
                }
            }
            "close" -> null
            else -> error("Unsupported migration connection method: ${method.name}")
        }
    } as SQLiteConnection

    @Test fun triggerContractMatchesAllCurrentRoomSchemaDefinitions() {
        val all = entities
        for (i in 0 until all.length()) {
            val e = all.getJSONObject(i); val exported = e.optJSONArray("contentSyncTriggers") ?: continue
            val expected = (0 until exported.length()).map { exported.getString(it) }.toSet()
            assertEquals(expected, FtsSchema.triggers.getValue(e.getString("tableName")).values.toSet())
        }
        assertEquals(16, FtsSchema.triggers.values.sumOf { it.size })
    }
    @Test fun healthyOpenDoesNotWriteSchemaOrRebuildSearch() = database { db ->
        assertFalse(OwnTVDatabase.healSchemaIfDrifted(driver(db) { statement ->
            assertTrue(statement.startsWith("SELECT"))
        }))
    }
    @Test fun missingTriggerIsRepairedAndUnindexedRowsAreRecovered() = database { db ->
        sql(db, "DROP TRIGGER room_fts_content_sync_channels_fts_AFTER_INSERT")
        channel(db, "original")
        assertEquals(0, hits(db, "original"))
        assertTrue(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
        assertEquals(1, hits(db, "original"))
        assertFalse(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
    }
    @Test fun malformedTriggerWithCorrectNameIsDetected() = database { db ->
        sql(db, "DROP TRIGGER room_fts_content_sync_channels_fts_AFTER_INSERT")
        sql(db, "CREATE TRIGGER room_fts_content_sync_channels_fts_AFTER_INSERT AFTER INSERT ON channels BEGIN SELECT 1; END")
        channel(db, "original")
        assertTrue(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
        assertEquals(1, hits(db, "original"))
    }
    @Test fun everyMissingTriggerIsRepairedIndependently() = database { db ->
        FtsSchema.triggers.values.flatMap { it.keys }.forEach { name ->
            sql(db, "DROP TRIGGER `$name`")
            assertTrue(name, OwnTVDatabase.healSchemaIfDrifted(driver(db)))
            assertFalse(name, OwnTVDatabase.healSchemaIfDrifted(driver(db)))
        }
    }
    @Test fun insertUpdateReplaceAndDeleteKeepSearchConsistentAfterRepair() = database { db ->
        sql(db, "DROP TRIGGER room_fts_content_sync_channels_fts_AFTER_UPDATE")
        OwnTVDatabase.healSchemaIfDrifted(driver(db))
        channel(db, "original"); assertEquals(1, hits(db, "original"))
        sql(db, "UPDATE channels SET name='updated' WHERE id=1")
        assertEquals(0, hits(db, "original")); assertEquals(1, hits(db, "updated"))
        channel(db, "replacement", replace = true)
        assertEquals(0, hits(db, "updated")); assertEquals(1, hits(db, "replacement"))
        sql(db, "DELETE FROM channels WHERE id=1"); assertEquals(0, hits(db, "replacement"))
    }
    @Test fun failedRepairRollsBackAndCanBeRetried() = database { db ->
        val names = FtsSchema.triggers.getValue("channels_fts").keys.toList()
        names.forEach { sql(db, "DROP TRIGGER `$it`") }
        var creates = 0
        try {
            OwnTVDatabase.healSchemaIfDrifted(driver(db) { statement ->
                if (statement.startsWith("CREATE TRIGGER") && ++creates == 3) error("synthetic failure")
            })
            fail("Expected injected failure")
        } catch (_: IllegalStateException) { }
        db.createStatement().use { q -> q.executeQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' AND tbl_name='channels'").use { r ->
            assertTrue(r.next()); assertEquals(0, r.getInt(1))
        } }
        assertTrue(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
        assertFalse(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
    }
    @Test fun repairFailureInsideOuterTransactionPreservesCallerWork() = database { db ->
        sql(db, "BEGIN")
        channel(db, "caller")
        sql(db, "DROP TRIGGER room_fts_content_sync_channels_fts_AFTER_UPDATE")
        try {
            OwnTVDatabase.healSchemaIfDrifted(driver(db) { if (it.startsWith("CREATE TRIGGER")) error("synthetic") })
            fail("Expected injected failure")
        } catch (_: IllegalStateException) { }
        sql(db, "COMMIT")
        assertEquals(1, hits(db, "caller"))
        assertTrue(OwnTVDatabase.healSchemaIfDrifted(driver(db)))
    }
}
