package tv.own.owntv.core.backup

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.settings.SettingsRepository
import tv.own.owntv.core.settings.SubtitleStyle
import tv.own.owntv.core.settings.StartupMode
import tv.own.owntv.core.settings.StartupChannelRef
import tv.own.owntv.core.model.MediaType

class CompleteTvSettingsBackupTest {
    @Test fun `output sync profiles and SDR survive repository backup without touching legacy HDR`() = runBlocking {
        val source = repository()
        source.setHdrEnabled(true)
        source.setPreferSdr(true)
        source.setAudioSyncOutput(tv.own.owntv.core.settings.AudioSyncOutput.BLUETOOTH)
        source.setOutputAudioDelay(tv.own.owntv.core.settings.AudioSyncOutput.HDMI, -75)
        source.setOutputAudioDelay(tv.own.owntv.core.settings.AudioSyncOutput.BLUETOOTH, 150)
        source.setAudioDelayMs(25)
        val wire = JSONObject(source.exportSettings().toString())
        val target = repository()
        target.importSettings(wire)
        assertTrue(target.hdrEnabled.first())
        assertTrue(target.preferSdr.first())
        assertEquals(tv.own.owntv.core.settings.AudioSyncOutput.BLUETOOTH, target.audioSyncOutput.first())
        assertEquals(-75, target.audioOutputDelays.first().hdmi)
        assertEquals(150, target.audioOutputDelays.first().bluetooth)
        assertEquals(25, target.audioDelayMs.first())
    }
    @Test fun `output sync zero defaults and bounded writes keep old playback unchanged`() = runBlocking {
        val repo = repository()
        assertTrue(repo.audioOutputDelays.first().isZero)
        assertFalse(repo.preferSdr.first())
        assertEquals(tv.own.owntv.core.settings.AudioSyncOutput.AUTO, repo.audioSyncOutput.first())
        for (output in tv.own.owntv.core.settings.AudioSyncOutput.entries.filter { it != tv.own.owntv.core.settings.AudioSyncOutput.AUTO }) {
            repo.setOutputAudioDelay(output, Int.MAX_VALUE)
            assertEquals(5000, repo.audioOutputDelays.first().forOutput(output))
            repo.setOutputAudioDelay(output, Int.MIN_VALUE)
            assertEquals(-5000, repo.audioOutputDelays.first().forOutput(output))
        }
    }
    @Test fun `invalid output corrections and route fail before any mutation`() = runBlocking {
        val repo = repository()
        for (bad in listOf(JSONObject().put("audio_delay_hdmi", 5001), JSONObject().put("audio_delay_usb", -5001),
            JSONObject().put("audio_sync_output", "SOUNDBAR_ADDRESS"), JSONObject().put("prefer_sdr", "true"))) {
            bad.put("hdr_enabled", true)
            try { repo.importSettings(bad); fail() } catch (_: IllegalArgumentException) { }
            assertFalse(repo.hdrEnabled.first())
        }
    }

    @Test fun `unmatched startup target cannot activate a remembered local target`() = runBlocking {
        val destination = repository()
        val previous = StartupChannelRef(9, "previous", "Previous", 99)
        destination.setStartupChannel(1, previous)
        destination.setStartupMode(1, StartupMode.HOME)
        val modes = JSONObject().put("8", StartupMode.SPECIFIC_CHANNEL.name)
        val channels = JSONObject().put("8", StartupChannelRef(4, "incoming", "Incoming", 123).toJson())
        val foreign = BackupRestoreIdentity(mapOf(8L to 1L), emptyMap())
        destination.importStartupModes(foreign.startupModes(modes, channels), setOf(1))
        destination.importStartupChannels(foreign.startupChannels(channels), setOf(1), emptyMap())
        assertEquals(StartupMode.HOME, destination.startupMode(1).first())
        assertEquals(previous, destination.startupChannel(1).first())
        assertEquals(2, foreign.skipped)
        val known = BackupRestoreIdentity(mapOf(8L to 1L), mapOf(4L to 9L))
        destination.importStartupModes(known.startupModes(modes, channels), setOf(1))
        destination.importStartupChannels(known.startupChannels(channels), setOf(1), mapOf(4L to 9L))
        assertEquals(StartupMode.SPECIFIC_CHANNEL, destination.startupMode(1).first())
        assertEquals(StartupChannelRef(9, "incoming", "Incoming", -1), destination.startupChannel(1).first())
    }
    @Test fun `explicit subtitle default and boundaries survive actual repository JSON roundtrip`() = runBlocking {
        for (opacity in listOf(SubtitleStyle.OPACITY_DEFAULT, 0, 100)) {
            val source = repository()
            source.setSubtitleBgOpacity(opacity)
            val wire = JSONObject(source.exportSettings().toString())
            assertEquals(opacity, wire.getInt("sub_bg_opacity"))
            val destination = repository()
            destination.setSubtitleBgOpacity(50)
            destination.importSettings(wire)
            assertEquals(opacity, destination.subtitleBgOpacity.first())
        }
    }
    @Test fun `invalid subtitle domains are rejected before any settings mutate`() = runBlocking {
        val destination = repository()
        destination.setHwDecoding(false)
        for (value in listOf(-2, 101)) {
            try { destination.importSettings(JSONObject().put("hw_decoding", true).put("sub_bg_opacity", value)); fail() }
            catch (_: IllegalArgumentException) { }
            assertFalse(destination.hwDecoding.first())
        }
    }
    @Test fun `recordings obey Live even when hidden Movies choice disagrees`() = runBlocking {
        val repository = repository()
        for (live in listOf(false, true)) for (movies in listOf(false, true)) {
            repository.setExternalPlayer(SettingsRepository.ExternalPlayerSection.LIVE_TV, live)
            repository.setExternalPlayer(SettingsRepository.ExternalPlayerSection.MOVIES, movies)
            repository.setExternalPlayer(SettingsRepository.ExternalPlayerSection.SERIES, !movies)
            assertEquals(live, repository.externalPlayerFor(MediaType.LIVE).first())
            assertEquals(movies, repository.externalPlayerFor(MediaType.MOVIE).first())
            assertEquals(!movies, repository.externalPlayerFor(MediaType.SERIES).first())
            assertEquals(movies, repository.externalPlayerFor(MediaType.EPISODE).first())
        }
    }
    @Test fun `selective restore never attaches foreign profile settings to an equal local counter`() = runBlocking {
        val destination = repository()
        destination.setStartupMode(1, StartupMode.LAST_CHANNEL)
        destination.setCustomizePin(1, "1234")
        val pin = destination.customizePin(1).first()
        // Different names/identities yield no resolved mapping, despite both databases having id 1.
        val identity = BackupRestoreIdentity(emptyMap(), emptyMap())
        destination.importStartupModes(identity.profileMap(JSONObject().put("1", StartupMode.HOME.name)), setOf(1))
        destination.importCustomizePins(identity.profileMap(JSONObject().put("1", "9999")), setOf(1))
        assertEquals(StartupMode.LAST_CHANNEL, destination.startupMode(1).first())
        assertEquals(pin, destination.customizePin(1).first())
        assertEquals(2, identity.skipped)
        val resolved = BackupRestoreIdentity(mapOf(8L to 1L), emptyMap())
        destination.importStartupModes(resolved.profileMap(JSONObject().put("8", StartupMode.HOME.name)), setOf(1))
        assertEquals(StartupMode.HOME, destination.startupMode(1).first())
    }
    private fun repository(): SettingsRepository {
        val prefs = InMemorySharedPreferences()
        val context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = prefs
        }
        return SettingsRepository(context, LocaleStore(prefs, null), InMemoryPreferencesDataStore())
    }

    @Test fun `explicit TV recording and multiview choices survive JSON round trip`() = runBlocking {
        val source = repository()
        source.setRecordingPreRollMinutes(4)
        source.setRecordingPostRollMinutes(9)
        source.setRecordingReserveConnection(false)
        source.setRecordWhatImWatching(true)
        source.setRecordingOverMobileData(false)
        source.setMultiviewEnabled(true)
        source.setMultiviewTiles(3)
        val wire = JSONObject(source.exportSettings().toString())
        val destination = repository()
        destination.importSettings(wire)
        assertEquals(4, destination.recordingPreRollMinutes.first())
        assertEquals(9, destination.recordingPostRollMinutes.first())
        assertFalse(destination.recordingReserveConnection.first())
        assertTrue(destination.recordWhatImWatching.first())
        assertFalse(destination.recordingOverMobileData.first())
        assertTrue(destination.multiviewEnabled.first())
        assertEquals(3, destination.multiviewTiles.first())
    }

    @Test fun `snapshot restores effective default hardware and clears implicit portable overrides only`() = runBlocking {
        val wire = JSONObject(repository().exportSettings().toString())
        assertTrue(wire.getBoolean("hw_decoding"))
        val destination = repository()
        destination.setHwDecoding(false)
        destination.setSoftwareAudio(true)
        destination.setProxyEnabled(true)
        destination.setDownloadRoot("device-specific-folder")
        destination.setActiveProfile(9)
        destination.importSettings(wire)
        assertTrue(destination.hwDecoding.first())
        assertFalse(destination.softwareAudio.first())
        assertFalse(destination.proxyConfig.first().enabled)
        assertEquals("device-specific-folder", destination.downloadRoot.first())
        assertEquals(9L, destination.activeProfileId.first())
    }

    @Test fun `legacy backup is still a partial merge`() = runBlocking {
        val destination = repository()
        destination.setHwDecoding(false)
        destination.setRecordingPreRollMinutes(4)
        destination.importSettings(JSONObject().put("hdr_enabled", false))
        assertFalse(destination.hwDecoding.first())
        assertEquals(4, destination.recordingPreRollMinutes.first())
    }

    @Test fun `invalid snapshot and recording ranges are rejected before mutation`() = runBlocking {
        val destination = repository()
        destination.setHwDecoding(false)
        for (wire in listOf(
            JSONObject().put("hw_decoding", true).put("recording_pre_roll_minutes", 9999),
            JSONObject().put("hw_decoding", true).put("multiview_tiles", 0),
            JSONObject().put("hw_decoding", true).put("portableSettingsSnapshotVersion", 1)
                .put("unsetPortableKeys", JSONArray(listOf("download_root"))))) {
            try { destination.importSettings(wire); fail("accepted invalid settings") }
            catch (_: IllegalArgumentException) { }
            assertFalse(destination.hwDecoding.first())
        }
    }
    private class InMemorySharedPreferences : SharedPreferences {
        private val data = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = HashMap(data)
        override fun getString(key: String?, defValue: String?): String? = data[key] as? String ?: defValue
        @Suppress("UNCHECKED_CAST")
        override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? =
            (data[key] as? Set<String>)?.toMutableSet() ?: defValues
        override fun getInt(key: String?, defValue: Int): Int = data[key] as? Int ?: defValue
        override fun getLong(key: String?, defValue: Long): Long = data[key] as? Long ?: defValue
        override fun getFloat(key: String?, defValue: Float): Float = data[key] as? Float ?: defValue
        override fun getBoolean(key: String?, defValue: Boolean): Boolean = data[key] as? Boolean ?: defValue
        override fun contains(key: String?): Boolean = data.containsKey(key)
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            private val edits = HashMap<String, Any?>()
            private var clearAll = false
            override fun putString(key: String, value: String?): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor = apply { edits[key] = values }
            override fun putInt(key: String, value: Int): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putLong(key: String, value: Long): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putFloat(key: String, value: Float): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor = apply { edits[key] = value }
            override fun remove(key: String): SharedPreferences.Editor = apply { edits[key] = null }
            override fun clear(): SharedPreferences.Editor = apply { clearAll = true }
            override fun commit(): Boolean {
                if (clearAll) data.clear()
                edits.forEach { (k, v) -> if (v == null) data.remove(k) else data[k] = v }
                return true
            }
            override fun apply() { commit() }
        }
        override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
    }

    private class InMemoryPreferencesDataStore : DataStore<Preferences> {
        private val mutex = Mutex()
        private val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (t: Preferences) -> Preferences): Preferences =
            mutex.withLock {
                val updated = transform(state.value)
                state.value = updated
                updated
            }
    }

}
