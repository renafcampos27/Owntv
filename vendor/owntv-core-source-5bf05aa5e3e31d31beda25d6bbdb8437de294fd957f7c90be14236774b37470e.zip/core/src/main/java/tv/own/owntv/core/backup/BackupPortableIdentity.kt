package tv.own.owntv.core.backup

import org.json.JSONArray
import org.json.JSONObject
import tv.own.owntv.core.database.entity.ProfileEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.stalker.StalkerClient
import tv.own.owntv.core.util.Pin
import java.io.IOException
import java.security.MessageDigest
import kotlinx.coroutines.CancellationException

/** Portable matching metadata, never a reusable URL, login, password or MAC. */
internal object BackupPortableIdentity {
    fun fingerprint(source: SourceEntity): String {
        val mac = if (source.type == SourceType.STALKER) source.mac?.takeIf { it.isNotBlank() }
            ?.let { StalkerClient.canonicalizeMac(it) ?: it.trim().uppercase() }.orEmpty() else ""
        val fields = listOf(source.type.name, source.url.trim(), source.username.orEmpty(), mac)
        val bytes = fields.joinToString("") { "${it.length}:$it" }.toByteArray(Charsets.UTF_8)
        return MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    }

    fun export(sources: List<SourceEntity>): JSONArray = JSONArray().apply {
        sources.forEach { put(JSONObject().put("id", it.id).put("fingerprint", fingerprint(it))) }
    }

    /** Only unique claims on BOTH sides establish identity. Duplicate IDs are invalid input. */
    fun resolve(input: JSONArray?, candidates: List<SourceEntity>): Map<Long, Long> {
        if (input == null) return emptyMap()
        val rows = (0 until input.length()).map { input.getJSONObject(it) }
        require(rows.map { it.getLong("id") }.distinct().size == rows.size) { "Duplicate backup source identity" }
        val incomingCounts = rows.groupingBy { it.getString("fingerprint") }.eachCount()
        val device = candidates.groupBy(::fingerprint)
        return buildMap {
            rows.forEach { row ->
                val key = row.getString("fingerprint")
                require(key.matches(Regex("[0-9a-f]{64}"))) { "Invalid backup source identity" }
                if (incomingCounts[key] == 1) device[key]?.singleOrNull()?.let { put(row.getLong("id"), it.id) }
            }
        }
    }

    fun uniqueProfile(candidates: List<ProfileEntity>, incoming: ProfileEntity): ProfileEntity? =
        candidates.filter { profileMatchKey(it.name) == profileMatchKey(incoming.name) }.singleOrNull()
}

/** Default restore never changes an existing viewer's protection, even from a trusted backup. */
internal object BackupProfileProtection {
    fun changes(existing: ProfileEntity, incoming: ProfileEntity): Boolean =
        existing.isKids != incoming.isKids || (incoming.pinHash != null && incoming.pinHash != existing.pinHash)

    fun apply(existing: ProfileEntity, incoming: ProfileEntity, pins: Map<Long, String>): ProfileEntity {
        if (!pins.containsKey(existing.id)) return incoming.copy(isKids = existing.isKids, pinHash = existing.pinHash)
        if (!Pin.verify(pins.getValue(existing.id), existing.pinHash, scope = Pin.profileScope(existing.id)))
            throw BackupManager.ProfileProtectionAuthorizationException()
        return incoming.copy(pinHash = incoming.pinHash ?: existing.pinHash)
    }
}

/** A selected mandatory section is either readable or export fails before publishing the file. */
internal suspend fun <T> readRequiredBackupSection(name: String, read: suspend () -> T): T = try {
    read()
} catch (cancelled: CancellationException) {
    throw cancelled
} catch (failed: Exception) {
    throw IOException("Unable to read selected backup section: $name", failed)
}

internal fun validateBackupFileName(name: String) {
    require(name.length in 5..180 && name.endsWith(".own", ignoreCase = true) &&
        name !in setOf(".", "..") && name.none { it in "/\\:\u0000" || it.code < 32 } &&
        !name.contains("..") && name.none { it in "*?\"<>|" }) { "Invalid backup filename" }
}

/** URLs and usernames can be credentials too; a complete export is never a plaintext metadata ZIP. */
internal fun requireBackupExportPassphrase(password: String?): String {
    require(!password.isNullOrBlank()) { "A complete backup requires encryption" }
    return password
}

/** Authentication failure asks for a password again; malformed metadata and I/O keep their identity. */
internal inline fun <T> authenticateBackupFields(read: () -> T): T = try {
    read()
} catch (_: javax.crypto.AEADBadTagException) {
    throw BackupManager.WrongPasswordException()
}
