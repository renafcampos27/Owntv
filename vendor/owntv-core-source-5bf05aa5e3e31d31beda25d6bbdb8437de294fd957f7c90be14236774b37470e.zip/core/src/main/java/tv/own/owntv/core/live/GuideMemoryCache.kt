package tv.own.owntv.core.live

/** Retains complete answers only. Eviction never cancels a shared request or trims programmes. */
internal class GuideMemoryCache<K, V>(
    private val maximumSize: Int,
    private val maximumWeight: Long,
    private val weigh: (V) -> Long,
) {
    private data class Entry<V>(val value: V, val weight: Long)
    private val entries = LinkedHashMap<K, Entry<V>>(16, 0.75f, true)
    private var weight = 0L

    init { require(maximumSize > 0 && maximumWeight > 0) }

    @Synchronized operator fun get(key: K): V? = entries[key]?.value

    @Synchronized operator fun set(key: K, value: V) {
        val cost = weigh(value).coerceAtLeast(1)
        remove(key)
        // A very large result is still returned by its caller; retaining it is optional.
        if (cost > maximumWeight) return
        val iterator = entries.entries.iterator()
        while (iterator.hasNext() && (entries.size >= maximumSize || weight > maximumWeight - cost)) {
            weight -= iterator.next().value.weight
            iterator.remove()
        }
        entries[key] = Entry(value, cost)
        weight += cost
    }

    @Synchronized fun remove(key: K) { entries.remove(key)?.let { weight -= it.weight } }
    @Synchronized fun clear() { entries.clear(); weight = 0 }
    @Synchronized internal fun size(): Int = entries.size
    @Synchronized internal fun retainedWeight(): Long = weight
}

/** Conservative retention weight, not a measurement of the JVM heap or shared string ownership. */
internal fun guideTextWeight(title: String, description: String?): Long =
    256L + 2L * title.length + 2L * (description?.length ?: 0)
