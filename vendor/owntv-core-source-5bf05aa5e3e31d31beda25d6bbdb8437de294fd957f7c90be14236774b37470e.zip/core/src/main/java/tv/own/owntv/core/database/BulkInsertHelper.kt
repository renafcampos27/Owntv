package tv.own.owntv.core.database

import android.os.SystemClock
import android.util.Log
import androidx.room.execSQL
import androidx.room.immediateTransaction
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import androidx.room.useWriterConnection
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class BulkInsertHelper(
    private val db: OwnTVDatabase,
) {
    /** Writers currently inside [withOptimizedBulkInsert] for one table, plus its active bulk mode. */
    private class TableBulkState {
        var writers = 0
        var dropped: BulkIndexState? = null
        var ftsOnly = false
    }

    private val tableStates = HashMap<String, TableBulkState>()

    suspend fun <T> withOptimizedBulkInsert(
        table: String,
        ftsTable: String? = null,
        eligible: Boolean,
        ftsOnly: Boolean = false,
        block: suspend () -> T,
    ): T {
        // Register as a writer on this table. The FIRST eligible writer on an empty table drops the
        // indexes/FTS trigger; anyone arriving while that mode is active — eligible or not — joins
        // the writer count instead of racing it, so the restore below can never run while another
        // sync is still inserting. (The old shape checked tableIsEmpty BEFORE taking the lock, so a
        // second source could bypass the mode once the first had inserted rows, then collide with
        // its restore — the truncated-movies/skipped-series concurrent-sync bug.) block() runs
        // OUTSIDE the lock, so concurrent syncs fetch/parse/insert in parallel.
        requireKnownTable(table)
        if (ftsTable != null) require(ftsTable in KNOWN_FTS && ftsTable.removeSuffix("_fts") == table)
        stateMutex.withLock {
            // Registration and committed DDL cannot be separated by cancellation. The transaction
            // rolls back a partial DROP; the retained state survives a failed restore for retry.
            withContext(NonCancellable) {
                val state = tableStates.getOrPut(table) { TableBulkState() }
                if (state.writers == 0 && state.dropped != null) {
                    restoreIndexes(checkNotNull(state.dropped), state.ftsOnly)
                    state.dropped = null
                }
                if (eligible && state.writers == 0 && state.dropped == null && tableIsEmpty(table)) {
                    state.dropped = dropIndexesForBulkInsert(table, ftsTable, ftsOnly)
                    state.ftsOnly = ftsOnly
                }
                state.writers++
            }
        }
        var failure: Throwable? = null
        try {
            currentCoroutineContext().ensureActive()
            return block()
        } catch (caught: Throwable) {
            failure = caught
            throw caught
        } finally {
            try {
                withContext(NonCancellable) {
                    stateMutex.withLock {
                        val state = tableStates.getValue(table)
                        state.writers--
                        if (state.writers == 0 && state.dropped != null) {
                            restoreIndexes(checkNotNull(state.dropped), state.ftsOnly)
                            state.dropped = null
                        }
                    }
                }
            } catch (cleanup: Throwable) {
                if (failure != null) failure.addSuppressed(cleanup) else throw cleanup
            }
        }
    }

    suspend fun analyzeTables(vararg tables: String) {
        tables.forEach { requireKnownAnalyzeTable(it) }
        db.useWriterConnection { connection ->
            tables.forEach { connection.execSQL("ANALYZE `$it`") }
        }
    }

    suspend fun tableIsEmpty(table: String): Boolean {
        requireKnownTable(table)
        return db.useWriterConnection { connection ->
            connection.usePrepared("SELECT COUNT(*) FROM `$table`") { it.step() && it.getLong(0) == 0L }
        }
    }

    private suspend fun dropIndexesForBulkInsert(table: String, ftsTable: String?, ftsOnly: Boolean): BulkIndexState {
        requireKnownTable(table)
        if (ftsTable != null) requireKnownFtsTable(ftsTable)

        val state = BulkIndexState(table, ftsTable)
        db.useWriterConnection { connection ->
            connection.immediateTransaction {
                // Only retire indexes in our canonical contract. Unknown/user indexes stay intact.
                if (!ftsOnly) {
                    OwnTVDatabase.EXPECTED_NON_UNIQUE_INDEXES.getValue(table).forEach { sql ->
                        val name = sql.substringAfter("IF NOT EXISTS `").substringBefore('`')
                        connection.execSQL("DROP INDEX IF EXISTS `$name`")
                    }
                }
                if (ftsTable != null) {
                    val name = "room_fts_content_sync_${ftsTable}_AFTER_INSERT"
                    connection.execSQL("DROP TRIGGER IF EXISTS `$name`")
                }
            }
        }
        return state
    }

    private suspend fun restoreIndexes(state: BulkIndexState, ftsOnly: Boolean = false) {
        val start = SystemClock.elapsedRealtime()
        val canonical = OwnTVDatabase.EXPECTED_NON_UNIQUE_INDEXES.getValue(state.table)
        db.useWriterConnection { connection ->
            connection.immediateTransaction {
                if (!ftsOnly) canonical.forEach { connection.execSQL(it) }
                if (state.ftsTable != null) {
                    FtsSchema.triggers.getValue(state.ftsTable).forEach { (name, sql) ->
                        val actual = connection.usePrepared("SELECT sql FROM sqlite_master WHERE type='trigger' AND name=?") { q ->
                            q.bindText(1, name)
                            if (q.step()) q.getText(0) else null
                        }
                        if (!FtsSchema.matches(actual, sql)) {
                            connection.execSQL("DROP TRIGGER IF EXISTS `$name`")
                            connection.execSQL(sql)
                        }
                    }
                    connection.execSQL("INSERT INTO `${state.ftsTable}`(`${state.ftsTable}`) VALUES('rebuild')")
                }
            }
        }
        Log.i(TAG, "Bulk search contract restored table=${state.table} ftsOnly=$ftsOnly ms=${SystemClock.elapsedRealtime() - start}")
    }

    private fun requireKnownTable(table: String) {
        require(table in KNOWN_TABLES) { "Unknown table: $table" }
    }

    private fun requireKnownAnalyzeTable(table: String) {
        require(table in KNOWN_ANALYZE_TABLES) { "Unknown table: $table" }
    }

    private fun requireKnownFtsTable(ftsTable: String) {
        require(ftsTable in KNOWN_FTS) { "Unknown FTS table: $ftsTable" }
    }

    private data class BulkIndexState(
        val table: String,
        val ftsTable: String?,
    )

    companion object {
        const val CHUNK = 5_000
        const val CHUNK_FRESH = 10_000

        private const val TAG = "BulkInsertHelper"
        // Derived, never hand-maintained: restoreIndexes() rebuilds a table from its canonical
        // entry in EXPECTED_NON_UNIQUE_INDEXES, so a table that is bulk-droppable but missing from
        // that map would have its indexes dropped and never restored — silently, until the next
        // migration's schema validation crash-loops the app on upgrade (the 4.1.0 failure mode).
        // Deriving the set makes that combination impossible to express.
        internal val KNOWN_TABLES: Set<String> get() = OwnTVDatabase.EXPECTED_NON_UNIQUE_INDEXES.keys
        // Deliberately wider than KNOWN_TABLES: these are analyzed but never bulk-dropped.
        private val KNOWN_ANALYZE_TABLES: Set<String> get() = KNOWN_TABLES + setOf("categories", "epg_channels")
        private val KNOWN_FTS = setOf("channels_fts", "movies_fts", "series_fts")

        // One app-wide lock for bulk-mode state + index/FTS DDL — held only for the short state
        // transitions (and the last writer's restore), never across a sync's insert loop.
        private val stateMutex = Mutex()
    }
}
