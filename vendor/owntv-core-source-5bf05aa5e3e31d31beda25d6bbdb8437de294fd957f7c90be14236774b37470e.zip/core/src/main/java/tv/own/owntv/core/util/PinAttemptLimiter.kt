package tv.own.owntv.core.util

import java.io.File
import java.util.Properties

/** Per-credential attempts shared by every gate; elapsed time governs an active process. */
internal class PinAttemptLimiter(
    private val file: File? = null,
    private val wall: () -> Long = System::currentTimeMillis,
    private val elapsed: () -> Long = { System.nanoTime() / 1_000_000L },
) {
    private data class Entry(val failures: Int, val until: Long)
    private val entries = LinkedHashMap<String, Entry>()
    private var damagedUntil = 0L
    init {
        val saved = file
        if (saved != null && saved.exists()) {
            runCatching {
                check(saved.length() <= 64 * 1024)
                val properties = Properties().apply { saved.inputStream().use { load(it) } }
                check(properties.size <= 128)
                properties.forEach { key, raw ->
                    check(key.toString().matches(Regex("[0-9a-f]{64}")))
                    val parts = raw.toString().split(',')
                    val failures = parts[0].toInt().coerceIn(0, 20)
                    val deadline = parts[1].toLong()
                    val savedWall = parts[2].toLong()
                    val remaining = if (deadline == 0L) 0L else if (wall() < savedWall) MAX_DELAY else (deadline - wall()).coerceIn(0, MAX_DELAY)
                    entries[key.toString()] = Entry(failures, elapsed() + remaining)
                }
            }.onFailure { entries.clear(); damagedUntil = elapsed() + MAX_DELAY }
        }
    }

    @Synchronized fun verify(key: String, verify: () -> Boolean): Boolean {
        val now = elapsed()
        if (now < damagedUntil) return false
        val previous = entries[key]
        if (previous != null && now < previous.until) return false
        val valid = verify()
        if (valid) entries.remove(key) else {
            val failures = ((previous?.failures ?: 0) + 1).coerceAtMost(20)
            val delay = if (failures < 5) 0L else (10_000L shl (failures - 5).coerceAtMost(5)).coerceAtMost(MAX_DELAY)
            if (!entries.containsKey(key) && entries.size >= 128) throw java.io.IOException("PIN attempt store capacity reached")
            entries[key] = Entry(failures, now + delay)
        }
        persist()
        return valid
    }

    @Synchronized fun remainingSeconds(key: String): Int =
        ((maxOf(damagedUntil, entries[key]?.until ?: 0L) - elapsed()).coerceAtLeast(0) + 999L).div(1000L).toInt()

    private fun persist() {
        val target = file ?: return
        target.parentFile?.mkdirs()
        val properties = Properties()
        val wallNow = wall()
        entries.forEach { (key, entry) ->
            val remaining = (entry.until - elapsed()).coerceIn(0, MAX_DELAY)
            properties[key] = "${entry.failures},${if (remaining == 0L) 0L else wallNow + remaining},$wallNow"
        }
        val staged = File(target.parentFile, target.name + ".tmp")
        try {
            staged.outputStream().use { output -> properties.store(output, null); output.fd.sync() }
            java.nio.file.Files.move(staged.toPath(), target.toPath(), java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        } finally { staged.delete() }
    }

    companion object { private const val MAX_DELAY = 300_000L }
}
