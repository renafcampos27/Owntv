package tv.own.owntv.core.settings

/** Output families, not device addresses: portable and never stored as hardware identifiers. */
enum class AudioSyncOutput { AUTO, HDMI, BLUETOOTH, WIRED, USB, SPEAKER }

data class AudioOutputDelays(
    val hdmi: Int = 0, val bluetooth: Int = 0, val wired: Int = 0,
    val usb: Int = 0, val speaker: Int = 0,
) {
    val isZero: Boolean get() = hdmi == 0 && bluetooth == 0 && wired == 0 && usb == 0 && speaker == 0
    fun forOutput(output: AudioSyncOutput): Int = when (output) {
        AudioSyncOutput.AUTO -> 0
        AudioSyncOutput.HDMI -> hdmi
        AudioSyncOutput.BLUETOOTH -> bluetooth
        AudioSyncOutput.WIRED -> wired
        AudioSyncOutput.USB -> usb
        AudioSyncOutput.SPEAKER -> speaker
    }
    companion object {
        fun effective(base: Int, output: Int): Int = (base.toLong() + output).coerceIn(-5_000, 5_000).toInt()
    }
}
