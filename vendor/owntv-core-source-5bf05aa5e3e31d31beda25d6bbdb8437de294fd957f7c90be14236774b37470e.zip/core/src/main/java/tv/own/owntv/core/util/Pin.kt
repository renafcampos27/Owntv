package tv.own.owntv.core.util

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

/**
 * Versioned PIN hashes and a common attempt authority. Legacy salted SHA-256 remains readable;
 * successful authentication can upgrade it without requiring a new PIN or rewriting backups.
 */
object Pin {
    const val DEFAULT_SCOPE = "credential"
    fun profileScope(id: Long): String = "profile:$id"
    fun customizationScope(id: Long): String = "customize:$id"
    @Volatile private var attempts = PinAttemptLimiter()
    private val upgrades = java.util.concurrent.ConcurrentHashMap<String, String>()

    fun configureAttemptStorage(file: java.io.File) { attempts = PinAttemptLimiter(file) }

    fun isHash(value: String): Boolean {
        if (value.matches(Regex("[0-9a-fA-F]{16}:[0-9a-fA-F]{64}"))) return true
        return value.matches(Regex("pbkdf2-sha256:[0-9]{5,6}:[0-9a-fA-F]{32}:[0-9a-fA-F]{64}")) &&
            value.split(':')[1].toIntOrNull() in 10_000..600_000
    }

    fun hash(pin: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        return "pbkdf2-sha256:120000:${salt.toHex()}:${derive(pin, salt, 120_000).toHex()}"
    }

    fun verify(pin: String, stored: String?, allowLegacyPlaintext: Boolean = false, scope: String = DEFAULT_SCOPE): Boolean {
        if (stored.isNullOrBlank()) return true // no PIN set
        val key = credentialKey(scope, stored)
        val valid = runCatching { attempts.verify(key) { verifyValue(pin, stored, allowLegacyPlaintext) } }.getOrDefault(false)
        if (valid && !stored.startsWith("pbkdf2-sha256:")) {
            if (upgrades.size >= 32) upgrades.clear()
            upgrades.computeIfAbsent(stored) { hash(pin) }
        }
        return valid
    }

    fun upgradedHash(stored: String?): String? = stored?.let { upgrades[it] }

    fun remainingLockSeconds(stored: String?, scope: String = DEFAULT_SCOPE): Int = stored?.let {
        attempts.remainingSeconds(credentialKey(scope, it))
    } ?: 0

    private fun verifyValue(pin: String, stored: String, allowLegacyPlaintext: Boolean): Boolean = runCatching {
        val parts = stored.split(':')
        val actual = when {
            parts.size == 4 && parts[0] == "pbkdf2-sha256" -> {
                val iterations = parts[1].toInt()
                check(iterations in 10_000..600_000 && parts[2].length == 32 && parts[3].length == 64)
                val salt = requireNotNull(parts[2].fromHex())
                derive(pin, salt, iterations).toHex()
            }
            parts.size == 2 && parts[0].length == 16 && parts[1].length == 64 -> digest(requireNotNull(parts[0].fromHex()), pin)
            allowLegacyPlaintext && stored.length in 4..12 && stored.all(Char::isDigit) -> pin
            else -> throw IllegalArgumentException()
        }
        MessageDigest.isEqual(actual.lowercase(Locale.ROOT).toByteArray(), parts.last().lowercase(Locale.ROOT).toByteArray())
    }.getOrDefault(false)

    private fun credentialKey(scope: String, stored: String): String =
        MessageDigest.getInstance("SHA-256").digest("${scope.length}:$scope$stored".toByteArray()).toHex()

    private fun derive(pin: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        return try { javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun digest(salt: ByteArray, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(salt + pin.toByteArray()).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(Locale.ROOT, it) }

    private fun String.fromHex(): ByteArray? = runCatching {
        chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }.getOrNull()
}
