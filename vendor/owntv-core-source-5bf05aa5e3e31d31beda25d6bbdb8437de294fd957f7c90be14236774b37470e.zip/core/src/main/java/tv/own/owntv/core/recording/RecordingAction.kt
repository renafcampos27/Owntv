package tv.own.owntv.core.recording

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import tv.own.owntv.core.model.RecordingFailure

sealed interface RecordingActionResult {
    data object Done : RecordingActionResult
    data object Superseded : RecordingActionResult
    data class Failed(val reason: RecordingFailure, val cause: Exception? = null) : RecordingActionResult
}

data class RecordingActionNotice(val profileId: Long, val reason: RecordingFailure)

/** Operational errors become actionable data; cancellation and stale owners are never failures. */
suspend fun runRecordingAction(
    isCurrent: suspend () -> Boolean,
    operation: suspend () -> RecordingFailure,
): RecordingActionResult {
    suspend fun current(): Boolean = try { isCurrent() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { false }
    if (!current()) return RecordingActionResult.Superseded
    var cause: Exception? = null
    val reason = try {
        operation()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (error: Exception) {
        cause = error
        when (error) {
            is java.nio.file.NoSuchFileException, is java.io.FileNotFoundException,
            is SecurityException -> RecordingFailure.STORAGE_UNAVAILABLE
            is java.nio.file.FileSystemException -> if (error.reason?.contains("ENOSPC", ignoreCase = true) == true)
                RecordingFailure.NO_SPACE else RecordingFailure.UNKNOWN
            is java.net.SocketException, is java.net.SocketTimeoutException,
            is java.net.UnknownHostException -> RecordingFailure.NETWORK
            else -> RecordingFailure.UNKNOWN
        }
    }
    currentCoroutineContext().ensureActive()
    if (!current()) return RecordingActionResult.Superseded
    return if (reason == RecordingFailure.NONE) RecordingActionResult.Done else RecordingActionResult.Failed(reason, cause)
}
