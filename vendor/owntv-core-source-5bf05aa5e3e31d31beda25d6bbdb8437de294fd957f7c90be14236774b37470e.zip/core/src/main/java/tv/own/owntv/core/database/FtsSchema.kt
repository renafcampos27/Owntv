package tv.own.owntv.core.database

import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import java.util.Locale

/** Room's four external-content FTS4 triggers, generated from the current schema contract. */
internal object FtsSchema {
    val triggers: Map<String, Map<String, String>> = OwnTVDatabase.EXPECTED_FTS_TABLES.keys.associateWith { fts ->
        val content = fts.removeSuffix("_fts")
        val prefix = "room_fts_content_sync_${fts}_"
        linkedMapOf(
            prefix + "BEFORE_UPDATE" to "CREATE TRIGGER IF NOT EXISTS ${prefix}BEFORE_UPDATE BEFORE UPDATE ON `$content` BEGIN DELETE FROM `$fts` WHERE `docid`=OLD.`rowid`; END",
            prefix + "BEFORE_DELETE" to "CREATE TRIGGER IF NOT EXISTS ${prefix}BEFORE_DELETE BEFORE DELETE ON `$content` BEGIN DELETE FROM `$fts` WHERE `docid`=OLD.`rowid`; END",
            prefix + "AFTER_UPDATE" to "CREATE TRIGGER IF NOT EXISTS ${prefix}AFTER_UPDATE AFTER UPDATE ON `$content` BEGIN INSERT INTO `$fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END",
            prefix + "AFTER_INSERT" to "CREATE TRIGGER IF NOT EXISTS ${prefix}AFTER_INSERT AFTER INSERT ON `$content` BEGIN INSERT INTO `$fts`(`docid`, `name`) VALUES (NEW.`rowid`, NEW.`name`); END",
        )
    }
    private val spaces = Regex("\\s+")
    private fun normalized(sql: String): String = spaces.replace(sql, " ").trim().trimEnd(';')
        .uppercase(Locale.ROOT).replace("IF NOT EXISTS ", "")

    fun matches(actual: String?, expected: String): Boolean = actual != null && normalized(actual) == normalized(expected)

    /** Called inside the schema repair savepoint. Rebuild only tables whose contract changed. */
    fun repair(db: SQLiteConnection, alreadyRebuilt: Set<String>) {
        triggers.forEach { (fts, expected) ->
            var changed = false
            expected.forEach { (name, sql) ->
                val actual = db.prepare("SELECT sql FROM sqlite_master WHERE type='trigger' AND name=?").use { q ->
                    q.bindText(1, name)
                    if (q.step()) q.getText(0) else null
                }
                if (!matches(actual, sql)) {
                    db.execSQL("DROP TRIGGER IF EXISTS `$name`")
                    db.execSQL(sql)
                    changed = true
                }
            }
            if (changed && fts !in alreadyRebuilt) db.execSQL("INSERT INTO `$fts`(`$fts`) VALUES('rebuild')")
        }
    }
}
