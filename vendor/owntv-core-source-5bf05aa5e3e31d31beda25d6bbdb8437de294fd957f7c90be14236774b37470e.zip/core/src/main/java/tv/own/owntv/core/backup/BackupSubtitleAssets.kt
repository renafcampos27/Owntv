package tv.own.owntv.core.backup

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException

/** A selected asset must fit and exist before the complete backup can be published. */
internal fun readSubtitleBackupAsset(file: File, budget: Long): ByteArray {
    if (!file.isFile || file.length() !in 1..budget) throw IOException("Subtitle asset unavailable or over budget")
    return file.inputStream().use { input ->
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (output.size().toLong() + count > budget) throw IOException("Subtitle asset exceeds backup budget")
            output.write(buffer, 0, count)
        }
        if (output.size() == 0) throw IOException("Subtitle asset is empty")
        output.toByteArray()
    }
}
