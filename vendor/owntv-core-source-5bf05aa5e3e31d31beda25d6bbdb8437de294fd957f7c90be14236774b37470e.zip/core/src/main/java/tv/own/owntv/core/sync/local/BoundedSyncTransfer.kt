package tv.own.owntv.core.sync.local

import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

internal fun copyBoundedSync(input: InputStream, output: OutputStream, maximum: Long, declared: Long = -1): Long {
    if (declared > maximum) throw IOException("Local sync payload exceeds limit")
    var total = 0L
    val buffer = ByteArray(8192)
    while (true) {
        val read = input.read(buffer)
        if (read < 0) break
        total += read
        if (total > maximum) throw IOException("Local sync payload exceeds limit")
        output.write(buffer, 0, read)
    }
    if (declared >= 0 && total != declared) throw EOFException("Local sync payload length mismatch")
    return total
}
