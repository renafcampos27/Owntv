package tv.own.owntv.core.network

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Pure validation shared by settings Save/Test; it never resolves a host or rewrites secrets. */
object NetworkConfigInput {
    fun host(value: String): String? {
        val raw = value.trim().removeSurrounding("[", "]")
        if (raw.isBlank() || raw.any { it.isWhitespace() || it in "/\\@?#" }) return null
        return runCatching { okhttp3.HttpUrl.Builder().scheme("http").host(raw).build().host }.getOrNull()
    }

    fun port(value: String): Int? = value.trim().toIntOrNull()?.takeIf { it in 1..65535 }

    fun dns(value: String, enabled: Boolean = true): DnsConfig? {
        val raw = value.trim()
        if (raw.startsWith("https://", true)) {
            val url = raw.toHttpUrlOrNull()?.takeIf { it.isHttps && it.username.isEmpty() && it.password.isEmpty() && it.fragment == null } ?: return null
            return DnsConfig(enabled = enabled, dohUrl = url.toString())
        }
        val endpoint = when {
            raw.startsWith('[') -> {
                val close = raw.indexOf(']')
                if (close < 0) return null
                val suffix = raw.substring(close + 1)
                val p = if (suffix.isEmpty()) 53 else if (suffix.startsWith(':')) port(suffix.drop(1)) ?: return null else return null
                raw.substring(1, close) to p
            }
            raw.count { it == ':' } == 1 -> raw.substringBefore(':') to (port(raw.substringAfter(':')) ?: return null)
            else -> raw to 53 // Unbracketed IPv6 is a whole address; a custom port requires brackets.
        }
        return DnsConfig(enabled, host(endpoint.first) ?: return null, endpoint.second)
    }

    fun dnsText(config: DnsConfig): String = when {
        config.dohUrl.isNotBlank() -> config.dohUrl
        config.host.isBlank() -> ""
        config.port == 53 -> config.host
        ':' in config.host -> "[${config.host}]:${config.port}"
        else -> "${config.host}:${config.port}"
    }

    fun sourceLocation(value: String, allowLocal: Boolean = true): Boolean {
        val raw = value.trim()
        if (raw.isBlank() || raw.any { it.code < 32 }) return false
        if (raw.toHttpUrlOrNull() != null) return true
        if (!allowLocal) return false
        if (raw.startsWith('/')) return true
        val uri = runCatching { java.net.URI(raw) }.getOrNull() ?: return false
        return when (uri.scheme?.lowercase(java.util.Locale.ROOT)) {
            "content" -> !uri.rawAuthority.isNullOrBlank() && !uri.rawPath.isNullOrBlank()
            "file" -> !uri.rawPath.isNullOrBlank() && uri.rawPath.startsWith('/')
            else -> false
        }
    }

    fun proxy(host: String, port: Int, username: String, password: String): ProxyConfig? {
        if (port !in 1..65535) return null
        return ProxyConfig(true, this.host(host) ?: return null, port, username.trim(), password)
    }
}
