package tv.own.owntv.core.live

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import tv.own.owntv.core.CorePerf
import tv.own.owntv.core.customize.SectionCustomizations
import tv.own.owntv.core.database.dao.EpgDao
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.epg.EpgDedupe
import tv.own.owntv.core.epg.EpgShift
import tv.own.owntv.core.epg.EpgSourceStore
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.parser.XtEpgEntry
import tv.own.owntv.core.parser.XtreamClient
import tv.own.owntv.core.stalker.StreamUrlResolver

/** Archive window assumed when the playlist doesn't say how many days it keeps. One shared value:
 *  the catch-up picker used to assume 1 day while live rewind assumed 7, so the same channel
 *  offered a day of programmes in the list and a week of rewinding on the timeline. */
const val DEFAULT_CATCHUP_DAYS = 7

/** Upper bound on a playlist's `catchup-days`. Guards the arithmetic that turns it into seconds. */
const val MAX_CATCHUP_DAYS = 31

// How far past a finished catch-up programme to look for the next one. Beyond this the guide has a
// gap rather than a next programme, and auto-play stops instead of leaping hours ahead.
private const val NEXT_PROGRAMME_GAP_CAP_MS = 3L * 60 * 60 * 1000

private const val LOG_TAG = "OwnTVHome"

/**
 * How long a resolved now/next stays usable. Long enough that scrolling back to a channel costs
 * nothing, short enough that a programme changing over is noticed.
 */
private const val CACHE_TTL_MS = 5 * 60_000L

/** How many entries the provider's short-EPG endpoint is asked for. Its own practical maximum. */
private const val SHORT_EPG_LIMIT = 8

/**
 * How many stored rows to read for Next/Later. More than the four Later shows, because duplicates
 * from a second feed are collapsed afterwards and would otherwise eat the list.
 */
private const val UPCOMING_LIMIT = 12

/**
 * Every guide read Live TV performs: now/next for the focused channel, the batched "what's on now" for a
 * list of channels, the catch-up programme list, and the "Match EPG" picker.
 *
 * Split out of the TV app's Live view model, which kept none of this state beyond the now/next cache this class now
 * owns. Nothing here touches playback, the engine ladder or the tune state machine — it reads the
 * database (falling back to the provider's short-EPG API) and maps rows. The guide shift is passed in
 * rather than observed, so the caller stays the single place that knows a customization changed.
 */
class LiveEpgReader(
    private val epgDao: EpgDao,
    private val epgSourceStore: EpgSourceStore,
    private val sourceDao: SourceDao,
    private val xtreamClient: XtreamClient,
    private val streamUrlResolver: StreamUrlResolver,
) {
    private data class CachedEpg(val at: Long, val expiresAt: Long, val signature: List<Any?>, val data: EpgNowNext)

    /** Written from the IO dispatcher (the now/next fetch) and cleared from Main (EPG mapping/shift
     *  changes), so it cannot be a plain HashMap — concurrent structural modification of one is
     *  undefined, up to a corrupt table or an infinite loop inside `get`. */
    private val cache = java.util.concurrent.ConcurrentHashMap<Long, CachedEpg>()

    private data class CachedRows(val at: Long, val signature: List<Any?>, val rows: List<EpgProgrammeEntity>)

    /** Provider-fetched guide rows per channel, so the grid and the preview share one request. */
    private val providerRows = java.util.concurrent.ConcurrentHashMap<Long, CachedRows>()
    private val revision = java.util.concurrent.atomic.AtomicLong()
    private data class ProviderKey(val source: tv.own.owntv.core.database.entity.SourceEntity, val remoteId: String)
    private val rawRows = GuideRequestCache<ProviderKey, List<XtEpgEntry>>(
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO),
        System::currentTimeMillis, CACHE_TTL_MS)
    private data class HistoryKey(val provider: ProviderKey, val from: Long, val to: Long)
    private val historyRows = GuideRequestCache<HistoryKey, List<XtEpgEntry>>(
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO),
        System::currentTimeMillis, CACHE_TTL_MS, maximumSize = 4, cancelWhenUnused = true)
    private val historyPermits = kotlinx.coroutines.sync.Semaphore(2)

    private fun signature(ch: ChannelEntity, cust: SectionCustomizations, offset: Int): List<Any?> =
        listOf(ch.sourceId, ch.remoteId, ch.epgChannelId, cust.epgMatchResolver.epgIdFor(ch),
            cust.epgFallbackFor(ch), EpgShift.minutesFor(cust, ch, offset))


    /** Drop every cached now/next — the global guide offset moved, so all of them are stale. */
    @Synchronized fun clearCache() {
        revision.incrementAndGet()
        cache.clear()
        providerRows.clear()
        rawRows.clear()
        historyRows.clear()
    }

    /** Drop one channel's cached now/next (its EPG match or per-channel shift changed). */
    @Synchronized fun invalidate(channelId: Long) {
        revision.incrementAndGet()
        cache.remove(channelId)
        providerRows.remove(channelId)
    }

    /** Now/next for [ch], cached ~5 min. Prefers a manual EPG match / stored bulk guide, then falls
     *  back to Xtream's short EPG API. */
    suspend fun nowNext(ch: ChannelEntity, cust: SectionCustomizations, globalShiftMinutes: Int): EpgNowNext? =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val owner = revision.get()
            val context = signature(ch, cust, globalShiftMinutes)
            cache[ch.id]?.takeIf { now < it.expiresAt && it.signature == context }?.let { return@withContext it.data }
            fun publish(result: EpgNowNext) = synchronized(this@LiveEpgReader) {
                if (owner != revision.get()) return@synchronized
                val expiry = guideCacheExpiry(now, CACHE_TTL_MS,
                    listOfNotNull(result.now?.stopMs, result.next?.startMs))
                cache[ch.id] = CachedEpg(now, expiry, context, result)
            }

            // 1) Bulk guide via the effective EPG id (manual match overrides the channel's own id).
            val channelShift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
            val epgKey = tv.own.owntv.core.epg.GuideInheritance.key(ch, cust, epgDao,
                EpgShift.toStored(now, channelShift), EpgShift.toStored(now + 3_600_000L, channelShift))
            // Guide shift (global or per-channel): the stored rows keep the feed's own clock, so we look
            // up the SHIFTED "now" and move what comes back — display and catch-up then agree.
            val shift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
            if (epgKey != null) {
                val at = EpgShift.toStored(now, shift)
                val rows = EpgDedupe.collapse(epgDao.programmesForChannel(epgKey, at - 86_400_000L, at + 6 * 3_600_000L), ch.sourceId)
                val nowProg = rows.lastOrNull { at in it.startMs until it.stopMs }
                // Collapsed first: two feeds covering one channel list every programme twice, which
                // put the same title in Next AND at the head of Later.
                val future = rows.filter { it.stopMs > at }.take(UPCOMING_LIMIT)
                    .filter { it.startMs > (nowProg?.startMs ?: 0) }
                val nextProg = future.firstOrNull()
                if (nowProg != null || nextProg != null) {
                    val prevProg = rows.filter { it.stopMs <= (nowProg?.startMs ?: at) }.maxByOrNull { it.stopMs }
                    // Days of stored guide — accurate for bulk-guide channels (the short-EPG API path
                    // leaves this null, since its ~8 entries only span a few hours).
                    val days = try { epgDao.coverageDays(epgKey)?.takeIf { it > 0 } }
                    catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                    catch (_: Exception) { null }
                    fun EpgProgrammeEntity.shifted() = EpgShift.apply(this, shift).toXt()
                    val result = EpgNowNext(nowProg?.shifted(), nextProg?.shifted(), future.drop(1).take(4).map { it.shifted() }, previous = prevProg?.shifted(), coverageDays = days)
                    publish(result)
                    return@withContext result.takeIf { owner == revision.get() }
                }
            }

            // 2) Provider short-EPG API fallback (Xtream get_short_epg / Stalker get_short_epg, Phase E §5.5).
            val entries = providerEntries(ch, shift) ?: return@withContext null
            // A gap in the provider's own guide data around "now" (nothing covers this instant) must leave
            // current null — picking the next entry that simply hasn't ended yet would mislabel an upcoming
            // programme as live (issue #68). "Next"/"Later" are computed independently below, so a genuine
            // gap correctly shows no "Now" while the upcoming programme still appears as "Next".
            val current = entries.firstOrNull { it.startMs <= now && it.stopMs > now }
            val future = entries.filter { it.startMs > (current?.startMs ?: now) }.sortedBy { it.startMs }
            // Short-EPG responses sometimes include the just-finished programme — surface it as "Before".
            val previous = entries.filter { it.stopMs <= (current?.startMs ?: now) }.maxByOrNull { it.stopMs }
            val result = EpgNowNext(current, future.firstOrNull(), future.drop(1).take(4), previous = previous)
            publish(result)
            result.takeIf { owner == revision.get() }
        }

    /**
     * The channel's guide as the **provider** reports it right now, on the user's clock.
     *
     * This is the second of the two guides OwnTV reads, and the reason the preview pane could show a
     * programme while the grid and the channel row beside it stayed blank: these entries are fetched
     * live and are never written to `epg_programmes`, so anything reading only the table sees nothing.
     * Pulled out of [nowNext] so the guide grid and the channel rows can read exactly the same answer.
     *
     * Null — as distinct from empty — means there is no provider guide to ask for at all: no stream
     * id, no source, or a source type with no short-EPG endpoint. Callers use that to tell "the
     * provider says nothing is on" from "there was nobody to ask".
     *
     * **It is only ever a few hours.** `get_short_epg` returns about eight entries, so this fills now
     * and the rest of the evening, never a whole scrollable day.
     */
    private suspend fun providerEntries(ch: ChannelEntity, shift: Int, strictFailure: Boolean = false): List<XtEpgEntry>? {
        val streamId = ch.remoteId ?: return null
        val source = sourceDao.getById(ch.sourceId) ?: return null
        if (source.type != SourceType.XTREAM && source.type != SourceType.STALKER) return null
        val raw = try {
            rawRows.get(ProviderKey(source, streamId)) {
                when (source.type) {
                    SourceType.XTREAM -> xtreamClient.getShortEpg(source, streamId, limit = SHORT_EPG_LIMIT)
                    SourceType.STALKER -> streamUrlResolver.shortEpg(source, streamId)
                        .map { XtEpgEntry(title = it.title, description = it.description, startMs = it.startMs, stopMs = it.stopMs) }
                }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (failed: Exception) {
            if (strictFailure) throw failed
            return null // Failed reads are not successful empty guide responses.
        }
        // The provider's own guide needs the same shift as the stored one — same channel, same clock.
        return if (shift == 0) raw else raw.map {
            it.copy(startMs = it.startMs + shift * 60_000L, stopMs = it.stopMs + shift * 60_000L,
                guideShiftMs = it.guideShiftMs + shift * 60_000L)
        }
    }

    /**
     * The provider's guide for [channel] as guide rows, ready to draw — the grid's half of the same
     * fallback the preview pane has always had.
     *
     * The rows are **synthetic** — they exist nowhere in the database — so anything that looks a
     * programme up by id must fall back to the row it already holds, which is why the description
     * travels with it rather than being fetched later.
     *
     * Their ids are the **negated start time**: negative, so they can never collide with a real row's
     * (Room generates those upwards from 1), and distinct within a channel, so a caller that gathers
     * ids into a set — the grid marks its catch-up cells that way — cannot have one synthetic row
     * stand for all of them.
     *
     * Cached per channel for [CACHE_TTL_MS], so a row scrolling in and out of view, and the list's
     * own periodic refresh, cost one request rather than one per look.
     */
    suspend fun providerProgrammes(
        channel: ChannelEntity,
        cust: SectionCustomizations,
        globalShiftMinutes: Int,
        from: Long? = null,
        to: Long? = null,
    ): List<EpgProgrammeEntity> = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (channel.catchup && from != null && to != null && from < now - 6 * 3_600_000L) {
            val source = sourceDao.getById(channel.sourceId)
            val remoteId = channel.remoteId
            if (source?.type == SourceType.XTREAM && remoteId != null) {
                val shift = EpgShift.minutesFor(cust, channel, globalShiftMinutes)
                val block = 6 * 3_600_000L
                val start = Math.floorDiv(EpgShift.toStored(from, shift), block) * block
                val end = minOf(Math.floorDiv(EpgShift.toStored(to, shift), block) * block + block,
                    start + tv.own.owntv.core.epg.GuideHistoryPolicy.MAX_LOOKBACK_MS + block)
                val owner = revision.get()
                val entries = try {
                    historyRows.get(HistoryKey(ProviderKey(source, remoteId), start, end)) {
                        historyPermits.acquire()
                        try { xtreamClient.getHistoricalEpg(source, remoteId, start, end) }
                        finally { historyPermits.release() }
                    }
                } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                catch (failed: Exception) { throw ProviderGuideUnavailableException(emptyList(), failed) }
                currentCoroutineContext().ensureActive()
                if (owner != revision.get()) throw kotlinx.coroutines.CancellationException()
                return@withContext entries.map { entry ->
                    EpgShift.apply(EpgProgrammeEntity(id = -entry.startMs, sourceId = channel.sourceId,
                        epgChannelId = channel.epgChannelId ?: remoteId, startMs = entry.startMs,
                        stopMs = entry.stopMs, title = entry.title, description = entry.description), shift)
                }.filter { it.stopMs > from && it.startMs < to }
            }
        }
        val context = signature(channel, cust, globalShiftMinutes)
        providerRows[channel.id]?.takeIf { now - it.at < CACHE_TTL_MS && it.signature == context }?.let { return@withContext it.rows }
        val shift = EpgShift.minutesFor(cust, channel, globalShiftMinutes)
        val key = (cust.epgMatchResolver.epgIdFor(channel) ?: channel.epgChannelId)
            ?.trim()?.lowercase()?.takeIf { it.isNotEmpty() } ?: channel.streamUrl
        val owner = revision.get()
        val entries = try {
            providerEntries(channel, shift, strictFailure = true) ?: return@withContext emptyList()
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (failed: Exception) {
            if (owner != revision.get()) throw kotlinx.coroutines.CancellationException()
            val previous = providerRows[channel.id]?.takeIf { it.signature == context }?.rows.orEmpty()
            throw ProviderGuideUnavailableException(previous, failed)
        }
        val rows = entries.map {
            EpgProgrammeEntity(
                id = -it.startMs,
                sourceId = channel.sourceId,
                epgChannelId = key,
                startMs = it.startMs,
                stopMs = it.stopMs,
                title = it.title,
                description = it.description,
                guideShiftMs = it.guideShiftMs,
            )
        }.sortedBy { it.startMs }
        kotlinx.coroutines.currentCoroutineContext().ensureActive()
        synchronized(this@LiveEpgReader) {
            if (owner != revision.get()) throw kotlinx.coroutines.CancellationException()
            providerRows[channel.id] = CachedRows(now, context, rows)
        }
        rows
    }

    /**
     * The programme currently airing on each of [channels] (channel id → title), looked up in ONE batch
     * against the stored bulk guide — same query the Home "On Now" rail uses. This powers the small
     * "current programme" subtitle under each channel row in the Live list and the in-player channel
     * overlay. Returns only channels that actually have something airing right now.
     *
     * **Two passes, because there are two guides.** The stored bulk guide answers first, in one query,
     * and covers most channels for the cost of a single round trip. Whatever it cannot answer then goes
     * through [nowNext] — *the very function that fills the preview pane* — which checks its own cache,
     * then the stored guide, then falls back to the provider's short-EPG API.
     *
     * That second pass is the whole point. Those short-EPG programmes are never written to the table, so
     * a channel served that way showed a full guide in the preview pane and a blank second line in the
     * list right beside it, permanently — the two were reading different guides. Now there is one answer
     * for one channel, and the row and the pane agree by construction rather than by coincidence: if the
     * preview has a programme the row shows it, and if the preview has none the row is blank too.
     *
     * **Nothing here goes to the network.** That is a hard rule, not an optimisation: see the note at
     * the second pass for what filling a list of hundreds by asking the provider actually did.
     */
    suspend fun nowPlayingFor(
        channels: List<ChannelEntity>,
        cust: SectionCustomizations,
        globalShiftMinutes: Int,
    ): Map<Long, String> = withContext(Dispatchers.IO) {
        if (channels.isEmpty()) return@withContext emptyMap()
        val now = System.currentTimeMillis()
        // Every playlist plus every EPG feed — NOT just the sources the visible page happens to come
        // from. Guide rows are keyed by epgChannelId and routinely live under a different source than
        // the channel showing them (one playlist's xmltv.php covering another's channels), and
        // [nowNext] — which fills the preview pane — applies no source filter at all. Narrowing this to
        // the page's own sources made the two disagree: the preview showed a programme while the row
        // under it stayed blank, until an EPG re-sync happened to rewrite the rows under an id the
        // filter included.
        // Manual EPG-match overrides take precedence over the channel's own epgChannelId, mirroring nowNext.
        // Shifted channels look up a different instant, so the batch is grouped by shift — with no
        // offsets configured (the normal case) that's still exactly one query group.
        val channelKeys = channels.mapNotNull { ch ->
            val key = (cust.epgMatchResolver.epgIdFor(ch) ?: ch.epgChannelId)
                ?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
            if (key != null) Triple(ch.id, key, EpgShift.minutesFor(cust, ch, globalShiftMinutes)) else null
        }
        if (channelKeys.isEmpty() && channels.none { tv.own.owntv.core.epg.GuideInheritance.fallback(it, cust) != null }) return@withContext emptyMap()
        val startedAt = android.os.SystemClock.elapsedRealtime()
        var chunks = 0
        val sourceByChannel = channels.associate { it.id to it.sourceId }
        val result = HashMap<Long, String>()
        for ((shift, group) in channelKeys.groupBy { it.third }) {
            val at = EpgShift.toStored(now, shift)
            val rowsByKey = group
                .map { it.second }.distinct()
                .chunked(400)
                .flatMap { keys ->
                    chunks++
                    epgDao.programmeSummariesForChannels(keys, at, at + 1)
                }
                .groupBy { it.epgChannelId }
            for ((channelId, epgKey, _) in group) {
                rowsByKey[epgKey]?.let { EpgDedupe.collapse(it, sourceByChannel[channelId]) }
                    ?.lastOrNull { at in it.startMs until it.stopMs }
                    ?.let { result[channelId] = it.title }
            }
        }
        val inherited = channels.filter { it.id !in result }
            .mapNotNull { ch -> tv.own.owntv.core.epg.GuideInheritance.fallback(ch, cust)?.let { Triple(ch.id, it, EpgShift.minutesFor(cust, ch, globalShiftMinutes)) } }
        for ((shift, group) in inherited.groupBy { it.third }) {
            val at = EpgShift.toStored(now, shift)
            val rows = group.map { it.second }.distinct().chunked(400)
                .flatMap { epgDao.programmeSummariesForChannels(it, at, at + 1) }.groupBy { it.epgChannelId }
            for ((id, key, _) in group) rows[key]?.let { EpgDedupe.collapse(it, sourceByChannel[id]) }?.lastOrNull { at in it.startMs until it.stopMs }?.let { result[id] = it.title }
        }
        // Second pass: whatever the preview pane has already resolved for a channel the stored guide
        // could not answer — **from cache, never from the network**.
        //
        // Fetching here was tried and was a mistake worth recording. A list holds hundreds of
        // channels, so "ask the provider for the ones we cannot answer" became hundreds of
        // `get_short_epg` requests, most of them returning nothing because that provider has no short
        // guide for those channels at all. Worse, the batch could not return until the last one
        // finished, so the list that used to fill from one query instantly now filled from nothing:
        // EVERY row went blank, which is the opposite of the bug it set out to fix.
        //
        // The provider is still asked — just never in bulk. The channel under the cursor is fetched
        // by the preview pane itself, and a guide row fetches as it scrolls into view. Both land in
        // this cache, so the list fills in behind them for free.
        val fromStored = result.size
        for (ch in channels) {
            if (ch.id in result) continue
            cachedNowTitle(ch, now, cust, globalShiftMinutes)?.let { result[ch.id] = it }
        }
        CorePerf.log {
            "live_nowplaying channels=${channels.size} keyed=${channelKeys.size} " +
                "keys=${channelKeys.map { it.second }.distinct().size} chunks=$chunks " +
                "fromStored=$fromStored fromCache=${result.size - fromStored} " +
                "totalMs=${android.os.SystemClock.elapsedRealtime() - startedAt}"
        }
        result
    }

    /**
     * The current programme already resolved for [channelId], if it is still fresh — from either
     * cache, because the preview pane and the guide grid fill different ones.
     *
     * Deliberately never fetches. See the note in [nowPlayingFor] for what happened when it did.
     */
    private fun cachedNowTitle(channel: ChannelEntity, now: Long, cust: SectionCustomizations, offset: Int): String? {
        val context = signature(channel, cust, offset)
        cache[channel.id]?.takeIf { now < it.expiresAt && it.signature == context }?.data?.now?.title
            ?.takeIf { it.isNotBlank() }?.let { return it }
        return providerRows[channel.id]
            ?.takeIf { now - it.at < CACHE_TTL_MS && it.signature == context }
            ?.rows?.firstOrNull { it.startMs <= now && it.stopMs > now }
            ?.title?.takeIf { it.isNotBlank() }
    }

    /**
     * What was on [ch] at [atMs], and what followed it — the archive counterpart of [nowNext], for the
     * "PLAYING / THEN" card shown while a recording is playing.
     *
     * Stored-guide only, deliberately: the provider short-EPG APIs report *now and upcoming*, so they
     * can say nothing about yesterday afternoon. A channel whose guide comes only from that API gets
     * no archive card, which is correct — there is genuinely no data for the moment being watched.
     *
     * Returns null when nothing is known at [atMs], so the caller can simply omit the card.
     */
    suspend fun nowNextAt(
        ch: ChannelEntity,
        atMs: Long,
        cust: SectionCustomizations,
        globalShiftMinutes: Int,
    ): EpgNowNext? = withContext(Dispatchers.IO) {
        val lookupShift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
        val epgKey = tv.own.owntv.core.epg.GuideInheritance.key(ch, cust, epgDao,
            EpgShift.toStored(atMs, lookupShift), EpgShift.toStored(atMs + 3_600_000L, lookupShift)) ?: return@withContext null
        // Same shift dance as [nowNext]: stored rows keep the feed's own clock, so look up the shifted
        // instant and move what comes back, or the card would disagree with the archive it describes.
        val shift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
        val at = EpgShift.toStored(atMs, shift)
        val rows = EpgDedupe.collapse(epgDao.programmesForChannel(epgKey, at, at + 6 * 3_600_000L), ch.sourceId)
        val playing = rows.lastOrNull { at in it.startMs until it.stopMs }
        val then = rows
            .firstOrNull { it.startMs > (playing?.startMs ?: 0) }
        if (playing == null && then == null) return@withContext null
        fun EpgProgrammeEntity.shifted() = EpgShift.apply(this, shift).toXt()
        EpgNowNext(playing?.shifted(), then?.shifted())
    }

    suspend fun timelineProgrammes(
        ch: ChannelEntity, cust: SectionCustomizations, globalShiftMinutes: Int,
        from: Long, to: Long,
    ): List<EpgProgrammeEntity> = withContext(Dispatchers.IO) {
        if (!ch.catchup || to <= from) return@withContext emptyList()
        val shift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
        val start = EpgShift.toStored(from, shift)
        val stop = EpgShift.toStored(minOf(to, from + 6 * 3_600_000L), shift)
        val key = tv.own.owntv.core.epg.GuideInheritance.key(ch, cust, epgDao, start, stop)
        val stored = key?.let { epgDao.programmeSummariesForChannel(it, start, stop) }.orEmpty()
        if (stored.isEmpty()) providerProgrammes(ch, cust, globalShiftMinutes, from, to)
        else EpgDedupe.collapse(stored, ch.sourceId).map { EpgShift.apply(it, shift) }
    }

    /** Recent (already-aired) programmes for a catch-up channel, newest first — drives the Live TV
     *  catch-up picker. Bounded to the retained EPG and the channel's archive window. */
    suspend fun catchupProgrammes(
        ch: ChannelEntity,
        cust: SectionCustomizations,
        globalShiftMinutes: Int,
    ): List<EpgProgrammeEntity> = withContext(Dispatchers.IO) {
        if (!ch.catchup) return@withContext emptyList()
        val now = System.currentTimeMillis()
        // Provider depth can be stale. Browse the same history as the Guide; the detail dialog
        // distinguishes confirmed availability from a deliberate archive attempt.
        val windowStart = tv.own.owntv.core.epg.GuideHistoryPolicy.windowStart(now, ch.catchupDays)
        // Shifted guide → shifted window, and the rows come back on the corrected clock, so the
        // archive URL built from the picked programme asks for the time it really aired.
        val shift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
        val at = EpgShift.toStored(now, shift)
        val epgKey = tv.own.owntv.core.epg.GuideInheritance.key(ch, cust, epgDao,
            EpgShift.toStored(windowStart, shift), at + 3_600_000L)
        val stored = epgKey?.let { epgDao.programmesForChannel(it, EpgShift.toStored(windowStart, shift), at + 3_600_000L) }.orEmpty()
        if (stored.isEmpty()) providerProgrammes(ch, cust, globalShiftMinutes, windowStart, now + 1)
            .filter { it.startMs <= now }.sortedByDescending { it.startMs }
        else EpgDedupe.collapse(stored.filter { it.startMs <= at }, ch.sourceId)
            .sortedByDescending { it.startMs }.map { EpgShift.apply(it, shift) }
    }

    /**
     * The guide entry that follows [afterStopMs] on [ch] — what a finished catch-up programme rolls
     * into. Null when the guide stops there, or when the gap to the next entry is longer than
     * [NEXT_PROGRAMME_GAP_CAP_MS]: a channel whose guide resumes tomorrow morning has nothing to
     * continue with tonight, and jumping hours forward is not "the next programme".
     *
     * [afterStopMs] is on the clock the user sees; the result comes back on it too, so the archive URL
     * built from it asks for the time the programme really aired.
     */
    suspend fun programmeAfter(
        ch: ChannelEntity,
        afterStopMs: Long,
        cust: SectionCustomizations,
        globalShiftMinutes: Int,
    ): EpgProgrammeEntity? = withContext(Dispatchers.IO) {
        val shift = EpgShift.minutesFor(cust, ch, globalShiftMinutes)
        val from = EpgShift.toStored(afterStopMs, shift)
        val epgKey = tv.own.owntv.core.epg.GuideInheritance.key(ch, cust, epgDao, from, from + NEXT_PROGRAMME_GAP_CAP_MS)
        val stored = epgKey?.let { epgDao.programmesForChannel(it, from, from + NEXT_PROGRAMME_GAP_CAP_MS) }.orEmpty()
        if (stored.isEmpty()) providerProgrammes(ch, cust, globalShiftMinutes, afterStopMs, afterStopMs + NEXT_PROGRAMME_GAP_CAP_MS)
            .firstOrNull { it.startMs >= afterStopMs }
        else EpgDedupe.collapse(stored, ch.sourceId).firstOrNull { it.startMs >= from }
            ?.let { EpgShift.apply(it, shift) }
    }

    /** Full description for a programme picked in the catch-up dialog. The list query drops it to stay
     *  under the CursorWindow limit, so the detail popup fetches it on demand (same as the Guide). */
    suspend fun programmeDescription(programmeId: Long): String? =
        withContext(Dispatchers.IO) {
            try { epgDao.programmeDescription(programmeId) }
            catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
            catch (_: Exception) { null }
        }

    // The "Match EPG" picker used to be answered from here, filtered to the profile's own sources.
    // It is now [tv.own.owntv.core.epg.GuideCandidates], which filters by no source at all — the same
    // rule every guide read already followed, and the half of it that was missing.

    private fun EpgProgrammeEntity.toXt() =
        XtEpgEntry(title = title, description = description, startMs = startMs, stopMs = stopMs,
            guideShiftMs = guideShiftMs)
}

/**
 * The archive URLs Live TV builds: one for a picked catch-up programme, one for a live-rewind offset.
 * Both are pure construction — no state, no playback — kept beside the guide reads they follow on from.
 */
class LiveArchiveUrls(
    private val sourceDao: SourceDao,
    private val xtreamClient: XtreamClient,
    private val streamUrlResolver: StreamUrlResolver,
    private val settings: tv.own.owntv.core.settings.SettingsRepository,
) {
    /** Compatibility entry point for callers that only need the initial archive address. */
    suspend fun forProgramme(ch: ChannelEntity, displayProgramme: EpgProgrammeEntity): String? =
        resolveProgramme(ch, displayProgramme)?.url

    suspend fun resolveProgramme(ch: ChannelEntity, displayProgramme: EpgProgrammeEntity): tv.own.owntv.core.epg.ResolvedArchiveSource? =
        withContext(Dispatchers.IO) {
            val correction = settings.catchupRequestShiftMinutes.first()
            val programme = tv.own.owntv.core.epg.CatchupUrl.requestProgramme(displayProgramme, correction)
            val source = sourceDao.getById(ch.sourceId) ?: return@withContext null
            // Stalker archive URLs are minted per-play via create_link (Phase E §5.6); the others
            // are pure string templates handled by CatchupUrl.
            val base = if (source.type == SourceType.STALKER) {
                ch.remoteId?.let { rid ->
                    try { streamUrlResolver.resolveCatchup(source, rid, programme.startMs, programme.stopMs) }
                    catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                    catch (failed: Exception) { Log.w(LOG_TAG, "Stalker catch-up resolve failed channelId=${ch.id}", failed); null }
                }
            } else {
                tv.own.owntv.core.epg.CatchupUrl.forSource(
                    ch, programme, source,
                    tv.own.owntv.core.epg.CatchupClock.resolve(source, settings.resolveCatchupTimeZone(),
                        settings.catchupTimezone.first() == tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.AUTO),
                    xtreamClient,
                )
            }
            val zone = tv.own.owntv.core.epg.CatchupClock.resolve(source, settings.resolveCatchupTimeZone(),
                settings.catchupTimezone.first() == tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.AUTO)
            val providerCorrection = if (source.type == SourceType.M3U) ch.catchupCorrectionMin else 0
            val requestStart = programme.startMs + providerCorrection * 60_000L
            val effectiveDisplay = tv.own.owntv.core.epg.CatchupClock.effectiveDisplayStart(
                displayProgramme.startMs, requestStart, startsOnMinute(source.type, ch))
            tv.own.owntv.core.epg.ArchiveTemplateResolver.resolve(
                base, settings.catchupFormat.first(), ch, source, programme.startMs, programme.stopMs,
                settings.archivePlaybackConfigs.first(),
            )?.copy(displayStartMs = effectiveDisplay, requestStartMs = requestStart - (displayProgramme.startMs - effectiveDisplay),
                clockZoneId = zone.id, requestCorrectionMinutes = correction + providerCorrection,
                reconnect = if (source.type == SourceType.STALKER) tv.own.owntv.core.stalker.ReconnectUrlProvider {
                    forProgramme(ch, displayProgramme)
                } else null)
        }

    /** The rolling-archive URL for watching [ch] [offsetSec] behind the live edge. */
    suspend fun forTimeshift(
        ch: ChannelEntity,
        source: tv.own.owntv.core.database.entity.SourceEntity,
        operationalStartMs: Long,
        offsetSec: Int,
        tz: java.util.TimeZone,
    ): String? = resolveTimeshift(ch, source, operationalStartMs, offsetSec, tz)?.url

    suspend fun resolveTimeshift(
        ch: ChannelEntity,
        source: tv.own.owntv.core.database.entity.SourceEntity,
        operationalStartMs: Long,
        offsetSec: Int,
        tz: java.util.TimeZone,
    ): tv.own.owntv.core.epg.ResolvedArchiveSource? {
        val correction = settings.catchupRequestShiftMinutes.first()
        val startMs = tv.own.owntv.core.epg.CatchupUrl.requestStartMs(operationalStartMs, correction)
        val sourceTimeZone = tv.own.owntv.core.epg.CatchupClock.resolve(source, tz,
            settings.catchupTimezone.first() == tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.AUTO)
        val durationMin = (offsetSec / 60 + 5).coerceAtLeast(1) // rewound window + buffer to play up to live
        val base = when (source.type) {
            SourceType.XTREAM -> ch.remoteId?.let {
                // Archive format has its own preference, independent of the live HLS setting.
                xtreamClient.timeshiftUrl(source, it, startMs, durationMin, sourceTimeZone, "ts")
            }
            // No HLS swap here: [resolveStreamUrl] is Xtream-only, so it would be a no-op on M3U.
            SourceType.M3U -> tv.own.owntv.core.epg.CatchupUrl.forM3u(
                ch.streamUrl,
                ch.catchupType,
                ch.catchupSource,
                startMs,
                startMs + durationMin * 60_000L,
                sourceTimeZone,
                bounded = false,
                correctionMin = ch.catchupCorrectionMin,
            )
            // Stalker rewind = the same per-play archive create_link as catch-up (Phase E §5.6).
            SourceType.STALKER -> ch.remoteId?.let { rid ->
                try { streamUrlResolver.resolveCatchup(source, rid, startMs, startMs + durationMin * 60_000L) }
                catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                catch (failed: Exception) { Log.w(LOG_TAG, "Stalker rewind resolve failed channelId=${ch.id}", failed); null }
            }
            else -> null
        }
        val providerCorrection = if (source.type == SourceType.M3U) ch.catchupCorrectionMin else 0
        val requestStart = startMs + providerCorrection * 60_000L
        val effectiveDisplay = tv.own.owntv.core.epg.CatchupClock.effectiveDisplayStart(
            operationalStartMs, requestStart, startsOnMinute(source.type, ch))
        return tv.own.owntv.core.epg.ArchiveTemplateResolver.resolve(
            base, settings.catchupFormat.first(), ch, source, startMs, startMs + durationMin * 60_000L,
            settings.archivePlaybackConfigs.first(),
        )?.copy(displayStartMs = effectiveDisplay, requestStartMs = requestStart - (operationalStartMs - effectiveDisplay),
            clockZoneId = sourceTimeZone.id, requestCorrectionMinutes = correction + providerCorrection,
            reconnect = if (source.type == SourceType.STALKER) tv.own.owntv.core.stalker.ReconnectUrlProvider {
                forTimeshift(ch, source, operationalStartMs, offsetSec, tz)
            } else null)
    }

    private fun startsOnMinute(type: SourceType, channel: ChannelEntity): Boolean =
        type == SourceType.XTREAM || (type == SourceType.M3U && channel.catchupSource.isNullOrBlank() &&
            channel.catchupType?.lowercase()?.trim() in setOf("xc", "xtream"))
}
