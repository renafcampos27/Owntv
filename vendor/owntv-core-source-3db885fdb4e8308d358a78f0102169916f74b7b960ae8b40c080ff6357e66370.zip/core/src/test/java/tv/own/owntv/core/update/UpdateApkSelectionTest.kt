package tv.own.owntv.core.update

import org.junit.Assert.*
import org.junit.Test

class UpdateApkSelectionTest {
    private fun asset(name: String) = UpdateApkAsset(name, "https://example.test/$name")

    @Test fun `select exact supported ABI instead of release ordering`() {
        val arm64 = asset("OwnTV-arm64-v8a.apk")
        val v7 = asset("OwnTV-armeabi-v7a.apk")
        val universal = asset("OwnTV-universal.apk")
        val assets = listOf(arm64, universal, v7)
        assertEquals(v7, selectUpdateApk(assets, listOf("armeabi-v7a")))
        assertEquals(arm64, selectUpdateApk(assets, listOf("arm64-v8a", "armeabi-v7a")))
    }

    @Test fun `wrong architecture never becomes an arbitrary fallback`() {
        assertNull(selectUpdateApk(listOf(asset("OwnTV-arm64.apk")), listOf("armeabi-v7a")))
        assertNull(selectUpdateApk(listOf(asset("OwnTV-x86_64.apk")), listOf("arm64-v8a")))
        assertNull(selectUpdateApk(listOf(asset("OwnTV.apk")), listOf("x86_64")))
    }

    @Test fun `universal and legacy generic ARM remain supported`() {
        val universal = asset("OwnTV-universal.apk")
        val generic = asset("OwnTV.apk")
        assertEquals(universal, selectUpdateApk(listOf(universal), listOf("armeabi-v7a")))
        assertEquals(generic, selectUpdateApk(listOf(generic), listOf("arm64-v8a")))
        assertNull(selectUpdateApk(emptyList(), listOf("arm64-v8a")))
    }

    @Test fun `ignore non APK and blank download locations`() {
        assertNull(selectUpdateApk(listOf(asset("OwnTV-arm64.txt"), UpdateApkAsset("OwnTV.apk", "")), listOf("arm64-v8a")))
    }
}
