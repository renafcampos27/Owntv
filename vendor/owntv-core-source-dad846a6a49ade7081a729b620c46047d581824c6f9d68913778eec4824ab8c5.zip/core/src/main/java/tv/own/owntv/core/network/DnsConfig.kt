package tv.own.owntv.core.network

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

/**
 * Immutable snapshot of the global custom DNS config — a sibling to the global proxy.
 * Two modes: a plain DNS-over-UDP IP (host + port), or a DNS-over-HTTPS (DoH) URL.
 *
 * DNS resolution happens BEFORE a request is sent, so this is a per-OkHttpClient setting,
 * not a per-request one. The DNS is resolved by the singleton client, which reads the
 * live snapshot from [DnsConfigHolder.current] on every lookup.
 */
data class DnsConfig(
    val enabled: Boolean = false,
    val host: String = "",
    val port: Int = DNS_DEFAULT_PORT,
    val dohUrl: String = "",
) {
    /** Host:port mode enabled with a sane host/port. */
    val plainUsable: Boolean get() = enabled && host.isNotBlank() && port in 1..65535

    /** DoH mode enabled with a URL. */
    val dohUsable: Boolean get() = enabled && dohUrl.isNotBlank()

    companion object {
        const val DNS_DEFAULT_PORT = 53
    }
}

/**
 * Well-known DNS-over-HTTPS endpoints — offered as one-tap presets in the settings UI.
 */
object DohPresets {
    val GOOGLE = "https://dns.google/dns-query"
    val CLOUDFLARE = "https://cloudflare-dns.com/dns-query"
    val QUAD9 = "https://dns.quad9.net/dns-query"

    val all = listOf(
        "Google" to GOOGLE,
        "Cloudflare" to CLOUDFLARE,
        "Quad9" to QUAD9,
    )
}

/**
 * Live holder for the custom DNS config — same pattern as [ProxyConfigHolder].
 * Provides an OkHttp [Dns] that reads the live snapshot so DNS can be toggled at
 * runtime without rebuilding the singleton [OkHttpClient].
 *
 * DNS-over-HTTPS bootstraps itself: the DoH requests go through a separate bootstrap
 * OkHttpClient that uses system DNS so there is no infinite loop.
 */
class DnsConfigHolder(
    configFlow: Flow<DnsConfig>,
    initialConfig: DnsConfig = DnsConfig(),
    private val fallbackToSystem: Boolean = true,
) {

    data class ResolverSnapshot(val generation: Long, val resolver: Dns)
    private data class State(val config: DnsConfig, val resolver: ResolverSnapshot)
    private val configLock = Any()
    @Volatile private var current = state(initialConfig, 0)

    private fun state(config: DnsConfig, generation: Long) = State(config, ResolverSnapshot(generation, Dns { hostname ->
        resolve(hostname, config)
    }))

    internal fun configure(config: DnsConfig) = synchronized(configLock) {
        if (current.config != config) current = state(config, current.resolver.generation + 1)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var dohClientOverride: OkHttpClient? = null
    @Volatile private var fallbackDns: Dns = Dns.SYSTEM

    /** Bootstrap client for DoH requests — always uses system DNS, never our custom DNS. */
    private val defaultBootstrapClient by lazy {
        OkHttpClient.Builder()
            .dns(Dns.SYSTEM)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    private fun dohClient(): OkHttpClient = dohClientOverride ?: defaultBootstrapClient

    init {
        configFlow.onEach(::configure).launchIn(scope)
    }

    fun snapshot(): DnsConfig = current.config

    /** Atomic generation/resolver pair: this resolver never reads a later configuration. */
    fun capture(): ResolverSnapshot = current.resolver

    /**
     * The [Dns] implementation fed to OkHttpClient.Builder. On every lookup it reads
     * the live [current] snapshot and routes to the appropriate backend, falling back
     * to system DNS when custom DNS is disabled or errors occur.
     */
    val dns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            return capture().resolver.lookup(hostname)
        }
    }

    private fun resolve(hostname: String, config: DnsConfig): List<InetAddress> = when {
        config.dohUsable -> resolveViaDoH(hostname, config.dohUrl)
        config.plainUsable -> resolveViaUdp(hostname, config.host, config.port)
        else -> fallbackDns.lookup(hostname)
    }

    // --- DNS-over-HTTPS (RFC 8484 / JSON) via manual HTTP requests ---

    private fun resolveViaDoH(hostname: String, dohUrl: String): List<InetAddress> {
        return try {
            val baseUrl = dohUrl.trim().trimEnd('/').toHttpUrl()
            // Query both A and AAAA independently so a failure on one family never discards valid answers
            // from the other (matching the UDP path).
            val ipv4 = runCatching { dohLookup(hostname, baseUrl, "A", DNS_TYPE_A) }
            val ipv6 = runCatching { dohLookup(hostname, baseUrl, "AAAA", DNS_TYPE_AAAA) }
            val results = buildList {
                addAll(ipv4.getOrDefault(emptyList()))
                addAll(ipv6.getOrDefault(emptyList()))
            }
            if (results.isNotEmpty()) {
                Log.d(TAG, "DoH lookup $hostname → ${results.map { it.hostAddress }} (server=$dohUrl)")
                results
            } else {
                val failure = ipv4.exceptionOrNull() ?: ipv6.exceptionOrNull()
                if (failure != null) throw failure
                if (!fallbackToSystem) return emptyList()
                Log.w(TAG, "DoH lookup returned no addresses for $hostname, falling back to system DNS")
                fallbackDns.lookup(hostname)
            }
        } catch (e: Exception) {
            if (!fallbackToSystem) throw e
            Log.w(TAG, "DoH lookup failed for $hostname, falling back to system DNS", e)
            fallbackDns.lookup(hostname)
        }
    }

    private fun dohLookup(hostname: String, baseUrl: HttpUrl, type: String, expectedType: Int): List<InetAddress> {
        val url = baseUrl.newBuilder()
            .addQueryParameter("name", hostname)
            .addQueryParameter("type", type)
            .build()
        val request = Request.Builder().url(url)
            .header("Accept", "application/dns-json")
            .build()
        val response = dohClient().newCall(request).execute()
        return response.use { resp ->
            if (!resp.isSuccessful) throw java.io.IOException("DoH HTTP ${resp.code}")
            val body = resp.body.string()
            parseDohJson(body, expectedType)
        }
    }

    // --- Plain DNS-over-UDP resolver ---

    private fun resolveViaUdp(hostname: String, server: String, port: Int): List<InetAddress> {
        try {
            // Both families, like the DoH path: asking only for A left an AAAA-only host unresolvable
            // whenever custom plain DNS was in use. A failure of the AAAA half never costs the A answers.
            val result = askUdp(hostname, DNS_TYPE_A, server, port) +
                runCatching { askUdp(hostname, DNS_TYPE_AAAA, server, port) }.getOrDefault(emptyList())
            Log.d(TAG, "UDP DNS lookup $hostname → ${result.map { it.hostAddress }} (server=$server:$port)")
            return if (result.isNotEmpty() || !fallbackToSystem) result else fallbackDns.lookup(hostname)
        } catch (e: SocketTimeoutException) {
            if (!fallbackToSystem) throw e
            Log.w(TAG, "UDP DNS timeout for $hostname via $server:$port, falling back to system DNS")
            return fallbackDns.lookup(hostname)
        } catch (e: Exception) {
            if (!fallbackToSystem) throw e
            Log.w(TAG, "UDP DNS lookup failed for $hostname via $server:$port, falling back to system DNS", e)
            return fallbackDns.lookup(hostname)
        }
    }

    /** One question of [qtype], with its own random ID checked against the answer. */
    @Throws(Exception::class)
    private fun askUdp(hostname: String, qtype: Int, server: String, port: Int): List<InetAddress> {
        val id = randomQueryId()
        val response = sendUdpQuery(buildDnsQuery(hostname, qtype, id), server, port)
        return parseDnsResponse(response, id, qtype)
    }

    @Throws(Exception::class)
    private fun sendUdpQuery(query: ByteArray, server: String, port: Int): ByteArray {
        val sock = DatagramSocket()
        sock.soTimeout = REQUEST_TIMEOUT_MS
        try {
            val addr = InetSocketAddress(server, port)
            val req = DatagramPacket(query, query.size, addr)
            sock.send(req)
            val buf = ByteArray(RESPONSE_BUFFER_SIZE)
            val resp = DatagramPacket(buf, buf.size)
            sock.receive(resp)
            return resp.data.copyOf(resp.length)
        } finally {
            sock.close()
        }
    }

    companion object {
        private const val TAG = "DnsConfig"
        private const val REQUEST_TIMEOUT_MS = 5_000
        private const val RESPONSE_BUFFER_SIZE = 1024

        // DNS header offsets (RFC 1035 §4.1.1 — 12 bytes)
        private const val DNS_HEADER_LEN = 12
        private const val DNS_FLAG_QR_MASK = 0x8000
        private const val DNS_FLAG_OPCODE_MASK = 0x7800
        private const val DNS_FLAG_TC_MASK = 0x0200
        private const val DNS_FLAG_RCODE_MASK = 0x000F
        internal const val DNS_TYPE_A = 1
        internal const val DNS_TYPE_CNAME = 5
        internal const val DNS_TYPE_AAAA = 28
        private const val DNS_CLASS_IN = 1
        private const val DNS_MAX_LABEL_LEN = 63
        private const val DNS_MAX_NAME_WIRE_LEN = 255
        private const val DNS_MAX_POINTER_JUMPS = 64

        internal fun forTest(
            configFlow: Flow<DnsConfig>,
            initialConfig: DnsConfig = DnsConfig(),
            fallbackToSystem: Boolean = true,
            dohClient: OkHttpClient? = null,
            systemDns: Dns = Dns.SYSTEM,
        ): DnsConfigHolder = DnsConfigHolder(configFlow, initialConfig, fallbackToSystem).apply {
            this.dohClientOverride = dohClient
            this.fallbackDns = systemDns
        }

        /**
         * Parse a DoH JSON response (`application/dns-json`).
         *
         * Filters strictly by DNS record type (`1` = A, `28` = AAAA) and parses only numeric IP
         * literals — never calling [InetAddress.getByName] on hostnames or intermediate CNAME
         * records (`type == 5`), which would leak queries to the system resolver.
         */
        internal fun parseDohJson(json: String, expectedType: Int? = null): List<InetAddress> {
            val obj = JSONObject(json)
            if (obj.optInt("Status", 0) != 0) return emptyList()
            val answers = obj.optJSONArray("Answer") ?: return emptyList()
            val results = mutableListOf<InetAddress>()
            for (i in 0 until answers.length()) {
                val a = answers.optJSONObject(i) ?: continue
                val recordType = a.optInt("type", -1)
                if (recordType != DNS_TYPE_A && recordType != DNS_TYPE_AAAA) continue
                if (expectedType != null && recordType != expectedType) continue
                val data = a.optString("data", "").trim()
                if (data.isEmpty()) continue
                parseNumericIpAddress(data, recordType)?.let(results::add)
            }
            return results
        }

        /**
         * Parse a numeric IPv4 (`DNS_TYPE_A`) or IPv6 (`DNS_TYPE_AAAA`) literal directly into its
         * raw address bytes without ever invoking platform DNS resolution.
         */
        internal fun parseNumericIpAddress(literal: String, expectedType: Int): InetAddress? = when (expectedType) {
            DNS_TYPE_A -> parseIpv4Literal(literal)?.let { InetAddress.getByAddress(it) }
            DNS_TYPE_AAAA -> parseIpv6Literal(literal)?.let { Inet6Address.getByAddress(null, it, -1) }
            else -> null
        }

        private fun parseIpv4Literal(literal: String): ByteArray? {
            if (literal.isEmpty() || literal.length > 15) return null
            val parts = literal.split('.')
            if (parts.size != 4) return null
            val bytes = ByteArray(4)
            for (i in 0 until 4) {
                val part = parts[i]
                if (part.isEmpty() || part.length > 3) return null
                if (part.length > 1 && part[0] == '0') return null
                var value = 0
                for (ch in part) {
                    if (ch !in '0'..'9') return null
                    value = value * 10 + (ch - '0')
                }
                if (value > 255) return null
                bytes[i] = value.toByte()
            }
            return bytes
        }

        private fun parseIpv6Literal(literal: String): ByteArray? {
            if (literal.isEmpty() || literal.length > 45) return null
            if ('%' in literal || '[' in literal || ']' in literal) return null

            // Optional IPv4-embedded suffix (e.g. ::ffff:192.0.2.1) occupies the final 4 bytes (2 hextets).
            var ipv6Part = literal
            var ipv4Tail: ByteArray? = null
            if ('.' in literal) {
                val lastColon = literal.lastIndexOf(':')
                if (lastColon < 0) return null
                ipv4Tail = parseIpv4Literal(literal.substring(lastColon + 1)) ?: return null
                ipv6Part = literal.substring(0, lastColon)
                // Preserve "::" when the IPv4 tail directly follows "::" (e.g. "::192.0.2.1", "64:ff9b::192.0.2.1").
                if (ipv6Part.endsWith(':')) ipv6Part += ':'
            }

            val targetHextets = if (ipv4Tail != null) 6 else 8
            val compressAt = ipv6Part.indexOf("::")
            val hextets = IntArray(targetHextets)
            if (compressAt >= 0) {
                if (ipv6Part.indexOf("::", compressAt + 2) >= 0) return null
                val leftRaw = ipv6Part.substring(0, compressAt)
                val rightRaw = ipv6Part.substring(compressAt + 2)
                val left = if (leftRaw.isEmpty()) emptyList() else parseHextetList(leftRaw) ?: return null
                val right = if (rightRaw.isEmpty()) emptyList() else parseHextetList(rightRaw) ?: return null
                if (left.size + right.size >= targetHextets) return null
                for (i in left.indices) hextets[i] = left[i]
                val rightStart = targetHextets - right.size
                for (i in right.indices) hextets[rightStart + i] = right[i]
            } else {
                val groups = parseHextetList(ipv6Part) ?: return null
                if (groups.size != targetHextets) return null
                for (i in groups.indices) hextets[i] = groups[i]
            }

            val bytes = ByteArray(16)
            for (i in 0 until targetHextets) {
                bytes[i * 2] = ((hextets[i] ushr 8) and 0xFF).toByte()
                bytes[i * 2 + 1] = (hextets[i] and 0xFF).toByte()
            }
            if (ipv4Tail != null) {
                System.arraycopy(ipv4Tail, 0, bytes, 12, 4)
            }
            return bytes
        }

        private fun parseHextetList(segment: String): List<Int>? {
            if (segment.startsWith(':') || segment.endsWith(':')) return null
            val parts = segment.split(':')
            val out = ArrayList<Int>(parts.size)
            for (part in parts) {
                if (part.isEmpty() || part.length > 4) return null
                var value = 0
                for (ch in part) {
                    val digit = when (ch) {
                        in '0'..'9' -> ch - '0'
                        in 'a'..'f' -> ch - 'a' + 10
                        in 'A'..'F' -> ch - 'A' + 10
                        else -> return null
                    }
                    value = (value shl 4) or digit
                }
                out.add(value)
            }
            return out
        }

        /**
         * One DNS question for [hostname].
         *
         * [qtype] is [DNS_TYPE_A] or [DNS_TYPE_AAAA] — the UDP resolver asks for both, because DoH always
         * did and a host that publishes only AAAA was unreachable through the plain-DNS path alone.
         *
         * [id] is random per query and checked on the way back. It used to be the constant 1, which makes
         * an off-path forged answer trivial to accept: anything arriving on the socket in time matched.
         */
        fun buildDnsQuery(hostname: String, qtype: Int = DNS_TYPE_A, id: Int = randomQueryId()): ByteArray {
            val normalized = hostname.trim().trimEnd('.')
            require(normalized.isNotEmpty()) { "DNS hostname must not be blank" }
            val labels = normalized.split('.')
            val encodedLabels = labels.map { label ->
                val bytes = label.encodeToByteArray()
                require(bytes.isNotEmpty() && bytes.size <= DNS_MAX_LABEL_LEN) { "Invalid DNS label length" }
                bytes
            }
            val qnameWireLen = encodedLabels.sumOf { it.size + 1 } + 1
            require(qnameWireLen <= DNS_MAX_NAME_WIRE_LEN) { "DNS hostname exceeds maximum wire length" }
            // Header (12) + labels + null terminator + QTYPE (2) + QCLASS (2)
            val size = DNS_HEADER_LEN + qnameWireLen + 4
            val buf = ByteBuffer.allocate(size).order(ByteOrder.BIG_ENDIAN)
            // Header
            buf.putShort(id.toShort()) // ID — random, verified in parseDnsResponse
            buf.putShort(0x0100) // Flags: standard query, recursion desired
            buf.putShort(0x0001) // QDCOUNT = 1
            buf.putShort(0x0000) // ANCOUNT = 0
            buf.putShort(0x0000) // NSCOUNT = 0
            buf.putShort(0x0000) // ARCOUNT = 0
            // Question — QNAME
            for (labelBytes in encodedLabels) {
                buf.put(labelBytes.size.toByte())
                buf.put(labelBytes)
            }
            buf.put(0x00.toByte()) // null terminator
            buf.putShort(qtype.toShort())
            buf.putShort(DNS_CLASS_IN.toShort())
            return buf.array()
        }

        /** A query ID in 1..65535 from a cryptographically strong source. */
        fun randomQueryId(): Int = java.security.SecureRandom().nextInt(0xFFFF) + 1

        fun parseDnsResponse(data: ByteArray, expectedId: Int? = null): List<InetAddress> =
            parseDnsResponse(data, expectedId, expectedType = null)

        internal fun parseDnsResponse(
            data: ByteArray,
            expectedId: Int? = null,
            expectedType: Int? = null,
        ): List<InetAddress> {
            if (data.size < DNS_HEADER_LEN) return emptyList()
            val buf = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN)
            val id = buf.getShort().toInt() and 0xFFFF
            val flags = buf.getShort().toInt() and 0xFFFF
            if (expectedId != null && id != (expectedId and 0xFFFF)) return emptyList()
            // Check QR (response), standard query (opcode == 0), not truncated (TC == 0), NOERROR (rcode == 0).
            val qr = (flags and DNS_FLAG_QR_MASK) != 0
            val opcode = (flags and DNS_FLAG_OPCODE_MASK) ushr 11
            val truncated = (flags and DNS_FLAG_TC_MASK) != 0
            val rcode = flags and DNS_FLAG_RCODE_MASK
            if (!qr || opcode != 0 || truncated || rcode != 0) return emptyList()
            val qdCount = buf.getShort().toInt() and 0xFFFF
            val anCount = buf.getShort().toInt() and 0xFFFF
            buf.getShort() // NSCOUNT — part of the 12-byte RFC 1035 §4.1.1 header
            buf.getShort() // ARCOUNT — part of the 12-byte RFC 1035 §4.1.1 header

            // Question section always starts at byte 12 (DNS_HEADER_LEN).
            var pos = DNS_HEADER_LEN
            for (q in 0 until qdCount) {
                pos = skipDnsName(data, pos)
                if (pos < 0 || pos + 4 > data.size) return emptyList()
                pos += 4 // QTYPE + QCLASS
            }

            // Parse answer records; any truncated/corrupt RR invalidates the packet.
            val results = mutableListOf<InetAddress>()
            for (a in 0 until anCount) {
                pos = skipDnsName(data, pos)
                if (pos < 0 || pos + 10 > data.size) return emptyList()
                val atype = ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
                val aclass = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
                val rdLen = ((data[pos + 8].toInt() and 0xFF) shl 8) or (data[pos + 9].toInt() and 0xFF)
                val rdPos = pos + 10
                if (rdPos + rdLen > data.size) return emptyList()
                if (aclass == DNS_CLASS_IN && (expectedType == null || atype == expectedType)) {
                    when (atype) {
                        DNS_TYPE_A -> {
                            if (rdLen != 4) return emptyList()
                            results.add(InetAddress.getByAddress(data.copyOfRange(rdPos, rdPos + 4)))
                        }
                        DNS_TYPE_AAAA -> {
                            if (rdLen != 16) return emptyList()
                            results.add(Inet6Address.getByAddress(null, data.copyOfRange(rdPos, rdPos + 16), -1))
                        }
                    }
                }
                pos = rdPos + rdLen
            }
            return results
        }

        private fun skipDnsName(data: ByteArray, start: Int): Int {
            if (start < 0 || start >= data.size) return -1
            var pos = start
            var wireLen = 0
            while (pos < data.size) {
                val len = data[pos].toInt() and 0xFF
                if (len == 0) return pos + 1 // null terminator
                val typeBits = len and 0xC0
                if (typeBits == 0xC0) {
                    if (pos + 2 > data.size) return -1
                    val ptr = ((len and 0x3F) shl 8) or (data[pos + 1].toInt() and 0xFF)
                    if (!isValidPointerTarget(data, ptr, pos)) return -1
                    return pos + 2 // compression pointer terminates the name
                }
                if (typeBits != 0) return -1 // reserved label bits (0x40 / 0x80)
                val next = pos + 1 + len
                wireLen += 1 + len
                if (next > data.size || wireLen > DNS_MAX_NAME_WIRE_LEN) return -1
                pos = next
            }
            return -1
        }

        private fun isValidPointerTarget(data: ByteArray, target: Int, origin: Int): Boolean {
            if (target < DNS_HEADER_LEN || target >= data.size || target == origin) return false
            var pos = target
            var jumps = 0
            var wireLen = 0
            val seen = HashSet<Int>()
            while (pos < data.size) {
                val len = data[pos].toInt() and 0xFF
                if (len == 0) return true
                val typeBits = len and 0xC0
                if (typeBits == 0xC0) {
                    if (pos + 2 > data.size || !seen.add(pos) || ++jumps > DNS_MAX_POINTER_JUMPS) return false
                    val nextPtr = ((len and 0x3F) shl 8) or (data[pos + 1].toInt() and 0xFF)
                    if (nextPtr < DNS_HEADER_LEN || nextPtr >= data.size) return false
                    pos = nextPtr
                    continue
                }
                if (typeBits != 0) return false
                val next = pos + 1 + len
                wireLen += 1 + len
                if (next > data.size || wireLen > DNS_MAX_NAME_WIRE_LEN) return false
                pos = next
            }
            return false
        }
    }
}
