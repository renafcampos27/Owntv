package tv.own.owntv.core.epg

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.EpgProgrammeEntity
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.parser.XtreamClient
import java.util.TimeZone
import java.net.URI

/**
 * Builds catch-up / archive playback URLs for a past programme (#13 / Catch-up TV).
 *
 * Two provider conventions:
 *  - **M3U** carries a `catchup-source` URL *template* with placeholders (`${start}`, `{utc}`,
 *    `{Y}-{m}-{d}`, …) that [fromTemplate] fills from the programme's start/end. A `catchup="append"`
 *    channel instead *appends* its template to the live URL — that join is the caller's job.
 *  - **Xtream** has no template; its timeshift URL is built from the source credentials (see
 *    `XtreamClient.timeshiftUrl`).
 *
 * Pure string work, no I/O — easy to unit-test and reuse from any layer.
 */
object CatchupUrl {

    /** Positive correction requests a later archive instant; display metadata stays untouched. */
    fun requestStartMs(displayStartMs: Long, correctionMinutes: Int): Long =
        displayStartMs + correctionMinutes * 60_000L

    /** Copy only at the request boundary, preserving duration and the original programme. */
    fun requestProgramme(programme: EpgProgrammeEntity, correctionMinutes: Int): EpgProgrammeEntity =
        EpgShift.apply(programme, correctionMinutes)


    /** Unix-second tokens (both `${name}` and `{name}`, case-insensitive) → their value. */
    private val START_TOKENS = setOf("start", "utc", "start-timestamp", "utcstart")
    private val END_TOKENS = setOf("end", "utcend", "end-timestamp", "stop")

    /** "Now", in unix seconds. `catchup-source="…?utc={utc}&lutc={lutc}"` is one of the most common
     *  templates in the wild, and an unsubstituted `{lutc}` reached the provider verbatim.
     *  `timestamp` is now as well — Kodi documents `${timestamp}` as "same as `{lutc}`", and TiviMate
     *  agrees; it used to be sent as the programme start. */
    private val NOW_TOKENS = setOf("lutc", "now", "timenow", "currenttime", "timestamp")

    /** `{name}` / `${name}`, optionally with an argument after a colon: `{duration:60}`, `{utc:YmdHMS}`. */
    private val TOKEN = Regex("\\$?\\{([A-Za-z_][A-Za-z0-9_-]*)(?::([^}]*))?\\}")

    /**
     * Fill an M3U `catchup-source` [template] for the programme spanning [startMs]..[endMs].
     * Recognised placeholders (UTC), after Kodi IPTV Simple, the de-facto reference:
     *  - unix start/end/now, and duration/offset in seconds;
     *  - `{duration:X}` / `{offset:X}` — the same divided by X seconds (`{duration:60}` = minutes);
     *  - `{utc:FMT}`, `${start:FMT}`, `{utcend:FMT}`, `${end:FMT}`, `{lutc:FMT}`, `${now:FMT}`,
     *    `${timestamp:FMT}` — that instant formatted, the letters Y m d H M S replaced and anything
     *    else kept (`{utc:Ymd-H-M}` → `20210101-00-00`);
     *  - the bare date parts Y/m/d/H/M/S of the start.
     * Unknown placeholders are left untouched so unusual templates degrade gracefully.
     */
    fun fromTemplate(template: String, startMs: Long, endMs: Long, nowMs: Long = System.currentTimeMillis(), legacyTimestampAsStart: Boolean = false): String {
        val startS = startMs / 1000
        val endS = endMs / 1000
        val durationS = ((endMs - startMs) / 1000).coerceAtLeast(0)
        val offsetS = ((nowMs - startMs) / 1000).coerceAtLeast(0)
        return TOKEN.replace(template) { match ->
            val raw = match.groupValues[1]
            val name = raw.lowercase()
            val arg = match.groups[2]?.value
            val instantMs = when {
                legacyTimestampAsStart && name == "timestamp" -> startMs
                name in START_TOKENS -> startMs
                name in END_TOKENS -> endMs
                name in NOW_TOKENS -> nowMs
                else -> null
            }
            when {
                arg != null -> when {
                    instantMs != null && arg.isNotEmpty() -> formatUtc(instantMs, arg)
                    name == "duration" -> divided(durationS, arg) ?: match.value
                    name == "offset" -> divided(offsetS, arg) ?: match.value
                    else -> match.value
                }
                instantMs != null -> (instantMs / 1000).toString()
                name == "duration" -> durationS.toString()
                name == "offset" -> offsetS.toString()
                // Date parts are single-letter and case-sensitive in the wild (M = month/minute), so map
                // by the ORIGINAL token: Y/m/d/H/M/S.
                raw.length == 1 && raw[0] in DATE_LETTERS -> formatUtc(startMs, raw)
                else -> match.value // unknown placeholder: leave as-is
            }
        }
    }

    private const val DATE_LETTERS = "YmdHMS"

    /** [seconds] divided by the whole number [arg]; null when [arg] is not a positive number. */
    private fun divided(seconds: Long, arg: String): String? =
        arg.toLongOrNull()?.takeIf { it > 0 }?.let { (seconds / it).toString() }

    /** [ms] in UTC, with each of Y m d H M S in [format] replaced by that field; other characters kept. */
    private fun formatUtc(ms: Long, format: String): String {
        val cal = java.util.Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = ms }
        fun two(n: Int) = n.toString().padStart(2, '0')
        return buildString {
            format.forEach { c ->
                append(
                    when (c) {
                        'Y' -> cal.get(java.util.Calendar.YEAR).toString()
                        'm' -> two(cal.get(java.util.Calendar.MONTH) + 1)
                        'd' -> two(cal.get(java.util.Calendar.DAY_OF_MONTH))
                        'H' -> two(cal.get(java.util.Calendar.HOUR_OF_DAY))
                        'M' -> two(cal.get(java.util.Calendar.MINUTE))
                        'S' -> two(cal.get(java.util.Calendar.SECOND))
                        else -> c.toString()
                    },
                )
            }
        }
    }

    /**
     * Build the catch-up URL for a [programme] on [channel] given its resolved [source] and the [tz] the
     * provider expects timeshift timestamps in. Shared by the Guide and Live TV catch-up entry points.
     */
    fun forSource(
        channel: ChannelEntity,
        programme: EpgProgrammeEntity,
        source: SourceEntity,
        tz: TimeZone,
        xtream: XtreamClient,
    ): String? {
        if (!channel.catchup) return null
        return when (source.type) {
            SourceType.XTREAM -> channel.remoteId?.let { streamId ->
                val durationMin = (((programme.stopMs - programme.startMs) / 60_000L).toInt()).coerceAtLeast(1)
                // TS is the conservative default. The archive playback resolver applies its own
                // format preference; the live HLS preference must never rewrite an archive URL.
                xtream.timeshiftUrl(source, streamId, programme.startMs, durationMin, tz, "ts")
            }
            // F17 — the catch-up TYPE is now persisted, so `append` (and the templateless styles)
            // finally reach [forM3u]; it used to be hardcoded to null here.
            SourceType.M3U -> forM3u(
                channel.streamUrl,
                channel.catchupType,
                channel.catchupSource,
                programme.startMs,
                programme.stopMs,
                tz,
                correctionMin = channel.catchupCorrectionMin,
            )
            else -> null
        }
    }

    private val TIMESHIFT_PATH = Regex(
        "^(.+?)/timeshift/([^/]+)/([^/]+)/([^/]+)/([^/]+)/([^/.]+)\\.(?:ts|m3u8)$",
        RegexOption.IGNORE_CASE,
    )

    /**
     * Convert a path-style Xtream catch-up URL
     * (`…/timeshift/user/pass/duration/start/streamId.ts`) into the PHP query form
     * (`…/streaming/timeshift.php?username=…&password=…&stream=…&start=…&duration=…`) that some panels
     * require instead. Returns null if [url] isn't a recognised timeshift path. The player tries this
     * automatically when the path form is rejected (issue: some panels reply with an HTML error page).
     */
    fun timeshiftPhpAlternate(url: String?): String? {
        val parsed = url?.toHttpUrlOrNull() ?: return null
        val address = parsed.newBuilder().query(null).fragment(null).build().toString()
        val g = TIMESHIFT_PATH.find(address)?.groupValues ?: return null
        val parts = parsed.pathSegments.takeLast(5)
        return timeshiftPhp(g[1], parts[0], parts[1], parts[4].substringBeforeLast('.'),
            parts[3], parts[2], parsed.encodedQuery)
    }

    /** Path segments are decoded once by HttpUrl; query values are encoded for their new context. */
    private fun timeshiftPhp(base: String, username: String, password: String, stream: String,
        start: String, duration: String, encodedQuery: String?): String? {
        val builder = (base.toHttpUrlOrNull() ?: return null).newBuilder()
            .query(null).fragment(null)
            .addPathSegment("streaming").addPathSegment("timeshift.php")
            .addQueryParameter("username", username)
            .addQueryParameter("password", password)
            .addQueryParameter("stream", stream)
            .addQueryParameter("start", start)
            .addQueryParameter("duration", duration)
        // Colons are legal in query values; retain the existing timestamp spelling for providers.
        val query = builder.build().encodedQuery!!.replace("%3A", ":")
        // Provider tokens are already encoded. Preserve their spelling, order and duplicate keys.
        builder.encodedQuery(query + if (encodedQuery.isNullOrEmpty()) "" else "&$encodedQuery")
        return builder.build().toString()
    }

    /** Rewrite only recognised Xtream archive paths, preserving query tokens. */
    fun timeshiftFormat(url: String, extension: String): String? {
        if (extension != "ts" && extension != "m3u8") return null
        val path = url.substringBefore('?')
        if (!TIMESHIFT_PATH.matches(path)) return null
        val query = url.substringAfter('?', "").let { if (it.isEmpty()) "" else "?$it" }
        return path.substringBeforeLast('.') + ".$extension" + query
    }

    /**
     * Resolve an M3U channel's catch-up URL from its `catchup` [catchupType] and `catchup-source`
     * [catchupSource] template. Returns null when nothing usable can be built.
     *
     * Four conventions, in the order playlists use them:
     *  - **append** — the template is a query fragment joined onto the [liveUrl] (the most common form,
     *    and previously unreachable because the type was never stored, F17).
     *  - **shift / timeshift** — usually typeless: append the standard `?utc=…&lutc=…` pair.
     *  - **flussonic** — no template at all; the archive lives at a different path on the same server.
     *  - **xc** — an Xtream panel behind an M3U playlist: rebuild the URL as `timeshift.php`.
     *
     * A plain template with no type is substituted as-is, exactly as before.
     */
    fun forM3u(
        liveUrl: String,
        catchupType: String?,
        catchupSource: String?,
        startMs: Long,
        endMs: Long,
        tz: TimeZone = TimeZone.getTimeZone("UTC"),
        bounded: Boolean = true,
        correctionMin: Int = 0,
    ): String? {
        val template = catchupSource?.takeIf { it.isNotBlank() }
        val type = catchupType?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        if (type in setOf("none", "off", "false", "0")) return null
        val start = requestStartMs(startMs, correctionMin)
        val end = requestStartMs(endMs, correctionMin)
        return when {
            template != null -> resolveTemplate(liveUrl, fromTemplate(template.trim(), start, end), type == "append")
            type == "shift" || type == "timeshift" || type == "default" -> joinQuery(liveUrl, fromTemplate(SHIFT_TEMPLATE, start, end))
            type != null && type.startsWith("flussonic") -> flussonic(liveUrl, start, end, bounded)
            type == "xc" || type == "xtream" -> xtreamStyle(liveUrl, start, end, tz)
            // A bare catchup="default" with no source needs server support we can't model.
            else -> null
        }
    }

    /** Archive days describe retention, not a mechanism capable of constructing an archive request. */
    fun canBuildM3u(liveUrl: String, type: String?, template: String?): Boolean {
        if (type.isNullOrBlank() && template.isNullOrBlank()) return false
        val sample = forM3u(liveUrl, type, template, 1_600_000_000_000L, 1_600_003_600_000L) ?: return false
        return runCatching { URI(sample).let { it.scheme?.lowercase(java.util.Locale.ROOT) in listOf("http", "https") && !it.host.isNullOrBlank() } }.getOrDefault(false)
    }

    /** Query fragments keep live tokens; path references use URI resolution, never query concatenation. */
    private fun resolveTemplate(base: String, template: String, append: Boolean): String? = runCatching {
        val bareQuery = append && template.substringBefore('?').let { '=' in it && '/' !in it && ':' !in it }
        val result = if (template.startsWith('?') || template.startsWith('&') || bareQuery) joinQuery(base, template)
            else URI(base).resolve(URI(template)).toString()
        URI(result).takeIf { it.scheme?.lowercase(java.util.Locale.ROOT) in listOf("http", "https") && !it.host.isNullOrBlank() }?.toString()
    }.getOrNull()

    /** The `shift` convention's fixed query. */
    private const val SHIFT_TEMPLATE = "?utc={utc}&lutc={lutc}"

    /**
     * Join an appended query [fragment] onto [base]. A channel URL that already carries a query (a CDN
     * token, say) would otherwise get a second `?` and be rejected outright, so the separator is
     * corrected — everything else is appended verbatim, as the convention expects.
     */
    private fun joinQuery(base: String, fragment: String): String {
        if (fragment.isEmpty()) return base
        // Playlists write the fragment three ways — "?utc=…", "&utc=…" and a bare "utc=…" — and only the
        // first was handled. A bare fragment concatenated onto a URL that already carried a query produced
        // "…?token=abcutc=1700000000", which the archive answers with a 404.
        val body = fragment.substringBefore('#').removePrefix("?").removePrefix("&")
        val anchor = fragment.substringAfter('#', base.substringAfter('#', ""))
        val address = base.substringBefore('#')
        val joined = if (address.contains('?')) "$address&$body" else "$address?$body"
        return joined + if (anchor.isNotEmpty()) "#$anchor" else ""
    }

    /**
     * Flussonic: the archive is a sibling of the live playlist —
     * A picked programme uses a finite `index-<start>-<duration>[.fmp4].m3u8` window;
     * rolling rewind keeps `timeshift_abs-<start>[.fmp4].m3u8`. The MPEG-TS forms
     * (`…/channel/mpegts`, `…/channel/index.ts`) → `…/channel/archive-<start>-<duration>.ts`.
     * Any query string is preserved. Returns null when the URL doesn't look like one of those.
     */
    private fun flussonic(liveUrl: String, startMs: Long, endMs: Long, bounded: Boolean): String? {
        if (bounded && endMs <= startMs) return null
        val query = liveUrl.substringAfter('?', "").let { if (it.isEmpty()) "" else "?$it" }
        val path = liveUrl.substringBefore('?')
        val slash = path.lastIndexOf('/')
        if (slash <= 0) return null
        val last = path.substring(slash + 1).lowercase()
        val prefix = path.substring(0, slash + 1)
        val startS = startMs / 1000
        val durationS = ((endMs - startMs) / 1000).coerceAtLeast(1)
        return when {
            last.endsWith(".m3u8") -> {
                val suffix = if (last.endsWith(".fmp4.m3u8")) ".fmp4.m3u8" else ".m3u8"
                val window = if (bounded) "index-$startS-$durationS" else "timeshift_abs-$startS"
                "$prefix$window$suffix$query"
            }
            last == "mpegts" || last.endsWith(".ts") -> "${prefix}archive-$startS-$durationS.ts$query"
            else -> null
        }
    }

    private val XC_LIVE_URL = Regex(
        "^(https?://[^/]+)/(?:live/)?([^/]+)/([^/]+)/(\\d+)(?:\\.[A-Za-z0-9]+)?$",
        RegexOption.IGNORE_CASE,
    )

    /**
     * `catchup="xc"` — an Xtream panel served through a plain M3U playlist. The live URL carries the
     * credentials (`…/live/user/pass/1234.ts`), so the panel's own timeshift endpoint can be rebuilt
     * from it. The start timestamp is local to the provider, hence [tz]. Null when the URL isn't in
     * that shape.
     */
    private fun xtreamStyle(liveUrl: String, startMs: Long, endMs: Long, tz: TimeZone): String? {
        val parsed = liveUrl.toHttpUrlOrNull() ?: return null
        val address = parsed.newBuilder().query(null).fragment(null).build().toString()
        val g = XC_LIVE_URL.find(address)?.groupValues ?: return null
        val parts = parsed.pathSegments.takeLast(3)
        val durationMin = (((endMs - startMs) / 60_000L).toInt()).coerceAtLeast(1)
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd:HH-mm", java.util.Locale.US).apply { timeZone = tz }
        val start = fmt.format(java.util.Date(startMs))
        return timeshiftPhp(g[1], parts[0], parts[1], g[4], start, durationMin.toString(), parsed.encodedQuery)
    }
}
