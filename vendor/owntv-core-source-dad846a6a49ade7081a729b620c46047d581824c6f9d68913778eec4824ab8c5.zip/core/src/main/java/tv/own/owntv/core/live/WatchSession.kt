package tv.own.owntv.core.live

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

/**
 * Which playlist the user is watching right now, so background work can step out of its way.
 *
 * This exists because [OpenStreamRegistry] cannot answer the question, although it looks as though
 * it should. That register is the **connection budget** — Multiview tiles and recordings claim
 * against it because they have to ask "may I open one more?". Fullscreen playback never asks, so it
 * never claims, so `openOn(sourceId).total > 0` is false for the single most important case there
 * is. The background catalogue drain was gated on exactly that expression and consequently never
 * yielded once; a channel played for four minutes on the reference portal and the drain paged
 * straight through it (plan N1f-3, §4D).
 *
 * The engines in `:player-core` cannot raise this themselves — they are handed a URL and have no
 * notion of a `sourceId`. So it is the host's playback screen, which holds the row, that opens and
 * closes a session. That makes this one of core's assigned hooks, in the same family as
 * `CoreBuildInfo` and `CrashRecorder.diagnostics`: core owns the state and the meaning, the app
 * supplies the event.
 *
 * Deliberately separate from [OpenStreamRegistry] rather than folded into it. Widening that
 * register would mean fullscreen playback spending from a budget shared with recordings, which
 * would start refusing Multiview tiles the user is entitled to. Nothing here can affect Multiview
 * or recordings at all.
 *
 * Also deliberately not persisted, for the same reason the claim register is not: a session left
 * behind by a crash would hold a drain off forever.
 */
class WatchSession {

    /** Owner-scoped lease for one active viewer; releasing it never clears another viewer's lease. */
    data class Lease(val id: Long, val sourceId: Long)

    private val lock = Any()
    private val nextLeaseId = java.util.concurrent.atomic.AtomicLong(0)
    private val legacySources = HashSet<Long>()
    private val leases = LinkedHashMap<Long, Long>() // leaseId -> sourceId
    private val _watching = MutableStateFlow<Set<Long>>(emptySet())

    /** The playlists currently on screen. A set, because Multiview can show several at once. */
    val watching: StateFlow<Set<Long>> = _watching.asStateFlow()

    /** The user started watching something from [sourceId]. Safe to call twice. */
    fun open(sourceId: Long) {
        if (sourceId < 0) return
        val snapshot = synchronized(lock) {
            legacySources.add(sourceId)
            publishLocked()
        }
        Log.i(TAG, "watch open sourceId=$sourceId watching=$snapshot")
    }

    /** Playback of [sourceId] stopped. Safe to call for a session that was never opened. */
    fun close(sourceId: Long) {
        val snapshot = synchronized(lock) {
            legacySources.remove(sourceId)
            publishLocked()
        }
        Log.i(TAG, "watch close sourceId=$sourceId watching=$snapshot")
    }

    /**
     * Acquire an owner-scoped watch lease for [sourceId]. Two concurrent viewers on the same
     * playlist hold independent leases, so closing one never clears the other's reservation.
     */
    fun openLease(sourceId: Long): Lease? {
        if (sourceId < 0) return null
        val lease = Lease(nextLeaseId.incrementAndGet(), sourceId)
        val snapshot = synchronized(lock) {
            leases[lease.id] = sourceId
            publishLocked()
        }
        Log.i(TAG, "watch lease open id=${lease.id} sourceId=$sourceId watching=$snapshot")
        return lease
    }

    /** Release a previously acquired [lease]. Idempotent; leaves other active leases intact. */
    fun close(lease: Lease) {
        val snapshot = synchronized(lock) {
            leases.remove(lease.id)
            publishLocked()
        }
        Log.i(TAG, "watch lease close id=${lease.id} sourceId=${lease.sourceId} watching=$snapshot")
    }

    /**
     * Nothing is playing at all — what a player screen calls when it is torn down and cannot say
     * which source it held. Cheaper and safer than leaking a session.
     */
    fun closeAll() {
        synchronized(lock) {
            legacySources.clear()
            leases.clear()
            _watching.value = emptySet()
        }
    }

    /** Bounded deferral: a permanently playing TV must not leave the guide stale forever. */
    suspend fun awaitIdleWithin(timeoutMs: Long): Boolean = kotlinx.coroutines.withTimeoutOrNull(timeoutMs) {
        watching.first { it.isEmpty() }
        true
    } ?: false

    fun isWatching(sourceId: Long): Boolean = sourceId in _watching.value

    private fun publishLocked(): Set<Long> {
        val merged = buildSet(legacySources.size + leases.size) {
            addAll(legacySources)
            addAll(leases.values)
        }
        _watching.value = merged
        return merged
    }

    private companion object {
        const val TAG = "WatchSession"
    }
}
