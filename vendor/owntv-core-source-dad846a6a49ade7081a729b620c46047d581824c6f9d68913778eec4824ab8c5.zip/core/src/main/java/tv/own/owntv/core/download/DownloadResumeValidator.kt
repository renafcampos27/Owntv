package tv.own.owntv.core.download

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/** Persisted representation identity used to validate Range resumes across retries and restarts. */
internal data class DownloadResumeMetadata(
    val strongETag: String? = null,
    val lastModified: String? = null,
    val lastModifiedStrong: Boolean = false,
    val totalBytes: Long? = null,
) {
    /** RFC 9110 §13.1.5 If-Range validator (strong ETag preferred, else strong HTTP-date). */
    val ifRangeValue: String? get() = strongETag ?: lastModified.takeIf { lastModifiedStrong }
    val hasStrongValidator: Boolean get() = strongETag != null || (lastModifiedStrong && !lastModified.isNullOrBlank())
}

internal data class ContentRangeHeader(
    val first: Long?,
    val last: Long?,
    val completeLength: Long?,
) {
    val isUnsatisfied: Boolean get() = first == null && last == null
}

internal enum class PreserveReason {
    INVALID_RANGE,
    LENGTH_MISMATCH,
    IDENTITY_MISMATCH,
    IDENTITY_UNVERIFIABLE,
    EMPTY_REPLACEMENT,
    UNREQUESTED_PARTIAL,
}

internal sealed interface DownloadResponsePlan {
    /** Validated 206 byte range starting at [startOffset]; safe to append to the partial file. */
    data class Append(
        val startOffset: Long,
        val expectedTotal: Long,
        val expectedBodyBytes: Long,
        val metadata: DownloadResumeMetadata,
    ) : DownloadResponsePlan

    /** Complete 200 representation; write from byte 0 (fresh download, Range ignored, or If-Range refresh). */
    data class RestartFromZero(
        val expectedTotal: Long?,
        val expectedBodyBytes: Long?,
        val metadata: DownloadResumeMetadata,
    ) : DownloadResponsePlan

    /** HTTP 416 confirmed via Content-Range unsatisfied length matching [totalBytes] and coherent identity. */
    data class AlreadyComplete(val totalBytes: Long) : DownloadResponsePlan

    /** HTTP 416 matched unsatisfied length == existing but omitted validators; confirm with HEAD before completing. */
    data class VerifyCompleteViaHead(val expectedBytes: Long) : DownloadResponsePlan

    /** Unverifiable or mismatched splice/416: preserve existing partial on disk without completing or corrupting. */
    data class PreservePartial(val reason: PreserveReason) : DownloadResponsePlan

    /** Transient HTTP error eligible for the normal retry loop. */
    data class RetryableHttpFailure(val code: Int) : DownloadResponsePlan
}

/**
 * RFC 9110 range-resume validation for [DownloadEngine].
 *
 * Ensures a 206 body is appended ONLY when `Content-Range`, expected total length, and strong
 * representation identity agree with the partial bytes on disk, and that HTTP 416 only completes
 * when `Content-Range` confirms unsatisfied total length == existing with coherent identity.
 */
internal object DownloadResumeValidator {
    private val SATISFIED_RANGE = Regex("""bytes\s+(\d+)-(\d+)/(\d+|\*)""", RegexOption.IGNORE_CASE)
    private val UNSATISFIED_RANGE = Regex("""bytes\s+\*/(\d+|\*)""", RegexOption.IGNORE_CASE)

    private enum class IdentityCheck { MATCHED, MISMATCH, MISSING_ON_RESPONSE, UNVERIFIABLE }

    fun parseStrongETag(raw: String?): String? {
        val value = raw?.trim() ?: return null
        if (value.length < 2 || value.startsWith("W/", ignoreCase = true)) return null
        return value.takeIf { it.startsWith('"') && it.endsWith('"') }
    }

    fun isWeakETag(raw: String?): Boolean =
        raw?.trim()?.startsWith("W/", ignoreCase = true) == true

    /** RFC 9110 §8.8.2.2: Last-Modified is strong only when strictly earlier than response Date. */
    fun isStrongLastModified(lastModified: String?, date: String?): Boolean {
        val lm = parseHttpDateSeconds(lastModified) ?: return false
        val dt = parseHttpDateSeconds(date) ?: return false
        return dt - lm >= 1L
    }

    fun parseContentRange(header: String?): ContentRangeHeader? {
        val trimmed = header?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        SATISFIED_RANGE.matchEntire(trimmed)?.let { match ->
            val first = match.groupValues[1].toLongOrNull() ?: return null
            val last = match.groupValues[2].toLongOrNull() ?: return null
            if (first < 0L || last < first) return null
            val totalRaw = match.groupValues[3]
            val total = if (totalRaw == "*") null else totalRaw.toLongOrNull() ?: return null
            if (total != null && total <= last) return null
            return ContentRangeHeader(first = first, last = last, completeLength = total)
        }
        UNSATISFIED_RANGE.matchEntire(trimmed)?.let { match ->
            val totalRaw = match.groupValues[1]
            val total = if (totalRaw == "*") null else totalRaw.toLongOrNull() ?: return null
            return ContentRangeHeader(first = null, last = null, completeLength = total)
        }
        return null
    }

    fun captureMetadata(
        totalBytes: Long?,
        etagHeader: String?,
        lastModifiedHeader: String?,
        dateHeader: String?,
    ): DownloadResumeMetadata {
        val strongETag = parseStrongETag(etagHeader)
        val lm = lastModifiedHeader?.trim()?.takeIf { it.isNotEmpty() }
        val lmStrong = strongETag == null && !isWeakETag(etagHeader) && isStrongLastModified(lm, dateHeader)
        return DownloadResumeMetadata(
            strongETag = strongETag,
            lastModified = lm,
            lastModifiedStrong = lmStrong,
            totalBytes = totalBytes?.takeIf { it > 0L },
        )
    }

    fun evaluate(
        existing: Long,
        saved: DownloadResumeMetadata?,
        recordedTotalBytes: Long,
        code: Int,
        contentRangeHeader: String?,
        contentLength: Long,
        etagHeader: String?,
        lastModifiedHeader: String?,
        dateHeader: String?,
        sentIfRange: String? = null,
    ): DownloadResponsePlan {
        val knownTotal = saved?.totalBytes?.takeIf { it > 0L } ?: recordedTotalBytes.takeIf { it > 0L }

        if (code == 416) {
            if (existing <= 0L) return DownloadResponsePlan.RetryableHttpFailure(416)
            val range = parseContentRange(contentRangeHeader)
            val complete = range?.takeIf { it.isUnsatisfied }?.completeLength
                ?: return DownloadResponsePlan.PreservePartial(PreserveReason.INVALID_RANGE)
            if (complete != existing) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.LENGTH_MISMATCH)
            }
            if (knownTotal != null && knownTotal != complete) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.LENGTH_MISMATCH)
            }
            return when (checkIdentity(saved, etagHeader, lastModifiedHeader)) {
                IdentityCheck.MATCHED -> DownloadResponsePlan.AlreadyComplete(complete)
                IdentityCheck.MISSING_ON_RESPONSE -> DownloadResponsePlan.VerifyCompleteViaHead(complete)
                IdentityCheck.MISMATCH -> DownloadResponsePlan.PreservePartial(PreserveReason.IDENTITY_MISMATCH)
                IdentityCheck.UNVERIFIABLE -> DownloadResponsePlan.PreservePartial(PreserveReason.IDENTITY_UNVERIFIABLE)
            }
        }

        if (code == 206) {
            if (existing <= 0L) return DownloadResponsePlan.PreservePartial(PreserveReason.UNREQUESTED_PARTIAL)
            val range = parseContentRange(contentRangeHeader)
            if (range == null || range.isUnsatisfied || range.first != existing || range.last == null) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.INVALID_RANGE)
            }
            val complete = range.completeLength
                ?: return DownloadResponsePlan.PreservePartial(PreserveReason.INVALID_RANGE)
            if (knownTotal != null && complete != knownTotal) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.LENGTH_MISMATCH)
            }
            val rangeBytes = range.last - range.first + 1L
            if (contentLength >= 0L && contentLength != rangeBytes) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.LENGTH_MISMATCH)
            }
            val identity = checkIdentity(saved, etagHeader, lastModifiedHeader)
            // A conditional 206 can omit Last-Modified. Use the actual request header;
            // persisted metadata alone cannot prove that the request was conditional.
            val confirmedByDate = identity == IdentityCheck.MISSING_ON_RESPONSE &&
                saved?.lastModifiedStrong == true && saved.strongETag == null &&
                sentIfRange != null && sentIfRange == saved.lastModified
            return when (if (confirmedByDate) IdentityCheck.MATCHED else identity) {
                IdentityCheck.MATCHED -> {
                    val refreshed = saved!!.copy(totalBytes = complete)
                    DownloadResponsePlan.Append(
                        startOffset = existing,
                        expectedTotal = complete,
                        expectedBodyBytes = rangeBytes,
                        metadata = refreshed,
                    )
                }
                IdentityCheck.MISMATCH -> DownloadResponsePlan.PreservePartial(PreserveReason.IDENTITY_MISMATCH)
                IdentityCheck.MISSING_ON_RESPONSE,
                IdentityCheck.UNVERIFIABLE,
                -> DownloadResponsePlan.PreservePartial(PreserveReason.IDENTITY_UNVERIFIABLE)
            }
        }

        if (code == 200) {
            if (existing > 0L && contentLength == 0L) {
                return DownloadResponsePlan.PreservePartial(PreserveReason.EMPTY_REPLACEMENT)
            }
            val expected = contentLength.takeIf { it >= 0L }
            val meta = captureMetadata(expected, etagHeader, lastModifiedHeader, dateHeader)
            return DownloadResponsePlan.RestartFromZero(
                expectedTotal = expected,
                expectedBodyBytes = expected,
                metadata = meta,
            )
        }

        return DownloadResponsePlan.RetryableHttpFailure(code)
    }

    /** Confirms a 416 probe against a 200 HEAD response: requires matching length AND strong identity. */
    fun confirmHeadCompletion(
        expectedBytes: Long,
        saved: DownloadResumeMetadata?,
        code: Int,
        contentLength: Long,
        etagHeader: String?,
        lastModifiedHeader: String?,
    ): Boolean {
        if (code != 200 || contentLength != expectedBytes) return false
        return checkIdentity(saved, etagHeader, lastModifiedHeader) == IdentityCheck.MATCHED
    }

    private fun checkIdentity(
        saved: DownloadResumeMetadata?,
        etagHeader: String?,
        lastModifiedHeader: String?,
    ): IdentityCheck {
        if (saved == null || !saved.hasStrongValidator) return IdentityCheck.UNVERIFIABLE
        if (saved.strongETag != null) {
            if (etagHeader.isNullOrBlank()) return IdentityCheck.MISSING_ON_RESPONSE
            val incoming = parseStrongETag(etagHeader) ?: return IdentityCheck.MISMATCH
            return if (incoming == saved.strongETag) IdentityCheck.MATCHED else IdentityCheck.MISMATCH
        }
        // Strong Last-Modified origin without strong ETag.
        if (isWeakETag(etagHeader)) return IdentityCheck.UNVERIFIABLE
        if (lastModifiedHeader.isNullOrBlank()) return IdentityCheck.MISSING_ON_RESPONSE
        return if (lastModifiedHeader.trim() == saved.lastModified) IdentityCheck.MATCHED else IdentityCheck.MISMATCH
    }

    private fun parseHttpDateSeconds(raw: String?): Long? {
        val text = raw?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        return runCatching { ZonedDateTime.parse(text, DateTimeFormatter.RFC_1123_DATE_TIME).toEpochSecond() }.getOrNull()
    }
}
