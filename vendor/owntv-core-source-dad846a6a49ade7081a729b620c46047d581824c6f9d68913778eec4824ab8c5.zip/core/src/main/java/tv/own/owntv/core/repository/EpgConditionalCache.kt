package tv.own.owntv.core.repository

import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import tv.own.owntv.core.network.HttpClient
import java.io.File
import java.security.MessageDigest

/**
 * Complete identity tuple for conditional HTTP EPG revalidation (RFC 9110 §13 / §15.4.5).
 *
 * Binds every dimension that can alter the resource, representation, or imported programme set:
 * store ID, feed URL (including credentials/query), effective User-Agent, source/account
 * configuration key, retention window bounds, and the filtered channel ID set.
 *
 * Serialized on disk only as a SHA-256 digest so URLs with Xtream credentials never hit disk.
 */
internal data class EpgConditionalIdentity(
    val storeId: Long,
    val url: String,
    val effectiveUserAgent: String,
    val sourceIdentityKey: String?,
    val windowBackMs: Long,
    val windowAheadMs: Long,
    val neededChannelIds: Set<String>?,
) {
    fun fingerprint(): String {
        val digest = MessageDigest.getInstance("SHA-256")
        fun updateField(value: String?) {
            if (value == null) {
                digest.update("-:".toByteArray(Charsets.UTF_8))
            } else {
                val bytes = value.toByteArray(Charsets.UTF_8)
                digest.update("${bytes.size}:".toByteArray(Charsets.UTF_8))
                digest.update(bytes)
            }
        }
        updateField(storeId.toString())
        updateField(url)
        updateField(effectiveUserAgent)
        updateField(sourceIdentityKey)
        updateField(windowBackMs.toString())
        updateField(windowAheadMs.toString())
        if (neededChannelIds == null) {
            updateField(null)
        } else {
            val sorted = neededChannelIds.sorted()
            updateField("set:${sorted.size}")
            for (id in sorted) updateField(id)
        }
        return digest.digest().toLowerHex()
    }
}

internal data class EpgConditionalMetadata(
    val version: Int = SCHEMA_VERSION,
    val storeId: Long,
    val identityHash: String,
    val etag: String?,
    val lastModified: String?,
    val contentType: String?,
    val wireEncoding: String?,
    val varyHeaders: List<String>,
    val varyValuesHash: String?,
    val fileLength: Long,
    val fileLastModified: Long,
    val fileSha256: String,
    val syncedAtMs: Long,
    val validatedAtMs: Long,
    val nextUnimportedFutureStartMs: Long?,
) {
    companion object {
        const val SCHEMA_VERSION = 1
    }
}

/**
 * Manages conditional HTTP validators (`ETag` / `Last-Modified`) for promoted XMLTV cache files.
 *
 * A validator is only eligible to send `If-None-Match` / `If-Modified-Since` when:
 * 1. The identity tuple matches (URL, source/account config, User-Agent, retention window, filter).
 * 2. Stored DB programmes exist for the store (`dbProgrammeCount > 0`).
 * 3. The promoted `epg_<storeId>.xmltv` file is present, non-empty, intact (size/mtime/SHA-256),
 *    and still within the cache freshness TTL.
 * 4. The retention horizon has not advanced past any future programme clipped during the last sync.
 * 5. No `Vary: *` or mismatched `Vary` header value prevents reuse.
 */
internal object EpgConditionalCache {
    private const val TAG = "EpgConditionalCache"
    private const val MAX_HASH_VERIFY_BYTES = 32L * 1024L * 1024L

    fun metaFile(cacheDir: File, storeId: Long): File = File(cacheDir, "epg_$storeId$EPG_CACHE_META_SUFFIX")

    private fun tempMetaFile(cacheDir: File, storeId: Long): File =
        File(cacheDir, "epg_$storeId$EPG_CACHE_META_TEMP_SUFFIX")

    fun lookupEligible(
        cacheDir: File,
        cacheFile: File,
        identity: EpgConditionalIdentity,
        dbProgrammeCount: Int,
        nowMs: Long,
        maxCacheAgeMs: Long,
        requestHeaders: Map<String, String>,
    ): EpgConditionalMetadata? {
        if (dbProgrammeCount <= 0) return null
        val meta = read(cacheDir, identity.storeId) ?: return null
        if (meta.version != EpgConditionalMetadata.SCHEMA_VERSION || meta.storeId != identity.storeId) return null
        if (meta.etag.isNullOrBlank() && meta.lastModified.isNullOrBlank()) return null
        if (meta.identityHash != identity.fingerprint()) return null
        if ("*" in meta.varyHeaders) return null
        if (meta.varyHeaders.isNotEmpty() && hashVaryValues(meta.varyHeaders, requestHeaders) != meta.varyValuesHash) {
            return null
        }
        val age = nowMs - meta.validatedAtMs
        if (age < 0L || age >= maxCacheAgeMs) return null
        val horizonEnd = nowMs + identity.windowAheadMs
        if (meta.nextUnimportedFutureStartMs != null && horizonEnd > meta.nextUnimportedFutureStartMs) return null
        if (!verifyLocalFile(cacheFile, meta)) return null
        return meta
    }

    fun validateNotModified(
        cacheFile: File,
        cached: EpgConditionalMetadata,
        responseMeta: HttpClient.ConditionalResponseMeta,
        dbProgrammeCount: Int,
        requestHeaders: Map<String, String>,
    ): Boolean {
        if (dbProgrammeCount <= 0) return false
        val responseVary = parseVaryHeaders(responseMeta.vary)
        if ("*" in responseVary) return false
        if (responseMeta.vary != null && responseVary != cached.varyHeaders) return false
        if (cached.varyHeaders.isNotEmpty() &&
            hashVaryValues(cached.varyHeaders, requestHeaders) != cached.varyValuesHash
        ) return false
        if (!responseMeta.etag.isNullOrBlank() && !cached.etag.isNullOrBlank() &&
            !etagMatches(cached.etag, responseMeta.etag)
        ) return false
        val cachedType = normalizeContentType(cached.contentType)
        val responseType = normalizeContentType(responseMeta.contentType)
        if (cachedType != null && responseType != null && cachedType != responseType) return false
        return verifyLocalFile(cacheFile, cached)
    }

    fun save(
        cacheDir: File,
        cacheFile: File,
        identity: EpgConditionalIdentity,
        responseMeta: HttpClient.ConditionalResponseMeta,
        requestHeaders: Map<String, String>,
        fileSha256: String,
        nowMs: Long,
        nextUnimportedFutureStartMs: Long?,
    ) {
        val etag = responseMeta.etag?.trim()?.takeIf { it.isNotEmpty() }
        val lastModified = responseMeta.lastModified?.trim()?.takeIf { it.isNotEmpty() }
        val varyHeaders = parseVaryHeaders(responseMeta.vary)
        if ((etag == null && lastModified == null) || "*" in varyHeaders ||
            !cacheFile.isFile || cacheFile.length() <= 0L || fileSha256.isBlank()
        ) {
            clear(cacheDir, identity.storeId)
            return
        }
        val meta = EpgConditionalMetadata(
            storeId = identity.storeId,
            identityHash = identity.fingerprint(),
            etag = etag,
            lastModified = lastModified,
            contentType = normalizeContentType(responseMeta.contentType),
            wireEncoding = responseMeta.wireEncoding?.trim()?.lowercase()?.takeIf { it.isNotEmpty() },
            varyHeaders = varyHeaders,
            varyValuesHash = if (varyHeaders.isEmpty()) null else hashVaryValues(varyHeaders, requestHeaders),
            fileLength = cacheFile.length(),
            fileLastModified = cacheFile.lastModified(),
            fileSha256 = fileSha256,
            syncedAtMs = nowMs,
            validatedAtMs = nowMs,
            nextUnimportedFutureStartMs = nextUnimportedFutureStartMs,
        )
        writeAtomic(cacheDir, meta)
    }

    fun touchAfterNotModified(
        cacheDir: File,
        cacheFile: File,
        cached: EpgConditionalMetadata,
        responseMeta: HttpClient.ConditionalResponseMeta,
        nowMs: Long,
    ) {
        runCatching { cacheFile.setLastModified(nowMs) }
        val updated = cached.copy(
            etag = responseMeta.etag?.trim()?.takeIf { it.isNotEmpty() } ?: cached.etag,
            lastModified = responseMeta.lastModified?.trim()?.takeIf { it.isNotEmpty() } ?: cached.lastModified,
            fileLastModified = cacheFile.lastModified(),
            validatedAtMs = nowMs,
        )
        writeAtomic(cacheDir, updated)
    }

    fun clear(cacheDir: File, storeId: Long) {
        runCatching { metaFile(cacheDir, storeId).delete() }
        runCatching { tempMetaFile(cacheDir, storeId).delete() }
    }

    internal fun verifyLocalFile(cacheFile: File, meta: EpgConditionalMetadata): Boolean {
        if (!cacheFile.isFile) return false
        val length = cacheFile.length()
        if (length <= 0L || length != meta.fileLength) return false
        if (meta.fileLastModified > 0L && cacheFile.lastModified() != meta.fileLastModified) return false
        if (length <= MAX_HASH_VERIFY_BYTES) {
            val actualHash = runCatching { sha256File(cacheFile) }.getOrNull() ?: return false
            if (actualHash != meta.fileSha256) return false
        }
        return true
    }

    internal fun etagMatches(expected: String, actual: String): Boolean {
        val normExpected = normalizeWeakEtag(expected)
        val normActual = normalizeWeakEtag(actual)
        return normExpected.isNotEmpty() && normExpected == normActual
    }

    private fun normalizeWeakEtag(raw: String): String {
        val trimmed = raw.trim()
        return if (trimmed.startsWith("W/") || trimmed.startsWith("w/")) trimmed.substring(2).trim() else trimmed
    }

    internal fun normalizeContentType(raw: String?): String? =
        raw?.substringBefore(';')?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }

    internal fun parseVaryHeaders(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(',')
            .map { it.trim().lowercase() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
    }

    private fun hashVaryValues(varyHeaders: List<String>, requestHeaders: Map<String, String>): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val lowered = requestHeaders.entries.associate { (k, v) -> k.lowercase() to v }
        for (header in varyHeaders) {
            val value = lowered[header].orEmpty()
            val entry = "$header=${value.length}:$value\n".toByteArray(Charsets.UTF_8)
            digest.update(entry)
        }
        return digest.digest().toLowerHex()
    }

    private fun sha256File(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(16 * 1024)
        file.inputStream().use { input ->
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                if (n > 0) digest.update(buf, 0, n)
            }
        }
        return digest.digest().toLowerHex()
    }

    private fun read(cacheDir: File, storeId: Long): EpgConditionalMetadata? {
        val file = metaFile(cacheDir, storeId)
        if (!file.isFile || file.length() <= 0L) return null
        return runCatching {
            val obj = JSONObject(file.readText(Charsets.UTF_8))
            val varyJson = obj.optJSONArray("varyHeaders")
            val vary = buildList {
                if (varyJson != null) {
                    for (i in 0 until varyJson.length()) {
                        varyJson.optString(i).trim().lowercase().takeIf { it.isNotEmpty() }?.let(::add)
                    }
                }
            }
            EpgConditionalMetadata(
                version = obj.getInt("version"),
                storeId = obj.getLong("storeId"),
                identityHash = obj.getString("identityHash"),
                etag = obj.optString("etag").takeIf { it.isNotEmpty() },
                lastModified = obj.optString("lastModified").takeIf { it.isNotEmpty() },
                contentType = obj.optString("contentType").takeIf { it.isNotEmpty() },
                wireEncoding = obj.optString("wireEncoding").takeIf { it.isNotEmpty() },
                varyHeaders = vary,
                varyValuesHash = obj.optString("varyValuesHash").takeIf { it.isNotEmpty() },
                fileLength = obj.getLong("fileLength"),
                fileLastModified = obj.getLong("fileLastModified"),
                fileSha256 = obj.getString("fileSha256"),
                syncedAtMs = obj.getLong("syncedAtMs"),
                validatedAtMs = obj.getLong("validatedAtMs"),
                nextUnimportedFutureStartMs = if (obj.has("nextUnimportedFutureStartMs")) {
                    obj.getLong("nextUnimportedFutureStartMs")
                } else {
                    null
                },
            )
        }.onFailure {
            Log.w(TAG, "Ignoring unreadable EPG validator metadata storeId=$storeId")
        }.getOrNull()
    }

    private fun writeAtomic(cacheDir: File, meta: EpgConditionalMetadata) {
        val tmp = tempMetaFile(cacheDir, meta.storeId)
        val target = metaFile(cacheDir, meta.storeId)
        try {
            val obj = JSONObject()
                .put("version", meta.version)
                .put("storeId", meta.storeId)
                .put("identityHash", meta.identityHash)
                .put("fileLength", meta.fileLength)
                .put("fileLastModified", meta.fileLastModified)
                .put("fileSha256", meta.fileSha256)
                .put("syncedAtMs", meta.syncedAtMs)
                .put("validatedAtMs", meta.validatedAtMs)
                .apply {
                    meta.etag?.let { put("etag", it) }
                    meta.lastModified?.let { put("lastModified", it) }
                    meta.contentType?.let { put("contentType", it) }
                    meta.wireEncoding?.let { put("wireEncoding", it) }
                    if (meta.varyHeaders.isNotEmpty()) {
                        put("varyHeaders", JSONArray(meta.varyHeaders))
                        meta.varyValuesHash?.let { put("varyValuesHash", it) }
                    }
                    meta.nextUnimportedFutureStartMs?.let { put("nextUnimportedFutureStartMs", it) }
                }
            tmp.writeText(obj.toString(), Charsets.UTF_8)
            if (!promoteEpgTempFile(tmp, target)) {
                Log.w(TAG, "EPG validator metadata promote failed storeId=${meta.storeId}")
            }
        } catch (failed: Exception) {
            Log.w(TAG, "Unable to persist EPG validator metadata storeId=${meta.storeId}", failed)
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }
}

private fun ByteArray.toLowerHex(): String = joinToString("") { "%02x".format(it) }
