package tv.own.owntv.core.parser

import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Base64

internal enum class ProviderTextEncoding {
    /** Plain-text field — never speculatively Base64-decoded. */
    PLAIN,

    /**
     * Mixed/unverified field where standard providers may send Base64 while non-compliant ones
     * send plain text. Decodes only unambiguous Base64 payloads and preserves ambiguous plain text
     * (such as `"UEFA"`, `"RTVE"`, `"TVI1"`, `"Vida"`).
     */
    AUTO,

    /**
     * Field explicitly known/declared to be Base64-encoded by the protocol or feed context.
     * Decodes any canonical UTF-8 Base64 payload (including short 4-char unpadded encodings such
     * as `"SEJP"` → `"HBO"`), falling back to the original string if decoding fails.
     */
    BASE64_DECLARED,
}

private val BASE64_PATTERN = Regex("[A-Za-z0-9+/]*={0,2}")
private val SUSPICIOUS_ASCII_NOISE = setOf('@', '[', ']', '\\', '^', '`', '{', '}', '|', '~', '<', '>')

internal fun decodeProviderText(
    original: String,
    encoding: ProviderTextEncoding = ProviderTextEncoding.AUTO,
): String {
    if (encoding == ProviderTextEncoding.PLAIN) return original
    val candidate = tryDecodeCanonicalBase64(original) ?: return original
    return when (encoding) {
        ProviderTextEncoding.PLAIN -> original
        ProviderTextEncoding.BASE64_DECLARED -> candidate.decoded
        ProviderTextEncoding.AUTO ->
            if (isUnambiguousBase64(candidate.compact, candidate.decoded)) candidate.decoded else original
    }
}

/** True when [original] is a valid canonical UTF-8 Base64 text payload. */
internal fun isCanonicalBase64Text(original: String): Boolean = tryDecodeCanonicalBase64(original) != null

/** True when [original] is unambiguously Base64-encoded rather than plausible plain text. */
internal fun isUnambiguousBase64Text(original: String): Boolean {
    val candidate = tryDecodeCanonicalBase64(original) ?: return false
    return isUnambiguousBase64(candidate.compact, candidate.decoded)
}

private data class DecodedBase64(val compact: String, val decoded: String)

private fun tryDecodeCanonicalBase64(original: String): DecodedBase64? {
    val trimmed = original.trim()
    if (trimmed.isEmpty()) return null
    // Internal spaces or tabs belong to plain text, never to Base64 payloads.
    if (trimmed.any { it == ' ' || it == '\t' }) return null
    val compact = trimmed.filterNot { it == '\r' || it == '\n' }
    if (compact.length < 2 || compact.length % 4 == 1 || !BASE64_PATTERN.matches(compact)) return null
    return runCatching {
        val bytes = Base64.getDecoder().decode(compact)
        val canonical = Base64.getEncoder().encodeToString(bytes)
        if (compact != canonical && compact != canonical.trimEnd('=')) return@runCatching null
        val decoded = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes))
            .toString()
            .trim()
        if (decoded.isBlank() ||
            decoded.any { (it.isISOControl() && it !in "\n\r\t") || it == '\uFFFD' } ||
            decoded.none(Char::isLetterOrDigit)
        ) null else DecodedBase64(compact, decoded)
    }.getOrNull()
}

private fun isUnambiguousBase64(compact: String, decoded: String): Boolean {
    // Explicit RFC 4648 padding ('=' / '==') with valid canonical UTF-8 text is unambiguous.
    if (compact.endsWith('=')) return true
    if (looksLikePlainWord(compact)) return false
    // Valid multi-byte UTF-8 output (e.g. accented letters like "Notícias") proves UTF-8 encoding.
    if (decoded.any { it.code > 0x7F }) return true
    // Unpadded 4-char ASCII tokens (3 decoded bytes) are inherently ambiguous with channel/title
    // acronyms ("UEFA", "RTVE", "TVI1", "Vida") unless the field is explicitly declared Base64.
    if (compact.length < 8) return false
    // Multi-word decoded output (spaces/newlines) from an 8+ char mixed-case Base64 token.
    if (decoded.any { it == ' ' || it == '\n' }) return true
    // Single-word unpadded 8+ char ASCII decode requires strong Base64 character-class entropy
    // and clean text without accidental symbol noise.
    return base64CharClasses(compact) >= 3 && decoded.none { it in SUSPICIOUS_ASCII_NOISE }
}

private fun looksLikePlainWord(token: String): Boolean {
    if (token.all { it in 'A'..'Z' || it in '0'..'9' }) return true
    if (token.all { it in 'a'..'z' || it in '0'..'9' }) return true
    if (token[0] in 'A'..'Z' && token.drop(1).all { it in 'a'..'z' || it in '0'..'9' }) return true
    return false
}

private fun base64CharClasses(token: String): Int {
    var upper = 0
    var lower = 0
    var digit = 0
    var symbol = 0
    for (ch in token) {
        when (ch) {
            in 'A'..'Z' -> upper = 1
            in 'a'..'z' -> lower = 1
            in '0'..'9' -> digit = 1
            '+', '/' -> symbol = 1
        }
    }
    return upper + lower + digit + symbol
}

/** BOM is authoritative; otherwise UTF-8 is strict, so a wrong charset cannot silently corrupt IDs. */
internal fun playlistReader(input: java.io.InputStream): java.io.BufferedReader {
    val stream = java.io.PushbackInputStream(input, 3)
    val prefix = ByteArray(3)
    var count = 0
    while (count < prefix.size) {
        val n = stream.read(prefix, count, prefix.size - count)
        if (n < 0) break
        if (n == 0) { val b = stream.read(); if (b < 0) break; prefix[count++] = b.toByte() } else count += n
    }
    val utf8 = count >= 3 && prefix[0] == 0xEF.toByte() && prefix[1] == 0xBB.toByte() && prefix[2] == 0xBF.toByte()
    val le = count >= 2 && prefix[0] == 0xFF.toByte() && prefix[1] == 0xFE.toByte()
    val be = count >= 2 && prefix[0] == 0xFE.toByte() && prefix[1] == 0xFF.toByte()
    val skip = if (utf8) 3 else if (le || be) 2 else 0
    if (count > skip) stream.unread(prefix, skip, count - skip)
    val charset = if (le) Charsets.UTF_16LE else if (be) Charsets.UTF_16BE else Charsets.UTF_8
    return java.io.InputStreamReader(stream, charset.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)).buffered()
}
