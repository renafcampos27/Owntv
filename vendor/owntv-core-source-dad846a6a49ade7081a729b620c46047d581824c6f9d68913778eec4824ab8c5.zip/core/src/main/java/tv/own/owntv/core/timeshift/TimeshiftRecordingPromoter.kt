package tv.own.owntv.core.timeshift

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/**
 * Safely promotes already-captured segments from a live [LocalSegmentStore] ring buffer into a
 * standalone MPEG-TS recording file without starving live timeshift admission.
 *
 * ## Safety invariants
 * 1. **One segment pinned at a time:** opens, copies, and immediately releases each segment before
 *    touching the next so ring rotation can always evict retired segments and admit new live data.
 * 2. **Explicit space reserve:** verifies destination free space against [reserveBytes] before
 *    starting and before every segment copy, refusing to exhaust internal/USB storage.
 * 3. **Bounded pin duration:** aborts explicitly if copying a single segment exceeds
 *    [maxSegmentPinMs] (e.g. a stalled or failing USB stick), preventing indefinite ring starvation.
 * 4. **Atomic publication:** writes to `<outputFile>.part`, calls `fsync`, and promotes to
 *    [outputFile] only on clean completion; cancellation or failure deletes `.part` and never
 *    reports the promotion as completed.
 */
class TimeshiftRecordingPromoter(
    private val reserveBytes: Long = DEFAULT_RESERVE_BYTES,
    private val maxSegmentPinMs: Long = DEFAULT_MAX_SEGMENT_PIN_MS,
    private val chunkSizeBytes: Int = DEFAULT_CHUNK_BYTES,
    private val freeBytes: (File) -> Long = { dir -> dir.usableSpace },
    private val clockMs: () -> Long = System::currentTimeMillis,
) {
    init {
        require(reserveBytes >= 0L)
        require(maxSegmentPinMs > 0L)
        require(chunkSizeBytes > 0)
    }

    enum class FailureReason {
        EMPTY_BUFFER,
        INSUFFICIENT_SPACE,
        PIN_TIMEOUT,
        IO_ERROR,
    }

    sealed class Result {
        data class Completed(
            val outputFile: File,
            val bytesWritten: Long,
            val capturedDurationMs: Long,
            val segmentCount: Int,
            val firstSegmentId: Long,
            val lastSegmentId: Long,
            val skippedRotatedSegments: Int,
        ) : Result()

        data class Failed(
            val reason: FailureReason,
            val bytesCopiedBeforeFailure: Long = 0L,
            val durationMsBeforeFailure: Long = 0L,
            val segmentsCopiedBeforeFailure: Int = 0,
        ) : Result()
    }

    /**
     * Promote segments currently present in [store] (optionally bounded to `[fromSegmentId, toSegmentId]`)
     * into [outputFile].
     *
     * Throws [CancellationException] if the coroutine is cancelled after removing the temporary
     * `.part` file so a cancelled promotion can never appear published.
     */
    suspend fun promote(
        store: LocalSegmentStore,
        outputFile: File,
        fromSegmentId: Long? = null,
        toSegmentId: Long? = null,
    ): Result {
        currentCoroutineContext().ensureActive()
        val initial = store.snapshot().filter { seg ->
            (fromSegmentId == null || seg.id >= fromSegmentId) &&
                (toSegmentId == null || seg.id <= toSegmentId)
        }
        if (initial.isEmpty()) return Result.Failed(FailureReason.EMPTY_BUFFER)

        val parentDir = outputFile.parentFile ?: return Result.Failed(FailureReason.IO_ERROR)
        if (!parentDir.exists() && !parentDir.mkdirs()) return Result.Failed(FailureReason.IO_ERROR)

        val estimatedBytes = initial.sumOf { it.bytes }
        val availableAtStart = freeBytes(parentDir)
        if (availableAtStart < reserveBytes || availableAtStart - reserveBytes < estimatedBytes) {
            return Result.Failed(FailureReason.INSUFFICIENT_SPACE)
        }

        val partFile = File(parentDir, "${outputFile.name}$PART_SUFFIX")
        val buffer = ByteArray(chunkSizeBytes)
        var bytesWritten = 0L
        var durationMs = 0L
        var segmentsCopied = 0
        var firstCopiedId = -1L
        var lastCopiedId = -1L
        var skippedRotated = 0

        var failure: Result.Failed? = null
        try {
            FileOutputStream(partFile).use { fos ->
                for (segment in initial) {
                    currentCoroutineContext().ensureActive()
                    val freeNow = freeBytes(parentDir)
                    if (freeNow < reserveBytes || freeNow - reserveBytes < segment.bytes) {
                        failure = Result.Failed(FailureReason.INSUFFICIENT_SPACE, bytesWritten, durationMs, segmentsCopied)
                        break
                    }

                    // Pin ONLY this single segment and release immediately on exit so live writes
                    // always have headroom in the circular ring buffer.
                    val reader = store.open(segment.id)
                    if (reader == null) {
                        skippedRotated++
                        continue
                    }
                    val pinStartedMs = clockMs()
                    var segBytes = 0L
                    reader.use { pinned ->
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = pinned.input.read(buffer)
                            if (n < 0) break
                            if (n > 0) {
                                fos.write(buffer, 0, n)
                                segBytes += n
                            }
                            if (clockMs() - pinStartedMs > maxSegmentPinMs) {
                                failure = Result.Failed(FailureReason.PIN_TIMEOUT, bytesWritten, durationMs, segmentsCopied)
                                break
                            }
                        }
                    }
                    if (failure != null) break
                    if (segBytes <= 0L) continue
                    if (firstCopiedId < 0L) firstCopiedId = segment.id
                    lastCopiedId = segment.id
                    bytesWritten += segBytes
                    durationMs += segment.durationMs
                    segmentsCopied++
                }
                if (failure == null) {
                    if (segmentsCopied == 0 || bytesWritten <= 0L) {
                        failure = Result.Failed(FailureReason.EMPTY_BUFFER)
                    } else {
                        currentCoroutineContext().ensureActive()
                        fos.flush()
                        fos.fd.sync()
                    }
                }
            }
            failure?.let { failed ->
                runCatching { partFile.delete() }
                return failed
            }

            currentCoroutineContext().ensureActive()
            if (!promotePartFile(partFile, outputFile)) {
                return abort(partFile, FailureReason.IO_ERROR, bytesWritten, durationMs, segmentsCopied)
            }
            return Result.Completed(
                outputFile = outputFile,
                bytesWritten = bytesWritten,
                capturedDurationMs = durationMs,
                segmentCount = segmentsCopied,
                firstSegmentId = firstCopiedId,
                lastSegmentId = lastCopiedId,
                skippedRotatedSegments = skippedRotated,
            )
        } catch (cancelled: CancellationException) {
            runCatching { partFile.delete() }
            throw cancelled
        } catch (_: IOException) {
            return abort(partFile, FailureReason.IO_ERROR, bytesWritten, durationMs, segmentsCopied)
        } catch (_: Throwable) {
            runCatching { partFile.delete() }
            return Result.Failed(FailureReason.IO_ERROR, bytesWritten, durationMs, segmentsCopied)
        }
    }

    private fun abort(
        partFile: File,
        reason: FailureReason,
        bytesWritten: Long,
        durationMs: Long,
        segmentsCopied: Int,
    ): Result.Failed {
        runCatching { partFile.delete() }
        return Result.Failed(
            reason = reason,
            bytesCopiedBeforeFailure = bytesWritten,
            durationMsBeforeFailure = durationMs,
            segmentsCopiedBeforeFailure = segmentsCopied,
        )
    }

    private fun promotePartFile(partFile: File, targetFile: File): Boolean {
        if (!partFile.isFile || partFile.length() <= 0L) return false
        val moved = runCatching {
            java.nio.file.Files.move(
                partFile.toPath(),
                targetFile.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE,
            )
        }.isSuccess || runCatching {
            java.nio.file.Files.move(
                partFile.toPath(),
                targetFile.toPath(),
                java.nio.file.StandardCopyOption.REPLACE_EXISTING,
            )
        }.isSuccess
        return moved && targetFile.isFile && targetFile.length() > 0L && !partFile.exists()
    }

    companion object {
        private const val PART_SUFFIX = ".part"
        const val DEFAULT_RESERVE_BYTES = 512L * 1024 * 1024
        const val DEFAULT_MAX_SEGMENT_PIN_MS = 10_000L
        const val DEFAULT_CHUNK_BYTES = 32 * 1024
    }
}
