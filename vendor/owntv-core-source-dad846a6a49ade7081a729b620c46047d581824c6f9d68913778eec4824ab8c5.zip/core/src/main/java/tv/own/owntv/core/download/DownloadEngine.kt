package tv.own.owntv.core.download

import android.content.Context
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import tv.own.owntv.core.database.dao.DownloadDao
import tv.own.owntv.core.database.dao.MovieDao
import tv.own.owntv.core.database.dao.SeriesDao
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.DownloadEntity
import tv.own.owntv.core.model.DownloadStatus
import tv.own.owntv.core.model.MediaType
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.network.cancelBlockingCallWithCoroutine
import tv.own.owntv.core.stalker.StalkerClient
import tv.own.owntv.core.stalker.StreamUrlResolver
import tv.own.owntv.core.storage.MediaTarget
import tv.own.owntv.core.storage.MediaStorageBudget
import java.io.File
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/** What the foreground notification shows about the transfer currently running. */
data class DownloadProgress(val title: String, val downloadedBytes: Long, val totalBytes: Long)

/**
 * The transfer half of downloads, split out of [DownloadManager] so it can run inside
 * [DownloadWorker] — a foreground service — instead of an app-scoped coroutine that Android kills
 * as soon as the user leaves OwnTV (audit item DL1).
 *
 * [DownloadDao] stays the single source of truth: the engine holds no queue of its own, it just
 * drains whatever rows are QUEUED/RUNNING, one at a time, until none are left.
 */
class DownloadEngine(
    /** Only to resolve a stored `filePath` into something writable — a document needs a resolver. */
    private val context: Context,
    private val downloadDao: DownloadDao,
    private val client: OkHttpClient,
    private val sourceDao: SourceDao,
    private val movieDao: MovieDao,
    private val seriesDao: SeriesDao,
    private val streamUrlResolver: StreamUrlResolver,
    private val activityTracker: DownloadActivityTracker,
    private val storageBudget: MediaStorageBudget,
) {
    /** Jobs of transfers currently running, so pause/delete/retry can stop one precisely. */
    private val active = ConcurrentHashMap<Long, Job>()
    private val storageLeases = ConcurrentHashMap<Long, MediaStorageBudget.Lease>()
    private val resumeStore by lazy { DownloadResumeStore(File(context.filesDir, RESUME_STORE_DIR)) }

    /**
     * Ids the user has just paused/deleted. The drain loop skips them: without this, a pause would
     * be undone the moment the loop re-read the queue before the PAUSED row was written.
     */
    private val suppressed = Collections.newSetFromMap(ConcurrentHashMap<Long, Boolean>())

    /** Set whenever a row is queued, so a drain that is about to finish takes one more look. */
    @Volatile
    private var queueDirty = false

    fun markQueued() {
        queueDirty = true
    }

    /** Drop stored resume validators when the user explicitly restarts from zero or deletes a download. */
    fun clearResumeMetadata(id: Long) {
        resumeStore.clear(id)
    }

    /**
     * Run every pending download, oldest first, one at a time, returning when the queue is empty.
     * Each transfer runs as a child job so that cancelling it (pause/delete) does not tear down the
     * drain itself — the next queued item still starts.
     */
    suspend fun drainQueue(onProgress: (DownloadProgress) -> Unit) = coroutineScope {
        // Every progress report also feeds the shell's status pill, so a transfer is visible in the
        // app and not only in the notification shade.
        val report: (DownloadProgress) -> Unit = { activityTracker.progress(it); onProgress(it) }
        val seen = mutableSetOf<Long>()
        while (currentCoroutineContext().isActive) {
            queueDirty = false
            val next = downloadDao.pending().firstOrNull { it.id !in suppressed && it.id !in seen }
            if (next == null) {
                // Something was queued between the read above and now: look again rather than exit,
                // otherwise the kick that follows it would be dropped by ExistingWorkPolicy.KEEP.
                if (queueDirty) continue else return@coroutineScope
            }
            seen += next.id
            val job = launch { runDownload(next.id, report) }
            active[next.id] = job
            try {
                job.join()
            } finally {
                active.remove(next.id, job)
                // Completed, failed, paused or deleted — either way this transfer is no longer live.
                activityTracker.finished()
            }
        }
    }

    /**
     * Stop the transfer of [id] if it is running and wait for it to actually let go of the file,
     * keeping the drain loop off it until [release] is called. Callers write the row's new status
     * in between, while nothing can touch it.
     */
    suspend fun suspendTransfer(id: Long) {
        suppressed += id
        active.remove(id)?.cancelAndJoin()
    }

    fun release(id: Long) {
        suppressed -= id
    }

    private enum class AttemptResult { COMPLETED, RETRY, PRESERVE_PARTIAL_FAILED }

    private suspend fun runDownload(id: Long, onProgress: (DownloadProgress) -> Unit) {
        val d = downloadDao.getById(id) ?: return
        val target = MediaTarget.of(context, d.filePath)
        // A download folder on removable storage can simply be gone (card pulled, USB unplugged),
        // and a folder the user picked through the system picker can have its grant revoked.
        // Fail loudly rather than silently re-homing gigabytes onto internal storage.
        if (target == null) { markFailed(id, d.downloadedBytes, d.totalBytes); return }
        val lease = try { storageBudget.acquire(target) }
        catch (_: MediaStorageBudget.Refused) {
            markFailed(id, DownloadResume.bytesOnDisk(target, d.downloadedBytes), d.totalBytes)
            return
        }
        storageLeases[id] = lease
        try {
            // Resume whenever a partial file is on disk — including a RUNNING row left behind by a
            // process death — instead of only after an explicit pause. retry() deletes the file first,
            // so a deliberate restart still starts from zero.
            if (target.exists() && target.length() == 0L) {
                target.truncate()
                resumeStore.clear(id)
            }
            // Attempt loop (plan D-3): a Stalker `create_link` URL dies after ~2-4 h, so a long download
            // can fail mid-stream. Each attempt re-resolves a FRESH URL from the stored cmd and resumes
            // with an HTTP Range from the bytes already written; a server that ignores Range restarts the
            // file from 0. M3U/Xtream pass through the resolver unchanged, so for them the loop is just a
            // plain transient-error retry with the same URL.
            var attempt = 0
            while (currentCoroutineContext().isActive) {
                attempt++
                val latest = downloadDao.getById(id) ?: d
                val outcome = try {
                    attemptDownload(id, latest, target, onProgress)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (_: MediaStorageBudget.Refused) {
                    markFailed(id, DownloadResume.bytesOnDisk(target, latest.downloadedBytes), latest.totalBytes)
                    return
                } catch (e: Exception) {
                    if (storageBudget.classifyWriteFailure(e, target) != null) {
                        val after = downloadDao.getById(id) ?: latest
                        markFailed(id, DownloadResume.bytesOnDisk(target, after.downloadedBytes), after.totalBytes)
                        return
                    }
                    android.util.Log.w(TAG, "download attempt $attempt/$MAX_ATTEMPTS failed id=$id: ${e.message}")
                    AttemptResult.RETRY
                }
                when (outcome) {
                    AttemptResult.COMPLETED -> return
                    AttemptResult.PRESERVE_PARTIAL_FAILED -> {
                        val after = downloadDao.getById(id) ?: latest
                        markFailed(id, DownloadResume.bytesOnDisk(target, after.downloadedBytes), after.totalBytes)
                        return
                    }
                    AttemptResult.RETRY -> Unit
                }
                if (!currentCoroutineContext().isActive) return // paused/deleted — status already set by caller
                if (attempt >= MAX_ATTEMPTS) {
                    val after = downloadDao.getById(id) ?: latest
                    markFailed(id, DownloadResume.bytesOnDisk(target, after.downloadedBytes), after.totalBytes)
                    return
                }
                delay(RETRY_DELAY_MS * attempt)
            }
        } finally {
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) {
                val latest = downloadDao.getById(id) ?: d
                lease.close(DownloadResume.bytesOnDisk(target, latest.downloadedBytes))
                storageLeases.remove(id)
            }
        }
    }

    /** One download attempt. Validates range offsets, lengths and strong representation identity before splicing or completing. */
    private suspend fun attemptDownload(
        id: Long,
        d: DownloadEntity,
        target: MediaTarget,
        onProgress: (DownloadProgress) -> Unit,
    ): AttemptResult {
        // Resolve at download-start time, fresh every attempt — the row keeps the stored cmd as the
        // item's identity; only this attempt's HTTP request sees the minted URL. A resolve failure
        // (portal down / bad auth) is a retryable attempt like any HTTP failure.
        val (url, userAgent) = resolveTarget(d)
        val existing = DownloadResume.resumeOffset(target)
        val savedMeta = if (existing > 0L) resumeStore.read(id) else null
        val rb = Request.Builder().url(url).header("User-Agent", userAgent)
        if (existing > 0L) {
            rb.header("Range", "bytes=$existing-")
            savedMeta?.ifRangeValue?.let { rb.header(IF_RANGE, it) }
        }
        val call = client.newCall(rb.build())
        return cancelBlockingCallWithCoroutine(call::cancel) {
            call.execute().use { resp ->
                val plan = DownloadResumeValidator.evaluate(
                    existing = existing,
                    saved = savedMeta,
                    recordedTotalBytes = d.totalBytes,
                    sentIfRange = resp.request.header(IF_RANGE),
                    code = resp.code,
                    contentRangeHeader = resp.header("Content-Range"),
                    contentLength = resp.body.contentLength(),
                    etagHeader = resp.header("ETag"),
                    lastModifiedHeader = resp.header("Last-Modified"),
                    dateHeader = resp.header("Date"),
                )
                when (plan) {
                    is DownloadResponsePlan.AlreadyComplete -> {
                        resumeStore.clear(id)
                        downloadDao.updateProgress(id, DownloadStatus.COMPLETED, plan.totalBytes, plan.totalBytes, System.currentTimeMillis())
                        AttemptResult.COMPLETED
                    }
                    is DownloadResponsePlan.VerifyCompleteViaHead -> {
                        resp.close()
                        if (confirmCompleteViaHead(url, userAgent, plan.expectedBytes, savedMeta)) {
                            resumeStore.clear(id)
                            downloadDao.updateProgress(id, DownloadStatus.COMPLETED, plan.expectedBytes, plan.expectedBytes, System.currentTimeMillis())
                            AttemptResult.COMPLETED
                        } else {
                            AttemptResult.PRESERVE_PARTIAL_FAILED
                        }
                    }
                    is DownloadResponsePlan.PreservePartial -> {
                        android.util.Log.w(TAG, "download resume preserved partial id=$id reason=${plan.reason}")
                        AttemptResult.PRESERVE_PARTIAL_FAILED
                    }
                    is DownloadResponsePlan.RetryableHttpFailure -> AttemptResult.RETRY
                    is DownloadResponsePlan.Append -> streamBody(
                        id = id,
                        d = d,
                        target = target,
                        body = resp.body,
                        append = true,
                        startOffset = plan.startOffset,
                        expectedTotal = plan.expectedTotal,
                        expectedBodyBytes = plan.expectedBodyBytes,
                        metadata = plan.metadata,
                        onProgress = onProgress,
                    )
                    is DownloadResponsePlan.RestartFromZero -> streamBody(
                        id = id,
                        d = d,
                        target = target,
                        body = resp.body,
                        append = false,
                        startOffset = 0L,
                        expectedTotal = plan.expectedTotal,
                        expectedBodyBytes = plan.expectedBodyBytes,
                        metadata = plan.metadata,
                        onProgress = onProgress,
                    )
                }
            }
        }
    }

    private suspend fun confirmCompleteViaHead(
        url: String,
        userAgent: String,
        expectedBytes: Long,
        savedMeta: DownloadResumeMetadata?,
    ): Boolean {
        val headCall = client.newCall(Request.Builder().url(url).head().header("User-Agent", userAgent).build())
        return runCatching {
            cancelBlockingCallWithCoroutine(headCall::cancel) {
                headCall.execute().use { headResp ->
                    val contentLength = headResp.header("Content-Length")?.toLongOrNull() ?: headResp.body.contentLength()
                    DownloadResumeValidator.confirmHeadCompletion(
                        expectedBytes = expectedBytes,
                        saved = savedMeta,
                        code = headResp.code,
                        contentLength = contentLength,
                        etagHeader = headResp.header("ETag"),
                        lastModifiedHeader = headResp.header("Last-Modified"),
                    )
                }
            }
        }.getOrDefault(false)
    }

    private suspend fun streamBody(
        id: Long,
        d: DownloadEntity,
        target: MediaTarget,
        body: okhttp3.ResponseBody,
        append: Boolean,
        startOffset: Long,
        expectedTotal: Long?,
        expectedBodyBytes: Long?,
        metadata: DownloadResumeMetadata,
        onProgress: (DownloadProgress) -> Unit,
    ): AttemptResult {
        val reportedTotal = expectedTotal ?: DownloadResume.expectedTotal(append, startOffset, body.contentLength())
        var done = startOffset
        var readFromBody = 0L
        downloadDao.updateProgress(id, DownloadStatus.RUNNING, done, reportedTotal, System.currentTimeMillis())
        onProgress(DownloadProgress(d.title, done, reportedTotal))
        body.byteStream().use { input ->
            // Commit an empty replacement before publishing its identity. Some document
            // providers apply truncation on close. An interrupted replacement can then
            // only leave the old bytes with their old validator, or an empty/new file.
            if (!append && target is MediaTarget.Document && target.exists()) {
                target.openOutput(false).use { }
                if (target.length() > 0L) return AttemptResult.PRESERVE_PARTIAL_FAILED
            }
            target.openOutput(append).use { out ->
                resumeStore.write(id, metadata)
                val buf = ByteArray(128 * 1024)
                var lastTick = 0L
                while (true) {
                    if (!currentCoroutineContext().isActive) return AttemptResult.RETRY
                    val n = input.read(buf)
                    if (n < 0) break
                    storageLeases[id]?.reserve(done + n)
                    out.write(buf, 0, n)
                    done += n
                    readFromBody += n
                    storageLeases[id]?.commit(done)
                    val t = System.currentTimeMillis()
                    if (t - lastTick > 500) {
                        downloadDao.updateProgress(id, DownloadStatus.RUNNING, done, reportedTotal, t)
                        onProgress(DownloadProgress(d.title, done, reportedTotal))
                        lastTick = t
                    }
                }
            }
        }
        if (expectedBodyBytes != null && readFromBody != expectedBodyBytes) {
            downloadDao.updateProgress(id, DownloadStatus.RUNNING, done, reportedTotal, System.currentTimeMillis())
            return AttemptResult.RETRY
        }
        val size = target.length()
        if (expectedTotal != null && size != expectedTotal) {
            downloadDao.updateProgress(id, DownloadStatus.RUNNING, size, expectedTotal, System.currentTimeMillis())
            return AttemptResult.RETRY
        }
        if (size <= 0L && expectedTotal != 0L) {
            return AttemptResult.RETRY
        }
        resumeStore.clear(id)
        downloadDao.updateProgress(id, DownloadStatus.COMPLETED, size, size, System.currentTimeMillis())
        return AttemptResult.COMPLETED
    }

    /**
     * The URL + User-Agent this download should fetch. Non-Stalker rows return their stored
     * `streamUrl` untouched (byte-identical to the pre-D-3 behavior). Stalker rows mint a playable
     * URL via `create_link` from the stored cmd — episodes carry `series=<ep>` (the season cmd is
     * shared, looked up from the episode row) — and fetch with the source's MAG-style User-Agent.
     * If the catalog item was pruned by a re-sync mid-queue, falls back to the stored URL (a Stalker
     * cmd will then fail → FAILED, which is the honest outcome).
     */
    private suspend fun resolveTarget(d: DownloadEntity): Pair<String, String> {
        val (sourceId, episode) = when (d.mediaType) {
            MediaType.EPISODE -> {
                val ep = seriesDao.getEpisodeById(d.itemId)
                val show = ep?.let { seriesDao.getSeriesById(it.seriesId) }
                show?.sourceId to ep?.episodeNumber
            }
            else -> movieDao.getById(d.itemId)?.sourceId to null
        }
        val source = sourceId?.let { sourceDao.getById(it) }
        if (source == null || !streamUrlResolver.needsResolve(source)) {
            return d.streamUrl to HttpClient.DEFAULT_USER_AGENT
        }
        val ua = source.userAgent?.takeIf { it.isNotBlank() } ?: StalkerClient.DEFAULT_MAG_USER_AGENT
        return streamUrlResolver.resolve(source, d.streamUrl, vod = true, episode = episode) to ua
    }

    /** Keep the real partial byte count — a 90%-then-failed download showing 0 bytes is misleading,
     *  and the partial file IS still on disk (resume/retry can use it). */
    private suspend fun markFailed(id: Long, downloaded: Long, total: Long) {
        downloadDao.updateProgress(id, DownloadStatus.FAILED, downloaded.coerceAtLeast(0), total, System.currentTimeMillis())
    }

    private companion object {
        const val IF_RANGE = "If-Range"
        const val TAG = "DownloadManager"
        const val RESUME_STORE_DIR = "owntv-download-resume"

        /** Attempts per download — attempt 2/3 re-resolve the URL and resume via Range (D-3). */
        const val MAX_ATTEMPTS = 3
        const val RETRY_DELAY_MS = 2_000L
    }
}
