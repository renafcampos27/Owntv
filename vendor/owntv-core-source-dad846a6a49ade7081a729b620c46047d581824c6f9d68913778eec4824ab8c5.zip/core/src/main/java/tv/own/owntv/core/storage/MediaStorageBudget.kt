package tv.own.owntv.core.storage

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import tv.own.owntv.core.database.dao.DownloadDao
import tv.own.owntv.core.database.dao.RecordingDao
import tv.own.owntv.core.settings.SettingsRepository
import java.io.File

/** Rebuilt from all profiles' durable rows after restart; no filesystem scan on the UI thread. */
class MediaStorageBudget(private val context: Context, private val settings: SettingsRepository,
    private val recordings: RecordingDao, private val downloads: DownloadDao) {
    enum class Reason { UNAVAILABLE, QUOTA, NO_SPACE, FILE_LIMIT }
    class Refused(val reason: Reason) : java.io.IOException()
    data class Info(val known: Boolean, val free: Long = 0, val total: Long = 0, val reserve: Long = 0,
        val quota: Long = 0, val used: Long = 0, val removable: Boolean = false) {
        val usableBytes: Long get() = if (!known) 0L else minOf(
            (free - reserve).coerceAtLeast(0L),
            if (quota > 0) (quota - used).coerceAtLeast(0L) else Long.MAX_VALUE
        )
        val estimatedRemainingMs: Long get() = estimateDurationMs(usableBytes)
    }

    companion object {
        /** Conservative standard HD streaming bitrate (~5 Mbps). */
        const val CONSERVATIVE_HD_BITRATE_BPS = 5_000_000L
        /** Safety margin (~10% buffer for container overhead & bitrate spikes). */
        const val BITRATE_SAFETY_MARGIN = 1.10
        /** Effective conservative bytes per second: (5_000_000 * 1.10) / 8 = 687_500 bytes/sec (~2.47 GB/h). */
        const val CONSERVATIVE_BYTES_PER_SECOND = (CONSERVATIVE_HD_BITRATE_BPS * BITRATE_SAFETY_MARGIN / 8).toLong()

        /**
         * Estimates remaining recording duration in milliseconds based on usable bytes.
         */
        fun estimateDurationMs(usableBytes: Long): Long {
            if (usableBytes <= 0L) return 0L
            val seconds = usableBytes / CONSERVATIVE_BYTES_PER_SECOND
            return seconds * 1000L
        }
    }
    private val ledgers = mutableMapOf<String, StorageQuotaLedger>()
    private val mutex = Mutex()
    private val refreshMutex = Mutex()
    @Volatile private var refreshedAt = 0L
    private val physical = java.util.concurrent.ConcurrentHashMap<String, PhysicalStorageLedger>()

    private suspend fun quota(volume: StorageVolumeInfo) = (if (volume.removable) settings.externalMediaQuotaGiB.first()
        else settings.internalMediaQuotaGiB.first()) * StorageQuotaPolicy.GIB

    private suspend fun scanStorageUsage(): Pair<Map<String, Map<String, Long>>, Long> {
        val now = System.nanoTime()
        data class Entry(val path: String, val captured: Long, val recordingId: Long? = null, val finalized: Boolean = false)
        val rows = recordings.storageRows().mapNotNull { row -> row.filePath?.let { Entry(it, row.bytes, row.id, tv.own.owntv.core.recording.RecordingIntegrity.canPlay(row)) } } +
            downloads.storageRows().mapNotNull { row -> row.filePath?.let { Entry(it, row.downloadedBytes) } }
        val groups = mutableMapOf<String, MutableMap<String, Long>>()
        val volumes = mutableMapOf<String, StorageVolumeInfo?>()
        rows.forEach { row ->
            val cacheKey = if (MediaTarget.isDocument(row.path)) runCatching {
                val uri = android.net.Uri.parse(row.path)
                uri.authority + ":" + DocumentVolumes.volumeIdOf(android.provider.DocumentsContract.getDocumentId(uri))
            }.getOrDefault(row.path) else File(row.path).parent.orEmpty()
            if (!volumes.containsKey(cacheKey)) volumes[cacheKey] = StorageVolumeInfo.resolve(context, row.path)
            val volume = volumes[cacheKey] ?: return@forEach
            val target = MediaTarget.of(context, row.path) ?: return@forEach
            val actual = runCatching { if (tv.own.owntv.core.recording.RecordingParts.isIndex(target) && target.exists()) row.captured + target.length() else target.length() }.getOrDefault(0)
            val staged = row.recordingId?.let { id -> runCatching {
                // Durable progress avoids scanning thousands of HLS segments every refresh.
                val hls = if (spool(tv.own.owntv.core.recording.RecordingParts.spoolTarget(target), ".owntv-hls-$id").isDirectory) row.captured else 0L
                val parent = spool(target, ".owntv-dash").parentFile
                val dash = (0..1).sumOf { index -> File(parent, "owntv-dash-$id-$index.part").length() }
                maxOf(hls, dash)
            }.getOrDefault(0) } ?: 0
            // Missing manually removed files no longer consume quota. Live leases retain their reservation.
            val parts = row.recordingId?.let { id -> runCatching {
                tv.own.owntv.core.recording.RecordingParts.stagedBytes(context, target, id)
            }.getOrDefault(0) } ?: 0
            val size = (if (row.finalized) actual + staged else maxOf(actual, staged)) + parts
            val group = groups.getOrPut(volume.key) { mutableMapOf() }
            group[row.path] = maxOf(group[row.path] ?: 0, size)
        }
        return groups to now
    }

    private suspend fun refresh(force: Boolean = false) {
        val now = System.nanoTime()
        if (!force && refreshedAt != 0L && now - refreshedAt < 5_000_000_000L) return
        refreshMutex.withLock {
            val checkNow = System.nanoTime()
            if (!force && refreshedAt != 0L && checkNow - refreshedAt < 5_000_000_000L) return@withLock
            val (groups, timestamp) = withContext(Dispatchers.IO) { scanStorageUsage() }
            mutex.withLock {
                (ledgers.keys + groups.keys).toSet().forEach { key ->
                    ledgers.getOrPut(key) { StorageQuotaLedger() }.reconcile(groups[key].orEmpty())
                }
                refreshedAt = timestamp
            }
        }
    }

    suspend fun info(root: String): Info = withContext(Dispatchers.IO) {
        val volume = StorageVolumeInfo.resolve(context, root) ?: return@withContext Info(false)
        refresh()
        val quotaBytes = quota(volume)
        val reserveBytes = StorageQuotaPolicy.reserve(volume.total, volume.removable)
        val usedBytes = mutex.withLock {
            ledgers.getOrPut(volume.key) { StorageQuotaLedger() }.total()
        }
        Info(true, volume.free, volume.total, reserveBytes, quotaBytes, usedBytes, volume.removable)
    }

    suspend fun acquire(target: MediaTarget): Lease = withContext(Dispatchers.IO) {
        val volume = StorageVolumeInfo.resolve(context, target.stored) ?: throw Refused(Reason.UNAVAILABLE)
        if (!target.ensureWritable()) throw Refused(Reason.UNAVAILABLE)
        if (volume.free <= StorageQuotaPolicy.reserve(volume.total, volume.removable)) throw Refused(Reason.NO_SPACE)
        refresh(force = true)
        mutex.withLock {
            val ledger = ledgers.getOrPut(volume.key) { StorageQuotaLedger() }
            try { ledger.acquire(target.stored) } catch (_: IllegalStateException) { throw Refused(Reason.UNAVAILABLE) }
            Lease(target, volume.key, volume.removable, ledger, volume.maxFileBytes,
                physical.computeIfAbsent(volume.key) { PhysicalStorageLedger() })
        }
    }

    inner class Lease internal constructor(private val target: MediaTarget, private val volumeKey: String,
        private val removable: Boolean, private val ledger: StorageQuotaLedger, private val maxFileBytes: Long,
        private val physicalLedger: PhysicalStorageLedger) {
        private var committed = target.length()
        private var closed = false
        private var spoolVolumeKey: String? = null
        private var spoolLedger: PhysicalStorageLedger? = null
        private val spoolOwnerKey: String get() = spoolOwner(target.stored)
        @Volatile private var checkedAt = 0L
        @Volatile private var snapshot: StorageVolumeInfo? = null
        @Volatile private var quotaBytes = 0L

        val requiresParts: Boolean get() = maxFileBytes != Long.MAX_VALUE

        /** Quota admission is atomic across writers; mount/permissions are rechecked every 500 ms. */
        suspend fun reserve(desired: Long, scratchBytes: Long = 0, perFileBytes: Long = desired) {
            check(!closed)
            require(desired >= 0 && scratchBytes >= 0 && perFileBytes >= 0)
            val now = System.nanoTime()
            val needVolumeCheck = snapshot == null || now - checkedAt >= 500_000_000L
            val needPhysicalObservation = physicalLedger.needsObservation(now)

            val ticket = if (needPhysicalObservation) physicalLedger.observationTicket() else 0L
            val fresh = if (needVolumeCheck || needPhysicalObservation) {
                withContext(Dispatchers.IO) {
                    StorageVolumeInfo.resolve(context, target.stored)
                } ?: throw Refused(Reason.UNAVAILABLE)
            } else null
            if (fresh != null && fresh.key != volumeKey) throw Refused(Reason.UNAVAILABLE)
            val freshQuota = fresh?.let { quota(it) }

            mutex.withLock {
                check(!closed)
                if (fresh != null) {
                    snapshot = fresh
                    checkedAt = now
                    quotaBytes = freshQuota!!
                }
                val volume = snapshot ?: fresh ?: throw Refused(Reason.UNAVAILABLE)
                if (needPhysicalObservation && fresh != null) {
                    physicalLedger.observe(fresh.free, now, ticket)
                }
                if (perFileBytes > volume.maxFileBytes - minOf(128L * 1024 * 1024, volume.maxFileBytes / 100)) throw Refused(Reason.FILE_LIMIT)
                val increase = (desired - committed).coerceAtLeast(0)
                if (!physicalLedger.reserve(target.stored, increase, scratchBytes,
                        StorageQuotaPolicy.reserve(volume.total, removable))) throw Refused(Reason.NO_SPACE)
                if (!ledger.grow(target.stored, desired, quotaBytes)) {
                    // Keep the conservative physical reservation until the refused writer closes;
                    // older scratch files may still exist while cancellation/finalization unwinds.
                    throw Refused(Reason.QUOTA)
                }
            }
        }

        /**
         * Reserve spool space on [spoolPath]'s own physical volume when spool and destination live on
         * distinct volumes, applying that volume's own reserve floor and concurrent reservations.
         */
        suspend fun reserveSpool(spoolPath: String, requiredBytes: Long) {
            check(!closed)
            require(requiredBytes >= 0L)
            val spoolVolume = withContext(Dispatchers.IO) {
                StorageVolumeInfo.resolve(context, spoolPath)
            } ?: throw Refused(Reason.UNAVAILABLE)
            if (spoolVolume.key == volumeKey) return
            val ledgerForSpool = physical.computeIfAbsent(spoolVolume.key) { PhysicalStorageLedger() }
            val now = System.nanoTime()
            val ticket = ledgerForSpool.observationTicket()
            val floor = StorageQuotaPolicy.reserve(spoolVolume.total, spoolVolume.removable)
            mutex.withLock {
                check(!closed)
                ledgerForSpool.observe(spoolVolume.free, now, ticket)
                if (!ledgerForSpool.reserve(spoolOwnerKey, 0L, requiredBytes, floor)) {
                    throw Refused(Reason.NO_SPACE)
                }
                if (spoolVolumeKey != null && spoolVolumeKey != spoolVolume.key) {
                    spoolLedger?.release(spoolOwnerKey)
                }
                spoolVolumeKey = spoolVolume.key
                spoolLedger = ledgerForSpool
            }
        }

        fun commit(bytes: Long) {
            val actual = bytes.coerceAtLeast(0)
            physicalLedger.commit(target.stored, (actual - committed).coerceAtLeast(0))
            committed = actual
            ledger.grow(target.stored, actual, Long.MAX_VALUE)
        }
        suspend fun close(actual: Long = committed) = mutex.withLock {
            if (!closed) {
                closed = true
                physicalLedger.commit(target.stored, (actual - committed).coerceAtLeast(0))
                physicalLedger.release(target.stored)
                spoolLedger?.release(spoolOwnerKey)
                spoolLedger = null
                spoolVolumeKey = null
                ledger.release(target.stored, actual)
            }
        }
    }
    fun destinationAvailable(target: MediaTarget): Boolean =
        StorageVolumeInfo.resolve(context, target.stored) != null && target.ensureWritable()

    fun reserveFloor(target: MediaTarget): Long = reserveFloor(target.stored)

    fun reserveFloor(storedPath: String): Long {
        val volume = StorageVolumeInfo.resolve(context, storedPath) ?: throw Refused(Reason.UNAVAILABLE)
        return StorageQuotaPolicy.reserve(volume.total, volume.removable)
    }

    fun sameVolume(firstStored: String, secondStored: String): Boolean {
        val first = StorageVolumeInfo.resolve(context, firstStored) ?: return false
        val second = StorageVolumeInfo.resolve(context, secondStored) ?: return false
        return first.key == second.key
    }

    /**
     * Checks physical headroom on [storedPath]'s own volume using that volume's own reserve floor
     * and subtracting concurrent active reservations from other writers on that volume.
     */
    fun hasHeadroom(storedPath: String, requiredBytes: Long = 0L, excludeOwner: String? = null): Boolean {
        require(requiredBytes >= 0L)
        val volume = StorageVolumeInfo.resolve(context, storedPath) ?: return false
        val floor = StorageQuotaPolicy.reserve(volume.total, volume.removable)
        val others = physical[volume.key]?.otherReservations(excludeOwner) ?: 0L
        val needed = if (requiredBytes > Long.MAX_VALUE - others) Long.MAX_VALUE else others + requiredBytes
        val usableAboveFloor = (volume.free - minOf(volume.free, floor)).coerceAtLeast(0L)
        return usableAboveFloor > needed
    }

    internal fun spoolOwner(targetStored: String): String = "spool:$targetStored"
    /** Android file-write failures are terminal; they must not become network reconnect loops. */
    fun classifyWriteFailure(error: Exception, target: MediaTarget): Refused? {
        var cause: Throwable? = error
        repeat(8) {
            val current = cause ?: return@repeat
            if (current is android.system.ErrnoException) {
                when (current.errno) {
                    android.system.OsConstants.EFBIG -> return Refused(Reason.FILE_LIMIT)
                    android.system.OsConstants.ENOSPC -> return Refused(Reason.NO_SPACE)
                    android.system.OsConstants.ENODEV, android.system.OsConstants.EACCES -> return Refused(Reason.UNAVAILABLE)
                }
            }
            cause = current.cause
        }
        return if (StorageVolumeInfo.resolve(context, target.stored) == null) Refused(Reason.UNAVAILABLE) else null
    }
    /** A document capture must stage on the destination volume, never silently on the internal one. */
    fun spool(target: MediaTarget, name: String): File {
        if (target is MediaTarget.Path) return File(target.file.parentFile, name)
        val volume = StorageVolumeInfo.resolve(context, target.stored) ?: throw Refused(Reason.UNAVAILABLE)
        val base = if (!volume.removable) context.filesDir else context.getExternalFilesDirs(null).filterNotNull()
            .firstOrNull { StorageVolumeInfo.resolve(context, it.absolutePath)?.key == volume.key }
            ?: throw Refused(Reason.UNAVAILABLE)
        if ((!base.exists() && !base.mkdirs()) || !base.canWrite()) throw Refused(Reason.UNAVAILABLE)
        return File(base, name)
    }
}
