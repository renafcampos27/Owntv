package tv.own.owntv.core.parser

import java.io.ByteArrayOutputStream
import java.net.URI

/** Import-time interpretation only; never rewrites an existing source or playback URL. */
data class XtreamM3uLink(
    val server: String,
    val username: String,
    val password: String,
    val preferHls: Boolean,
) {
    companion object {
        fun clean(url: String): String = url.trim().replace("&amp;", "&", ignoreCase = true)

        fun parse(url: String): XtreamM3uLink? {
            val cleaned = clean(url)
            val uri = runCatching { URI(cleaned) }.getOrNull()
                ?: runCatching { URI(escapeStrayPercents(cleaned)) }.getOrNull()
                ?: return null
            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") return null
            val authority = uri.rawAuthority?.takeIf { it.isNotBlank() } ?: return null
            if (uri.rawUserInfo != null || uri.host.isNullOrBlank()) return null
            val path = uri.rawPath.orEmpty()
            if (!path.endsWith("/get.php", ignoreCase = true)) return null
            val params = uri.rawQuery.orEmpty().split('&').mapNotNull { pair ->
                val key = pair.substringBefore('=').takeIf { it.isNotBlank() } ?: return@mapNotNull null
                key.lowercase() to percentDecodeQueryValue(pair.substringAfter('=', ""))
            }.toMap()
            val username = params["username"]?.takeIf { it.isNotBlank() } ?: return null
            val password = params["password"]?.takeIf { it.isNotBlank() } ?: return null
            return XtreamM3uLink(
                server = "$scheme://$authority${path.dropLast("/get.php".length)}",
                username = username,
                password = password,
                preferHls = params["output"]?.lowercase() in setOf("m3u8", "hls"),
            )
        }

        /**
         * Percent-decode an RFC 3986 query value without turning literal `+` into space and without
         * throwing on stray/literal `%` characters inside provider passwords.
         */
        internal fun percentDecodeQueryValue(raw: String): String {
            if ('%' !in raw) return raw
            val out = ByteArrayOutputStream(raw.length)
            var i = 0
            while (i < raw.length) {
                val c = raw[i]
                if (c == '%' && i + 2 < raw.length) {
                    val hi = hexDigit(raw[i + 1])
                    val lo = hexDigit(raw[i + 2])
                    if (hi >= 0 && lo >= 0) {
                        out.write((hi shl 4) or lo)
                        i += 3
                        continue
                    }
                }
                val bytes = c.toString().toByteArray(Charsets.UTF_8)
                out.write(bytes)
                i++
            }
            return out.toString(Charsets.UTF_8.name())
        }

        /** Escape malformed `%` (not followed by two hex digits) so `java.net.URI` can parse raw user URLs. */
        private fun escapeStrayPercents(raw: String): String {
            if ('%' !in raw) return raw
            val sb = StringBuilder(raw.length + 8)
            var i = 0
            while (i < raw.length) {
                val c = raw[i]
                if (c == '%' && (i + 2 >= raw.length || hexDigit(raw[i + 1]) < 0 || hexDigit(raw[i + 2]) < 0)) {
                    sb.append("%25")
                } else {
                    sb.append(c)
                }
                i++
            }
            return sb.toString()
        }

        private fun hexDigit(c: Char): Int = when (c) {
            in '0'..'9' -> c - '0'
            in 'a'..'f' -> c - 'a' + 10
            in 'A'..'F' -> c - 'A' + 10
            else -> -1
        }
    }
}
