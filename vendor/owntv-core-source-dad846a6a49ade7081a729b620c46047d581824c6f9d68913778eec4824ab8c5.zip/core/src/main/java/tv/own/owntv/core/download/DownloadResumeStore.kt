package tv.own.owntv.core.download

import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/**
 * Local sidecar store persisting representation validators per download id so Range resumes stay
 * validated across process restarts, pause/resume, SAF documents, and removable-volume unmounts.
 */
internal class DownloadResumeStore(private val directory: File) {

    fun read(id: Long): DownloadResumeMetadata? = runCatching {
        val file = fileFor(id)
        if (!file.isFile) return null
        var etag: String? = null
        var lastModified: String? = null
        var lmStrong = false
        var totalBytes: Long? = null
        file.readLines(Charsets.UTF_8).forEach { line ->
            val idx = line.indexOf('=')
            if (idx <= 0) return@forEach
            val key = line.substring(0, idx)
            val value = line.substring(idx + 1)
            when (key) {
                "etag" -> etag = value.takeIf { it.isNotEmpty() }
                "lastModified" -> lastModified = value.takeIf { it.isNotEmpty() }
                "lastModifiedStrong" -> lmStrong = value == "true"
                "totalBytes" -> totalBytes = value.toLongOrNull()?.takeIf { it > 0L }
            }
        }
        DownloadResumeMetadata(
            strongETag = etag,
            lastModified = lastModified,
            lastModifiedStrong = lmStrong,
            totalBytes = totalBytes,
        )
    }.getOrNull()

    fun write(id: Long, metadata: DownloadResumeMetadata) {
        if (!directory.exists()) directory.mkdirs()
        val target = fileFor(id)
        val tmp = File(directory, "$id.meta.tmp")
        val content = buildString {
            metadata.strongETag?.let { append("etag=").append(sanitize(it)).append('\n') }
            metadata.lastModified?.let { append("lastModified=").append(sanitize(it)).append('\n') }
            append("lastModifiedStrong=").append(metadata.lastModifiedStrong).append('\n')
            metadata.totalBytes?.takeIf { it > 0L }?.let { append("totalBytes=").append(it).append('\n') }
        }
        tmp.writeText(content, Charsets.UTF_8)
        runCatching {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        }.onFailure {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    fun clear(id: Long) {
        runCatching {
            fileFor(id).delete()
            File(directory, "$id.meta.tmp").delete()
        }
    }

    private fun fileFor(id: Long): File = File(directory, "$id.meta")

    private fun sanitize(value: String): String = value.replace('\r', ' ').replace('\n', ' ').trim()
}
