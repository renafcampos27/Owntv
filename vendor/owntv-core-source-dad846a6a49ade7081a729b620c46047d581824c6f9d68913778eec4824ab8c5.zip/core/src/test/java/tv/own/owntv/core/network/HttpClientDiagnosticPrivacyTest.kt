package tv.own.owntv.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket

class HttpClientDiagnosticPrivacyTest {
    @Test fun `origin omits every path query fragment and userinfo regardless of token name`() {
        val urls = listOf(
            "https://user:secret@example.invalid:8443/live/user/secret/1.m3u8?opaque=token#fragment",
            "https://example.invalid/timeshift/user/secret/60/date/1.ts?signature=secret",
            "https://example.invalid/list/secret?providerCustomCredential=secret",
        )
        assertEquals("https://example.invalid:8443", HttpClient.diagnosticOrigin(urls.first()))
        for (url in urls.drop(1)) assertEquals("https://example.invalid", HttpClient.diagnosticOrigin(url))
        assertEquals("invalid-url", HttpClient.diagnosticOrigin("not a valid URL with secret"))
    }
    @Test fun `failure diagnostics never include messages causes or signed URLs`() {
        val error = IOException("https://user:secret@example.invalid/private?unknownToken=secret",
            IllegalArgumentException("nested-secret"))
        val message = HttpClient.diagnosticFailure(error, true)
        assertEquals("type=IOException status=0 retrying=true", message)
        assertFalse(message.contains("secret"))
        assertEquals("type=HttpStatusException status=403 retrying=false",
            HttpClient.diagnosticFailure(HttpClient.HttpStatusException(403, "secret"), false))
    }
    @Test(timeout = 10000) fun `request identity remains intact while status exception exposes only origin`() = runBlocking {
        val server = ServerSocket(0, 1, InetAddress.getByName("127.0.0.1"))
        val client = OkHttpClient()
        val peer = async(Dispatchers.IO) {
            server.accept().use { socket ->
                socket.soTimeout = 3000
                val input = socket.getInputStream().bufferedReader()
                val request = input.readLine()
                val headers = buildList { while (true) { val line = input.readLine(); if (line.isNullOrEmpty()) break; add(line) } }
                socket.getOutputStream().apply { write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray()); flush() }
                request to headers
            }
        }
        try {
            val url = "http://127.0.0.1:${server.localPort}/live/test-user/test-secret/1.m3u8?customToken=test-secret"
            try {
                HttpClient(client).get(url, userAgent = "TestAgent", headers = mapOf("Referer" to "https://example.invalid/private")) { it.readBytes() }
                fail("status should remain an error")
            } catch (error: HttpClient.HttpStatusException) {
                assertEquals(403, error.code)
                assertEquals("HTTP 403 for http://127.0.0.1:${server.localPort}", error.message)
            }
            val (request, headers) = withTimeout(3000) { peer.await() }
            assertTrue(request.contains("/live/test-user/test-secret/1.m3u8?customToken=test-secret"))
            assertTrue(headers.any { it.equals("User-Agent: TestAgent", true) })
            assertTrue(headers.any { it.equals("Referer: https://example.invalid/private", true) })
        } finally {
            peer.cancel(); server.close(); client.connectionPool.evictAll(); client.dispatcher.executorService.shutdown()
        }
    }
    @Test fun `compiled redaction keeps the exact masking contract for embedded diagnostic URLs`() {
        val lines = listOf(
            "http://user:secret@example.invalid/live/user/secret/12.m3u8?token=secret&foo=bar",
            "failure https://example.invalid/timeshift/user/secret/60/2026-10-22/1.ts?password=secret",
            "https://example.invalid/list?USERNAME=user&PASSWORD=secret&signature=secret",
            "http://example.invalid/series/user/secret/1?auth=secret",
            "http://user@example.invalid/movie/user/secret/1",
        )
        fun oldMask(value: String): String = value
            .replace(Regex("(?i)(username|password|user|pass|token|data|auth|signature|sig|key)=[^&]*"), "$1=***")
            .replace(Regex("(?i)(://[^/]+/(?:live|movie|series|vod|timeshift)/)([^/]+)/([^/]+)/"), "$1•••/•••/")
            .replace(Regex("(?i)(://)([^/@:]+)(:[^/@]*)?@"), "$1***@")
        for (line in lines) {
            val masked = HttpClient.redactUrl(line)
            assertEquals(oldMask(line), masked)
            assertFalse(masked.contains("secret"))
        }
    }
    @Test fun `MAC and short Xtream paths are masked in text without changing ordinary paths`() {
        assertEquals("https://example.invalid/get?MAC=***&foo=ok", HttpClient.redactUrl("https://example.invalid/get?MAC=AA:BB:CC:DD:EE:FF&foo=ok"))
        for (tail in listOf("123", "123.m3u8", "123.ts?token=secret", "123.m3u8) failed")) {
            val masked = HttpClient.redactUrl("failure https://example.invalid/user/secret/$tail")
            assertFalse(masked.contains("/user/secret/"))
            assertTrue(masked.contains("/•••/•••/123"))
        }
        assertEquals("https://example.invalid/docs/public/readme.html", HttpClient.redactUrl("https://example.invalid/docs/public/readme.html"))
    }
}
