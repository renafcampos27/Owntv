package tv.own.owntv.core.companion

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.util.concurrent.atomic.AtomicInteger

class CompanionPreAuthBoundsTest {

    @Test
    fun `readRequestHead parses normal HTTP request line and headers`() {
        val raw = "POST /xtream?pin=123456 HTTP/1.1\r\nHost: 192.168.1.50\r\nContent-Length: 10\r\nX-Companion-Pin: 123456\r\n\r\n"
        val result = CompanionHttpProtocol.readRequestHead(BufferedInputStream(ByteArrayInputStream(raw.toByteArray())))
        assertTrue(result is CompanionHttpProtocol.RequestHeadResult.Parsed)
        val parsed = result as CompanionHttpProtocol.RequestHeadResult.Parsed
        assertEquals("POST", parsed.method)
        assertEquals("/xtream?pin=123456", parsed.rawPath)
        assertEquals("10", parsed.headers["content-length"])
        assertEquals("123456", parsed.headers["x-companion-pin"])
    }

    @Test
    fun `readRequestHead rejects oversized request line without reading unbounded stream`() {
        val bytesRead = AtomicInteger(0)
        // Infinite stream of 'A' without newline — must stop right after MAX_REQUEST_LINE_BYTES!
        val infinite = object : InputStream() {
            override fun read(): Int {
                bytesRead.incrementAndGet()
                return 'A'.code
            }
        }
        val result = CompanionHttpProtocol.readRequestHead(BufferedInputStream(infinite, 256))
        assertEquals(CompanionHttpProtocol.RequestHeadResult.UriTooLong, result)
        assertTrue(
            "Stopped early before OOM (read=${bytesRead.get()})",
            bytesRead.get() <= CompanionHttpProtocol.MAX_REQUEST_LINE_BYTES + 1024,
        )
    }

    @Test
    fun `readRequestHead rejects excessive header count and excessive total header bytes`() {
        val manyHeaders = buildString {
            append("GET / HTTP/1.1\r\n")
            repeat(CompanionHttpProtocol.MAX_HEADER_COUNT + 5) { i ->
                append("X-H-$i: v\r\n")
            }
            append("\r\n")
        }
        assertEquals(
            CompanionHttpProtocol.RequestHeadResult.HeadersTooLarge,
            CompanionHttpProtocol.readRequestHead(BufferedInputStream(ByteArrayInputStream(manyHeaders.toByteArray()))),
        )

        val hugeHeaders = buildString {
            append("GET / HTTP/1.1\r\n")
            val bigVal = "x".repeat(4000)
            repeat(12) { i -> append("X-Big-$i: $bigVal\r\n") }
            append("\r\n")
        }
        assertEquals(
            CompanionHttpProtocol.RequestHeadResult.HeadersTooLarge,
            CompanionHttpProtocol.readRequestHead(BufferedInputStream(ByteArrayInputStream(hugeHeaders.toByteArray()))),
        )

        assertEquals(
            CompanionHttpProtocol.RequestHeadResult.Invalid,
            CompanionHttpProtocol.readRequestHead(BufferedInputStream(ByteArrayInputStream("BADREQUEST\r\n\r\n".toByteArray()))),
        )
    }
}
