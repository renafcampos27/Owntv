package tv.own.owntv.core.download

import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.asResponseBody
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import okio.ForwardingSource
import okio.buffer
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import tv.own.owntv.core.database.dao.DownloadDao
import tv.own.owntv.core.database.dao.MovieDao
import tv.own.owntv.core.database.dao.RecordingDao
import tv.own.owntv.core.database.dao.SeriesDao
import tv.own.owntv.core.database.dao.SourceDao
import tv.own.owntv.core.database.entity.DownloadEntity
import tv.own.owntv.core.database.entity.RecordingEntity
import tv.own.owntv.core.i18n.LocaleStore
import tv.own.owntv.core.model.DownloadStatus
import tv.own.owntv.core.model.MediaType
import tv.own.owntv.core.settings.SettingsRepository
import tv.own.owntv.core.stalker.StalkerAuthManager
import tv.own.owntv.core.stalker.StalkerClient
import tv.own.owntv.core.stalker.StreamUrlResolver
import tv.own.owntv.core.storage.MediaStorageBudget
import tv.own.owntv.core.storage.StorageVolumeInfo
import java.io.File
import java.io.IOException
import java.lang.reflect.Proxy
import java.util.concurrent.atomic.AtomicInteger

/**
 * Fase 2 (DVR-04): End-to-end verification of [DownloadEngine] + [DownloadResumeValidator] +
 * [DownloadResumeStore] against controlled 16-byte objects, RFC 9110 Range/If-Range/416/206/200
 * responses, origins without strong ETag, process restarts, and unavailable USB storage.
 */
class DownloadEngineResumeTest {

    @get:Rule
    val temp = TemporaryFolder()

    private lateinit var rootDir: File
    private lateinit var filesDir: File
    private lateinit var context: Context
    private lateinit var downloadDao: InMemoryDownloadDao
    private lateinit var settings: SettingsRepository
    private lateinit var storageBudget: MediaStorageBudget

    private val v1Bytes = "0123456789ABCDEF".toByteArray(Charsets.US_ASCII) // 16 bytes
    private val v2Bytes = "fedcba9876543210".toByteArray(Charsets.US_ASCII) // 16 bytes

    @Before
    fun setUp() {
        rootDir = temp.newFolder("owntv-dl-ops")
        filesDir = File(rootDir, "app-files").apply { mkdirs() }
        StorageVolumeInfo.testResolver = { _, stored ->
            val file = File(stored)
            val dir = if (file.isDirectory) file else file.parentFile ?: rootDir
            StorageVolumeInfo(
                key = "internal",
                root = dir,
                removable = false,
                free = 50L * 1024 * 1024 * 1024,
                total = 100L * 1024 * 1024 * 1024,
                maxFileBytes = Long.MAX_VALUE,
            )
        }
        val prefs = InMemorySharedPreferences()
        context = object : ContextWrapper(null) {
            override fun getApplicationContext(): Context = this
            override fun getFilesDir(): File = this@DownloadEngineResumeTest.filesDir
            override fun getSharedPreferences(name: String?, mode: Int): SharedPreferences = prefs
            override fun getSystemService(name: String): Any? = null
            override fun getSystemServiceName(serviceClass: Class<*>): String? = null
        }
        settings = SettingsRepository(context, LocaleStore(prefs, null), InMemoryPreferencesDataStore())
        runBlocking {
            settings.setActiveProfile(1L)
            settings.setDownloadRoot(rootDir.absolutePath)
        }
        downloadDao = InMemoryDownloadDao()
        val recordingDao = proxyDao(RecordingDao::class.java) { m, _ ->
            if (m.name == "storageRows") emptyList<RecordingEntity>() else null
        }
        storageBudget = MediaStorageBudget(context, settings, recordingDao, downloadDao)
    }

    @After
    fun tearDown() {
        StorageVolumeInfo.testResolver = null
    }

    /**
     * Exact 8-case simulation matrix with 16-byte objects:
     * 3 valid responses complete with exact content; 5 invalid/unverifiable responses preserve
     * the existing partial file on disk without corrupting it or falsely marking COMPLETED.
     */
    @Test
    fun eightControlledResumeResponsesCompleteThreeValidAndPreserveFiveForRecovery() = runBlocking {
        data class Case(
            val id: Long,
            val initialBytes: ByteArray,
            val savedMeta: DownloadResumeMetadata?,
            val expectCompleted: Boolean,
            val expectedFinalBytes: ByteArray,
            val respond: (Interceptor.Chain) -> Response,
        )

        val cases = listOf(
            // 1. Valid 206 matching offset + length + strong ETag -> COMPLETED (v1)
            Case(
                id = 1L,
                initialBytes = v1Bytes.copyOfRange(0, 8),
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = true,
                expectedFinalBytes = v1Bytes,
            ) { chain ->
                assertEquals("bytes=8-", chain.request().header("Range"))
                assertEquals("\"v1\"", chain.request().header("If-Range"))
                response(chain, 206, v1Bytes.copyOfRange(8, 16))
                    .header("Content-Range", "bytes 8-15/16")
                    .header("ETag", "\"v1\"")
                    .build()
            },
            // 2. Complete 200 OK response to a ranged request (If-Range triggered fresh v2) -> COMPLETED (v2)
            Case(
                id = 2L,
                initialBytes = v1Bytes.copyOfRange(0, 8),
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = true,
                expectedFinalBytes = v2Bytes,
            ) { chain ->
                response(chain, 200, v2Bytes)
                    .header("ETag", "\"v2\"")
                    .build()
            },
            // 3. Valid 416 with Content-Range bytes */16 and matching strong ETag when existing == 16 -> COMPLETED (v1)
            Case(
                id = 3L,
                initialBytes = v1Bytes,
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = true,
                expectedFinalBytes = v1Bytes,
            ) { chain ->
                response(chain, 416, ByteArray(0))
                    .header("Content-Range", "bytes */16")
                    .header("ETag", "\"v1\"")
                    .build()
            },
            // 4. 206 with wrong start offset (bytes 0-15/16 instead of 8-15/16) -> PRESERVE PARTIAL
            Case(
                id = 4L,
                initialBytes = v1Bytes.copyOfRange(0, 8),
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = false,
                expectedFinalBytes = v1Bytes.copyOfRange(0, 8),
            ) { chain ->
                response(chain, 206, v1Bytes)
                    .header("Content-Range", "bytes 0-15/16")
                    .header("ETag", "\"v1\"")
                    .build()
            },
            // 5. 206 with changed strong ETag ("v2" instead of "v1") -> PRESERVE PARTIAL
            Case(
                id = 5L,
                initialBytes = v1Bytes.copyOfRange(0, 8),
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = false,
                expectedFinalBytes = v1Bytes.copyOfRange(0, 8),
            ) { chain ->
                response(chain, 206, v2Bytes.copyOfRange(8, 16))
                    .header("Content-Range", "bytes 8-15/16")
                    .header("ETag", "\"v2\"")
                    .build()
            },
            // 6. 206 from origin WITHOUT strong ETag (weak ETag W/"v1") -> PRESERVE PARTIAL
            Case(
                id = 6L,
                initialBytes = v1Bytes.copyOfRange(0, 8),
                savedMeta = DownloadResumeMetadata(strongETag = null, lastModified = null, lastModifiedStrong = false, totalBytes = 16L),
                expectCompleted = false,
                expectedFinalBytes = v1Bytes.copyOfRange(0, 8),
            ) { chain ->
                response(chain, 206, v1Bytes.copyOfRange(8, 16))
                    .header("Content-Range", "bytes 8-15/16")
                    .header("ETag", "W/\"v1\"")
                    .build()
            },
            // 7. 416 where remote resource shrank (bytes */12 while existing == 16) -> PRESERVE PARTIAL
            Case(
                id = 7L,
                initialBytes = v1Bytes,
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = false,
                expectedFinalBytes = v1Bytes,
            ) { chain ->
                response(chain, 416, ByteArray(0))
                    .header("Content-Range", "bytes */12")
                    .header("ETag", "\"v1\"")
                    .build()
            },
            // 8. 416 with missing/wildcard Content-Range or mismatched ETag -> PRESERVE PARTIAL
            Case(
                id = 8L,
                initialBytes = v1Bytes,
                savedMeta = DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L),
                expectCompleted = false,
                expectedFinalBytes = v1Bytes,
            ) { chain ->
                response(chain, 416, ByteArray(0))
                    .header("Content-Range", "bytes */*")
                    .header("ETag", "\"v2\"")
                    .build()
            },
        )

        val store = DownloadResumeStore(File(filesDir, "owntv-download-resume"))
        var completed = 0
        var preserved = 0

        for (c in cases) {
            val file = File(rootDir, "case-${c.id}.mp4").apply { writeBytes(c.initialBytes) }
            if (c.savedMeta != null) store.write(c.id, c.savedMeta) else store.clear(c.id)
            downloadDao.upsert(
                DownloadEntity(
                    id = c.id,
                    profileId = 1L,
                    mediaType = MediaType.MOVIE,
                    itemId = c.id,
                    title = "Case ${c.id}",
                    streamUrl = "https://example.invalid/case-${c.id}.mp4",
                    filePath = file.absolutePath,
                    status = DownloadStatus.RUNNING,
                    downloadedBytes = c.initialBytes.size.toLong(),
                    totalBytes = 16L,
                ),
            )
            val client = OkHttpClient.Builder().addInterceptor(Interceptor { c.respond(it) }).build()
            var observedReplacement = false
            withTimeout(5_000L) {
                createEngine(client).drainQueue {
                    if (c.id == 2L && file.readBytes().contentEquals(c.initialBytes)) {
                        observedReplacement = true
                        assertEquals(c.savedMeta?.strongETag, store.read(c.id)?.strongETag)
                    }
                }
            }
            if (c.id == 2L) assertTrue(observedReplacement)

            val updated = downloadDao.getById(c.id)!!
            assertArrayEquals("Case ${c.id} bytes mismatch", c.expectedFinalBytes, file.readBytes())
            if (c.expectCompleted) {
                assertEquals("Case ${c.id} must complete", DownloadStatus.COMPLETED, updated.status)
                assertEquals(c.expectedFinalBytes.size.toLong(), updated.downloadedBytes)
                assertNull("Completed download must clear sidecar validator", store.read(c.id))
                completed++
            } else {
                assertEquals("Case ${c.id} must fail preserving partial", DownloadStatus.FAILED, updated.status)
                assertEquals(c.initialBytes.size.toLong(), updated.downloadedBytes)
                preserved++
            }
        }

        assertEquals(3, completed)
        assertEquals(5, preserved)
    }

    @Test
    fun restartAcrossEngineInstancesResumesUsingPersistedValidatorAndRejectsTruncatedEof() = runBlocking {
        val file = File(rootDir, "restart.mp4")
        val id = 50L
        downloadDao.upsert(
            DownloadEntity(
                id = id,
                profileId = 1L,
                mediaType = MediaType.MOVIE,
                itemId = id,
                title = "Restartable Film",
                streamUrl = "https://example.invalid/restart.mp4",
                filePath = file.absolutePath,
                status = DownloadStatus.QUEUED,
            ),
        )

        // Engine 1: attempt 1 writes 8 of 16 bytes then drops; engine is cancelled before retry.
        val engine1Calls = AtomicInteger(0)
        val client1 = OkHttpClient.Builder().addInterceptor { chain ->
            if (engine1Calls.incrementAndGet() > 1) return@addInterceptor response(chain, 503, ByteArray(0)).build()
            val prefix = v1Bytes.copyOfRange(0, 8)
            val source = object : ForwardingSource(Buffer().write(prefix)) {
                override fun read(sink: Buffer, byteCount: Long): Long {
                    val n = super.read(sink, byteCount)
                    if (n == -1L) throw IOException("simulated disconnect after 8 bytes")
                    return n
                }
            }.buffer()
            Response.Builder()
                .request(chain.request())
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .header("ETag", "\"film-v1\"")
                .body(source.asResponseBody("video/mp4".toMediaType(), 16L))
                .build()
        }.build()

        withTimeout(15_000L) { createEngine(client1).drainQueue {} }
        assertEquals(DownloadStatus.FAILED, downloadDao.getById(id)!!.status)
        assertArrayEquals(v1Bytes.copyOfRange(0, 8), file.readBytes())

        // Simulate app restart: requeue row on a brand-new DownloadEngine instance.
        // First resume returns a truncated 206 (only 4 of 8 bytes before EOF) -> must NOT mark COMPLETED.
        // Second attempt resumes from byte 12 and receives bytes 12..15 -> exact 16-byte COMPLETED.
        downloadDao.updateProgress(id, DownloadStatus.QUEUED, 8L, 16L, System.currentTimeMillis())
        val engine2Calls = AtomicInteger(0)
        val client2 = OkHttpClient.Builder().addInterceptor { chain ->
            val n = engine2Calls.incrementAndGet()
            assertEquals("\"film-v1\"", chain.request().header("If-Range"))
            if (n == 1) {
                assertEquals("bytes=8-", chain.request().header("Range"))
                // Advertises 8 bytes in Content-Range/Content-Length but closes cleanly after 4 bytes.
                val truncated = Buffer().write(v1Bytes.copyOfRange(8, 12))
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(206)
                    .message("Partial Content")
                    .header("Content-Range", "bytes 8-15/16")
                    .header("ETag", "\"film-v1\"")
                    .body(truncated.asResponseBody("video/mp4".toMediaType(), 8L))
                    .build()
            } else {
                assertEquals("bytes=12-", chain.request().header("Range"))
                response(chain, 206, v1Bytes.copyOfRange(12, 16))
                    .header("Content-Range", "bytes 12-15/16")
                    .header("ETag", "\"film-v1\"")
                    .build()
            }
        }.build()

        withTimeout(15_000L) { createEngine(client2).drainQueue {} }
        val finished = downloadDao.getById(id)!!
        assertEquals(DownloadStatus.COMPLETED, finished.status)
        assertEquals(16L, finished.downloadedBytes)
        assertEquals(16L, finished.totalBytes)
        assertArrayEquals(v1Bytes, file.readBytes())
    }

    @Test
    fun http416WithoutValidatorHeaderConfirmsViaHeadAndRejectsChangedHead() = runBlocking {
        val store = DownloadResumeStore(File(filesDir, "owntv-download-resume"))

        // Subcase A: 416 omits ETag, HEAD confirms matching strong ETag + exact length -> COMPLETED.
        val okFile = File(rootDir, "head-ok.mp4").apply { writeBytes(v1Bytes) }
        store.write(60L, DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L))
        downloadDao.upsert(
            DownloadEntity(
                id = 60L, profileId = 1L, mediaType = MediaType.MOVIE, itemId = 60L,
                title = "Head OK", streamUrl = "https://example.invalid/head-ok.mp4",
                filePath = okFile.absolutePath, status = DownloadStatus.RUNNING,
                downloadedBytes = 16L, totalBytes = 16L,
            ),
        )
        val okClient = OkHttpClient.Builder().addInterceptor { chain ->
            if (chain.request().method == "HEAD") {
                response(chain, 200, ByteArray(0))
                    .header("Content-Length", "16")
                    .header("ETag", "\"v1\"")
                    .build()
            } else {
                response(chain, 416, ByteArray(0))
                    .header("Content-Range", "bytes */16")
                    .build()
            }
        }.build()
        withTimeout(5_000L) { createEngine(okClient).drainQueue {} }
        assertEquals(DownloadStatus.COMPLETED, downloadDao.getById(60L)!!.status)

        // Subcase B: 416 omits ETag, HEAD reveals content changed ("v2") -> PRESERVE PARTIAL (FAILED).
        val badFile = File(rootDir, "head-changed.mp4").apply { writeBytes(v1Bytes) }
        store.write(61L, DownloadResumeMetadata(strongETag = "\"v1\"", totalBytes = 16L))
        downloadDao.upsert(
            DownloadEntity(
                id = 61L, profileId = 1L, mediaType = MediaType.MOVIE, itemId = 61L,
                title = "Head Changed", streamUrl = "https://example.invalid/head-changed.mp4",
                filePath = badFile.absolutePath, status = DownloadStatus.RUNNING,
                downloadedBytes = 16L, totalBytes = 16L,
            ),
        )
        val badClient = OkHttpClient.Builder().addInterceptor { chain ->
            if (chain.request().method == "HEAD") {
                response(chain, 200, ByteArray(0))
                    .header("Content-Length", "16")
                    .header("ETag", "\"v2\"")
                    .build()
            } else {
                response(chain, 416, ByteArray(0))
                    .header("Content-Range", "bytes */16")
                    .build()
            }
        }.build()
        withTimeout(5_000L) { createEngine(badClient).drainQueue {} }
        assertEquals(DownloadStatus.FAILED, downloadDao.getById(61L)!!.status)
        assertArrayEquals(v1Bytes, badFile.readBytes())
    }

    @Test
    fun conditionalResumeWithStrongDateAccepts206WithoutRepeatedLastModified() = runBlocking {
        val lm = "Wed, 15 Oct 2025 10:00:00 GMT"
        val dateLater = "Wed, 15 Oct 2025 10:05:00 GMT"
        val file = File(rootDir, "last-mod.mp4")
        val id = 70L
        downloadDao.upsert(
            DownloadEntity(
                id = id, profileId = 1L, mediaType = MediaType.MOVIE, itemId = id,
                title = "Last-Modified Origin", streamUrl = "https://example.invalid/lm.mp4",
                filePath = file.absolutePath, status = DownloadStatus.QUEUED,
            ),
        )

        val calls = AtomicInteger(0)
        val client = OkHttpClient.Builder().addInterceptor { chain ->
            if (calls.incrementAndGet() == 1) {
                val prefix = v1Bytes.copyOfRange(0, 8)
                val source = object : ForwardingSource(Buffer().write(prefix)) {
                    override fun read(sink: Buffer, byteCount: Long): Long {
                        val n = super.read(sink, byteCount)
                        if (n == -1L) throw IOException("drop mid stream")
                        return n
                    }
                }.buffer()
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(200)
                    .message("OK")
                    .header("Last-Modified", lm)
                    .header("Date", dateLater)
                    .body(source.asResponseBody("video/mp4".toMediaType(), 16L))
                    .build()
            } else {
                assertEquals("bytes=8-", chain.request().header("Range"))
                assertEquals(lm, chain.request().header("If-Range"))
                response(chain, 206, v1Bytes.copyOfRange(8, 16))
                    .header("Content-Range", "bytes 8-15/16")
                    .header("Date", dateLater)
                    .build()
            }
        }.build()

        withTimeout(10_000L) { createEngine(client).drainQueue {} }
        val row = downloadDao.getById(id)!!
        assertEquals(DownloadStatus.COMPLETED, row.status)
        assertArrayEquals(v1Bytes, file.readBytes())
    }

    @Test
    fun unavailableUsbPreservesRecordedPartialByteCountInsteadOfZeroing() = runBlocking {
        val missingUsbPath = File(rootDir, "unmounted-usb/movie.mp4").absolutePath
        val id = 80L
        downloadDao.upsert(
            DownloadEntity(
                id = id, profileId = 1L, mediaType = MediaType.MOVIE, itemId = id,
                title = "USB Movie", streamUrl = "https://example.invalid/usb.mp4",
                filePath = missingUsbPath, status = DownloadStatus.QUEUED,
                downloadedBytes = 12_345_678L, totalBytes = 50_000_000L,
            ),
        )
        StorageVolumeInfo.testResolver = { _, _ -> null } // USB unmounted / unavailable

        val client = OkHttpClient.Builder().addInterceptor { error("network must not be called when USB unavailable") }.build()
        withTimeout(5_000L) { createEngine(client).drainQueue {} }

        val row = downloadDao.getById(id)!!
        assertEquals(DownloadStatus.FAILED, row.status)
        assertEquals(12_345_678L, row.downloadedBytes)
        assertEquals(50_000_000L, row.totalBytes)
        assertEquals(missingUsbPath, row.filePath)
    }

    private fun createEngine(client: OkHttpClient): DownloadEngine {
        val stalkerClient = StalkerClient(client)
        val resolver = StreamUrlResolver(StalkerAuthManager(stalkerClient), stalkerClient)
        val sourceDao = proxyDao(SourceDao::class.java) { _, _ -> null }
        val movieDao = proxyDao(MovieDao::class.java) { _, _ -> null }
        val seriesDao = proxyDao(SeriesDao::class.java) { _, _ -> null }
        return DownloadEngine(
            context = context,
            downloadDao = downloadDao,
            client = client,
            sourceDao = sourceDao,
            movieDao = movieDao,
            seriesDao = seriesDao,
            streamUrlResolver = resolver,
            activityTracker = DownloadActivityTracker(),
            storageBudget = storageBudget,
        )
    }

    private fun response(chain: Interceptor.Chain, code: Int, body: ByteArray): Response.Builder =
        Response.Builder()
            .request(chain.request())
            .protocol(Protocol.HTTP_1_1)
            .code(code)
            .message(if (code in 200..299) "OK" else "Error")
            .body(body.toResponseBody("video/mp4".toMediaType()))

    @Suppress("UNCHECKED_CAST")
    private fun <T> proxyDao(iface: Class<T>, handler: (java.lang.reflect.Method, Array<out Any?>?) -> Any?): T =
        Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            handler(method, args)
        } as T

    private class InMemoryDownloadDao : DownloadDao {
        private val rows = MutableStateFlow<Map<Long, DownloadEntity>>(emptyMap())

        override suspend fun storageRows(): List<DownloadEntity> = rows.value.values.filter { it.filePath != null }
        override suspend fun upsert(download: DownloadEntity): Long {
            rows.value = rows.value + (download.id to download)
            return download.id
        }
        override suspend fun delete(download: DownloadEntity) { rows.value = rows.value - download.id }
        override suspend fun getById(id: Long): DownloadEntity? = rows.value[id]
        override fun observeForProfile(profileId: Long): Flow<List<DownloadEntity>> = MutableStateFlow(emptyList())
        override fun observeForSeries(seriesId: Long): Flow<List<DownloadEntity>> = MutableStateFlow(emptyList())
        override suspend fun byStatus(status: DownloadStatus): List<DownloadEntity> =
            rows.value.values.filter { it.status == status }.sortedBy { it.createdAt }
        override suspend fun pending(): List<DownloadEntity> =
            rows.value.values.filter { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.RUNNING }.sortedBy { it.createdAt }
        override fun count(profileId: Long): Flow<Int> = MutableStateFlow(rows.value.size)
        override suspend fun updateProgress(id: Long, status: DownloadStatus, downloaded: Long, total: Long, timestamp: Long) {
            val cur = rows.value[id] ?: return
            rows.value = rows.value + (id to cur.copy(status = status, downloadedBytes = downloaded, totalBytes = total, updatedAt = timestamp))
        }
    }

    private class InMemorySharedPreferences : SharedPreferences {
        private val data = HashMap<String, Any?>()
        override fun getAll(): MutableMap<String, *> = HashMap(data)
        override fun getString(key: String?, defValue: String?): String? = data[key] as? String ?: defValue
        @Suppress("UNCHECKED_CAST")
        override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? =
            (data[key] as? Set<String>)?.toMutableSet() ?: defValues
        override fun getInt(key: String?, defValue: Int): Int = data[key] as? Int ?: defValue
        override fun getLong(key: String?, defValue: Long): Long = data[key] as? Long ?: defValue
        override fun getFloat(key: String?, defValue: Float): Float = data[key] as? Float ?: defValue
        override fun getBoolean(key: String?, defValue: Boolean): Boolean = data[key] as? Boolean ?: defValue
        override fun contains(key: String?): Boolean = data.containsKey(key)
        override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
            private val edits = HashMap<String, Any?>()
            private var clearAll = false
            override fun putString(key: String, value: String?): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putStringSet(key: String, values: MutableSet<String>?): SharedPreferences.Editor = apply { edits[key] = values }
            override fun putInt(key: String, value: Int): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putLong(key: String, value: Long): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putFloat(key: String, value: Float): SharedPreferences.Editor = apply { edits[key] = value }
            override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor = apply { edits[key] = value }
            override fun remove(key: String): SharedPreferences.Editor = apply { edits[key] = null }
            override fun clear(): SharedPreferences.Editor = apply { clearAll = true }
            override fun commit(): Boolean {
                if (clearAll) data.clear()
                edits.forEach { (k, v) -> if (v == null) data.remove(k) else data[k] = v }
                return true
            }
            override fun apply() { commit() }
        }
        override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
        override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) {}
    }

    private class InMemoryPreferencesDataStore : DataStore<Preferences> {
        private val mutex = Mutex()
        private val state = MutableStateFlow(emptyPreferences())
        override val data: Flow<Preferences> = state
        override suspend fun updateData(transform: suspend (t: Preferences) -> Preferences): Preferences =
            mutex.withLock {
                val updated = transform(state.value)
                state.value = updated
                updated
            }
    }
}
