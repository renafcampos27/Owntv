package tv.own.owntv.core.parser

import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Test
import tv.own.owntv.core.network.HttpClient
import java.util.Base64

class ProviderTextTest {

    private fun b64(text: String): String = Base64.getEncoder().encodeToString(text.toByteArray(Charsets.UTF_8))

    @Test
    fun `ambiguous plain-text titles including UEFA are never misdecoded as Base64`() {
        val plainTitles = listOf(
            "UEFA",
            "RTVE",
            "TVI1",
            "TVE1",
            "TV10",
            "TUBE",
            "SERA",
            "Vida",
            "TVN1",
            "RTV1",
            "TVI+",
            "UEFA TVI1",
            "UEFATUBE",
            "TVE1TVI1",
            "News",
            "Test",
            "Live",
            "SIC HD",
            "RTP 1",
        )
        plainTitles.forEach { title ->
            assertEquals("Plain title corrupted: $title", title, decodeProviderText(title))
        }
    }

    @Test
    fun `unambiguous Base64 payloads still decode cleanly in AUTO mode`() {
        val payloads = listOf(
            "UEFA",
            "Notícias",
            "RTP 1",
            "Jornal",
            "Cinema",
            "Series",
            "The Simpsons",
            "Jornal da Noite",
            "UEFA Champions League",
            "OK",
            "F1",
        )
        payloads.forEach { expected ->
            val encoded = b64(expected)
            assertEquals("Failed to decode Base64 for: $expected ($encoded)", expected, decodeProviderText(encoded))
        }
    }

    @Test
    fun `explicit PLAIN and BASE64_DECLARED encodings are distinguished strictly`() {
        val encodedUefa = b64("UEFA") // "VUVGQQ=="
        assertEquals(encodedUefa, decodeProviderText(encodedUefa, ProviderTextEncoding.PLAIN))
        assertEquals("UEFA", decodeProviderText("UEFA", ProviderTextEncoding.PLAIN))

        // Short 4-char unpadded Base64 ("SEJP" = "HBO", "U0lD" = "SIC", "VFZJ" = "TVI"):
        // ambiguous in AUTO, decoded when explicitly declared Base64.
        assertEquals("SEJP", decodeProviderText("SEJP", ProviderTextEncoding.AUTO))
        assertEquals("HBO", decodeProviderText("SEJP", ProviderTextEncoding.BASE64_DECLARED))
        assertEquals("SIC", decodeProviderText("U0lD", ProviderTextEncoding.BASE64_DECLARED))
        assertEquals("TVI", decodeProviderText("VFZJ", ProviderTextEncoding.BASE64_DECLARED))

        // Invalid UTF-8 and control bytes still fall back to original even in BASE64_DECLARED.
        assertEquals("//8=", decodeProviderText("//8=", ProviderTextEncoding.BASE64_DECLARED))
        assertEquals("AAE=", decodeProviderText("AAE=", ProviderTextEncoding.BASE64_DECLARED))
    }

    @Test
    fun `Xtream EPG listing decoder preserves plain UEFA while decoding real Base64 feeds including 3-letter titles`() {
        val client = XtreamClient(HttpClient(OkHttpClient()))

        // 1. Plain-text panel sending literal "UEFA" (both multi-entry and single-entry)
        val plainEntries = client.decodeEpgListings(
            listOf(
                XtreamClient.RawEpgListing("UEFA", "Champions League", 1_700_000_000_000L, 1_700_003_600_000L),
                XtreamClient.RawEpgListing("RTVE", "", 1_700_003_600_000L, 1_700_007_200_000L),
            ),
        )
        assertEquals(listOf("UEFA", "RTVE"), plainEntries.map { it.title })
        assertEquals("Champions League", plainEntries[0].description)
        assertEquals(null, plainEntries[1].description)

        val singlePlainEntries = client.decodeEpgListings(
            listOf(XtreamClient.RawEpgListing("UEFA", null, 1_700_000_000_000L, 1_700_003_600_000L)),
        )
        assertEquals(listOf("UEFA"), singlePlainEntries.map { it.title })

        val mixedEntries = client.decodeEpgListings(
            listOf(
                XtreamClient.RawEpgListing("UEFA", b64("Notícias!"), 1_000L, 2_000L),
                XtreamClient.RawEpgListing("U2ljIEhEIQ", null, 2_000L, 3_000L),
            ),
        )
        assertEquals(listOf("UEFA", "Sic HD!"), mixedEntries.map { it.title })
        assertEquals("Notícias!", mixedEntries.first().description)

        // 2. Standard Base64 Xtream panel containing both long encoded titles and short 4-char Base64 ("SEJP" = "HBO")
        val encodedEntries = client.decodeEpgListings(
            listOf(
                XtreamClient.RawEpgListing(b64("UEFA Champions League"), b64("Notícias"), 1_700_000_000_000L, 1_700_003_600_000L),
                XtreamClient.RawEpgListing(b64("HBO"), b64("Series"), 1_700_003_600_000L, 1_700_007_200_000L),
            ),
        )
        assertEquals(listOf("UEFA Champions League", "HBO"), encodedEntries.map { it.title })
        assertEquals(listOf("Notícias", "Series"), encodedEntries.map { it.description })
    }
}
