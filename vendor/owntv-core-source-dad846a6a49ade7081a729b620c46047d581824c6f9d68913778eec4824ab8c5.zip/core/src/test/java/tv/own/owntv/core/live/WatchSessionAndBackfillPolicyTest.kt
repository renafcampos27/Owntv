package tv.own.owntv.core.live

import androidx.work.ExistingWorkPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import tv.own.owntv.core.sync.work.CatalogSyncScheduler
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class WatchSessionAndBackfillPolicyTest {

    @Test
    fun `WatchSession keeps legacy open-close idempotent while isolating concurrent leases`() {
        val session = WatchSession()

        // Legacy idempotent behavior preserved
        session.open(7L)
        session.open(7L)
        assertTrue(session.isWatching(7L))
        session.close(7L)
        assertFalse(session.isWatching(7L))

        // Two distinct leases on the same source: closing one MUST NOT drop the other
        val leaseA = session.openLease(7L)
        val leaseB = session.openLease(7L)
        assertNotNull(leaseA)
        assertNotNull(leaseB)
        assertTrue(session.isWatching(7L))

        session.close(leaseA!!)
        assertTrue("Second active viewer lease must remain protected", session.isWatching(7L))
        // Closing leaseA a second time is a safe no-op
        session.close(leaseA)
        assertTrue(session.isWatching(7L))

        session.close(leaseB!!)
        assertFalse(session.isWatching(7L))

        // Invalid negative sourceId returns null lease
        assertNull(session.openLease(-1L))
    }

    @Test
    fun `WatchSession handles concurrent multi-thread lease open and close without losing updates`() {
        val session = WatchSession()
        val pool = Executors.newFixedThreadPool(8)
        val start = CountDownLatch(1)
        val done = CountDownLatch(8)
        try {
            for (t in 0 until 8) {
                pool.submit {
                    start.await()
                    val sourceId = (t % 3 + 1).toLong()
                    repeat(200) {
                        val lease = session.openLease(sourceId)!!
                        session.close(lease)
                    }
                    done.countDown()
                }
            }
            start.countDown()
            assertTrue(done.await(10, TimeUnit.SECONDS))
            assertTrue("All leases released -> watching set must be empty", session.watching.value.isEmpty())
        } finally {
            pool.shutdownNow()
        }
    }

    @Test
    fun `CatalogSyncScheduler uses KEEP for external requests and APPEND_OR_REPLACE for worker continuation`() {
        assertEquals(ExistingWorkPolicy.KEEP, CatalogSyncScheduler.backfillWorkPolicy(isContinuation = false))
        assertEquals(ExistingWorkPolicy.APPEND_OR_REPLACE, CatalogSyncScheduler.backfillWorkPolicy(isContinuation = true))
    }
}
