package tv.own.owntv.core.network

import kotlinx.coroutines.flow.emptyFlow
import okhttp3.Dns
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicInteger

class DnsConfigResolutionTest {

    // --- UDP DNS wire-format parser (RFC 1035 §4.1.1) ---

    @Test
    fun `UDP parser decodes standard A response for example com`() {
        val queryId = 0x1234
        val packet = buildUdpResponse(
            id = queryId,
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 1)),
            ),
        )

        val addrs = DnsConfigHolder.parseDnsResponse(packet, expectedId = queryId)

        assertEquals(listOf("192.0.2.1"), addrs.map { it.hostAddress })
        assertTrue(addrs.single() is Inet4Address)
    }

    @Test
    fun `UDP parser decodes AAAA and multiple answers with authority and additional counts`() {
        val queryId = 0x4321
        val v6 = byteArrayOf(
            0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 1,
        )
        val packet = buildUdpResponse(
            id = queryId,
            qname = "ipv6.example.com",
            qtype = DnsConfigHolder.DNS_TYPE_AAAA,
            nsCount = 2,
            arCount = 1,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_AAAA, rdata = v6),
            ),
        )

        val addrs = DnsConfigHolder.parseDnsResponse(packet, expectedId = queryId)

        assertEquals(1, addrs.size)
        assertTrue(addrs.single() is Inet6Address)
        assertEquals(InetAddress.getByAddress(v6), addrs.single())
    }

    @Test
    fun `UDP parser skips CNAME answer records and extracts following A record`() {
        val queryId = 0x2222
        val cnameTarget = encodeName("cdn.example.com")
        val packet = buildUdpResponse(
            id = queryId,
            qname = "www.example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_CNAME, rdata = cnameTarget),
                AnswerRr(nameRaw = cnameTarget, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 9)),
            ),
        )

        val addrs = DnsConfigHolder.parseDnsResponse(packet, expectedId = queryId, expectedType = DnsConfigHolder.DNS_TYPE_A)

        assertEquals(listOf("192.0.2.9"), addrs.map { it.hostAddress })
    }

    @Test
    fun `UDP parser returns empty for CNAME-only, empty, truncated, mismatched ID, or malformed packets`() {
        val queryId = 0x3333
        val validA = buildUdpResponse(
            id = queryId,
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 1)),
            ),
        )

        // CNAME only
        val cnameOnly = buildUdpResponse(
            id = queryId,
            qname = "alias.example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_CNAME, rdata = encodeName("target.example.com")),
            ),
        )
        assertTrue(DnsConfigHolder.parseDnsResponse(cnameOnly, queryId).isEmpty())

        // Empty answer (ANCOUNT = 0)
        val emptyAnswer = buildUdpResponse(id = queryId, qname = "example.com", qtype = DnsConfigHolder.DNS_TYPE_A, answers = emptyList())
        assertTrue(DnsConfigHolder.parseDnsResponse(emptyAnswer, queryId).isEmpty())

        // Truncated flag (TC = 0x0200)
        val tcSet = buildUdpResponse(
            id = queryId,
            flags = 0x8380, // QR=1, TC=1, RD=1, RA=1
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 1)),
            ),
        )
        assertTrue(DnsConfigHolder.parseDnsResponse(tcSet, queryId).isEmpty())

        // Physically truncated at every byte boundary shorter than the full valid response
        for (len in 0 until validA.size) {
            assertTrue("Expected empty for truncated len=$len", DnsConfigHolder.parseDnsResponse(validA.copyOf(len), queryId).isEmpty())
        }

        // Wrong transaction ID
        assertTrue(DnsConfigHolder.parseDnsResponse(validA, expectedId = queryId + 1).isEmpty())

        // Non-zero RCODE (NXDOMAIN = 3)
        val nxdomain = buildUdpResponse(id = queryId, flags = 0x8183, qname = "missing.example.com", qtype = DnsConfigHolder.DNS_TYPE_A, answers = emptyList())
        assertTrue(DnsConfigHolder.parseDnsResponse(nxdomain, queryId).isEmpty())

        // Malformed A record with rdLen != 4
        val badRdLen = buildUdpResponse(
            id = queryId,
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2)),
            ),
        )
        assertTrue(DnsConfigHolder.parseDnsResponse(badRdLen, queryId).isEmpty())

        // Compression pointer pointing into the 12-byte header (invalid)
        val badPointer = buildUdpResponse(
            id = queryId,
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = listOf(
                AnswerRr(namePointer = 4, type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 1)),
            ),
        )
        assertTrue(DnsConfigHolder.parseDnsResponse(badPointer, queryId).isEmpty())

        // Compression pointer loop in answer section
        val loopPacket = buildUdpResponse(
            id = queryId,
            qname = "example.com",
            qtype = DnsConfigHolder.DNS_TYPE_A,
            answers = emptyList(),
        ).let { base ->
            // Patch ANCOUNT = 1 and append self-referential pointer at end of question.
            val patched = base.copyOf(base.size + 16)
            patched[7] = 1
            val selfOffset = base.size
            patched[selfOffset] = (0xC0 or ((selfOffset ushr 8) and 0x3F)).toByte()
            patched[selfOffset + 1] = (selfOffset and 0xFF).toByte()
            patched
        }
        assertTrue(DnsConfigHolder.parseDnsResponse(loopPacket, queryId).isEmpty())
    }

    // --- End-to-end local loopback UDP server ---

    @Test
    fun `local UDP DNS server resolves A, AAAA and CNAME chains and respects fallbackToSystem`() {
        val fallbackCalls = AtomicInteger(0)
        val spySystemDns = Dns {
            fallbackCalls.incrementAndGet()
            listOf(InetAddress.getByAddress(byteArrayOf(198.toByte(), 51, 100, 77)))
        }

        withLocalUdpServer({ qname, qtype, id ->
            when {
                qname == "dual.example.com" && qtype == DnsConfigHolder.DNS_TYPE_A -> buildUdpResponse(
                    id = id,
                    qname = qname,
                    qtype = qtype,
                    answers = listOf(
                        AnswerRr(namePointer = 12, type = DnsConfigHolder.DNS_TYPE_CNAME, rdata = encodeName("edge.example.com")),
                        AnswerRr(nameRaw = encodeName("edge.example.com"), type = DnsConfigHolder.DNS_TYPE_A, rdata = byteArrayOf(192.toByte(), 0, 2, 10)),
                    ),
                )
                qname == "dual.example.com" && qtype == DnsConfigHolder.DNS_TYPE_AAAA -> buildUdpResponse(
                    id = id,
                    qname = qname,
                    qtype = qtype,
                    answers = listOf(
                        AnswerRr(
                            namePointer = 12,
                            type = DnsConfigHolder.DNS_TYPE_AAAA,
                            rdata = byteArrayOf(0x20, 0x01, 0x0d, 0xb8.toByte(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x10),
                        ),
                    ),
                )
                else -> buildUdpResponse(id = id, qname = qname, qtype = qtype, answers = emptyList())
            }
        }) { port ->
            val strictHolder = DnsConfigHolder.forTest(
                configFlow = emptyFlow(),
                initialConfig = DnsConfig(enabled = true, host = "127.0.0.1", port = port),
                fallbackToSystem = false,
                systemDns = spySystemDns,
            )

            val dual = strictHolder.dns.lookup("dual.example.com")
            assertEquals(2, dual.size)
            assertEquals("192.0.2.10", dual[0].hostAddress)
            assertTrue(dual[1] is Inet6Address)
            assertEquals(0, fallbackCalls.get())

            // Empty UDP answer with fallbackToSystem = false must NOT touch system DNS
            val emptyStrict = strictHolder.dns.lookup("empty.example.com")
            assertTrue(emptyStrict.isEmpty())
            assertEquals(0, fallbackCalls.get())

            // Empty UDP answer with fallbackToSystem = true falls back to system DNS
            val fallbackHolder = DnsConfigHolder.forTest(
                configFlow = emptyFlow(),
                initialConfig = DnsConfig(enabled = true, host = "127.0.0.1", port = port),
                fallbackToSystem = true,
                systemDns = spySystemDns,
            )
            val fallbackResult = fallbackHolder.dns.lookup("empty.example.com")
            assertEquals(listOf("198.51.100.77"), fallbackResult.map { it.hostAddress })
            assertEquals(1, fallbackCalls.get())
        }
    }

    // --- DoH JSON parser & strict literal IP validation ---

    @Test
    fun `DoH JSON parser ignores CNAME records and never resolves hostnames via system DNS`() {
        // Note: "localhost" WOULD resolve to 127.0.0.1 if InetAddress.getByName were called!
        val json = """
            {
              "Status": 0,
              "Answer": [
                {"name": "stream.example.com.", "type": 5, "TTL": 60, "data": "localhost"},
                {"name": "stream.example.com.", "type": 1, "TTL": 60, "data": "localhost"},
                {"name": "stream.example.com.", "type": 1, "TTL": 60, "data": "192.0.2.42"},
                {"name": "stream.example.com.", "type": 28, "TTL": 60, "data": "2001:db8::42"}
              ]
            }
        """.trimIndent()

        val aOnly = DnsConfigHolder.parseDohJson(json, expectedType = DnsConfigHolder.DNS_TYPE_A)
        assertEquals(listOf("192.0.2.42"), aOnly.map { it.hostAddress })

        val aaaaOnly = DnsConfigHolder.parseDohJson(json, expectedType = DnsConfigHolder.DNS_TYPE_AAAA)
        assertEquals(1, aaaaOnly.size)
        assertTrue(aaaaOnly.single() is Inet6Address)
        assertEquals("2001:db8:0:0:0:0:0:42", aaaaOnly.single().hostAddress)

        // Non-zero DNS Status (NXDOMAIN = 3) returns empty even if Answer is present
        val nxJson = """{"Status": 3, "Answer": [{"type": 1, "data": "192.0.2.42"}]}"""
        assertTrue(DnsConfigHolder.parseDohJson(nxJson).isEmpty())
    }

    @Test
    fun `numeric IP literal parser validates IPv4 and IPv6 strictly without DNS lookups`() {
        assertEquals("192.0.2.1", DnsConfigHolder.parseNumericIpAddress("192.0.2.1", DnsConfigHolder.DNS_TYPE_A)?.hostAddress)
        assertNull(DnsConfigHolder.parseNumericIpAddress("localhost", DnsConfigHolder.DNS_TYPE_A))
        assertNull(DnsConfigHolder.parseNumericIpAddress("192.0.2.256", DnsConfigHolder.DNS_TYPE_A))
        assertNull(DnsConfigHolder.parseNumericIpAddress("01.2.3.4", DnsConfigHolder.DNS_TYPE_A))
        assertNull(DnsConfigHolder.parseNumericIpAddress("2001:db8::1", DnsConfigHolder.DNS_TYPE_A))

        assertTrue(DnsConfigHolder.parseNumericIpAddress("::1", DnsConfigHolder.DNS_TYPE_AAAA) is Inet6Address)
        assertTrue(DnsConfigHolder.parseNumericIpAddress("::", DnsConfigHolder.DNS_TYPE_AAAA) is Inet6Address)
        assertTrue(DnsConfigHolder.parseNumericIpAddress("2001:db8::1", DnsConfigHolder.DNS_TYPE_AAAA) is Inet6Address)
        assertTrue(DnsConfigHolder.parseNumericIpAddress("::ffff:192.0.2.1", DnsConfigHolder.DNS_TYPE_AAAA) is Inet6Address)
        assertTrue(DnsConfigHolder.parseNumericIpAddress("64:ff9b::192.0.2.1", DnsConfigHolder.DNS_TYPE_AAAA) is Inet6Address)
        assertNull(DnsConfigHolder.parseNumericIpAddress("localhost", DnsConfigHolder.DNS_TYPE_AAAA))
        assertNull(DnsConfigHolder.parseNumericIpAddress("192.0.2.1", DnsConfigHolder.DNS_TYPE_AAAA))
        assertNull(DnsConfigHolder.parseNumericIpAddress("2001::db8::1", DnsConfigHolder.DNS_TYPE_AAAA))
        assertNull(DnsConfigHolder.parseNumericIpAddress("[::1]", DnsConfigHolder.DNS_TYPE_AAAA))
        assertNull(DnsConfigHolder.parseNumericIpAddress("fe80::1%eth0", DnsConfigHolder.DNS_TYPE_AAAA))
    }

    @Test
    fun `DoH resolver isolates A and AAAA errors and honors fallbackToSystem`() {
        val fallbackCalls = AtomicInteger(0)
        val spySystemDns = Dns {
            fallbackCalls.incrementAndGet()
            listOf(InetAddress.getByAddress(byteArrayOf(198.toByte(), 51, 100, 88)))
        }
        val mockDohClient = OkHttpClient.Builder()
            .addInterceptor(Interceptor { chain ->
                val url = chain.request().url
                val name = url.queryParameter("name")
                val type = url.queryParameter("type")
                val (code, body) = when {
                    name == "partial.example.com" && type == "A" ->
                        200 to """{"Status":0,"Answer":[{"type":5,"data":"localhost"},{"type":1,"data":"192.0.2.55"}]}"""
                    name == "partial.example.com" && type == "AAAA" ->
                        500 to "upstream error"
                    name == "cnameonly.example.com" ->
                        200 to """{"Status":0,"Answer":[{"type":5,"data":"localhost"}]}"""
                    else ->
                        502 to "bad gateway"
                }
                Response.Builder()
                    .request(chain.request())
                    .protocol(Protocol.HTTP_1_1)
                    .code(code)
                    .message(if (code == 200) "OK" else "Error")
                    .body(body.toResponseBody("application/dns-json".toMediaType()))
                    .build()
            })
            .build()

        val strictHolder = DnsConfigHolder.forTest(
            configFlow = emptyFlow(),
            initialConfig = DnsConfig(enabled = true, dohUrl = "https://doh.invalid/dns-query"),
            fallbackToSystem = false,
            dohClient = mockDohClient,
            systemDns = spySystemDns,
        )

        // A succeeds while AAAA fails -> keeps A answer and never touches system DNS
        assertEquals(listOf("192.0.2.55"), strictHolder.dns.lookup("partial.example.com").map { it.hostAddress })
        assertEquals(0, fallbackCalls.get())

        // CNAME-only answer with fallbackToSystem=false -> empty, never leaks to system DNS
        assertTrue(strictHolder.dns.lookup("cnameonly.example.com").isEmpty())
        assertEquals(0, fallbackCalls.get())

        // Both families fail with fallbackToSystem=false -> throws IOException, never falls back
        assertThrows(IOException::class.java) { strictHolder.dns.lookup("broken.example.com") }
        assertEquals(0, fallbackCalls.get())

        // Same queries with fallbackToSystem=true -> fall back to system DNS
        val fallbackHolder = DnsConfigHolder.forTest(
            configFlow = emptyFlow(),
            initialConfig = DnsConfig(enabled = true, dohUrl = "https://doh.invalid/dns-query"),
            fallbackToSystem = true,
            dohClient = mockDohClient,
            systemDns = spySystemDns,
        )
        assertEquals(listOf("198.51.100.88"), fallbackHolder.dns.lookup("cnameonly.example.com").map { it.hostAddress })
        assertEquals(listOf("198.51.100.88"), fallbackHolder.dns.lookup("broken.example.com").map { it.hostAddress })
        assertEquals(2, fallbackCalls.get())
    }

    // --- Wire-format builders & local loopback UDP helper ---

    private data class AnswerRr(
        val namePointer: Int? = null,
        val nameRaw: ByteArray? = null,
        val type: Int,
        val rclass: Int = 1,
        val ttl: Int = 60,
        val rdata: ByteArray,
    )

    private fun encodeName(hostname: String): ByteArray {
        val out = ByteArrayOutputStream()
        for (label in hostname.split('.')) {
            val bytes = label.encodeToByteArray()
            out.write(bytes.size)
            out.write(bytes)
        }
        out.write(0)
        return out.toByteArray()
    }

    private fun buildUdpResponse(
        id: Int,
        flags: Int = 0x8180,
        qname: String,
        qtype: Int,
        nsCount: Int = 0,
        arCount: Int = 0,
        answers: List<AnswerRr>,
    ): ByteArray {
        val baos = ByteArrayOutputStream()
        val out = DataOutputStream(baos)
        out.writeShort(id)
        out.writeShort(flags)
        out.writeShort(1) // QDCOUNT
        out.writeShort(answers.size) // ANCOUNT
        out.writeShort(nsCount)
        out.writeShort(arCount)
        // Question
        out.write(encodeName(qname))
        out.writeShort(qtype)
        out.writeShort(1) // IN
        // Answers
        for (ans in answers) {
            if (ans.namePointer != null) {
                out.writeShort(0xC000 or (ans.namePointer and 0x3FFF))
            } else {
                out.write(requireNotNull(ans.nameRaw))
            }
            out.writeShort(ans.type)
            out.writeShort(ans.rclass)
            out.writeInt(ans.ttl)
            out.writeShort(ans.rdata.size)
            out.write(ans.rdata)
        }
        return baos.toByteArray()
    }

    private fun withLocalUdpServer(
        respond: (qname: String, qtype: Int, id: Int) -> ByteArray,
        block: (port: Int) -> Unit,
    ) {
        val server = DatagramSocket(0, InetAddress.getByName("127.0.0.1"))
        server.soTimeout = 2_000
        val thread = Thread {
            val buf = ByteArray(512)
            while (!server.isClosed) {
                try {
                    val req = DatagramPacket(buf, buf.size)
                    server.receive(req)
                    val data = req.data.copyOf(req.length)
                    val id = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
                    val (qname, nextPos) = readQuestionName(data, 12)
                    val qtype = ((data[nextPos].toInt() and 0xFF) shl 8) or (data[nextPos + 1].toInt() and 0xFF)
                    val reply = respond(qname, qtype, id)
                    server.send(DatagramPacket(reply, reply.size, req.address, req.port))
                } catch (_: Exception) {
                    if (server.isClosed) break
                }
            }
        }.apply { isDaemon = true; start() }
        try {
            block(server.localPort)
        } finally {
            server.close()
            thread.join(1_000)
        }
    }

    private fun readQuestionName(data: ByteArray, start: Int): Pair<String, Int> {
        val labels = mutableListOf<String>()
        var pos = start
        while (pos < data.size) {
            val len = data[pos].toInt() and 0xFF
            if (len == 0) return labels.joinToString(".") to (pos + 1)
            labels += String(data, pos + 1, len, Charsets.UTF_8)
            pos += 1 + len
        }
        error("Unterminated QNAME")
    }
}
