package tv.own.owntv.core.parser

import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import tv.own.owntv.core.network.HttpClient
import tv.own.owntv.core.stalker.StalkerClient
import java.io.File

class XtreamM3uAndStalkerSafetyTest {

    @Test
    fun `XtreamM3uLink preserves literal plus and stray percent characters in credentials`() {
        // Literal '+' must NOT be converted to space, and literal '%' must NOT crash parse()
        val withPlusAndPercent = XtreamM3uLink.parse(
            "https://panel.example:8080/get.php?username=user+1&password=p+100%ok%26x&output=m3u8",
        )
        assertNotNull(withPlusAndPercent)
        assertEquals("https://panel.example:8080", withPlusAndPercent!!.server)
        assertEquals("user+1", withPlusAndPercent.username)
        assertEquals("p+100%ok&x", withPlusAndPercent.password)
        assertTrue(withPlusAndPercent.preferHls)

        // Trailing '%' and UTF-8 percent escapes both work cleanly
        val utf8AndTrailing = XtreamM3uLink.parse(
            "https://panel.example/sub/get.php?username=caf%C3%A9&password=pass%25end%",
        )
        assertNotNull(utf8AndTrailing)
        assertEquals("https://panel.example/sub", utf8AndTrailing!!.server)
        assertEquals("café", utf8AndTrailing.username)
        assertEquals("pass%end%", utf8AndTrailing.password)
    }

    @Test
    fun `StalkerClient redactForLog delegates to HttpClient and masks all credential shapes`() {
        val stalker = StalkerClient(OkHttpClient())
        val raw = "ffrt https://u:s3cr3t@portal.invalid/live/myuser/mypass/101.ts?mac=00:1A:79:11:22:33&play_token=abc999&stream_token=xyz888&sig=deadbeef"
        val redacted = stalker.redactForLog(raw)

        assertFalse("Must redact userinfo password: $redacted", "s3cr3t" in redacted)
        assertFalse("Must redact Xtream live credentials: $redacted", "myuser" in redacted || "mypass" in redacted)
        assertFalse("Must redact MAC: $redacted", "00:1A:79:11:22:33" in redacted)
        assertFalse("Must redact play_token: $redacted", "abc999" in redacted)
        assertFalse("Must redact stream_token: $redacted", "xyz888" in redacted)
        assertFalse("Must redact sig: $redacted", "deadbeef" in redacted)
        assertEquals(HttpClient.redactUrl(raw), redacted)
    }

    @Test
    fun `XtreamClient episode date branches consume JSON tokens unconditionally without Elvis short-circuit`() {
        val relative = "src/main/java/tv/own/owntv/core/parser/XtreamClient.kt"
        val src = listOf(File(relative), File("core/$relative")).first { it.exists() }.readText()
        val readEpisodeBody = src.substringAfter("private fun readEpisode(").substringBefore("private fun parseEpisodeDate(")

        assertFalse("Elvis must not guard reader.nextStringOrNull()", "?: parseEpisodeDate(reader.nextStringOrNull())" in readEpisodeBody)
        assertFalse("Elvis must not guard readEpisodeInfoDate(reader)", "?: readEpisodeInfoDate(reader)" in readEpisodeBody)
        assertTrue("Expected unconditional parse before null check", "val parsed = parseEpisodeDate(reader.nextStringOrNull())" in readEpisodeBody)
        assertTrue("Expected unconditional info parse before null check", "val parsed = readEpisodeInfoDate(reader)" in readEpisodeBody)
    }
}
