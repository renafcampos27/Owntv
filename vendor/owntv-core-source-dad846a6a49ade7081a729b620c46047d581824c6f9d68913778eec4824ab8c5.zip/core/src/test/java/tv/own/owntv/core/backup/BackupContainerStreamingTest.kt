package tv.own.owntv.core.backup

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import kotlin.random.Random

class BackupContainerStreamingTest {

    @get:Rule
    val temp = TemporaryFolder()

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    @Test
    fun `packToFile streams 20MB multi-entry unencrypted backup matching open and readJson bit-for-bit`() {
        val rng = Random(42)
        // Mirrors SIMULACAO:40 — synthetic JSON + 40 incompressible 512 KiB assets (~20 MiB total)
        val subtitles = (1..20).associate { i -> "sub_$i.srt" to rng.nextBytes(512 * 1024) }
        val avatars = (1..20).associate { i -> "av_$i.jpg" to rng.nextBytes(512 * 1024) }
        val json = """{"version":26,"profiles":[{"id":1,"name":"TV"}]}"""
        val payload = BackupContainer.Payload(
            json = json,
            wallpaper = BackupContainer.Asset("wall.jpg", rng.nextBytes(256 * 1024)),
            subtitles = subtitles,
            avatars = avatars,
        )

        val file = File(temp.root, "streamed-plain.own")
        BackupContainer.packToFile(payload, passphrase = null, target = file)

        assertEquals(BackupContainer.Kind.CONTAINER, BackupContainer.probe(file))
        assertTrue(file.length() > 20L * 1024 * 1024)
        assertEquals(json, BackupContainer.readJson(file))

        val opened = BackupContainer.open(file)
        assertEquals(json, opened.json)
        assertEquals(sha256(payload.wallpaper!!.bytes), sha256(opened.wallpaper!!.bytes))
        assertEquals(20, opened.subtitles.size)
        assertEquals(20, opened.avatars.size)
        subtitles.forEach { (k, v) -> assertEquals(sha256(v), sha256(opened.subtitles.getValue(k))) }
        avatars.forEach { (k, v) -> assertEquals(sha256(v), sha256(opened.avatars.getValue(k))) }
    }

    @Test
    fun `encrypted packToFile produces standard authenticated OWNTVBK1 container and rejects tampering`() {
        val rng = Random(99)
        val json = """{"version":26,"profiles":[{"id":1,"name":"Encrypted"}]}"""
        val payload = BackupContainer.Payload(
            json = json,
            wallpaper = BackupContainer.Asset("bg.png", rng.nextBytes(128 * 1024)),
            subtitles = mapOf("1_pt.srt" to "1\n00:00:01,000 --> 00:00:02,000\nOlá\n".toByteArray()),
            avatars = mapOf("1_av.png" to rng.nextBytes(64 * 1024)),
        )
        val pass = "stream-passphrase-2026"
        val file = File(temp.root, "streamed-enc.own")
        BackupContainer.packToFile(payload, passphrase = pass, target = file)

        assertEquals(BackupContainer.Kind.ENCRYPTED_CONTAINER, BackupContainer.probe(file))
        assertEquals(json, BackupContainer.readJson(file, pass))
        val opened = BackupContainer.open(file, pass)
        assertEquals(json, opened.json)
        assertArrayEquals(payload.wallpaper!!.bytes, opened.wallpaper!!.bytes)
        assertArrayEquals(payload.subtitles["1_pt.srt"], opened.subtitles["1_pt.srt"])
        assertArrayEquals(payload.avatars["1_av.png"], opened.avatars["1_av.png"])

        // Wrong passphrase throws WrongPasswordException
        assertTrue(runCatching { BackupContainer.open(file, "wrong-pass") }.exceptionOrNull() is BackupManager.WrongPasswordException)

        // Flipping a bit in the trailing GCM tag must fail authentication with WrongPasswordException
        val tampered = File(temp.root, "streamed-tampered.own")
        val raw = file.readBytes().also { it[it.lastIndex] = (it[it.lastIndex].toInt() xor 0x01).toByte() }
        tampered.writeBytes(raw)
        assertTrue(runCatching { BackupContainer.open(tampered, pass) }.exceptionOrNull() is BackupManager.WrongPasswordException)
    }

    @Test
    fun `BackupManager streaming writeAtomically preserves existing copy and cleans temp on mid-write failure`() {
        val target = File(temp.root, "owntv-backup.own")
        target.writeBytes("previous-good-backup".toByteArray())

        val failed = runCatching {
            BackupManager.writeAtomically(target) { out ->
                out.write("partial-corrupt".toByteArray())
                throw IOException("disk full")
            }
        }
        assertTrue(failed.isFailure)
        assertEquals("previous-good-backup", target.readText())
        assertFalse(File(temp.root, "owntv-backup.own.tmp").exists())

        // Subsequent successful streaming write replaces target and rotates previous to .bak
        BackupManager.writeAtomically(target) { out -> out.write("new-good-backup".toByteArray()) }
        assertEquals("new-good-backup", target.readText())
        assertEquals("previous-good-backup", File(temp.root, "owntv-backup.own.bak").readText())
    }
}
