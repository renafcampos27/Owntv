package tv.own.owntv.core.parser

import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient

@org.junit.runner.RunWith(androidx.test.ext.junit.runners.AndroidJUnit4::class)
class Up70XtreamAccountAndroidTest {
    private val source = SourceEntity(id = 1, name = "Test", type = SourceType.XTREAM,
        url = "https://example.invalid", username = "user", password = "secret")
    private fun client(body: String = "", code: Int = 200) = XtreamClient(HttpClient(OkHttpClient.Builder().addInterceptor { chain ->
        Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(code).message("Test")
            .body(body.toResponseBody()).build()
    }.build()))

    @Test fun explicitRejectionFailsSyncButMissingAuthIsUnknown() = runBlocking {
        for (auth in listOf("0", "\"0\"", "false")) {
            val error = runCatching { client("{\"user_info\":{\"auth\":$auth}}").fetchAccountDetails(source, true) }.exceptionOrNull()
            assertEquals(401, (error as HttpClient.HttpStatusException).code)
        }
        for (auth in listOf("1", "\"1\"", "true", "null", "\"unknown\"")) {
            assertTrue(client("{\"user_info\":{\"auth\":$auth}}").fetchAccountDetails(source, true)!!.authOk)
        }
        assertTrue(client("{\"user_info\":{}}").fetchAccountDetails(source, true)!!.authOk)
        assertNull(client("not JSON").fetchAccountDetails(source, true))
    }
}
