package tv.own.owntv.core.parser

import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.CancellationException
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType
import tv.own.owntv.core.network.HttpClient

class XtreamSyncAccountTest {
    private val source = SourceEntity(id = 1, name = "Test", type = SourceType.XTREAM,
        url = "https://example.invalid", username = "user", password = "secret")
    private fun client(body: String = "", code: Int = 200) = XtreamClient(HttpClient(OkHttpClient.Builder().addInterceptor { chain ->
        Response.Builder().request(chain.request()).protocol(Protocol.HTTP_1_1).code(code).message("Test")
            .body(body.toResponseBody()).build()
    }.build()))

    @Test fun api513IsScopedToTheSyncAuthenticationVerdict() = runBlocking {
        assertNull(client(code = 513).fetchAccountDetails(source))
        assertEquals(401, (runCatching { client(code = 513).fetchAccountDetails(source, true) }.exceptionOrNull() as HttpClient.HttpStatusException).code)
        assertEquals(513, (runCatching { client(code = 513).fetchAccountStatus(source) }.exceptionOrNull() as HttpClient.HttpStatusException).code)
        assertNull(client(code = 404).fetchAccountDetails(source, true))
    }
    @Test fun cancellationNeverTurnsIntoUnknownAccount() = runBlocking {
        val cancelled = XtreamClient(HttpClient(OkHttpClient.Builder().addInterceptor { throw CancellationException("cancelled") }.build()))
        assertTrue(runCatching { cancelled.fetchAccountDetails(source, true) }.exceptionOrNull() is CancellationException)
    }
}
