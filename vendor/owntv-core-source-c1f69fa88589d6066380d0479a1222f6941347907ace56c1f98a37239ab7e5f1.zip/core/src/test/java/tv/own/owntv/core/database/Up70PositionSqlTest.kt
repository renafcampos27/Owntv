package tv.own.owntv.core.database

import java.io.File
import java.sql.Connection
import java.sql.DriverManager
import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.dao.PositionParking

/** Executes the production DAO query text against SQLite/JDBC, without an Android device. */
class Up70PositionSqlTest {
    private fun query(dao: String, method: String): String {
        val relative = "src/main/java/tv/own/owntv/core/database/dao/$dao.kt"
        val file = listOf(File(relative), File("core/$relative")).first { it.exists() }
        val before = file.readText().substringBefore("suspend fun $method(")
        return before.substringAfterLast("@Query(\"").substringBefore("\")")
    }
    private fun run(db: Connection, sql: String, vararg values: Pair<String, Long>): Int {
        val names = Regex(":([a-zA-Z]+)").findAll(sql).map { it.groupValues[1] }.toList()
        return db.prepareStatement(sql.replace(Regex(":([a-zA-Z]+)"), "?")).use { statement ->
            names.forEachIndexed { i, name -> statement.setLong(i + 1, values.toMap().getValue(name)) }
            statement.executeUpdate()
        }
    }
    private fun positions(db: Connection, table: String): List<Long> = db.createStatement().use { statement ->
        statement.executeQuery("SELECT sortOrder FROM $table WHERE sourceId=1 ORDER BY id").use { rows ->
            buildList { while (rows.next()) add(rows.getLong(1)) }
        }
    }
    @Test fun rangesNeverHitMovedRowsAndRollbackRestoresEveryPosition() {
        for ((dao, table) in listOf("ChannelDao" to "channels", "MovieDao" to "movies", "SeriesDao" to "series")) {
            DriverManager.getConnection("jdbc:sqlite::memory:").use { db ->
                db.createStatement().use { it.execute("CREATE TABLE $table (id INTEGER PRIMARY KEY,sourceId INTEGER,sortOrder INTEGER)")
                    it.execute("INSERT INTO $table VALUES (1,1,-2),(2,1,-1),(3,1,0),(4,1,1),(5,1,2),(6,1,1000000000),(7,2,0),(8,1,2147483647)") }
                val before = positions(db, table)
                val froms = listOf(-2, 0, 1000000000, Int.MAX_VALUE)
                val tos = listOf(-1, 2, 1000000000, Int.MAX_VALUE)
                val deltas = listOf(2, 2, -1, -1)
                PositionParking.validate(froms, tos, deltas)
                fun park() { froms.indices.forEach { i -> run(db, query(dao, "shiftSortOrders"), "sourceId" to 1L,
                    "fromSortOrder" to froms[i].toLong(), "toSortOrder" to tos[i].toLong(), "delta" to (deltas[i].toLong() + PositionParking.OFFSET)) } }
                db.autoCommit = false
                park(); db.rollback()
                assertEquals(before, positions(db, table))
                park()
                run(db, query(dao, "restoreParkedPositions"), "sourceId" to 1L, "offset" to PositionParking.OFFSET,
                    "low" to PositionParking.LOW, "high" to PositionParking.HIGH)
                db.commit()
                assertEquals(listOf(0L,1L,2L,3L,4L,999999999L,2147483646L), positions(db, table))
                db.createStatement().use { st -> st.executeQuery("SELECT sortOrder FROM $table WHERE sourceId=2").use { it.next(); assertEquals(0L,it.getLong(1)) } }
            }
        }
    }
    @Test fun invalidParkingInputIsRejectedBeforeWriting() {
        for ((from, to, delta) in listOf(Triple(Int.MAX_VALUE,Int.MAX_VALUE,1), Triple(Int.MIN_VALUE,Int.MIN_VALUE,-1), Triple(5,2,1))) {
            assertTrue(runCatching { PositionParking.validate(listOf(from),listOf(to),listOf(delta)) }.isFailure)
        }
        assertTrue(runCatching { PositionParking.validate(listOf(0,1),listOf(2,3),listOf(1,1)) }.isFailure)
        assertTrue(runCatching { PositionParking.validate(listOf(0),emptyList(),emptyList()) }.isFailure)
        PositionParking.validate(listOf(Int.MIN_VALUE),listOf(Int.MIN_VALUE + 1),listOf(1))
    }
    @Test fun syncAnnouncementNeverOverwritesACompletedMeasurement() {
        DriverManager.getConnection("jdbc:sqlite::memory:").use { db ->
            db.createStatement().use { it.execute("CREATE TABLE sources (id INTEGER PRIMARY KEY,maxConnections INTEGER,maxConnectionsProbedAt INTEGER)")
                it.execute("INSERT INTO sources VALUES(1,0,0),(2,3,123)") }
            val sql = query("SourceDao", "updateMaxConnectionsUnlessMeasured")
            assertEquals(1, run(db,sql,"id" to 1L,"maxConnections" to 1L))
            assertEquals(0, run(db,sql,"id" to 2L,"maxConnections" to 1L))
            db.createStatement().use { it.execute("UPDATE sources SET maxConnections=4,maxConnectionsProbedAt=456 WHERE id=1") }
            assertEquals(0, run(db,sql,"id" to 1L,"maxConnections" to 1L))
            db.createStatement().use { it.executeQuery("SELECT maxConnections,maxConnectionsProbedAt FROM sources WHERE id=1").use {
                it.next(); assertEquals(4,it.getInt(1)); assertEquals(456L,it.getLong(2)) } }
        }
    }
}
