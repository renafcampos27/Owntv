package tv.own.owntv.core.player

import org.junit.Assert.*
import org.junit.Test
import tv.own.owntv.core.database.entity.SourceEntity
import tv.own.owntv.core.model.SourceType

class LiveSessionLimitTest {
    @Test fun measuredLimitReplacesCatalogSingleSessionWithoutAffectingOtherAccount() {
        val s = SourceEntity(id = 701, name = "Test", type = SourceType.XTREAM,
            url = "https://limits.invalid", username = "u/a", password = "p+q", maxConnections = 1)
        val stream = "https://limits.invalid/live/u%2Fa/p+q/1.m3u8"
        LiveSessionLimit.update(s)
        assertTrue(LiveSessionLimit.isSingleSession(stream))
        assertFalse(LiveSessionLimit.isSingleSession("https://limits.invalid/live/other/secret/1.m3u8"))
        LiveSessionLimit.update(s.copy(maxConnections = 3, maxConnectionsProbedAt = 123))
        assertFalse(LiveSessionLimit.isSingleSession(stream))
        LiveSessionLimit.update(s.copy(username = "new", maxConnections = 1))
        assertFalse(LiveSessionLimit.isSingleSession(stream))
        assertTrue(LiveSessionLimit.isSingleSession("https://limits.invalid/new/p+q/1.ts"))
        LiveSessionLimit.update(s.copy(maxConnections = 0))
    }
}
