package tv.own.owntv.core.database.dao

/** SQLite INTEGER is 64-bit; persisted positions are Int. Park OUTSIDE the entire Int domain. */
internal object PositionParking {
    const val OFFSET = 4_294_967_296L
    const val LOW = OFFSET + Int.MIN_VALUE.toLong()
    const val HIGH = OFFSET + Int.MAX_VALUE.toLong()

    fun validate(froms: List<Int>, tos: List<Int>, deltas: List<Int>) {
        require(froms.size == tos.size && tos.size == deltas.size)
        val order = froms.indices.sortedBy { froms[it] }
        order.forEachIndexed { index, i ->
            require(froms[i] <= tos[i])
            require(froms[i].toLong() + deltas[i] in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong())
            require(tos[i].toLong() + deltas[i] in Int.MIN_VALUE.toLong()..Int.MAX_VALUE.toLong())
            if (index > 0) require(tos[order[index - 1]] < froms[i])
        }
    }
}
