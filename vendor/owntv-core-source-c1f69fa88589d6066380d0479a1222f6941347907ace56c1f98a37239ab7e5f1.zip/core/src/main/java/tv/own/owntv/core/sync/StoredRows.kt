package tv.own.owntv.core.sync

/** One source/type/pass. Aliases share one row and contribute only once to occupancy. */
internal class StoredRows(initial: Map<String, StoredRow>) : AbstractMap<String, StoredRow>() {
    private val keysToIds = HashMap<String, Long>()
    private val rows = HashMap<Long, StoredRow>()
    private val insertedKeys = HashSet<String>()
    val occupied = HashMap<Int, Int>()

    init {
        initial.forEach { (key, row) -> keysToIds[key] = row.id; rows[row.id] = row }
        rows.values.forEach { occupy(it.sortOrder) }
    }
    override val size: Int get() = keysToIds.size
    override fun get(key: String): StoredRow? = keysToIds[key]?.let(rows::get)
    override fun containsKey(key: String): Boolean = keysToIds.containsKey(key)
    override val entries: Set<Map.Entry<String, StoredRow>> get() = keysToIds.map { (key, id) ->
        java.util.AbstractMap.SimpleImmutableEntry(key, rows.getValue(id))
    }.toSet()

    fun alias(now: String, was: String) { keysToIds[now] = keysToIds.getValue(was) }

    fun place(key: String, hash: Int, order: Int) {
        val id = keysToIds[key]
        if (id == null) {
            // @Insert(IGNORE) does not return row ids. Track the first insertion's occupancy only;
            // never invent an id or reposition an ignored duplicate in a later chunk.
            if (insertedKeys.add(key)) occupy(order)
            return
        }
        val old = rows.getValue(id)
        val count = occupied.getValue(old.sortOrder)
        if (count == 1) occupied.remove(old.sortOrder) else occupied[old.sortOrder] = count - 1
        rows[id] = StoredRow(id, hash, order)
        occupy(order)
    }
    fun occupy(order: Int) { occupied[order] = (occupied[order] ?: 0) + 1 }
}
