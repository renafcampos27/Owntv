package tv.own.owntv.core.player

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import tv.own.owntv.core.database.entity.SourceEntity
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Catalog evidence is replaceable and account-scoped; playback's observed refusals stay separate. */
object LiveSessionLimit {
    private data class Scope(val origin: String, val account: String?)
    private data class Entry(val scope: Scope, val single: Boolean)
    private val sources = ConcurrentHashMap<Long, Entry>()

    fun update(source: SourceEntity) {
        val url = source.url.toHttpUrlOrNull()
        if (url == null) { sources.remove(source.id); return }
        val account = source.username?.takeIf { it.isNotBlank() }?.let { digest(it, source.password.orEmpty()) }
        sources[source.id] = Entry(Scope(origin(url), account), source.maxConnections == 1)
    }

    fun isSingleSession(url: String): Boolean {
        val parsed = url.toHttpUrlOrNull() ?: return false
        val parts = parsed.pathSegments
        val kind = parts.indexOfLast { it in setOf("live", "movie", "series", "vod", "timeshift") }
        val credentials = when {
            kind >= 0 && kind + 2 < parts.size -> parts[kind + 1] to parts[kind + 2]
            parts.size == 3 && parts.last().substringBefore('.').toLongOrNull() != null -> parts[0] to parts[1]
            parsed.queryParameter("username") != null -> parsed.queryParameter("username")!! to parsed.queryParameter("password").orEmpty()
            else -> null
        }
        val account = credentials?.let { digest(it.first, it.second) }
        return sources.values.any { it.single && it.scope.origin == origin(parsed) &&
            (it.scope.account == null || it.scope.account == account) }
    }

    private fun origin(url: okhttp3.HttpUrl) = "${url.scheme}://${url.host}:${url.port}"
    private fun digest(user: String, password: String): String = MessageDigest.getInstance("SHA-256")
        .digest((user.length.toString() + ":" + user + password).toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
