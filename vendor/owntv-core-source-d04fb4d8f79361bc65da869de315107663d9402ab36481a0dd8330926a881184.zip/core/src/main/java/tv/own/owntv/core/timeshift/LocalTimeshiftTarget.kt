package tv.own.owntv.core.timeshift

/** Local presentation policy; never changes the shared recording parser or upstream playlist. */
internal object LocalTimeshiftTarget {
    fun roundedSeconds(durationMs: Long): Long =
        durationMs / 1000 + if (durationMs % 1000 >= 500) 1 else 0

    fun declared(text: String, maxDurationMs: Long): Long? {
        val value = text.lineSequence().map { it.trim() }
            .lastOrNull { it.startsWith("#EXT-X-TARGETDURATION:") }
            ?.substringAfter(':')?.toDoubleOrNull() ?: return null
        val upper = maxDurationMs / 1000 + if (maxDurationMs % 1000 > 0) 1 else 0
        return value.takeIf { it.isFinite() && it > 0 && it <= upper.toDouble() }
            ?.let { kotlin.math.ceil(it).toLong().coerceAtLeast(1) }
    }

    fun select(declared: Long?, durationsMs: Sequence<Long>, maxDurationMs: Long): Long =
        maxOf(declared ?: 1, durationsMs.filter { it in 1..maxDurationMs }
            .map(::roundedSeconds).maxOrNull() ?: 1)
}
