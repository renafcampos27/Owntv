package tv.own.owntv.core.timeshift

import java.io.InputStream
import java.io.PushbackInputStream

/** Check only active key-marked media, using the same TS acceptance as the existing final check. */
internal object LocalTimeshiftInput {
    fun plainTransport(input: InputStream, length: Long?, ensureActive: () -> Unit): InputStream {
        // A false AES tag on clear TS was already accepted; do not reject by tag alone.
        check(length == null || (length >= 188 && length % 188 == 0L))
        val replay = PushbackInputStream(input, 189)
        val prefix = ByteArray(189)
        var count = 0
        while (count < prefix.size) {
            ensureActive()
            val read = replay.read(prefix, count, prefix.size - count)
            if (read < 0) break
            check(read > 0)
            count += read
        }
        ensureActive()
        check(count >= 188 && prefix[0] == 0x47.toByte() && (count < 189 || prefix[188] == 0x47.toByte()))
        replay.unread(prefix, 0, count)
        return replay
    }
}
