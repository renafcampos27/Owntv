package tv.own.owntv.core.epg

import androidx.room.execSQL
import androidx.room.useWriterConnection
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import tv.own.owntv.core.database.ownTVTestDatabase
import tv.own.owntv.core.database.entity.EpgProgrammeEntity

/** Direct DAO transaction used by UP70-B; bundled driver, without the redundant outer transaction. */
@RunWith(AndroidJUnit4::class)
class EpgBatchTransactionTest {
    @Test fun committedBatchUpdatesNowNextGuideAndObserversEvenWhenCountDoesNotChange() = runBlocking {
        val db = ownTVTestDatabase()
        val updates = Channel<List<EpgProgrammeEntity>>(Channel.UNLIMITED)
        val collector = launch { db.epgDao().upcoming("c",0,10).collect { updates.send(it) } }
        try {
            withTimeout(5000) { assertTrue(updates.receive().isEmpty()) }
            val p = EpgProgrammeEntity(sourceId=1,epgChannelId="c",startMs=100,stopMs=200,title="Old")
            db.epgDao().upsertProgrammes(listOf(p,p.copy(startMs=200,stopMs=300,title="Next")))
            withTimeout(5000) { while (updates.receive().size != 2) { } }
            val current = db.epgDao().nowPlaying("c",150)!!
            db.epgDao().upsertProgrammes(listOf(current.copy(title="Changed",contentHash=33)))
            withTimeout(5000) { while (updates.receive().none { it.title == "Changed" }) { } }
            assertEquals("Changed",db.epgDao().nowPlaying("c",150)!!.title)
            assertEquals(listOf("Changed","Next"),db.epgDao().programmeSummariesForChannel("c",0,400).map { it.title })
            assertEquals(2,db.epgDao().countForSources(listOf(1)))
        } finally { collector.cancelAndJoin();updates.close();db.close() }
    }
    @Test fun aFailedRowRollsBackEarlierReplacementsAndNewRows() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            val p = EpgProgrammeEntity(sourceId=1,epgChannelId="c",startMs=100,stopMs=200,title="Original")
            db.epgDao().upsertProgrammes(listOf(p))
            db.useWriterConnection { it.execSQL("CREATE TRIGGER reject_bad BEFORE INSERT ON epg_programmes WHEN NEW.title='bad' BEGIN SELECT RAISE(ABORT,'rejected'); END") }
            assertTrue(runCatching { db.epgDao().upsertProgrammes(listOf(p.copy(title="Replaced"),p.copy(startMs=300,title="bad"))) }.isFailure)
            assertEquals("Original",db.epgDao().nowPlaying("c",150)!!.title)
            assertEquals(1,db.epgDao().countForSources(listOf(1)))
        } finally { db.close() }
    }
    @Test fun cancelledCallerDoesNotStartABatch() = runBlocking {
        val db = ownTVTestDatabase()
        try {
            val cancelled = Job().apply { cancel() }
            assertTrue(runCatching { withContext(cancelled) {
                db.epgDao().upsertProgrammes(listOf(EpgProgrammeEntity(sourceId=1,epgChannelId="c",startMs=100,stopMs=200,title="Cancelled")))
            } }.exceptionOrNull() is CancellationException)
            assertEquals(0,db.epgDao().countForSources(listOf(1)))
        } finally { db.close() }
    }
}
