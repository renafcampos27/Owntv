package tv.own.owntv.core.recording

/** Known requested-window loss only; unmeasured bytes are never presented as measured duration. */
internal object HlsCaptureCompleteness {
    fun missingWindow(
        capturedMs: Long, longestSegmentMs: Long, programmeStartMs: Long, programmeStopMs: Long,
        startedAtMs: Long, archive: Boolean, scheduledStartMs: Long,
    ): Boolean {
        val tolerance = longestSegmentMs.coerceIn(1_000L, 30_000L)
        return if (archive) {
            val intended = (programmeStopMs - programmeStartMs).coerceAtLeast(0)
            capturedMs > 0 && intended > capturedMs && intended - capturedMs > tolerance
        } else {
            // Record now only requests the rest of the programme. Pre-roll is optional.
            val requestedStart = maxOf(programmeStartMs, scheduledStartMs)
            val lateStart = startedAtMs > requestedStart && startedAtMs - requestedStart > tolerance
            val intended = (programmeStopMs - maxOf(startedAtMs, requestedStart)).coerceAtLeast(0L)
            lateStart || (capturedMs > 0 && intended > capturedMs && intended - capturedMs > tolerance)
        }
    }
}
