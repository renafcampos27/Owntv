package tv.own.owntv.core.epg

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.shareIn
import tv.own.owntv.core.database.entity.EpgChannelIcon
import tv.own.owntv.core.database.dao.EpgDao
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.settings.SettingsRepository

/**
 * "Use this guide's channel logos" (Settings → EPG Sources → add/edit a feed): channel logos taken from
 * an XMLTV feed's `<channel><icon src>` instead of the ones the playlist carries. Enabled **per EPG
 * source**, so one feed can supply logos while another only supplies programmes.
 *
 * Kept as a process-wide display override rather than being written into `channels.logoUrl` on purpose:
 * the provider logo stays untouched in the database, so turning a feed's toggle off restores it instantly
 * and a catalog re-sync (which REPLACE-upserts every channel row) can't wipe the user's choice.
 *
 * The map is Compose state, so flipping a toggle or finishing an EPG sync recomposes every logo on
 * screen. Nothing is loaded while no feed has it on — cold start stays free of EPG queries.
 */
object EpgLogoStore {

    /** Normalized EPG channel id → feed icon URL. Empty when no EPG source has logos enabled. */
    var icons by mutableStateOf<Map<String, String>>(emptyMap())
        private set

    /** Follow the enabled EPG sources; while any is enabled, follow their stored feed icons. */
    fun start(scope: CoroutineScope, settings: SettingsRepository, epgDao: EpgDao) =
        observeIcons(settings, epgDao).onEach { icons = it }.shareIn(scope, SharingStarted.Eagerly, replay = 1)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    fun observeIcons(settings: SettingsRepository, epgDao: EpgDao): Flow<Map<String, String>> =
        settings.epgUseLogos.distinctUntilChanged().flatMapLatest { ids ->
            if (ids.isEmpty()) flowOf(emptyMap())
            else epgDao.observeChannelIcons(ids.toList()).map(::preferredIcons)
        }.distinctUntilChanged()

    // Standalone feed IDs count down from -1. The DAO supplies the oldest enabled feed first.
    internal fun preferredIcons(rows: List<EpgChannelIcon>): Map<String, String> = buildMap {
        for (row in rows) {
            val key = row.epgChannelId.trim().lowercase()
            val url = row.iconUrl.trim()
            if (key.isNotEmpty() && url.isNotEmpty()) putIfAbsent(key, url)
        }
    }

    /** The feed icon for [epgChannelId], or null when there is none / no feed has logos enabled. */
    fun iconFor(epgChannelId: String?, available: Map<String, String> = icons): String? {
        if (available.isEmpty() || epgChannelId.isNullOrBlank()) return null
        return available[epgChannelId.trim().lowercase()]
    }
}

/**
 * The logo to show for this channel: the EPG feed's icon when "Prefer EPG logos" is on and the feed has
 * one, otherwise the provider's own logo. Use this everywhere a channel logo is displayed or handed to
 * the player — `logoUrl` alone always means "what the playlist said".
 */
val ChannelEntity.displayLogoUrl: String?
    get() = EpgLogoStore.iconFor(epgChannelId) ?: logoUrl
