package tv.own.owntv.core.epg

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import tv.own.owntv.core.database.entity.EpgChannelIcon

class EpgLogoStoreTest {
    @Test fun firstUsableFeedWinsAndRemovingItRevealsTheNext() {
        val primary = EpgChannelIcon("channel", " primary ")
        val secondary = EpgChannelIcon("CHANNEL", "secondary")
        val blank = EpgChannelIcon("channel", "  ")
        fun lookup(vararg rows: EpgChannelIcon) =
            EpgLogoStore.iconFor(" Channel ", EpgLogoStore.preferredIcons(rows.toList()))
        assertEquals("primary", lookup(blank, primary, secondary))
        assertEquals("secondary", lookup(blank, secondary))
        assertNull(lookup(blank))
        assertNull(lookup())
    }
}
