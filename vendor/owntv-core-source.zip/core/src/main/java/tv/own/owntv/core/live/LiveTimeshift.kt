package tv.own.owntv.core.live

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import tv.own.owntv.core.database.entity.ChannelEntity

/**
 * Live rewind / timeshift: watching a catch-up-capable channel some seconds behind the live edge,
 * out of the provider's rolling archive, and the "watching" clock that says which wall-clock instant
 * the picture actually belongs to.
 *
 * Split out of `LiveViewModel`, which was doing four jobs at once. The seam is deliberately narrow —
 * **offset in, archive load out**: this class owns how far back the user is, when to (re)load, and the
 * two counters that tick while an archive plays. It owns nothing about *how* a stream is opened: the
 * URL construction, the engine handover and `player.play` stay with the view model and arrive here as
 * [loadArchive]. The ladder and its outcome watcher are untouched by design.
 *
 * Everything time-related is injected ([nowMs], [coalesceMs], [tickMs]) and playback is read through
 * [Playback], so the sequencing is unit-testable without a player, a database or a view model.
 */
class LiveTimeshift(
    private val scope: CoroutineScope,
    private val playback: Playback,
    /** Open [ChannelEntity]'s archive starting at the given wall-clock instant. Returns false when the
     *  URL could not be built, or the user returned to live while it was being resolved. A false ends
     *  the rewind without silently selecting live — see [scheduleLoad]. */
    private val loadArchive: suspend (ChannelEntity, Long, Int) -> Boolean,
    /** Only an explicit forward scrub reaching the live edge selects the real-time stream. */
    private val onLiveEdge: () -> Unit,
    private val nowMs: () -> Long = { System.currentTimeMillis() },
    private val coalesceMs: Long = 350,
    private val tickMs: Long = 1_000,
    private val onUnavailable: () -> Unit = {},
) {

    /** The three things the counters need from whatever is playing. */
    interface Playback {
        val positionMs: Long
        val hasError: Boolean
        val hasActiveStream: Boolean
    }

    private val _offsetSec = MutableStateFlow<Int?>(null) // null = at the live edge; >0 = N s behind
    /** How far behind live the picture is, in seconds. Null while the live edge is on screen. */
    val offsetSec: StateFlow<Int?> = _offsetSec.asStateFlow()

    private val _watchingWallMs = MutableStateFlow<Long?>(null)
    /** The wall-clock instant on screen, for the HUD's second clock. Null when the picture IS the
     *  present (live edge, or a movie/episode). */
    val watchingWallMs: StateFlow<Long?> = _watchingWallMs.asStateFlow()

    /** True while the user is rewound — the guard that stops an engine swap re-tuning at the edge. */
    val isRewound: Boolean get() = _offsetSec.value != null

    private var loadJob: Job? = null
    private var tickJob: Job? = null

    /** A new tune invalidates a resolving archive without changing the current scrub offset. */
    fun cancelPendingLoad() { loadJob?.cancel(); loadJob = null }

    /** Wall-clock instant the loaded archive starts at. Both counters are derived from it plus the
     *  playback position, so one field serves the rewind and the guide catch-up paths alike. */
    private var archiveBaseWall: Long? = null

    /** How deep [ch]'s archive is, in seconds — the bound every jump and scrub is clamped to. */
    fun windowSec(ch: ChannelEntity): Int =
        // Capped: `catchup-days` comes from the playlist, and a silly value there overflowed the
        // seconds to a NEGATIVE window, which made beginAt's coerceIn(1, window) an empty range —
        // an IllegalArgumentException in the middle of tuning. A month of archive is already more
        // than any provider keeps.
        (ch.catchupDays.takeIf { it > 0 } ?: DEFAULT_CATCHUP_DAYS).coerceAtMost(MAX_CATCHUP_DAYS) * 24 * 3600

    /** Offsets worth offering for [ch], nearest first. Empty when the channel has no archive. */
    fun jumpOptions(ch: ChannelEntity): List<Int> =
        if (!ch.catchup) emptyList() else CatchupJumps.optionsFor(windowSec(ch))

    /**
     * Put [ch] at [offsetSec] behind live (absolute, not relative — this is aiming, so a second pick
     * from the "Go back to…" list must not stack on top of the first).
     */
    fun beginAt(ch: ChannelEntity, offsetSec: Int) {
        if (!ch.catchup) return
        val off = offsetSec.coerceIn(CatchupJumps.MIN_OFFSET_SEC, windowSec(ch))
        _offsetSec.value = off
        scheduleLoad(ch, nowMs() - off * 1000L)
    }

    /** An explicit clock selection must not drift or silently clamp to another programme. */
    fun beginAtInstant(ch: ChannelEntity, startMs: Long) {
        val ageMs = nowMs() - startMs
        if (!ch.catchup || ageMs < CatchupJumps.MIN_OFFSET_SEC * 1000L || ageMs > windowSec(ch) * 1000L) {
            clear()
            onUnavailable()
            return
        }
        val off = (ageMs / 1000L).toInt()
        _offsetSec.value = off
        scheduleLoad(ch, startMs)
    }

    /**
     * Move [deltaSec] further back (+) or toward live (−) — the rewind/forward buttons and the timeline
     * scrubber. Coalesced, so holding a key scrubs freely and loads the archive once at the final point;
     * reaching the live edge hands back to [onLiveEdge].
     */
    fun scrub(ch: ChannelEntity, deltaSec: Int) {
        if (!ch.catchup) return
        val requested = ((_offsetSec.value ?: 0).toLong() + deltaSec).coerceIn(0L, windowSec(ch).toLong()).toInt()
        val next = when {
            requested == 0 || requested >= CatchupJumps.MIN_OFFSET_SEC -> requested
            deltaSec < 0 -> 0
            else -> CatchupJumps.MIN_OFFSET_SEC
        }
        if (next == 0) { onLiveEdge(); return }
        _offsetSec.value = next
        scheduleLoad(ch, nowMs() - next * 1000L)
    }

    /**
     * Follow an archive that someone else already started — the guide catch-up path, which plays one
     * fixed programme rather than a rewind. The "behind live" offset stays null (a programme replay
     * keeps VOD chrome, not the live rewind chrome); only the watching clock runs.
     */
    fun followArchiveFrom(baseWall: Long) {
        loadJob?.cancel() // a fixed programme supersedes any rewind load still coalescing
        _offsetSec.value = null
        archiveBaseWall = baseWall
        startTick(rewinding = false)
    }

    /**
     * Drop every trace of a live rewind: the pending archive load, the counters and the offset the HUD
     * reads from.
     *
     * Anything that puts the channel back on a real-time stream has to call this. The rewind lives in
     * its own state, apart from tune state, so an engine change (compatibility mode, a ladder fallback)
     * would otherwise throw the user back to the live edge while the counter kept ticking upward
     * against a stream that was no longer the archive.
     */
    fun clear() {
        loadJob?.cancel()
        tickJob?.cancel()
        _offsetSec.value = null
        archiveBaseWall = null
        _watchingWallMs.value = null
    }

    private fun scheduleLoad(ch: ChannelEntity, startMs: Long) {
        loadJob?.cancel()
        tickJob?.cancel()
        archiveBaseWall = null
        _watchingWallMs.value = null
        loadJob = scope.launch {
            delay(coalesceMs) // coalesce rapid rewind/forward presses into one archive load
            val ageMs = nowMs() - startMs
            if (ageMs < CatchupJumps.MIN_OFFSET_SEC * 1000L || ageMs > windowSec(ch) * 1000L) {
                _offsetSec.value = null
                archiveBaseWall = null
                _watchingWallMs.value = null
                onUnavailable()
                return@launch
            }
            val opened = try {
                loadArchive(ch, startMs, (ageMs / 1000L).toInt())
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                false
            }
            currentCoroutineContext().ensureActive()
            if (!opened) {
                // Preserve user intent: a refused archive is not permission to tune live.
                if (_offsetSec.value != null) {
                    _offsetSec.value = null
                    archiveBaseWall = null
                    _watchingWallMs.value = null
                    onUnavailable()
                }
                return@launch
            }
            archiveBaseWall = startMs
            startTick(rewinding = true)
        }
    }

    /**
     * The one 1 Hz ticker (P-F2). There used to be two — one for the rewind counter, one for the
     * watching clock — and they were not exclusive: jumping into a rewind from a catch-up programme
     * left the clock's loop running alongside the new one, both writing the same value every second.
     *
     * Both counters read the same two inputs (the archive's start instant and the playback position),
     * so one loop serves both. [rewinding] is the only difference and it is small: a rewind also
     * recomputes "behind live", and treats a failed archive as the end of the rewind rather than just
     * the end of the clock.
     */
    private fun startTick(rewinding: Boolean) {
        tickJob?.cancel()
        tickJob = scope.launch {
            // The catch-up path paints its clock straight away; the rewind path already has an offset
            // on screen from the caller, and its first honest reading needs a position to exist.
            if (!rewinding) emitWatching()
            while (true) {
                delay(tickMs)
                if (archiveBaseWall == null) break
                if (rewinding && _offsetSec.value == null) break
                // The archive failed. For a rewind that ends the rewind outright: leaving the offset set
                // kept the rewind UI (and its "behind live" figure) alive over an error screen.
                if (playback.hasError) {
                    if (rewinding) clear() else _watchingWallMs.value = null
                    break
                }
                // The stream is gone entirely (player stopped, another item took over). Stop ticking, but
                // a rewind keeps its offset — a reload in flight still counts as the same rewind.
                if (!playback.hasActiveStream) {
                    if (!rewinding) _watchingWallMs.value = null
                    break
                }
                if (rewinding) {
                    // offset = realNow − watched time = realNow − (archive start + playback position).
                    // Pausing makes it grow: you fall further behind.
                    val base = archiveBaseWall ?: break
                    val behindSec = (nowMs() - (base + playback.positionMs)) / 1000
                    _offsetSec.value = behindSec.toInt().coerceAtLeast(0)
                }
                emitWatching()
            }
        }
    }

    private fun emitWatching() {
        _watchingWallMs.value = archiveBaseWall?.let { it + playback.positionMs }
    }
}
