package tv.own.owntv.core.epg

import java.util.SimpleTimeZone
import java.util.TimeZone
import tv.own.owntv.core.database.entity.SourceEntity

/** Source offset is a UTC timezone offset, never an extra programme/request shift. */
object CatchupClock {
    fun resolve(source: SourceEntity, fallback: TimeZone): TimeZone = when (source.catchupTimezone) {
        tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.DEVICE.name -> TimeZone.getDefault()
        tv.own.owntv.core.settings.SettingsRepository.CatchupTimezone.MANUAL.name -> source.catchupOffsetMin?.takeIf { it in -720..840 }
            ?.let { SimpleTimeZone(it * 60_000, "catchup-source") } ?: fallback
        else -> fallback
    }
}
