package tv.own.owntv.core.epg

import java.net.URI
import java.net.URLEncoder
import tv.own.owntv.core.database.entity.ChannelEntity
import tv.own.owntv.core.database.entity.SourceEntity

/** Pure resolution of provider-declared archive templates; no probing or inferred extra formats. */
object ArchiveTemplateResolver {
    private val token = Regex("\\$?\\{([A-Za-z_][A-Za-z0-9_-]*)\\}")
    private val startTokens = setOf("start", "utc", "timestamp", "start-timestamp", "utcstart")
    private val endTokens = setOf("end", "utcend", "end-timestamp", "stop", "duration")

    fun resolve(
        baseUrl: String?, mode: CatchupFormat, channel: ChannelEntity, source: SourceEntity,
        startMs: Long, endMs: Long, configs: List<ArchivePlaybackConfig>,
    ): ResolvedArchiveSource? {
        if (endMs <= startMs || channel.sourceId != source.id) return null
        val addresses = linkedSetOf<String>()
        // Provider-resolved addresses retain their existing authentication/encoding semantics.
        // Strict template validation applies only to the new manually configured alternatives.
        baseUrl?.takeIf(String::isNotBlank)?.let { addresses.addAll(CatchupFormats.candidates(it, mode)) }
        val manifestTypes = linkedMapOf<String, String>()
        ArchivePlaybackConfig.resolve(configs, channel)?.let { config ->
            config.templates.take(ArchivePlaybackConfig.MAX_TEMPLATES).forEach { template ->
                resolveTemplate(template, channel, source, startMs, endMs)?.let { url ->
                    addresses.add(url)
                    config.manifestType?.takeIf { it == "hls" || it == "mpd" }?.let { manifestTypes[url] = it }
                }
            }
        }
        val ordered = addresses.take(6)
        val initial = ordered.firstOrNull() ?: return null
        return ResolvedArchiveSource(initial, ordered.drop(1), manifestTypes.filterKeys { it in ordered })
    }

    private fun resolveTemplate(
        template: String, channel: ChannelEntity, source: SourceEntity, startMs: Long, endMs: Long,
    ): String? {
        if (!ArchivePlaybackConfig.isValidTemplate(template)) return null
        val tokens = token.findAll(template).map { it.groupValues[1] }.toSet()
        val normalized = tokens.map(String::lowercase).toSet()
        val hasStart = normalized.any { it in startTokens } || tokens.containsAll(setOf("Y", "m", "d", "H", "M"))
        if (!hasStart || normalized.none { it in endTokens }) return null
        var missing = false
        val withCredentials = token.replace(template) { match ->
            val value = when (match.groupValues[1].lowercase()) {
                "streamid" -> channel.remoteId
                "username" -> source.username
                "password" -> source.password
                else -> return@replace match.value
            }
            if (value.isNullOrBlank()) { missing = true; match.value }
            else URLEncoder.encode(value, "UTF-8").replace("+", "%20")
        }
        if (missing) return null
        val result = CatchupUrl.fromTemplate(withCredentials, startMs, endMs)
        if ('{' in result || '}' in result) return null
        return result.takeIf(::validAddress)
    }

    private fun validAddress(value: String): Boolean = runCatching {
        val uri = URI(value)
        uri.scheme?.lowercase() in setOf("http", "https") && !uri.host.isNullOrBlank() &&
            uri.userInfo == null && uri.fragment == null && value.none(Char::isWhitespace)
    }.getOrDefault(false)
}
