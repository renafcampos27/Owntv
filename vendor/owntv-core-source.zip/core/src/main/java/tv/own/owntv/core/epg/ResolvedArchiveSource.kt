package tv.own.owntv.core.epg

/** Ordered addresses for one archive interval. Never log or render these credential-bearing URLs. */
data class ResolvedArchiveSource(
    val url: String,
    val alternatives: List<String>,
    val manifestTypes: Map<String, String>,
)
